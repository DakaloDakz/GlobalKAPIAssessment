import static groovy.io.FileType.*

@NonCPS
def getSuiteName(xmlfile) {
    def xml = new XmlParser()
    xml.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false)
    xml.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
    def fs = xml.parse(xmlfile)

    return fs.@name
}


@NonCPS
def getXmlFiles() {
    def files = []
    new File("${workspace}").traverse(type: FILES, maxDepth: 0) {
        def fileName = it.getName()
        if (fileName.substring(fileName.lastIndexOf(".") + 1) == "xml" && fileName != "pom.xml") {
            files.add(it.getName().toString())
        }
    }
    return files
}

return this