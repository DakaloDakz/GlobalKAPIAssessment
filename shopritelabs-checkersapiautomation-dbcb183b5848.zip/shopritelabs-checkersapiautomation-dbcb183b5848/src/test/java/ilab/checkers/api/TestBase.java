package ilab.checkers.api;

import atu.alm.wrapper.ITestCaseRun;
import ilab.checkers.models.ApiControllerModel;
import ilab.checkers.models.QCModel;
import ilab.checkers.utilities.DataHelpers;
import ilab.checkers.utilities.FilePathHandler;
import ilab.checkers.utilities.GoogleUtils.GoogleDriveUtil;
import ilab.checkers.utilities.TestDataCreator;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Logger;

public class TestBase {

    public static String appUrl;
    public static String dslUrl;
    public static String commerceUrl;
    public static String foxUrl;
    public static String ciamUrl;
    public static String updateQC;
    public static ArrayList<QCModel> arrli;
    DataHelpers dataHelpers = new DataHelpers();
    public ApiFlowExecution apiFlowExecution;
    public final ThreadLocal<HashMap<String, ApiControllerModel>> testCaseArray = new ThreadLocal<>();
    public Logger streamLogger;
    public static boolean isALMExecuted;
    public static Properties prop;
    public static ITestCaseRun myrun;
    public static final ThreadLocal<Logger> LOGGER = ThreadLocal.withInitial(() -> Logger.getLogger(TestBase.class.getName()));

    @Parameters({"excelData", "spreadsheet_id", "appURL", "dslURL", "commerceURL", "foxURL", "ciamURL", "brand", "updateQC"})
    @BeforeClass
    public void initializeTestBaseSetup(String excelData, @Optional String spreadsheet_id, @Optional String appURL, @Optional String dslURL, @Optional String commerceURL, @Optional String foxURL, @Optional String ciamURL, @Optional String brand, @Optional String updateQC, ITestContext context) throws IOException, GeneralSecurityException {
        System.out.println(spreadsheet_id);
        System.out.println(brand);
        context.setAttribute("brand", brand);
        String status = "online";
        streamLogger = LOGGER.get();

        if(spreadsheet_id != null) {
            String pathname = FilePathHandler.GetTargetFolderPath() + excelData;
            GoogleDriveUtil.downloadByID(spreadsheet_id, pathname);
            status = "online";
        } else {
            status = "offline";
        }
        try {
            testCaseArray.set(new TestDataCreator().CreateArrayFromExcel(status, excelData, "Controller"));
            apiFlowExecution = new ApiFlowExecution();
            appUrl = appURL;
            dslUrl = dslURL;
            foxUrl = foxURL;
            ciamUrl = ciamURL;
            commerceUrl = commerceURL;
        } catch (Exception e) {
            System.out.println("Error....." + Arrays.toString(e.getStackTrace()));
        }
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        arrli = null;
    }
}