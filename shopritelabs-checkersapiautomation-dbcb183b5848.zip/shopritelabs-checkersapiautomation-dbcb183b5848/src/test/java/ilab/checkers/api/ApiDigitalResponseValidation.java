package ilab.checkers.api;

public class ApiDigitalResponseValidation {
}
