package ilab.checkers.models;

import java.util.ArrayList;

public class ApiControllerModel {

    public String SprintName;
    public String TestSetPath;
    public String TestSetName;
    public String TestSetID;
    public String TestName;
    public String Execute;
    public ArrayList<ApiActionsModel> ApiActions;

}
