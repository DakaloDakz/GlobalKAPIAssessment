package ilab.checkers.models;

public class QCModel {

    public String TestSetPath;
    public String TestSetName;
    public String TestSetID;
    public String TestcaseID;
    public String testFlow2;

}
