package ilab.checkers.models;

public class APICombined {
    public ApiActionsModel apiActionsModel;
    public ApiControllerModel apiControllerModel;
}
