package ilab.checkers.models;

import org.apache.poi.ss.usermodel.Sheet;

import java.util.HashMap;
import java.util.Map;

public class ApiActionsModel {

    public String TestCaseID;
    public String ExecuteScenario;
    public String Scenario;
    public String EndPoint;
    public String Resource;
    public String Parameter;
    public String UserName;
    public String PassWord;
    public String Method;
    public String WebServiceType;
    public String format;
    public String ContentType;
    public String SOAPAction;
    public String PAYLOAD;
    public String Users;
    public String UpdateData;
    public String Validation;
    public String DataToUpdate;
    public String DataToValidate;
    public String MissingFields;
    public String Expected;
    public String IdTokenReq;
    public String AccessTokenReq;
    public String SaveResponseValues;
    public String SaveRequestValues;
    public String UseContextValue;
    public String BearerTokenReq;


    public String FOX;
    public String CIAM;
    public String isArray;
    public String isDate;

    public String ValidationStatus;
    public String JSONValidationResponse;
    public String ValidationResults;
    public String Actual;
    public String Status;
    public String Response;


    public int RowNumber;
    public Sheet ScenarioSheet;
    public HashMap<Object, Object> ReplacementMap = new HashMap<>();
}
