package ilab.checkers.reporting;

import com.aventstack.extentreports.AnalysisStrategy;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;
import com.aventstack.extentreports.reporter.configuration.ViewStyle;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentManager {
    private static ExtentReports extent;
    private static final String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date());
    private static final String reportFileName = "Test-Automaton-Report.html";
    private static final String fileSeparator = System.getProperty("file.separator");
    private static final String reportFilepath = System.getProperty("user.dir") + fileSeparator + "TestReport";
    private static final String reportFileLocation = reportFilepath + fileSeparator + reportFileName;


    public static ExtentReports getInstance() {
        if (extent == null)
            extent = createInstance();
        return extent;
    }

    //Create an extent report instance
    private static ExtentReports createInstance() {
        String fileName = getReportPath();

        ExtentSparkReporter sparkFail = new ExtentSparkReporter(reportFilepath + fileSeparator + "Test-Automaton-Fail-Report.html").filter()
                .statusFilter()
                .as(new Status[] { Status.FAIL })
                .apply();
        ExtentSparkReporter spark = new ExtentSparkReporter(fileName).viewConfigurer().viewOrder().as(new ViewName[]{ViewName.DASHBOARD, ViewName.TEST}).apply();
        spark.config().setTheme(Theme.STANDARD);
        spark.config().setDocumentTitle(reportFileName);
        spark.config().setReportName("<h2><b>CHECKERS/SHOPRITE</b> API Automation</h2>");
        spark.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
        spark.config().setEncoding("utf-8");

        ExtentReports extent = new ExtentReports();
        extent.attachReporter(spark, sparkFail);

        return extent;
    }

    //Create the report path
    private static String getReportPath() {
        File testDirectory = new File(ExtentManager.reportFilepath);
        if (!testDirectory.exists()) {
            if (testDirectory.mkdir()) {
                System.out.println("Directory: " + ExtentManager.reportFilepath + " is created!");
                return reportFileLocation;
            } else {
                System.out.println("Failed to create directory: " + ExtentManager.reportFilepath);
                return System.getProperty("user.dir");
            }
        } else {
            System.out.println("Directory already exists: " + ExtentManager.reportFilepath);
        }
        return reportFileLocation;
    }

}