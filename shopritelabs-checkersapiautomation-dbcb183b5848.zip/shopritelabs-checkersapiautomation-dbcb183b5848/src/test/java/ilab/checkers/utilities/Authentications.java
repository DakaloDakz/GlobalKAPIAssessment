package ilab.checkers.utilities;

import com.aventstack.extentreports.ExtentTest;
import okhttp3.*;
import okhttp3.logging.HttpLoggingInterceptor;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.Properties;

import static org.apache.log4j.helpers.UtilLoggingLevel.FINE;

public class Authentications {
    ExtentTest extentTestCase;

    final static Logger logger = Logger.getLogger(Authentications.class);
    static DataHelpers dataHelpers = new DataHelpers();
    static Properties prop;

    static {
        try {
            prop = dataHelpers.ReadPropertiesFile("environment.properties");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Authentications(ExtentTest extentTC) throws IOException{
        Logger.getLogger(OkHttpClient.class.getName()).setLevel(FINE);
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor(logger::debug);
        interceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
        extentTestCase = extentTC;
    }

    public static String setapikey(String RequestUrl, String Password) throws IOException, ParseException {
        String apikeyvalue = null;
        // TODO Move tokens to config files
        if (RequestUrl.toLowerCase().contains(prop.getProperty("dslQAUrl")) && Password.toLowerCase().equals("auth_oidc")) {
            apikeyvalue = prop.getProperty("dslQAApiKey");
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslPrepUrl")) && Password.toLowerCase().equals("auth_oidc")) {
            apikeyvalue = prop.getProperty("dslPrepApiKey");
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslQAUrl")) && Password.toLowerCase().equals("auth_cognito")) {
            apikeyvalue = prop.getProperty("dslQAApiKey");
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslPrepUrl")) && Password.toLowerCase().equals("auth_cognito")) {
            apikeyvalue = prop.getProperty("dslPrepApiKey");
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslQAUrl")) && Password.toLowerCase().equals("auth_otp")) {
            apikeyvalue = prop.getProperty("dslQAApiKey");
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslPrepUrl")) && Password.toLowerCase().equals("auth_otp")) {
            apikeyvalue = prop.getProperty("dslPrepApiKey");
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslQAUrl")) && Password.toLowerCase().equals("auth_yonder")) {
            apikeyvalue = "x/A?D(G+KbPeShVmYp3s6v9y$B&E)H@McQfTjWnZr4t7w!z%C*F-JaNdRgUkXp2s";
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("ciamQAUrl")) && Password.toLowerCase().equals("auth_ciam")) {
            apikeyvalue = prop.getProperty("ciamQAApiKey");
        }  else if (RequestUrl.toLowerCase().contains(prop.getProperty("ciamPrepUrl")) && Password.toLowerCase().equals("auth_ciam")) {
            apikeyvalue = prop.getProperty("ciamPrepApiKey");
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("ciamQAUrl")) && Password.toLowerCase().equals("ciam_sixty60")) {
            apikeyvalue = "63bUvviVvj6uwlFJnFeB82rvq5WUmV1w9jGWhMO6";
        }  else if (RequestUrl.toLowerCase().contains(prop.getProperty("ciamPrepUrl")) && Password.toLowerCase().equals("ciam_sixty60")) {
            apikeyvalue = "jBojEUo1QZ1Lin4cpu7FC3LaVIZqhTck8rYfcD8P";
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslQAUrl")) && Password.toLowerCase().equals("invalidtoken")) {
            apikeyvalue = "BjPWvvF2Vr5BcW1iPw2hD4VVV";
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslPrepUrl")) && Password.toLowerCase().equals("invalidtoken")) {
            apikeyvalue = "K85RaNLMSg6MQ9SLBBD6De";
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslQAUrl")) && Password.toLowerCase().equals("blanktoken")) {
            apikeyvalue = "";
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslPrepUrl")) && Password.toLowerCase().equals("blanktoken")) {
            apikeyvalue = "";
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslPrepUrl")) && Password.isEmpty()) {
            apikeyvalue = prop.getProperty("dslPrepApiKey");
        } else if (RequestUrl.toLowerCase().contains(prop.getProperty("dslQAUrl")) && Password.isEmpty()) {
            apikeyvalue = prop.getProperty("dslQAApiKey");
        } else if (RequestUrl.toLowerCase().contains(".amazonaws.com") && Password.isEmpty()) {
            apikeyvalue = String.valueOf(Authentications.no_dsl_calls(RequestUrl));
        } else if(!Password.isEmpty()){
            apikeyvalue = Password;
        } else {
//            apikey = "";
            apikeyvalue = "";
        }

        return apikeyvalue;
    }

    public Authentications() {

    }

    /**
     * Implementation to get OIDC Access Tokens
     *
     * @param RequestUrl
     * @param sLoginCred
     * @return
     * @throws IOException
     */

    public String[] authenticate_using_oidc(String RequestUrl, String sLoginCred) throws IOException {
        String hostName = null;
        RequestBody bodyLogin;
        String[] sLoginCreds = sLoginCred.split("\\|");
        String bodyContent;
        String[] responseBody = new String[2];
        if (RequestUrl.toLowerCase().contains("qa")) {
            hostName = "rewardsauth.qa.shopritelabs.co.za";
        } else if (RequestUrl.toLowerCase().contains("prep")) {
            hostName = "rewardsauth.prep.shopritelabs.co.za";
        } else {
            hostName = "auth.checkers.co.za";
        }
        OkHttpClient.Builder okhttpClientBuilder = new OkHttpClient.Builder();
        okhttpClientBuilder.connectTimeout(60, TimeUnit.SECONDS) // connect timeout
                .writeTimeout(60, TimeUnit.SECONDS) // write timeout
                .readTimeout(60, TimeUnit.SECONDS); // read timeout
        okhttpClientBuilder.followRedirects(true);

        OkHttpClient client = okhttpClientBuilder
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
        Request request = new Request.Builder()
                .url("https://" + hostName + "/authorizationserver/oauth/authorize?scope=openid&response_type=code%20id_token&client_id=occOpenId&redirect_url=https://" + hostName + "/shopritewebservices/v2&state=10810")
                .method("GET", null)
                .build();
        Response response = client.newCall(request).execute();
        response.close();

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");

        if (sLoginCreds[0].toLowerCase().contains("#27")) {
            String replaceLeadingInt = sLoginCreds[0].replace("#27", "%2B27");
            String replaceLeadingZero = replaceLeadingInt.replace("%2B27", "0");
            bodyContent = "username=" + replaceLeadingInt + "&email=&mobileNumberLogin=" + replaceLeadingZero + "&password=" + sLoginCreds[1];
            bodyLogin = RequestBody.create(mediaType, bodyContent);
        } else {
            bodyContent = "username=" + sLoginCreds[0] + "&password=" + sLoginCreds[1];
            bodyLogin = RequestBody.create(mediaType, bodyContent);
        }

        Request request2 = new Request.Builder()
                .url("https://" + hostName + "/authorizationserver/login.do")
                .method("POST", bodyLogin)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .build();
        Response response2 = client.newCall(request2).execute();

        List<String> loginCookieList = response2.headers().values("Set-Cookie");

        // Assigns only the cookie values to fields: AWSALB
        String loginJsessionIdcookie = (loginCookieList.get(0).split(";"))[0];
        // Assigns only the cookie values to fields: AWSALBCORS
        String loginAWSALBCORS = (loginCookieList.get(1).split(";"))[0];
        // Assigns only the cookie values to fields: JSESSIONID
        String loginJSESSIONID = (loginCookieList.get(2).split(";"))[0];

        Request request3 = new Request.Builder()
                .url("https://" + hostName + "/authorizationserver/oauth/authorize?scope=openid&response_type=code%20id_token&client_id=occOpenId&redirect_url=https://" + hostName + "/shopritewebservices/v2&state=10810")
                .method("GET", null)
                .addHeader("Cookie", loginJsessionIdcookie)
                .addHeader("Cookie", loginAWSALBCORS)
                .addHeader("Cookie", loginJSESSIONID)
                .build();
        client.newCall(request3).execute();

        RequestBody bodyAuthorization = RequestBody.create(mediaType, "user_oauth_approval=true");
        Request request4 = new Request.Builder()
                .url("https://" + hostName + "/authorizationserver/oauth/authorize")
                .method("POST", bodyAuthorization)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Cookie", loginJsessionIdcookie)
                .addHeader("Cookie", loginAWSALBCORS)
                .addHeader("Cookie", loginJSESSIONID)
                .build();
        Response response4 = client.newCall(request4).execute();

        String location = response4.header("location");

        String code = StringUtils.substringBetween(location, "code=", "&state");

        String occAuthUserName = "occOpenId";
        String occAuthPassword = "secret";

        String credential = Base64.getEncoder().encodeToString((occAuthUserName + ":" + occAuthPassword).getBytes(StandardCharsets.UTF_8));

        Headers.Builder builder = new Headers.Builder();
        builder.add("Content-Type", "text/plain");
        builder.add("Authorization", "Basic " + credential);

        Headers headers = builder.build();

        RequestBody oAuthTokenBody = RequestBody.create(mediaType, "grant_type=authorization_code&code=" + code + "&redirect_url=https://" + hostName + "/shopritewebservices/v2");
        Request oAuthTokenRequest = new Request.Builder()
                .url("https://" + hostName + "/authorizationserver/oauth/token")
                .method("POST", oAuthTokenBody)
                .headers(headers)
                .build();

        response.close();
        response2.close();
        response4.close();
        try (Response responseBleh = client.newCall(oAuthTokenRequest).execute()) {
            responseBody[1] = Integer.toString(responseBleh.code());
            responseBody[0] = Objects.requireNonNull(responseBleh.body()).string();
        }
        return responseBody;
    }


    public String[] authenticate_using_mobile(String RequestUrl, String sLoginCred) throws IOException, IOException {
        /**/
        String hostName;
        String replaceLeadingInt = null;
        String replaceLeadingZero = null;
        String[] sLoginCreds = sLoginCred.split("\\|");
        String[] responseBody = new String[2];
        if (sLoginCreds[0].toLowerCase().contains("#27")) {
            replaceLeadingInt = sLoginCreds[0].replace("#27", "%2B27");
            replaceLeadingZero = replaceLeadingInt.replace("%2B27", "0");
        }

        if (RequestUrl.toLowerCase().contains("qa")) {
            hostName = "https://rewardsapi.qa.shopritelabs.co.za";
        } else if (RequestUrl.toLowerCase().contains("prep")) {
            hostName = "https://rewardsapi.prep.shopritelabs.co.za";
        } else {
            hostName = "https://api.checkers.co.za";
        }

        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();


        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url(hostName + "/shopriteauthorizationserver/oauth/token?grant_type=mobile&client_id=mobileClient&client_secret=secret&username=" + replaceLeadingInt + "&scope=openid")
                .method("POST", body)
                .build();
        try (Response response = client.newCall(request).execute()) {
            responseBody[1] = Integer.toString(response.code());
            responseBody[0] = Objects.requireNonNull(response.body()).string();
        }
        return responseBody;
    }

    /**
     * Implementation to get Cognito Access Tokens
     *
     * @param RequestUrl
     * @return
     * @throws IOException
     * @throws ParseException
     */

    public String[] dsl_cognito_test(String RequestUrl) throws IOException, ParseException {
        String auth_url;
        String clientId = "";
        String clientSecret = "";
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");

        if (RequestUrl.toLowerCase().contains("qa")) {
            auth_url = "https://dslqa.auth.eu-west-1.amazoncognito.com/oauth2/token";
            clientId = "4vqg8o5a5tbe39pla4j7rhuspk";
            clientSecret = "oe47kvn0e2a1orutl71p5islki0urd1h4vlb2p2u1t9knp8j8c6";
        } else if (RequestUrl.toLowerCase().contains("prep")) {
            auth_url = "https://dslprep.auth.eu-west-1.amazoncognito.com/oauth2/token";
            clientId = "5mrissc65hq5rglluonivrnq9s";
            clientSecret = "am8itqm5iah9dpj5ch38cm1faiiuedrtk0hlrtcnfcajkcmv2np";
        } else {
            auth_url = "CptL4ip1BM8ONePVWxWIt3ABUPplJLUq8aegn9Af";
        }

        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();

        String credential = Base64.getEncoder().encodeToString((clientId + ":" + clientSecret).getBytes(StandardCharsets.UTF_8));

        Headers.Builder builder = new Headers.Builder();
        builder.add("Content-Type", "text/plain");
        builder.add("Authorization", "Basic " + credential);

        Headers headers = builder.build();

        RequestBody oAuthTokenBody = RequestBody.create(mediaType, "grant_type=client_credentials&scope=");
        Request oAuthTokenRequest = new Request.Builder()
                .url(auth_url)
                .method("POST", oAuthTokenBody)
                .headers(headers)
                .build();

        String[] responseBody = new String[2];
        try (Response responseBleh = client.newCall(oAuthTokenRequest).execute()) {
            responseBody[1] = Integer.toString(responseBleh.code());
            responseBody[0] = Objects.requireNonNull(responseBleh.body()).string();
        }
        return responseBody;
    }

    public String[] authenticate_using_mm(String RequestUrl) throws IOException, ParseException {
        String hostName;

        if (RequestUrl.toLowerCase().contains("qa")) {
            hostName = "https://rewardsapi.qa.shopritelabs.co.za";
        } else if (RequestUrl.toLowerCase().contains("prep")) {
            hostName = "https://rewardsapi.prep.shopritelabs.co.za";
        } else {
            hostName = "https://api.checkers.co.za";
        }

        String occAuthUserName = "moneyMarketClient";
        String occAuthPassword = "secret";
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");

        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();

        String credential = Base64.getEncoder().encodeToString((occAuthUserName + ":" + occAuthPassword).getBytes(StandardCharsets.UTF_8));

        Headers.Builder builder = new Headers.Builder();
        builder.add("Content-Type", "text/plain");
        builder.add("Authorization", "Basic " + credential);

        Headers headers = builder.build();

        RequestBody oAuthTokenBody = RequestBody.create(mediaType, "grant_type=client_credentials&scope=");
        Request oAuthTokenRequest = new Request.Builder()
                .url(hostName + "/authorizationserver/oauth/token")
                .method("POST", oAuthTokenBody)
                .headers(headers)
                .build();
        String[] responseBody = new String[2];
        try (Response responseBleh = client.newCall(oAuthTokenRequest).execute()) {
            responseBody[1] = Integer.toString(responseBleh.code());
            responseBody[0] = Objects.requireNonNull(responseBleh.body()).string();
        }
        return responseBody;
    }

    public static String[] no_dsl_calls(String RequestUrl) throws IOException, ParseException {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();

        Headers.Builder builder = new Headers.Builder();
        builder.add("Content-Type", "text/plain");

        Headers headers = builder.build();
        Request request = new Request.Builder()
                .url(RequestUrl)
                .build();

        String[] responseBody = new String[2];
        try (Response responseBleh = client.newCall(request).execute()) {
            responseBody[1] = Integer.toString(responseBleh.code());
            responseBody[0] = Objects.requireNonNull(responseBleh.body()).string().replace("\"", "");
        }
        return responseBody;
    }

    /**
     * Implementation to get Commerce Access Tokens
     *
     * @param RequestUrl
     * @return
     * @throws IOException
     * @throws ParseException
     */

    public String[] authenticate_using_commerce(String RequestUrl) throws IOException, ParseException {
        String hostName;
        if (RequestUrl.toLowerCase().contains("qa")) {
            hostName = "https://rewardsapi.qa.shopritelabs.co.za";
        } else if (RequestUrl.toLowerCase().contains("prep")) {
            hostName = "https://rewardsapi.prep.shopritelabs.co.za";
        } else {
            hostName = "https://api.checkers.co.za";
        }

        String occAuthUserName = "qaClient";
        String occAuthPassword = "secret";
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");

        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();

        String credential = Base64.getEncoder().encodeToString((occAuthUserName + ":" + occAuthPassword).getBytes(StandardCharsets.UTF_8));

        Headers.Builder builder = new Headers.Builder();
        builder.add("Content-Type", "text/plain");
        builder.add("Authorization", "Basic " + credential);

        Headers headers = builder.build();

        RequestBody oAuthTokenBody = RequestBody.create(mediaType, "grant_type=client_credentials&scope=");
        Request commerceRequest = new Request.Builder()
                .url(hostName + "/authorizationserver/oauth/token")
                .method("POST", oAuthTokenBody)
                .headers(headers)
                .build();
        String[] responseBody = new String[2];
        try (Response responseBleh = client.newCall(commerceRequest).execute()) {
            responseBody[1] = Integer.toString(responseBleh.code());
            responseBody[0] = Objects.requireNonNull(responseBleh.body()).string();
        }
        return responseBody;
    }

    public String[] get_otp_reference(String RequestUrl, String mobileNumber) throws IOException, ParseException {
        String hostName;
        String access_token;
        String api_key = "";
        JSONParser parser = new JSONParser();

        String[] responseBody = new String[2];
        String[] response = new String[0];
        if (RequestUrl.toLowerCase().contains("qa")) {
            hostName = "https://api.qa.shopritelabs.co.za";
            api_key = "BjPWvvF2Vr5BcW1iPw2hD4VVVBefrFem1sra63RH";
            response = dsl_cognito_test("rewardsauth.qa.shopritelabs.co.za");
        } else if (RequestUrl.toLowerCase().contains("prep")) {
            hostName = "https://api.prep.shopritelabs.co.za";
            api_key = "K85RaNLMSg6MQ9SLBBD6DeNrW0tQONctZh5C8kb0";
            response = dsl_cognito_test("rewardsauth.prep.shopritelabs.co.za");
        } else {
            hostName = "https://api.checkers.co.za";
        }
        JSONObject jsonObject = (JSONObject) parser.parse(response[0]);
        access_token = (String) jsonObject.get("access_token");
        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();

        Headers.Builder builder = new Headers.Builder();
        builder.add("Content-Type", "application/json");
        builder.add("Authorization", "Bearer " + access_token);
        builder.add("x-api-key", api_key);

        Headers headers = builder.build();
        Request referenceRequest = new Request.Builder()
                .url(hostName + "/dsl/brands/checkers/countries/za/users/loginbymobile?mobileNumber=" + mobileNumber)
                .headers(headers)
                .build();
        try {
            CountDownLatch countDownLatch = new CountDownLatch(1);

            client.newCall(referenceRequest).enqueue(new Callback() {

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    responseBody[1] = Integer.toString(response.code());
                    responseBody[0] = Objects.requireNonNull(response.body()).string();
                    countDownLatch.countDown();
                }

                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    logger.error("Failed to connect: " + e.getMessage());
                    countDownLatch.countDown();
                }
            });
            countDownLatch.await();

        } catch (Exception ex) {
            extentTestCase.info("<br/><b>Exception Returned:</b><br/>" + ex.toString());
            ex.printStackTrace();
        }
        return responseBody;
    }

    public String[] get_otp(String reference) throws IOException, ParseException {
        String[] responseBody = new String[2];
        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();

        Request otpRequest = new Request.Builder()
                .url("https://m73lrxwau3.execute-api.eu-west-1.amazonaws.com/dev/getotp?reference=" + reference)
                .header("Content-Type", "application/json")
                .build();

        try {
            CountDownLatch countDownLatch = new CountDownLatch(1);

            client.newCall(otpRequest).enqueue(new Callback() {

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    responseBody[1] = Integer.toString(response.code());
                    responseBody[0] = Objects.requireNonNull(response.body()).string();
                    countDownLatch.countDown();
                }

                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    logger.error("Failed to connect: " + e.getMessage());
                    countDownLatch.countDown();
                }
            });
            countDownLatch.await();

        } catch (Exception ex) {
            extentTestCase.info("<br/><b>Exception Returned:</b><br/>" + ex.toString());
            ex.printStackTrace();
        }
        return responseBody;
    }

    public String[] authenticate_via_otp(ExtentTest extentTestCase, String RequestUrl, String mobileNumber) throws IOException, ParseException, InterruptedException {
        int count = 0;
        int maxTries = 3;
        String[] responseBody = new String[2];
        while (true) {
            System.out.println("Attempting to get Token: " + count);
            try {
                if (mobileNumber.toLowerCase().contains("#27")) {
                    mobileNumber = mobileNumber.replace("#27", "+27");
                }
                JSONParser parser = new JSONParser();
                String reference;
                String otp;
                String[] responseReference = get_otp_reference(RequestUrl, mobileNumber);
                extentTestCase.info(Arrays.toString(responseReference));
                JSONObject reference_json = (JSONObject) parser.parse(responseReference[0]);
                JSONObject resp = (JSONObject) reference_json.get("response");
                reference = (String) resp.get("reference");

                String[] responseOTP = get_otp(reference);
                if (!responseOTP[0].replaceAll("^\"|\"$", "").equals("null")) {
                    otp = responseOTP[0].substring(1, 5).replaceAll("^\"|\"$", "");
                } else {
                    otp = null;
                }

                String hostName;
                String access_token;
                String api_key = null;
                String[] response = new String[0];

                if (RequestUrl.toLowerCase().contains("qa")) {
                    hostName = "https://api.qa.shopritelabs.co.za";
                    api_key = "BjPWvvF2Vr5BcW1iPw2hD4VVVBefrFem1sra63RH";
                    response = dsl_cognito_test("rewardsauth.qa.shopritelabs.co.za");
                } else if (RequestUrl.toLowerCase().contains("prep")) {
                    hostName = "https://api.prep.shopritelabs.co.za";
                    api_key = "K85RaNLMSg6MQ9SLBBD6DeNrW0tQONctZh5C8kb0";
                    response = dsl_cognito_test("rewardsauth.prep.shopritelabs.co.za");
                } else {
                    hostName = "https://api.checkers.co.za";
                }
                JSONObject jsonObject = (JSONObject) parser.parse(response[0]);
                access_token = (String) jsonObject.get("access_token");

                MediaType mediaType = MediaType.parse("application/json");
                OkHttpClient.Builder okhttpClientBuilder = new OkHttpClient.Builder();
                okhttpClientBuilder.connectTimeout(60, TimeUnit.SECONDS) // connect timeout
                        .writeTimeout(60, TimeUnit.SECONDS) // write timeout
                        .readTimeout(60, TimeUnit.SECONDS); // read timeout
                okhttpClientBuilder.followRedirects(true);

                OkHttpClient client = okhttpClientBuilder
                        .followRedirects(false)
                        .followSslRedirects(false)
                        .build();

                Headers.Builder builder = new Headers.Builder();
                builder.add("Content-Type", "application/json");
                builder.add("Authorization", "Bearer " + access_token);
                builder.add("x-api-key", api_key);

                Headers headers = builder.build();

                RequestBody oAuthTokenBody = RequestBody.create(mediaType, "{\n" +
                        "  \"otp\": \"" + otp + "\",\n" +
                        "  \"target\": {\n" +
                        "    \"reference\": \"" + reference + "\",\n" +
                        "    \"identifier\": \"" + mobileNumber + "\",\n" +
                        "    \"type\": \"SMS\"\n" +
                        "  }\n" +
                        "}");
                Request oAuthTokenRequest = new Request.Builder()
                        .url(hostName + "/dsl/brands/checkers/countries/za/otp/loginbymobile/verify")
                        .method("POST", oAuthTokenBody)
                        .headers(headers)
                        .build();

                try (Response responseBleh = client.newCall(oAuthTokenRequest).execute()) {
                    responseBody[1] = Integer.toString(responseBleh.code());
                    responseBody[0] = Objects.requireNonNull(responseBleh.body()).string();
                }
                return responseBody;
            } catch (Exception ex) {
                if (++count == maxTries) throw ex;
                ex.printStackTrace();
            }
        }
    }

    @Test
    public static void otp() throws IOException, ParseException, InterruptedException {

    }

}
