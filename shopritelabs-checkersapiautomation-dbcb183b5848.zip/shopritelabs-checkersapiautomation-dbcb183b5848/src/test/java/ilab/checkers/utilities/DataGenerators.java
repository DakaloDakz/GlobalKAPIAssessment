package ilab.checkers.utilities;

import com.github.javafaker.Faker;
import com.github.javafaker.service.FakeValuesService;
import com.github.javafaker.service.RandomService;
import ilab.checkers.datahelpers.IdNumberValidator;
import org.apache.commons.lang3.RandomStringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ilab.checkers.api.TestBase.dslUrl;
import static java.util.Calendar.*;
import static java.util.Calendar.DATE;

public class DataGenerators {
    private FakeValuesService fakeValuesService;
    private Faker faker;
    private String currentEmail;
    private String currentCellNumber;
    private String firstName;
    private String lastName;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public DataGenerators() {
        fakeValuesService = new FakeValuesService(new Locale("en-ZA"), new RandomService());
        faker = new Faker(new Locale("en-ZA"));
    }

    public static Calendar getCalendar(Date date) {
        Calendar cal = Calendar.getInstance(Locale.US);
        cal.setTime(date);
        return cal;
    }

    private String GenerateSACellNumber(Boolean valid) {
        String saCellNumber;
        if (valid) {
            while (true) {
                saCellNumber = fakeValuesService.regexify("[156789][0-9]{8}");
                Pattern pattern = Pattern.compile("[156789][0-9]{8}");
                Matcher matcher = pattern.matcher(saCellNumber);
                if (matcher.matches()) {
                    break;
                }
            }
        } else {
            while (true) {
                saCellNumber = fakeValuesService.bothify("##########");
                Pattern pattern = Pattern.compile("[156789][0-9]{8}");
                Matcher matcher = pattern.matcher(saCellNumber);
                if (!matcher.matches()) {
                    break;
                }
            }
        }
        return "+27"+saCellNumber;
    }

    public String ReadDataJson(String xmlPath) throws IOException, ParseException {
        File f1 = null;
        FileReader fr = null;

        JSONParser parser = new JSONParser();
        try {
            f1 = new File(xmlPath);
            fr = new FileReader(f1);
            Object obj = parser.parse(fr);
            JSONObject jsonObject = (JSONObject) obj;
            // System.out.print(jsonObject);
            return jsonObject.toString();
        } finally {
            try {
                ArrayList<String> lines = new ArrayList<>();
                lines.clear();
                Objects.requireNonNull(fr).close();

                // out.close();

            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }

    }

    /**
     * Generates random SA ID number using regex expression
     * Checks is valid, citizen, older than 18 years old
     * @return 7712315046081
     */
    public String GenerateValidSAIdNumber() {
        IdNumberValidator idNumberValidator = new IdNumberValidator();
        String idNumber;
        while (true) {
            IdNumberValidator.IDNumberDetails idNumberDetails;
            do {
                idNumber = fakeValuesService.regexify(
                        "(((\\d{2}((0[13578]|1[02])(0[1-9]|[13]\\d|3[01])|(0[13456789]|1[012])(0[1-9]|[12]\\d|30)|02(0[1-9]|1\\d|2[0-8])))|([02468][048]|[13579][26])0229))((\\d{4})(\\d{3})|(\\d{7}))");
                idNumberDetails = idNumberValidator.extractInformation(idNumber);
            } while (!idNumberDetails.isValid() || !idNumberDetails.isCitizen());
            Date idBirthday = idNumberDetails.getBirthDate();
            Date dateNow = new Date(System.currentTimeMillis());
            Calendar a = getCalendar(idBirthday);
            Calendar b = getCalendar(dateNow);
            int diff = b.get(YEAR) - a.get(YEAR);
            if (a.get(MONTH) > b.get(MONTH) ||
                    (a.get(MONTH) == b.get(MONTH) && a.get(DATE) > b.get(DATE))) {
                diff--;
            }
            if (diff > 18) break;
        }
        return idNumber;
    }

    public String GenerateRequiredData(String dataTypeRequired) throws Exception {
        String requiredData = null;
        firstName = faker.name().firstName();
        lastName = faker.name().lastName();
        switch (dataTypeRequired.toUpperCase()) {
            case "GENERATED NAME":
                requiredData = firstName;
                break;
            case "GENERATED LASTNAME":
                requiredData = lastName;
                break;
            case "GENERATED EMAIL":
                requiredData = firstName + faker.number().digits(10) + "@ilabsuccessfactors.co.za";
                currentEmail = requiredData;
                break;
            case "GENERATED - USE EMAIL":
                requiredData = currentEmail;
                break;
            case "GENERATED CELL NUMBER":
                requiredData = GenerateSACellNumber(true);
                currentCellNumber = requiredData;
                break;
            case "GENERATED - USE CELL NUMBER":
                requiredData = currentCellNumber;
                break;
            case "GENERATED IDNUMBER":
                requiredData = GenerateValidSAIdNumber();
                break;
            case "GENERATED NUMBER - 10":
                requiredData = faker.number().digits(10).replace('0', '1');
                break;
            case "GENERATED TIMESTAMP":
                requiredData = new Timestamp(System.currentTimeMillis()).toString();
                break;
            case "GENERATED ALPHANUMERIC":
                requiredData = faker.bothify("??abc???");
                break;
            case "GENERATED UUID":
                requiredData = UUID.randomUUID().toString();
                break;
            case "GENERATED CREATIONDATE":
                requiredData = sdf.format(new Date());
                break;
            case "GENERATED DATE OF BIRTH":
                Random rndYears = new Random();
                SimpleDateFormat dateFor = new SimpleDateFormat("yyyy-MM-dd");
                int yearsToSubtract = rndYears.nextInt(70) + 18;
                Date dateNow = new Date(System.currentTimeMillis());
                String stringDate = dateFor.format(dateNow);
                String stringDayMonth = stringDate.substring(5, stringDate.length() - 3);
                String currentYear = stringDate.substring(0, stringDate.length() - 6);
                int yearOfBirth = (Integer.parseInt(currentYear) - yearsToSubtract);
                requiredData =  yearOfBirth+"-"+stringDayMonth+"-"+stringDayMonth;
                break;
            case "GENERATED DOB":
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                Date date = new Date();

                // Convert Date to Calendar
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);

                // Perform addition/subtraction
                cal.add(Calendar.YEAR, -35);
                cal.add(Calendar.MONTH, 1);
                cal.add(Calendar.DATE, -10);
                cal.add(Calendar.HOUR, -4);
                cal.add(Calendar.MINUTE, 30);
                cal.add(Calendar.SECOND, 50);

                // Convert calendar back to Date
                Date currentDatePlusOne = cal.getTime();

                requiredData =  dateFormat.format(currentDatePlusOne);
                System.out.println(">>>>>" + requiredData);
                break;
            case "GENERATED DOB UNDER 18":
                SimpleDateFormat dateFormats = new SimpleDateFormat("dd/MM/yyyy");
                Date dates = new Date();

                // Convert Date to Calendar
                Calendar cals = Calendar.getInstance();
                cals.setTime(dates);

                // Perform addition/subtraction
                cals.add(Calendar.YEAR, -10);
                cals.add(Calendar.MONTH, 1);
                cals.add(Calendar.DATE, -10);
                cals.add(Calendar.HOUR, -4);
                cals.add(Calendar.MINUTE, 30);
                cals.add(Calendar.SECOND, 50);

                // Convert calendar back to Date
                Date currentDatePlusOnes = cals.getTime();

                requiredData =  dateFormats.format(currentDatePlusOnes);
                System.out.println(">>>>>" + requiredData);
                break;
            case "GENERATED HYBRID ID":
                String number = faker.number().digits(5);
                String c = RandomStringUtils.randomAlphabetic(4).toUpperCase();
                requiredData = number + c;
                break;
            case "GET CARD CHECKERS - MARK USED":
            case "GET CARD CHECKERS":
//                requiredData = GetCardService.getCardFromSoapWebService("checkers", dslUrl);
                requiredData = new GetCardService(dslUrl).getCard("checkers");
                break;
            case "GET CARD SHOPRITE - MARK USED":
            case "GENERATED CURRENT DATE":
//              DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                Date dateobj = new Date();
                System.out.println(df.format(dateobj));
                requiredData = df.format(dateobj);
                break;
            case "GET CARD SHOPRITE":
//                requiredData = GetCardService.getCardFromSoapWebService("shoprite", dslUrl);
                requiredData = new GetCardService(dslUrl).getCard("shoprite");
                break;
        }
        return requiredData;
    }

    public JSONArray generateCIAMUserJson(int numberOfUsers){
        DataGenerators genData = new DataGenerators();
        JSONParser parser = new JSONParser();
        JSONArray array = new JSONArray();
        try {
            JSONObject data = (JSONObject) parser.parse(new FileReader(FilePathHandler.GetResourceFolderPath() + File.separator + "JSON-Body-Models" + File.separator + "ciam_migrate.json"));

            for (int i = 0; i < numberOfUsers; i++) {
                String dataN = data.toString()
                        .replace("{{$randomFirstName}}", genData.GenerateRequiredData("GENERATED NAME"))
                        .replace("{{$randomLastName}}", genData.GenerateRequiredData("GENERATED LASTNAME"))
                        .replace("{{$randomBankAccount}}", genData.GenerateRequiredData("GENERATED NUMBER - 10"))
                        .replace("{{$randomEmail}}", genData.GenerateRequiredData("GENERATED EMAIL"))
                        .replace("{{timestamp}}", genData.GenerateRequiredData("GENERATED TIMESTAMP"))
                        .replace("{{$randomAlphaNumeric}}", genData.GenerateRequiredData("GENERATED ALPHANUMERIC"));
                array.add(parser.parse(dataN));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return array;
    }

    public JSONObject generateDSLUserJson() throws Exception {
        DataGenerators genData = new DataGenerators();
        JSONParser parser = new JSONParser();
        JSONObject jsonObject;
            JSONObject obj = (JSONObject) parser.parse(new FileReader(FilePathHandler.GetResourceFolderPath() + File.separator + "JSON-Body-Models" + File.separator + "dsl_user.json"));
            String updatedJson = obj.toString()
                        .replace("{{BirthDate}}", "31/12/1975")
                        .replace("{{firstName}}", genData.GenerateRequiredData("GENERATED NAME"))
                        .replace("{{lastName}}", genData.GenerateRequiredData("GENERATED LASTNAME"))
                        .replace("{{MobileNumber}}", genData.GenerateRequiredData("GENERATED CELL NUMBER"))
                        .replace("{{Passport}}", genData.GenerateRequiredData("GENERATED NUMBER - 10"))
                        .replace("{{Password}}", Base64.getEncoder().encodeToString(genData.GenerateRequiredData("GENERATED NUMBER - 10").getBytes()))
                        .replace("{{PreferredStoreId}}", "2701")
                        .replace("{{titleCode}}", "mr")
                        .replace("{{email}}", genData.GenerateRequiredData("GENERATED EMAIL"));
            jsonObject = (JSONObject) parser.parse(updatedJson);
        return jsonObject;
    }
}
