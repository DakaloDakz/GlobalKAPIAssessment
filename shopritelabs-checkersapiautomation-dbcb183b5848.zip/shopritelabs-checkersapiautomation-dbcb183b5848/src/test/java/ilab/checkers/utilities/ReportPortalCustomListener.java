package ilab.checkers.utilities;

import com.epam.reportportal.listeners.ListenerParameters;
import com.epam.reportportal.service.Launch;
import com.epam.reportportal.service.ReportPortal;
import com.epam.reportportal.testng.BaseTestNGListener;
import com.epam.reportportal.testng.TestNGService;
import com.epam.reportportal.utils.properties.PropertiesLoader;
import com.epam.ta.reportportal.ws.model.launch.StartLaunchRQ;
import org.testng.ITestResult;
import org.testng.util.Strings;
import rp.com.google.common.base.Supplier;

import java.util.Calendar;

public class ReportPortalCustomListener extends BaseTestNGListener {

    public ReportPortalCustomListener() {
        super(new ParamOverrideTestNgService());
    }
}

class ParamOverrideTestNgService extends TestNGService {
    public ParamOverrideTestNgService() {
        super(getLaunchOverriddenProperties());
    }

    private static Supplier<Launch> getLaunchOverriddenProperties() {
        ListenerParameters parameters = new ListenerParameters(PropertiesLoader.load());
//        String reportPortalUuid = System.getenv("reportportal_uuid").trim();
//        parameters.setApiKey(reportPortalUuid);
        ReportPortal reportPortal = ReportPortal.builder().withParameters(parameters).build();
        StartLaunchRQ rq = buildStartLaunch(reportPortal.getParameters());
        return () -> reportPortal.newLaunch(rq);
    }

    private static StartLaunchRQ buildStartLaunch(ListenerParameters parameters) {
        StartLaunchRQ rq = new StartLaunchRQ();
        rq.setName(parameters.getLaunchName());
        rq.setStartTime(Calendar.getInstance().getTime());
        rq.setAttributes(parameters.getAttributes());
        rq.setMode(parameters.getLaunchRunningMode());
        if (!Strings.isNullOrEmpty(parameters.getDescription())) {
            rq.setDescription(parameters.getDescription());
        }
        return rq;
    }

    @Override
    protected String createStepName(ITestResult testResult) {
        return testResult.getName();
    }

}