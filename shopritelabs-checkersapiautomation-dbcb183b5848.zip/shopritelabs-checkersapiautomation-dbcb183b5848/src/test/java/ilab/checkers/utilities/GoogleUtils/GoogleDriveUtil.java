package ilab.checkers.utilities.GoogleUtils;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.drive.Drive;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;


public class GoogleDriveUtil {
    private static final String APPLICATION_NAME = "Google Sheets Example";
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

    private static HttpRequestInitializer setHttpTimeout(final HttpRequestInitializer requestInitializer) {
        return httpRequest -> {
            requestInitializer.initialize(httpRequest);
            httpRequest.setConnectTimeout(3 * 60000);  // 3 minutes connect timeout
            httpRequest.setReadTimeout(3 * 60000);  // 3 minutes read timeout
        };
    }

    private static Drive googleDriveService() throws IOException, GeneralSecurityException {
        Credential credential = GoogleAuthorizeUtil.authorize();
        return new Drive.Builder(GoogleNetHttpTransport.newTrustedTransport(), JSON_FACTORY, setHttpTimeout(credential))
                .setApplicationName(APPLICATION_NAME)
                .build();
    }

    public static void download(String fileId, String filePathAndName, String type) throws IOException, GeneralSecurityException {
        try (OutputStream outputStream = new FileOutputStream(new java.io.File(filePathAndName))) {
            googleDriveService().files().export(fileId, type)
                    .executeMediaAndDownloadTo(outputStream);
        }
    }

    public static void downloadByID(String fileId, String filePathAndName) throws IOException, GeneralSecurityException {
        try (OutputStream outputStream = new FileOutputStream(new java.io.File(filePathAndName))) {
            googleDriveService().files().get(fileId)
                    .executeMediaAndDownloadTo(outputStream);
        }
    }
}
