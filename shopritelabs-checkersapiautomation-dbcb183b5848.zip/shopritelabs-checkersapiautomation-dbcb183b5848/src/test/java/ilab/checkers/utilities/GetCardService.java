package ilab.checkers.utilities;


import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.ValueRange;
import ilab.checkers.utilities.GoogleUtils.GoogleSheetsServiceUtil;
import okhttp3.*;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.IOException;
import java.io.StringReader;
import java.net.InetAddress;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class GetCardService {
    private static Sheets sheetsService;
    private final String url;

    public GetCardService(String url) {
        this.url = url;
    }

    static {
        try {
            sheetsService = GoogleSheetsServiceUtil.getSheetsService();
        } catch (IOException | GeneralSecurityException e) {
            e.printStackTrace();
        }
    }

    public String getCard(String brand) throws Exception {
        String cardNum;
        if (this.url.contains("qa") || this.url.contains("prep")){
            cardNum = getCardFromSheet(brand, true);
            if (cardNum.isEmpty()){
                cardNum = getCardFromSoapWebService(brand, this.url);
            }
        }else {
            cardNum = getCardFromSheet(brand, true);
        }
        return cardNum;
    }


    private static String getCardFromSheet(String brand, Boolean markAsUsed) throws IOException {
        String SPREADSHEET_ID = "1SP567f5gTc2YGnYp3vBXLq67O-i612dDUA-rtk6EXIE";
        String name = InetAddress.getLocalHost().getHostName();
        ValueRange response = new ValueRange();
        try {
            if (brand.equalsIgnoreCase("shoprite")) {
                response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, "QA | Shoprite!A2:C")
                        .execute();
            }
            if (brand.equalsIgnoreCase("checkers")) {
                response = sheetsService.spreadsheets().values()
                        .get(SPREADSHEET_ID, "QA | Checkers!A2:C")
                        .execute();
            }
        } catch (GoogleJsonResponseException e) {
            System.out.println(e.getDetails().getMessage());
        }

        List<List<Object>> values = response.getValues();
        String cardNum = "";
        if (values != null) {
            for (int i = 0; i < values.size(); i++) {
                if (values.get(i).size() == 1) {
                    if (markAsUsed) {
                        ValueRange body = new ValueRange()
                                .setValues(Collections.singletonList(Arrays.asList(values.get(i).get(0), "Used By Automation on " + name)));
                        sheetsService.spreadsheets().values()
                                .update(SPREADSHEET_ID, "QA | " + brand + "!A" + (i + 2), body)
                                .setValueInputOption("RAW")
                                .execute();
                    }
                    cardNum = values.get(i).get(0).toString();
                    break;
                }
            }
            return cardNum;
        } else {
            return "NO CARDS AVAILABLE IN GOOGLE SHEET";
        }
    }

    private static String getCardServiceSessionKey(String env) throws Exception {
        String url = "";

        if (env.toLowerCase().contains("qa")) {
            url = "http://lprqaweb3.qa.shoprite.co.za/HQCoreWS/Authorization/Login.asmx";
        }
        if (env.toLowerCase().contains("prep")) {
            url = "http://ilb-lpr-int-web01.shopint.co.za/HQCoreWS/Authorization/Login.asmx";
        }
        String soapBody = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:hql=\"http://www.retalix.com/HQLWebServices\">\n" +
                "   <soapenv:Header/>\n" +
                "   <soapenv:Body>\n" +
                "      <hql:UserLogin>\n" +
                "         <!--Optional:-->\n" +
                "         <hql:in_UserName>SAPCommerce</hql:in_UserName>\n" +
                "         <!--Optional:-->\n" +
                "         <hql:in_Password>$@P(omM3rcE</hql:in_Password>\n" +
                "      </hql:UserLogin>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";

        RequestBody body = RequestBody.create(MediaType.parse("text/xml"), soapBody);

        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "text/xml")
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        String[] responseBody = new String[2];
        responseBody[1] = Integer.toString(response.code());
        responseBody[0] = Objects.requireNonNull(response.body()).string();

        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(responseBody[0]));
        Document doc = builder.parse(src);
        response.close();
        return doc.getElementsByTagName("out_SessionKey").item(0).getTextContent();
    }

    public static String getBulkCardFromSoapWebService(String brand, String env) throws Exception {
//        try {
        String url = "";
        String binRange = "";
        if (brand.equalsIgnoreCase("shoprite")) {
            binRange = "97100851";
        }
        if (brand.equalsIgnoreCase("checkers")) {
            binRange = "97100842";
        }
        if (env.toLowerCase().contains("qa")) {
            url = "http://lprqaweb3.qa.shoprite.co.za/XtraSavingsCards/XtraSavingsCards.svc";
        }
        if (env.toLowerCase().contains("prep")) {
            url = "http://lprintweb1.shopint.co.za/XtraSavingsCards/XtraSavingsCards.svc";
        }
        String session_key = getCardServiceSessionKey(env);
        String xml = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">\n" +
                "   <soapenv:Header/>\n" +
                "   <soapenv:Body>\n" +
                "      <tem:CreateNumbersToResults>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:sessionKey>" + session_key + "</tem:sessionKey>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:binRange>" + binRange + "</tem:binRange>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:minRange>2005</tem:minRange>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:maxRange>3000</tem:maxRange>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:unAssignedOnly>true</tem:unAssignedOnly>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:includeHeader>true</tem:includeHeader>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:delimiter>|</tem:delimiter>\n" +
                "      </tem:CreateNumbersToResults>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";

        RequestBody body = RequestBody.create(MediaType.parse("text/xml"), xml);
        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "text/xml")
                .addHeader("SOAPAction", "http://tempuri.org/IXtraSavingsCards/CreateNumbersToResults")
                .post(body)
                .build();
        System.out.println(request);
        Response response = client.newCall(request).execute();
        String[] responseBody = new String[2];
        responseBody[1] = Integer.toString(response.code());
        responseBody[0] = Objects.requireNonNull(response.body()).string();
        System.out.println(responseBody[1]);
        System.out.println(responseBody[0]);
        if (responseBody[1].equals("200")) {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            InputSource src = new InputSource();
            src.setCharacterStream(new StringReader(responseBody[0]));
            Document doc = builder.parse(src);
            String cardString = doc.getElementsByTagName("CreateNextNumberResult").item(0).getTextContent();
            String[] cardNumber = cardString.split("\\|");
            return cardNumber[0];
        } else {
            return "Service UNAVAILABLE - Status Code " + responseBody[1];
        }

//        } catch (Exception ex) {
//            return "CARD SERVICE NOT AVAILABLE";
//        }
    }

    public static String getCardFromSoapWebService(String brand, String env) throws Exception {
        String url = "";
        String binRange = "";
        if (brand.equalsIgnoreCase("shoprite")) {
            binRange = "97100851";
        }
        if (brand.equalsIgnoreCase("checkers")) {
            binRange = "97100843";
        }
        if (env.toLowerCase().contains("qa")) {
            url = "http://lprqaweb3.qa.shoprite.co.za/XtraSavingsCards/XtraSavingsCards.svc";
        }
        if (env.toLowerCase().contains("prep")) {
            url = "http://lprintweb1.shopint.co.za/XtraSavingsCards/XtraSavingsCards.svc";
        }
        String session_key = getCardServiceSessionKey(env);
        String xml = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">\n" +
                "   <soapenv:Header/>\n" +
                "   <soapenv:Body>\n" +
                "      <tem:CreateNextAutomatedNumber>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:sessionKey>" + session_key + "</tem:sessionKey>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:binRange>" + binRange + "</tem:binRange>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:lastNumber></tem:lastNumber>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:unAssignedOnly>true</tem:unAssignedOnly>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:includeHeader>true</tem:includeHeader>\n" +
                "         <!--Optional:-->\n" +
                "         <tem:delimiter>|</tem:delimiter>\n" +
                "      </tem:CreateNextAutomatedNumber>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";

        RequestBody body = RequestBody.create(MediaType.parse("text/xml"), xml);
        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "text/xml")
                .addHeader("SOAPAction", "http://tempuri.org/IXtraSavingsCards/CreateNextAutomatedNumber")
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        String[] responseBody = new String[2];
        responseBody[1] = Integer.toString(response.code());
        responseBody[0] = Objects.requireNonNull(response.body()).string();
        if (responseBody[1].equals("200")) {
            System.out.println(Arrays.toString(responseBody));
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            InputSource src = new InputSource();
            src.setCharacterStream(new StringReader(responseBody[0]));
            Document doc = builder.parse(src);
            String cardString = doc.getElementsByTagName("CreateNextAutomatedNumberResult").item(0).getTextContent();
            String[] cardNumber = cardString.split("\\|");
            return cardNumber[0];
        } else {
            return "Service UNAVAILABLE - Status Code " + responseBody[1];
        }
    }

    @Test()
    public void testCardGenerator() throws Exception {
//        String card = GetCardService.getBulkCardFromSoapWebService("checkers", "qa");
        String card = GetCardService.getCardFromSoapWebService("checkers", "qa");
        System.out.println(card);
    }
}
