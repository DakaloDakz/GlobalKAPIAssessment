package ilab.checkers.utilities;

import com.aventstack.extentreports.ExtentTest;
import com.epam.reportportal.service.ReportPortal;
import org.json.simple.parser.ParseException;
import org.testng.ITestContext;
import org.testng.asserts.SoftAssert;

import java.util.*;

import static ilab.checkers.api.TestBase.*;

public class ValidationHelpers {
    private final DataHelpers dataHelpers;
    private final DataGenerators dataGenerators;

    public ValidationHelpers() {
        dataHelpers = new DataHelpers();
        dataGenerators = new DataGenerators();
    }

    public String setCombinedUrl(String endPoint, String resource, String parameter, ITestContext context, ExtentTest extentTestCase) throws Exception {
        String combinedUrl = "";
        try {
            String cardNum;
            DataGenerators dataGenerators = new DataGenerators();
            if (endPoint.equalsIgnoreCase("") || endPoint.equalsIgnoreCase("dsl")) {
                combinedUrl = dslUrl + resource + Objects.toString(parameter, "");
            } else if (endPoint.equalsIgnoreCase("commerce")) {
                combinedUrl = commerceUrl + resource + Objects.toString(parameter, "");
            } else if (endPoint.equalsIgnoreCase("ciam")) {
                combinedUrl = ciamUrl + resource + Objects.toString(parameter, "");
            } else if (endPoint.equalsIgnoreCase("fox")) {
                combinedUrl = foxUrl + resource + Objects.toString(parameter, "");
            } else {
                combinedUrl = endPoint + resource + Objects.toString(parameter, "");
            }
            if (combinedUrl.contains("{{brand}}")) {
                combinedUrl = combinedUrl.replace("{{brand}}", context.getAttribute("brand").toString());
            }
            if (combinedUrl.contains("{{GET CARD CHECKERS}}")) {
                cardNum = GetCardService.getCardFromSoapWebService("checkers", endPoint);
                combinedUrl = combinedUrl.replace("{{GET CARD CHECKERS}}", cardNum);
                context.setAttribute("CH_CARDNUMBER", cardNum);
            }
            if (combinedUrl.contains("{{GET CARD SHOPRITE}}")) {
                cardNum = GetCardService.getCardFromSoapWebService("shoprite", endPoint);
                combinedUrl = combinedUrl.replace("{{GET CARD SHOPRITE}}", cardNum);
                context.setAttribute("SH_CARDNUMBER", cardNum);
            }
            if (combinedUrl.contains("{{GENERATE_SAID}}")) {
                String ID = dataGenerators.GenerateValidSAIdNumber();
                combinedUrl = combinedUrl.replace("{{GENERATE_SAID}}", ID);
                context.setAttribute("IDNUMBER", ID);
            }
            if (combinedUrl.equals("{{emailC4C}}")) {
                String val = ReplaceWithContextValue("{{emailC4C}}", context, extentTestCase);
                combinedUrl = combinedUrl.replace("{{emailC4C}}", val);
            }
            if (combinedUrl.equals("{{emailDup}}")) {
                String val = ReplaceWithContextValue("{{emailDup}}", context, extentTestCase);
                combinedUrl = combinedUrl.replace("{{emailDup}}", val);
            }
            if (combinedUrl.contains("{{mobileNumberC4C}}")) {
                String val = ReplaceWithContextValue("{{mobileNumberC4C}}", context, extentTestCase);
                String mobilec4c = val.replace("+", "");
                combinedUrl = combinedUrl.replace("{{mobileNumberC4C}}", mobilec4c);
            }
            if (combinedUrl.equals("{{email}}")) {
                String val = ReplaceWithContextValue("{{email}}", context, extentTestCase);
                combinedUrl = combinedUrl.replace("{{email}}", val.toLowerCase());
            }
            if (combinedUrl.equals("{{uid}}")) {
                String val = ReplaceWithContextValue("{{uid}}", context, extentTestCase);
                combinedUrl = combinedUrl.replace("{{uid}}", val.toLowerCase());
            }
            if (combinedUrl.contains("{{randomMobileNumber}}")) {
                String mobile = dataGenerators.GenerateRequiredData("GENERATED CELL NUMBER");
                combinedUrl = combinedUrl.replace("{{randomMobileNumber}}", mobile);
                context.setAttribute("voucherMobileNumber", mobile);
            }
            if (combinedUrl.contains("{{voucherMobileNumber}}")) {
                combinedUrl = combinedUrl.replace("{{voucherMobileNumber}}", context.getAttribute("voucherMobileNumber").toString());
            }
        } catch (Exception ex) {
            System.out.println(ex.toString());
            extentTestCase.info("<br/><b>Exception Thrown:</b><br/>" + ex.getMessage());
        }
        return combinedUrl;
    }

    public String ReplaceWithContextValue(String toReplace, ITestContext context, ExtentTest extentTestCase) {
        String val = "";
        String ctx = null;
        try {
            ctx = toReplace.replace("{{", "").replace("}}", "");

            val = context.getAttribute(ctx).toString();
            if (ctx.toLowerCase().equals("email")) {
                val = val.toLowerCase();
            }
            if (ctx.toLowerCase().equals("uuid")) {
                val = val.toUpperCase();
            }
        } catch (Exception ex) {
            extentTestCase.info("<br/><b>Exception Thrown:</b><br/>" + "Did not find in "+ctx+"JSON. Please check if you JsonPath is correct!");
        }
        return val;
    }

    public void SaveRequestValues(String jsonReplaced, ITestContext context, ExtentTest extentTestCase, String saveRequestValues) {
        try {
            String[] valuesToSave = saveRequestValues.replace("\n", "").split(",");
            for (String value : valuesToSave) {
                String[] kv = value.split(":");
                if (kv[1].equals(".")) {
                    context.setAttribute(kv[0], jsonReplaced);
                }
                List<Map<String, Object>> jsonValue = dataHelpers.getValuesFromJson(jsonReplaced, kv[1]);
                context.setAttribute(kv[0], jsonValue.get(0));
                extentTestCase.info("<br/><b>Response Values saved to context:</b><br/>" + kv[0] + "<br/><b>Response Path:</b><br/>" + kv[1] + "<br/><b>Response Value:</b><br/>" + jsonValue);
            }
        } catch (Exception ex) {
            extentTestCase.info("<br/><b>Exception Thrown:</b><br/>" + ex.getMessage());
        }
    }

    public void SaveResponseValues(String json, ITestContext context, ExtentTest extentTestCase, String saveResponseValues) {
        try {
            String[] valuesToSave = saveResponseValues.replace("\n", "").split(",");
            for (String value : valuesToSave) {
                String[] kv = value.split(":");
                if (kv[1].equals(".")) {
                    context.setAttribute(kv[0], json);
                } else {
                    List<Map<String, Object>> jsonValue = dataHelpers.getValuesFromJson(json, kv[1]);
                    context.setAttribute(kv[0], jsonValue.get(0));
                    extentTestCase.info("<br/><b>Response Values saved to context:</b><br/>" + kv[0] + "<br/><b>Response Path:</b><br/>" + kv[1] + "<br/><b>Response Value:</b><br/>" + jsonValue);
                }
            }
        } catch (Exception ex) {
            extentTestCase.info("<br/><b>Exception Thrown:</b><br/>" + ex.getMessage());
        }
    }

    public String ReplacePlaceholdersJSON(ITestContext context, ExtentTest extentTestCase, HashMap<Object, Object> replacedMap, String jsonModel) throws ParseException {
        String jsonReplaced = "";
        try {
            replacedMap.forEach((key, value) -> {
                if (String.valueOf(value).contains("GENERATED") || String.valueOf(value).contains("GET")) {
                    try {
                        replacedMap.replace(key, dataGenerators.GenerateRequiredData(value.toString()));
                    } catch (Exception e) {
                        extentTestCase.info("<br/><b>Exception Thrown:</b><br/>" + e.getMessage());
                    }
                } else if (String.valueOf(value).contains("{{")) {
                    replacedMap.replace(key, context.getAttribute(String.valueOf(value).replace("{", "").replace("}", "").replace("\n", "")).toString());
                } else if (String.valueOf(value).contains("bool")) {
                    if (String.valueOf(value).contains("bool_true")) {
                        replacedMap.replace(key, Boolean.valueOf("true"));
                    }
                    if (String.valueOf(value).contains("bool_false")) {
                        replacedMap.replace(key, Boolean.valueOf("false"));
                    }
                } else {
                    replacedMap.replace(key, value);
                }
            });
            jsonReplaced = dataHelpers.ReplaceBodyValuesfromMap(jsonModel, replacedMap);
            String prettyResponse = dataHelpers.PrettifyJson(jsonReplaced);
        } catch (Exception ex) {
            extentTestCase.info("<br/><b>Exception Thrown:</b><br/>" + ex.getMessage());
        }
        return jsonReplaced;


    }

    public String ReplacePlaceholderXml(ITestContext context, ExtentTest extentTestCase, HashMap<Object, Object> replacedMap, String xmlModel) {
        String xmlReplaced = "";
        try {
            replacedMap.forEach((key, value) -> {
                if (String.valueOf(value).contains("GENERATED") || value.toString().contains("GET")) {
                    try {
                        replacedMap.replace(key, dataGenerators.GenerateRequiredData(value.toString()));
                    } catch (Exception e) {
                        extentTestCase.info("<br/><b>Exception Thrown:</b><br/>" + e.getMessage());
                    }
                } else if (String.valueOf(value).contains("{{")) {
                    replacedMap.replace(key, context.getAttribute(String.valueOf(value).replace("{", "").replace("}", "").replace("\n", "")).toString());
                } else {
                    replacedMap.replace(key, value);
                }
            });
            xmlReplaced = dataHelpers.ReplaceBodyValuesXMLfromMap(xmlModel, replacedMap);
            extentTestCase.info("<b>Body data used : </b><br/>" + dataHelpers.addCodeMarkUpToReport(xmlReplaced, "xml"));
            ReportPortal.emitLog("Body data used: " + xmlReplaced, "INFO", Calendar.getInstance().getTime());

        } catch (Exception ex) {
            extentTestCase.info("<br/><b>Exception Thrown:</b><br/>" + ex.getMessage());
        }
        return xmlReplaced;
    }

    public void ValidateResponse(SoftAssert assertion, ITestContext context, ExtentTest extentTestCase, String s, String jsonResponse) {
        String[] kv = new String[0];
        try {
            if (s.contains(":")) {
                if (s.contains("\n")) {
                    s = s.replace("\n", "");
                }
                kv = s.split(":");

                if (kv[0].contains("\"")) {
                    if (jsonResponse.contains(s)) {
                        extentTestCase.pass("<br/><b>Found Expected Value in Response:</b><br/>" + s);
                    } else {
                        extentTestCase.fail("<br/><b>Did not find Expected Value in Response:</b><br/>" + s);
                    }
                    return;
                }
                List<Map<String, Object>> value = dataHelpers.getValuesFromJson(jsonResponse, kv[0]);
                if (kv[1].contains("{{")) {
                    String val = "";
                    try {
                        val = ReplaceWithContextValue(kv[1], context, extentTestCase);
                    } catch (Exception ex){
                        extentTestCase.fail("<br/><b>Did not find Expected Value in Response:</b><br/>" + ex.getMessage() + "<br/> Did not find expected value ("+kv[1]+") in response");
                    }


                    if (val.equals(String.valueOf(value.get(0)))) {
                        extentTestCase.pass("<br/><b>Found Expected Value in Response:</b><br/>" + val);
                    } else if (val.equalsIgnoreCase(String.valueOf(value.get(0)))) {
                        extentTestCase.pass("<br/><b>Found Expected Value in Response:</b><br/>" + val);
                    } else {
                        extentTestCase.fail("<br/><b>Expected Value not in Response:</b><br/>" + val);
                    }
                } else {
                    if (kv[1].equals(String.valueOf(value.get(0)))) {
                        extentTestCase.pass("<br/><b>Found Expected Value in Response:</b><br/>" + kv[1]);
                    } else {
                        extentTestCase.fail("<br/><b>Expected Value not in Response:</b><br/>" + kv[1]);
                    }
                }

            } else if (s.contains("{{") && !s.contains(":")) {
                String ctx = s.replace("{{", "").replace("}}", "");
                String val = ReplaceWithContextValue(s, context, extentTestCase);
                if (ctx.contains("newEmail")) {
                    val = val.toLowerCase();
                }
                s = s.replace("{{" + ctx + "}}", val);
                if (jsonResponse.contains(s)) {
                    extentTestCase.pass("<br/><b>Found Expected Value in Response:</b><br/>" + s);
                } else {
                    extentTestCase.fail("<br/><b>Expected Value not in Response:</b><br/>" + s);
                }
            } else {
                if (jsonResponse.contains(s)) {
                    extentTestCase.pass("<br/><b>Found Expected Value in Response:</b><br/>" + s);
                } else {
                    extentTestCase.fail("<br/><b>Expected Value not in Response:</b><br/>" + s);
                }
            }
        } catch (Exception ex) {
            extentTestCase.fail("<br/><b>Did not find Expected Value in Response:</b><br/>" + ex.getMessage() + "<br/> Did not find expected value ("+kv[1]+") in response");
        }
    }
}
