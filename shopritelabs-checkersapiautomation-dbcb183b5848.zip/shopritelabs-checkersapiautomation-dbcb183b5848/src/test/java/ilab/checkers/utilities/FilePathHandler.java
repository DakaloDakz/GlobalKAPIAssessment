package ilab.checkers.utilities;

import java.io.File;

public class FilePathHandler {
    private static final String currentDir = System.getProperty("user.dir");

    public static String GetResourceFolderPath() {
        return String.format("%s%ssrc%stest%sresources%s", currentDir, File.separator, File.separator, File.separator, File.separator);
    }

    public static String GetTargetFolderPath() {
        return String.format("%s%starget%s", currentDir, File.separator, File.separator);
    }
}
