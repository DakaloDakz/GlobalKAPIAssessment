package ilab.checkers.utilities;

import com.aventstack.extentreports.ExtentTest;
import com.epam.reportportal.service.ReportPortal;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;
import lombok.SneakyThrows;
import okhttp3.*;
import okhttp3.logging.HttpLoggingInterceptor;
import org.apache.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.json.simple.JSONArray;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static io.restassured.RestAssured.given;
import static org.apache.log4j.helpers.UtilLoggingLevel.FINE;


public class ApiHelpers {
    DataHelpers dataHelpers = new DataHelpers();
    final static Logger logger = Logger.getLogger(ApiHelpers.class);
    boolean result = false;
    public ApiHelpers() throws IOException {

    }

    /**
     * API REST using parameters:
     *
     * @param RequestUrl    - full API path including parameters
     * @param RequestMethod - GET, POST, PUT, DELETE, PATCH
     * @param ContentType   - application/json
     * @param GetJsonObj    - Loads data to generate body
     * @param userName
     * @param Password
     * @param accessToken
     * @param idToken
     * @param bearerToken
     * @return String [] - [0] Response Body, [1] Response Code
     * @throws Exception
     */
    public String[] WebServiceContentREST(ExtentTest extentTestCase, String RequestUrl, String RequestMethod, String ContentType,
                                          String GetJsonObj, String userName, String Password, String accessToken, String idToken, String bearerToken) throws Exception {

        Logger.getLogger(OkHttpClient.class.getName()).setLevel(FINE);
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor(logger::debug);
        interceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
        Authentications authentications = new Authentications(extentTestCase);

        String apikeyvalue;
        String apikey = "x-api-key";
        String authAccessToken = null;
        String authIdToken = null;
        JSONParser parser = new JSONParser();
        apikeyvalue = Authentications.setapikey(RequestUrl, Password);


        Integer iTimeOut = null;
        if (RequestUrl.contains("cat")) {
            iTimeOut = 60;
        } else {
            iTimeOut = 30;
        }
        OkHttpClient.Builder okhttpClientBuilder = new OkHttpClient.Builder();
        okhttpClientBuilder.connectTimeout(iTimeOut, TimeUnit.SECONDS) // connect timeout
                .writeTimeout(iTimeOut, TimeUnit.SECONDS) // write timeout
                .readTimeout(iTimeOut, TimeUnit.SECONDS); // read timeout
        okhttpClientBuilder.followRedirects(true);
        OkHttpClient client = okhttpClientBuilder.build();
        String[] responseBody = new String[2];
        MediaType mediaType = MediaType.parse(ContentType);
        RequestBody body = null;
        if (GetJsonObj != null) {
            body = RequestBody.create(mediaType, GetJsonObj);
        }
        Headers.Builder builder = new Headers.Builder();
        builder.add("Content-Type", "application/json;charset=UTF-8");

        switch (Password.toLowerCase()) {
            case "auth_otp":
                // code block
                responseBody = authentications.authenticate_via_otp(extentTestCase, RequestUrl, userName);
                if (responseBody[1].equals("200")) {
                    JSONObject jsonObjectOTP = (JSONObject) parser.parse(responseBody[0]);
                    JSONObject resp = (JSONObject) jsonObjectOTP.get("response");
                    authAccessToken = (String) resp.get("access_token");
                    authIdToken = (String) resp.get("id_token");

                    builder.add(apikey, apikeyvalue);
                } else {
                    return responseBody;
                }
                break;
            case "auth_commerce":
                // code block
                responseBody = authentications.authenticate_using_commerce(RequestUrl);
                JSONObject jsonObjectCommerce = (JSONObject) parser.parse(responseBody[0]);
                authAccessToken = (String) jsonObjectCommerce.get("access_token");
                builder.add("Content-Type", "text/plain");
                builder.add("Authorization", "Bearer " + authAccessToken);
                break;
            case "auth_mm":
                // code block
                responseBody = authentications.authenticate_using_mm(RequestUrl);
                JSONObject jsonObjectMM = (JSONObject) parser.parse(responseBody[0]);
                authAccessToken = (String) jsonObjectMM.get("access_token");
                builder.add("Content-Type", "text/plain");
                builder.add("Authorization", "Bearer " + authAccessToken);
                break;
            case "auth_cognito":
                // code block
                responseBody = authentications.dsl_cognito_test(RequestUrl);
                JSONObject jsonObjectCognito = (JSONObject) parser.parse(responseBody[0]);
                authAccessToken = (String) jsonObjectCognito.get("access_token");
                builder.add(apikey, apikeyvalue);
                builder.add("Authorization", "Bearer " + authAccessToken);
                break;
            case "auth_oidc":
                // code block
                responseBody = authentications.authenticate_using_oidc(RequestUrl, userName);
                JSONObject jsonObjectOidc = (JSONObject) parser.parse(responseBody[0]);
                authAccessToken = (String) jsonObjectOidc.get("access_token");
                authIdToken = jsonObjectOidc.get("id_token").toString();
                builder.add(apikey, apikeyvalue);
                break;
            case "auth_c4c":
                break;
            case "auth_ciam":
                break;
            case "auth_commerce_mobile":
                // code block
                responseBody = authentications.authenticate_using_mobile(RequestUrl, userName);
                JSONObject jsonObjectMobile = (JSONObject) parser.parse(responseBody[0]);
                authAccessToken = (String) jsonObjectMobile.get("access_token");
                authIdToken = jsonObjectMobile.get("id_token").toString();
                break;
            default:
                builder.add(apikey, apikeyvalue);
        }

        if (bearerToken == null) {
            bearerToken = "FALSE";
        }
        if (accessToken.toLowerCase().equals("true")) {
            assert authAccessToken != null;
            builder.add("access_token", authAccessToken);
            ReportPortal.emitLog("Actual access_token : " + authAccessToken, "INFO", Calendar.getInstance().getTime());
        } else if (accessToken.toLowerCase().equals("invalidtoken")) {
            builder.add("access_token", accessToken);
            ReportPortal.emitLog("Actual access_token : " + accessToken, "INFO", Calendar.getInstance().getTime());
        } else {
            ReportPortal.emitLog("Test does not require access_token", "INFO", Calendar.getInstance().getTime());
        }

        if (idToken.toLowerCase().equals("true")) {
            builder.add("id_token", authIdToken);
            ReportPortal.emitLog("Actual id_token : " + authIdToken, "INFO", Calendar.getInstance().getTime());
        } else if (idToken.toLowerCase().equals("invalidtoken")) {
            builder.add("id_token", idToken);
            ReportPortal.emitLog("Actual id_token : " + idToken, "INFO", Calendar.getInstance().getTime());
        } else {
            ReportPortal.emitLog("Test does not require id_token", "INFO", Calendar.getInstance().getTime());
        }

        try {
            if (bearerToken.toLowerCase().equals("true")) {
                builder.add("Authorization", "Bearer " + authAccessToken);
                ReportPortal.emitLog("Actual access_token : " + authAccessToken, "INFO", Calendar.getInstance().getTime());
            } else {
                ReportPortal.emitLog("Bearer token not required", "INFO", Calendar.getInstance().getTime());
            }
        } catch (Exception err) {
            ReportPortal.emitLog("Bearer token not required", "INFO", Calendar.getInstance().getTime());
        }

        if (Password.equalsIgnoreCase("auth_ciam")) {
            if(RequestUrl.contains("shoprite.eu-dev.janraincapture.com")) {
                String ciamAuthUserName = "h87eweww23d6rtuscn92jrh5yndnf86h";
                String ciamAuthPassword = "yq4ykpf6ghmw4gdcx8qkjjn5q8n66hwv";
                String credential = Base64.getEncoder().encodeToString((ciamAuthUserName + ":" + ciamAuthPassword).getBytes(StandardCharsets.UTF_8));
                builder.add("Authorization", "Basic " + credential);
                builder.add("Accept", "*/*");
            } else if(RequestUrl.contains("shoprite-stg.eu-dev.janraincapture.com")){
                String ciamAuthUserName = "jc2w7xrcy86nnjmb79vptbazsyt8rtyv";
                String ciamAuthPassword = "q6hy29dwa32r6bgybyvybenyj4dgjk6s";
                String credential = Base64.getEncoder().encodeToString((ciamAuthUserName + ":" + ciamAuthPassword).getBytes(StandardCharsets.UTF_8));
                builder.add("Authorization", "Basic " + credential);
                builder.add("Accept", "*/*");
            }else {
                builder.add("x-api-key", apikeyvalue);
            }
        }

        if (Password.equalsIgnoreCase("auth_c4c")) {
            String c4cAuthUserName = "caapi_mrkt_contacts";
            String c4cAuthPassword = "2z=&R9Xm_S@a";
            String credential = Base64.getEncoder().encodeToString((c4cAuthUserName + ":" + c4cAuthPassword).getBytes(StandardCharsets.UTF_8));
            builder.add("Accept", "application/json");
            builder.add("ContractID", "9bac3c4b-2957-4132-854c-f2b310572b98");
            builder.add("UIUser", "caapi_mrkt_contacts");
            builder.add("Authorization", "Basic " + credential);
        }

        Headers headers = builder.build();
        Request request = new Request.Builder().url(RequestUrl).method(RequestMethod, body).headers(headers).build();
        String[] finalResponseBody = responseBody;
        try {
            CountDownLatch countDownLatch = new CountDownLatch(1);
            if (Password.equalsIgnoreCase("auth_c4c")) {
                Thread.sleep(15000);
            }
            client.newCall(request).enqueue(new Callback() {
                @SneakyThrows
                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    finalResponseBody[1] = Integer.toString(response.code());
                    finalResponseBody[0] = Objects.requireNonNull(response.body()).string();

                    long tx = response.sentRequestAtMillis();
                    long rx = response.receivedResponseAtMillis();
                    extentTestCase.info("<br/><b>Response Time:</b><br/>" +(rx - tx)+" ms");
                    countDownLatch.countDown();
                }

                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    result = false;
                    logger.error("Failed to connect: "+e.getMessage());
                    countDownLatch.countDown();
                }
            });

            countDownLatch.await();


            /***
             * The code below writes the response times for each api call to a file.
             * DO NOT ENABLE THIS IN MASTER. RUN IT LOCALLY IF YOU NEED THIS DATA!!!
             * */
            /* File f1 = new File("timings.csv");
            if(!f1.exists()) {
                f1.createNewFile();
            }
            FileWriter csvWriter = new FileWriter(f1.getName(), true);
            BufferedWriter bw = new BufferedWriter(csvWriter);

            bw.write(RequestMethod+","+RequestUrl+","+(rx - tx)+" ms\n");

            bw.close();*/
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return finalResponseBody;
    }

    /**
     * Call to LPRO SOAP Webservice
     *
     * @param RequestUrl
     * @param RequestMethod
     * @param ContentType
     * @param GetXmlObj
     * @param userName
     * @param Password
     * @return
     * @throws Exception
     */

    public String[] WebServiceContentSOAP(String RequestUrl, String RequestMethod, String ContentType,
                                          String GetXmlObj, String userName, String Password) throws Exception {
        Properties prop = dataHelpers.ReadPropertiesFile("environment.properties");
        String sk = this.lpro_get_session_key("https://soaqaext1.shoprite.co.za");
        if (RequestUrl.toLowerCase().contains(prop.getProperty("lproQAUrl")) && Password.toLowerCase().equals("auth_lpro")) {
            System.out.println("LPRO implementation");
        }
        Response response = null;
        String[] responseBody = new String[2];
        try {
            RequestBody body = RequestBody.create(MediaType.parse(ContentType), GetXmlObj);
            String occAuthUserName = "caapi_zulzi";
            String occAuthPassword = "EBD@Bp9eNntG";
            String credential = Base64.getEncoder().encodeToString((occAuthUserName + ":" + occAuthPassword).getBytes(StandardCharsets.UTF_8));
            OkHttpClient client = new OkHttpClient().newBuilder()
                    .followRedirects(false)
                    .followSslRedirects(false)
                    .build();
            Request request = new Request.Builder()
                    .url(RequestUrl + "?sk=" + sk)
                    .addHeader("Content-Type", "text/xml")
                    .addHeader("Authorization", "Basic " + credential)
                    .addHeader("ContractID", "a4a32b70-acd2-440b-a4a7-310a0e0dcc57")
                    .addHeader("UIUser", "ncrlpro_login")
                    .post(body)
                    .build();
            response = client.newCall(request).execute();
            responseBody[1] = Integer.toString(response.code());
            responseBody[0] = Objects.requireNonNull(response.body()).string();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (response != null) {
                try {
                    Objects.requireNonNull(response.body()).close();
                } catch (final Throwable th) {
                    System.out.println(th.getMessage());
                }
            }
        }
        return responseBody;
    }

    /**
     * POST call via RestAssured
     *
     * @param body
     * @param apiPasswordHeader
     * @param apiPassword
     * @param combinedUrl
     * @return
     */
    public io.restassured.response.Response postRestAssured(JSONArray body, String contentType, String apiPasswordHeader, String apiPassword, String combinedUrl) {
        io.restassured.response.Response response = null;
        try {
            RequestSpecBuilder builder = new RequestSpecBuilder();
            builder.setBody(body);
            builder.setContentType(contentType);
            builder.addHeader(apiPasswordHeader, apiPassword);

            RequestSpecification requestSpec = builder.build();

            response = given().spec(requestSpec).when().post(combinedUrl);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return response;
    }

    /**
     * GET call via RestAssured
     *
     * @param apiPasswordHeader
     * @param apiPassword
     * @param combinedUrl
     * @param params
     * @return
     */
    public io.restassured.response.Response getRestAssured(String apiPasswordHeader, String apiPassword, String combinedUrl, HashMap<String, String> params) {
        io.restassured.response.Response response = null;
        PreemptiveBasicAuthScheme basicAuth = new PreemptiveBasicAuthScheme();
        basicAuth.setUserName(apiPasswordHeader);
        basicAuth.setPassword(apiPassword);
        try {
            RequestSpecBuilder builder = new RequestSpecBuilder();
            builder.setAuth(basicAuth);
            builder.addQueryParams(params);

            RequestSpecification requestSpec = builder.build();

            response = given().spec(requestSpec).when().post(combinedUrl);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return response;
    }


    /**
     * Implementation to get Session Key for LPRO Webservice call
     *
     * @param RequestUrl
     * @return
     * @throws IOException
     * @throws ParseException
     * @throws ParserConfigurationException
     * @throws SAXException
     */

    public String lpro_get_session_key(String RequestUrl) throws IOException, ParseException, ParserConfigurationException, SAXException {
        String hostName = null;

        if (RequestUrl.toLowerCase().contains("qa")) {
            hostName = "https://soaqaext1.shoprite.co.za";
        }
        if (RequestUrl.toLowerCase().contains("prep")) {
            hostName = "https://soaqaext1.shoprite.co.za";
        }
        String soapBody = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:hql=\"http://www.retalix.com/HQLWebServices\">\n" +
                "   <soapenv:Header/>\n" +
                "   <soapenv:Body>\n" +
                "      <hql:UserLogin>\n" +
                "         <!--Optional:-->\n" +
                "         <hql:in_UserName>SAPCommerce</hql:in_UserName>\n" +
                "         <!--Optional:-->\n" +
                "         <hql:in_Password>$@P(omM3rcE</hql:in_Password>\n" +
                "      </hql:UserLogin>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";
        String url = hostName + "/int/ncr/lpro/login/service";
        RequestBody body = RequestBody.create(MediaType.parse("text/xml"), soapBody);
        String occAuthUserName = "caapi_zulzi";
        String occAuthPassword = "EBD@Bp9eNntG";
        String credential = Base64.getEncoder().encodeToString((occAuthUserName + ":" + occAuthPassword).getBytes(StandardCharsets.UTF_8));

        OkHttpClient client = new OkHttpClient().newBuilder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "text/xml")
                .addHeader("Authorization", "Basic " + credential)
                .addHeader("ContractID", "a4a32b70-acd2-440b-a4a7-310a0e0dcc57")
                .addHeader("UIUser", "ncrlpro_login")
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        String[] responseBody = new String[2];
        responseBody[1] = Integer.toString(response.code());
        responseBody[0] = Objects.requireNonNull(response.body()).string();

        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(responseBody[0]));
        Document doc = builder.parse(src);
        response.close();
        return doc.getElementsByTagName("out_SessionKey").item(0).getTextContent();
    }
}
