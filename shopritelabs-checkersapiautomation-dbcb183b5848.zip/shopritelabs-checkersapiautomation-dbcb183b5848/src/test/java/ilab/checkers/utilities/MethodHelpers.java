package ilab.checkers.utilities;

import org.testng.annotations.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MethodHelpers {
    public Date generateDate() throws Exception {
        Date currentdate=java.util.Calendar.getInstance().getTime();
        //Thu Mar 11 12:45:06 SAST 2021
        return currentdate;
    }

    public String generateDates() throws Exception {
//        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date dateobj = new Date();
        System.out.println(df.format(dateobj));
        return df.format(dateobj);
    }

    public String generateDateOver18() throws Exception {
//        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
//        System.out.println("Current Date " + dateFormat.format(date));

        // Convert Date to Calendar
        Calendar c = Calendar.getInstance();
        c.setTime(date);

        // Perform addition/subtraction
        c.add(Calendar.YEAR, -35);
        c.add(Calendar.MONTH, 1);
        c.add(Calendar.DATE, -10);
        c.add(Calendar.HOUR, -4);
        c.add(Calendar.MINUTE, 30);
        c.add(Calendar.SECOND, 50);

        // Convert calendar back to Date
        Date currentDatePlusOne = c.getTime();

//        System.out.println("Updated Date " + dateFormat.format(currentDatePlusOne));
        return dateFormat.format(currentDatePlusOne);
    }

    @Test()
    public void getDate() throws Exception {
        String currentDate = this.generateDateOver18();
        System.out.println(currentDate);
    }

    @Test()
    public void getDates() throws Exception {
        String currentDate = this.generateDates();
        System.out.println(currentDate);
    }
}
