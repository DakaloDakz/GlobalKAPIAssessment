package ilab.checkers.utilities;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;

public class ExcelDataHandlers {
    public String folderPath;
    private final DataFormatter dataFormatter = new DataFormatter();

    public ExcelDataHandlers(String status) {
        if (status.equals("online")) {
            folderPath = FilePathHandler.GetTargetFolderPath();
        } else {
            folderPath = FilePathHandler.GetResourceFolderPath();
        }
    }

    public ExcelDataHandlers() {

    }

    public Sheet GetExcelSheet(String workbookName, String sheetName) throws Exception {
        File excelFile = new File(folderPath + workbookName);
        try (FileInputStream fileInputStream = new FileInputStream(excelFile); Workbook workbook = WorkbookFactory.create(fileInputStream)) {
            return workbook.getSheet(sheetName);
        }
    }

    public Sheet GetExcelSheet(Workbook workbook, String sheetName) {
        return workbook.getSheet(sheetName);
    }

    public Workbook GetExcelWorkbook(String workbookName) throws Exception {
        File ExcelFile = new File(folderPath + workbookName);
        FileInputStream fileInputStream = new FileInputStream(ExcelFile);
        Workbook workbook = new XSSFWorkbook(fileInputStream);
        fileInputStream.close();
        return workbook;
    }

    public String GetCellData(String columnName, int iRow, Sheet sheet) {
        String cellData = null;
        Row row = sheet.getRow(0);
        int rowCellCount = row.getLastCellNum();
        try {
            for (int i = 0; i <= rowCellCount; i++) {
                if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(columnName)) {
                    Row raw = sheet.getRow(iRow);
                    Cell cell = raw.getCell(i);
                    cellData = dataFormatter.formatCellValue(cell);
                    break;
                }
            }
        } catch (Exception e) {
//            System.out.println(e.getMessage());
        }
        return cellData;
    }

    public Workbook SetCellData(String columnName, int iRow, String sheetName, String inputData, Workbook workbook) {
        Sheet sheet = workbook.getSheet(sheetName);
        Row row = sheet.getRow(0);
        int rowCellCount = row.getLastCellNum();
        Cell cell = null;
        Row raw;
        for (int i = 0; i <= rowCellCount; i++) {
            if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(columnName)) {
                raw = sheet.getRow(iRow);
                cell = raw.getCell(i);
                break;
            }
        }
        //Update the value of cell
        cell.setCellValue(inputData);
        return workbook;
    }
}
