package ilab.checkers.utilities.datahelpers;

import java.util.Base64;

public class Base64Decoder {
    public static String decode(String Base64String){
        byte[] decodedBytes = Base64.getDecoder().decode(Base64String);
        return new String(decodedBytes);
    }
}
