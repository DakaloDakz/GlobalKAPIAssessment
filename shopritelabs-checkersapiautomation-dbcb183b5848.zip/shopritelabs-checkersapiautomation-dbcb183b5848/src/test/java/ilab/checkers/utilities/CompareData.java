package ilab.checkers.utilities;

import com.aventstack.extentreports.ExtentTest;
import com.epam.reportportal.service.ReportPortal;
import com.fasterxml.jackson.databind.ObjectMapper;
import ilab.checkers.models.ApiActionsModel;
import io.restassured.response.Response;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;

public class CompareData {

    @SuppressWarnings("unchecked")
    public void compareObjects(ExtentTest testCase, ApiActionsModel testData, JSONArray s1, Response s2, SoftAssert assertion) throws IOException {
        ExtentTest extentTestCase = testCase.createNode(testData.Scenario);
        extentTestCase.getModel().setStartTime(Calendar.getInstance().getTime());
        JSONObject field = (JSONObject) s1.get(0);
        boolean result;
        if (testData.isArray.equalsIgnoreCase("1")) {
            JSONArray array = new JSONArray();
            ObjectMapper mapper = new ObjectMapper();
            ArrayList<LinkedHashMap<String, String>> arr = s2.getBody().path("result." + testData.CIAM);
            for (int i = 0; i < arr.size(); i++) {
                arr.get(i).remove("id");
                array.add(arr.get(i));
            }
            extentTestCase.info("<b>FOX Field : </b><br/>" + testData.FOX + "<br/><br/>" + "<b>FOX Value : </b><br/>" + field.get(testData.FOX)
                    +"<br/><b>CIAM Field : </b><br/>" + testData.CIAM + "<br/><br/>" + "<b>CIAM Value : </b><br/>" + mapper.writeValueAsString(array));

            ReportPortal.emitLog("FOX Array Name: " + testData.FOX, "INFO", Calendar.getInstance().getTime());
            ReportPortal.emitLog("FOX Array Value: " + field.get(testData.FOX), "INFO", Calendar.getInstance().getTime());
            ReportPortal.emitLog("CIAM Array Name: " + testData.CIAM, "INFO", Calendar.getInstance().getTime());
            ReportPortal.emitLog("CIAM Array Value: " + array, "INFO", Calendar.getInstance().getTime());

            System.out.println(String.valueOf(field.get(testData.FOX)));
            System.out.println(mapper.writeValueAsString(array));
            result = mapper.readTree(String.valueOf(field.get(testData.FOX))).equals(mapper.readTree(mapper.writeValueAsString(array)));
            if (result){
                extentTestCase.pass(testData.Scenario + " - The data objects compared matches!");
            } else {
                extentTestCase.fail(testData.Scenario + " - The data objects compared did not match!");
            }
        } else {
            Object fieldCIAM = s2.getBody().path("result." + testData.CIAM);
            extentTestCase.info("<b>FOX Field : </b><br/>" + testData.FOX + "<br/><br/>" + "<b>FOX Value : </b><br/>" + field.get(testData.FOX)
                    +"<br/><br/><b>CIAM Field : </b><br/>" + testData.CIAM + "<br/><br/>" + "<b>CIAM Value : </b><br/>" + fieldCIAM);

            ReportPortal.emitLog("FOX Array Name: " + testData.FOX, "INFO", Calendar.getInstance().getTime());
            ReportPortal.emitLog("FOX Array Value: " + field.get(testData.FOX), "INFO", Calendar.getInstance().getTime());
            ReportPortal.emitLog("CIAM Array Name: " + testData.CIAM, "INFO", Calendar.getInstance().getTime());
            ReportPortal.emitLog("CIAM Array Value: " + fieldCIAM, "INFO", Calendar.getInstance().getTime());

            if (testData.isDate.equalsIgnoreCase("TRUE")) {
                if (testData.CIAM.equalsIgnoreCase("birthday")) {
                    LocalDate d1 = LocalDate.parse(String.valueOf(field.get(testData.FOX)), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    LocalDate d2 = LocalDate.parse(String.valueOf(fieldCIAM), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    result = d1.equals(d2);
                    if (result){
                        extentTestCase.pass(testData.Scenario + " - The data objects compared matches!");
                    } else {
                        extentTestCase.fail(testData.Scenario + " - The data objects compared did not match!");
                    }
                } else if (testData.CIAM.equalsIgnoreCase("commerce_Customer_Created")) {
                    LocalDate d1 = LocalDate.parse(String.valueOf(field.get(testData.FOX)), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                    LocalDate d2 = LocalDate.parse(String.valueOf(fieldCIAM), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    result = d1.equals(d2);
                    if (result){
                        extentTestCase.pass(testData.Scenario + " - The data objects compared matches!");
                    } else {
                        extentTestCase.fail(testData.Scenario + " - The data objects compared did not match!");
                    }
                } else {
                    LocalDateTime d1 = LocalDateTime.parse(String.valueOf(field.get(testData.FOX)), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                    LocalDateTime d2 = LocalDateTime.parse(String.valueOf(fieldCIAM), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss Z"));
                    result = d1.equals(d2);
                    if (result){
                        extentTestCase.pass(testData.Scenario + " - The data objects compared matches!");
                    } else {
                        extentTestCase.fail(testData.Scenario + " - The data objects compared did not match!");
                    }
                }
            }else {
                ObjectMapper mapper = new ObjectMapper();
                System.out.println(String.valueOf(field.get(testData.FOX)));
                System.out.println(mapper.writeValueAsString(fieldCIAM));
                result = String.valueOf(field.get(testData.FOX)).equals(mapper.writeValueAsString(fieldCIAM));
                if (result){
                    extentTestCase.pass(testData.Scenario + " - The data objects compared matches!");
                } else {
                    extentTestCase.fail(testData.Scenario + " - The data objects compared did not match!");
                }
            }
        }
    }
}
