package ilab.checkers.utilities;

import com.monitorjbl.xlsx.StreamingReader;
import ilab.checkers.models.ApiActionsModel;
import ilab.checkers.models.ApiControllerModel;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class TestDataCreator {

    public static HashMap<String, ApiControllerModel> CreateArrayFromExcel(String status, String excelWorkbookName, String controllerName) throws Exception {
        ExcelDataHandlers excelDataHandlers = new ExcelDataHandlers(status);
        HashMap<String, ApiControllerModel> testHashMap = new LinkedHashMap<>();
        try (InputStream is = new FileInputStream(new File(excelDataHandlers.folderPath + excelWorkbookName))) {
            try (Workbook workbook = StreamingReader.builder()
                    .rowCacheSize(100)
                    .bufferSize(4096)
                    .open(is)) {
                Sheet controllerSheet = workbook.getSheet(controllerName);
                ArrayList<ApiControllerModel> controllerModelArrayList = new ArrayList<>();
                Map<Object, Object> controllerColumnHeaderMap = new LinkedHashMap<>();
                for (Row controllerSheetRow : controllerSheet) {
                    if (controllerSheetRow.getRowNum() == 0) {
                        for (Cell controllerSheetCell : controllerSheetRow) {
                            controllerColumnHeaderMap.put(controllerSheetCell.getColumnIndex(), controllerSheetCell.getStringCellValue());
                        }
                        continue;//exclude header row from being added
                    }
                    ApiControllerModel apiControllerModel = new ApiControllerModel();
                    for (Cell controllerSheetCell : controllerSheetRow) {
                        int cellColumn = controllerSheetCell.getColumnIndex();
                        String controllerColumnHeaderName = String.valueOf(controllerColumnHeaderMap.get(cellColumn)).trim().toUpperCase();
                        switch (controllerColumnHeaderName) {
                            case "SPRINTNAME":
                                apiControllerModel.SprintName = controllerSheetCell.getStringCellValue();
                                break;
                            case "TESTSETPATH":
                                apiControllerModel.TestSetPath = controllerSheetCell.getStringCellValue();
                                break;
                            case "TESTSETNAME":
                                apiControllerModel.TestSetName = controllerSheetCell.getStringCellValue();
                                break;
                            case "TESTSETID":
                                apiControllerModel.TestSetID = controllerSheetCell.getStringCellValue();
                                break;
                            case "TESTNAME":
                                apiControllerModel.TestName = controllerSheetCell.getStringCellValue();
                                break;
                            case "EXECUTE":
                                apiControllerModel.Execute = controllerSheetCell.getStringCellValue();
                                break;
                        }
                    }
                    Map<Object, Object> testSheetColumnHeaderMap = new LinkedHashMap<>();
                    if (apiControllerModel.TestName == null || apiControllerModel.TestName.equalsIgnoreCase(""))
                        break;//stop reading controller sheet after getting all entries
                    if (apiControllerModel.Execute.toUpperCase().equalsIgnoreCase("YES")) {
                        ArrayList<ApiActionsModel> apiActionsModels = new ArrayList<>();
                        Sheet testSheet = workbook.getSheet(apiControllerModel.TestName);


                        for (Row testSheetRow : testSheet) {
                            if (testSheetRow.getRowNum() == 0) {
                                for (Cell testSheetCell : testSheetRow) {
                                    testSheetColumnHeaderMap.put(testSheetCell.getColumnIndex(), testSheetCell.getStringCellValue());
                                }
                                continue;
                            }
                            ApiActionsModel apiActionsModel = new ApiActionsModel();
                            for (Cell testSheetCell : testSheetRow) {
                                apiActionsModel.RowNumber = testSheetCell.getRowIndex();
                                apiActionsModel.ScenarioSheet = testSheet;
                                int cellColumn = testSheetCell.getColumnIndex();
                                String testSheetcolumnHeaderName = String.valueOf(testSheetColumnHeaderMap.get(cellColumn)).toUpperCase();

                                //TODO - replace rest of test headers with matching column names
                                switch (testSheetcolumnHeaderName) {
                                    case "TESTCASEID":
                                        apiActionsModel.TestCaseID = testSheetCell.getStringCellValue();
                                        break;
                                    case "EXECUTESCENARIO":
                                        apiActionsModel.ExecuteScenario = testSheetCell.getStringCellValue();
                                        break;
                                    case "SCENARIO":
                                        apiActionsModel.Scenario = testSheetCell.getStringCellValue();
                                        break;
                                    case "ENDPOINT":
                                        apiActionsModel.EndPoint = testSheetCell.getStringCellValue();
                                        break;
                                    case "RESOURCE":
                                        apiActionsModel.Resource = testSheetCell.getStringCellValue();
                                        break;
                                    case "PARAMETER":
                                        apiActionsModel.Parameter = testSheetCell.getStringCellValue();
                                        break;
                                    case "USERNAME":
                                        apiActionsModel.UserName = testSheetCell.getStringCellValue();
                                        break;
                                    case "PASSWORD":
                                        apiActionsModel.PassWord = testSheetCell.getStringCellValue();
                                        break;
                                    case "METHOD":
                                        apiActionsModel.Method = testSheetCell.getStringCellValue();
                                        break;
                                    case "WEBSERVICETYPE":
                                        apiActionsModel.WebServiceType = testSheetCell.getStringCellValue();
                                        break;
                                    case "FORMAT":
                                        apiActionsModel.format = testSheetCell.getStringCellValue();
                                        break;
                                    case "CONTENTTYPE":
                                        apiActionsModel.ContentType = testSheetCell.getStringCellValue();
                                        break;
                                    case "IDTOKENREQ":
                                        apiActionsModel.IdTokenReq = testSheetCell.getStringCellValue().equals("1") ? "TRUE" : "FALSE";
                                        break;
                                    case "ACCESSTOKENREQ":
                                        apiActionsModel.AccessTokenReq = testSheetCell.getStringCellValue().equals("1") ? "TRUE" : "FALSE";
                                        break;
                                    case "UPDATEDATA":
                                        apiActionsModel.UpdateData = testSheetCell.getStringCellValue().equals("1") ? "TRUE" : "FALSE";
                                        break;
                                    case "VALIDATION":
                                        apiActionsModel.Validation = testSheetCell.getStringCellValue().equals("1") ? "TRUE" : "FALSE";
                                        break;
                                    case "DATATOUPDATE":
                                        apiActionsModel.DataToUpdate = testSheetCell.getStringCellValue();
                                        break;
                                    case "EXPECTED":
                                        apiActionsModel.Expected = testSheetCell.getStringCellValue();
                                        break;
                                    case "SOAPACTION":
                                        apiActionsModel.SOAPAction = testSheetCell.getStringCellValue();
                                        break;
                                    case "PAYLOAD":
                                        apiActionsModel.PAYLOAD = testSheetCell.getStringCellValue();
                                        break;
                                    case "USERS":
                                        apiActionsModel.Users = testSheetCell.getStringCellValue();
                                        break;
                                    case "DATATOVALIDATE":
                                        apiActionsModel.DataToValidate = testSheetCell.getStringCellValue();
                                        break;
                                    case "MISSINGFIELDS":
                                        apiActionsModel.MissingFields = testSheetCell.getStringCellValue();
                                        break;
                                    case "FOX":
                                        apiActionsModel.FOX = testSheetCell.getStringCellValue();
                                        break;
                                    case "CIAM":
                                        apiActionsModel.CIAM = testSheetCell.getStringCellValue();
                                        break;
                                    case "ISARRAY":
                                        apiActionsModel.isArray = testSheetCell.getStringCellValue();
                                        break;
                                    case "ISDATE":
                                        apiActionsModel.isDate = testSheetCell.getStringCellValue();
                                        break;
                                    case "SAVERESPONSEVALUES":
                                        apiActionsModel.SaveResponseValues = testSheetCell.getStringCellValue();
                                        break;
                                    case "SAVEREQUESTVALUES":
                                        apiActionsModel.SaveRequestValues = testSheetCell.getStringCellValue();
                                        break;
                                    case "USECONTEXTVALUE":
                                        apiActionsModel.UseContextValue = testSheetCell.getStringCellValue();
                                        break;
                                    case "BEARERTOKENREQ":
                                        apiActionsModel.BearerTokenReq = testSheetCell.getStringCellValue();
                                        break;
                                }
                            }
                            if (apiActionsModel.DataToUpdate != null && !apiActionsModel.DataToUpdate.isEmpty()) {
                                String[] valuesToUpdate = apiActionsModel.DataToUpdate.split(",");
                                for (String value : valuesToUpdate) {
                                    for (Map.Entry<Object, Object> objectObjectEntry : testSheetColumnHeaderMap.entrySet()) {
                                        if (objectObjectEntry.getValue().toString().toUpperCase().equals(value.toUpperCase().trim())) {
                                            apiActionsModel.ReplacementMap.put(objectObjectEntry.getValue(), testSheetRow.getCell((Integer) objectObjectEntry.getKey()).getStringCellValue());
                                        }
                                    }

                                }
                            }
                            if (apiActionsModel.Scenario == null || apiActionsModel.Scenario.equalsIgnoreCase("")) {
                                break;//stop reading test sheet once last row is empty
                            } else if (!apiActionsModel.Scenario.equalsIgnoreCase("") && apiActionsModel.ExecuteScenario.equalsIgnoreCase("Yes")) {
                                apiActionsModels.add(apiActionsModel);
                            }
                            apiControllerModel.ApiActions = apiActionsModels;
                        }
                        controllerModelArrayList.add(apiControllerModel);
                        testHashMap.put(apiControllerModel.TestName, apiControllerModel);
                    }
                }
                return testHashMap;
            }
        }
    }
}
