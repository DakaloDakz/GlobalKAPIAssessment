package ilab.checkers.utilities;

import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.*;
import java.util.*;

import static org.apache.log4j.Level.INFO;

public class DataHelpers {
    private static final Configuration configuration = Configuration.builder()
            .jsonProvider(new JacksonJsonNodeJsonProvider()).mappingProvider(new JacksonMappingProvider()).build();

    public DataHelpers() {
        Logger.getLogger("com.jayway.jsonpath.internal.path.CompiledPath").setLevel(INFO);
    }

    /**
     * Formats and writes json string to file in output location:
     * /JSONOutputData/sScenaTestName - response.json
     *
     * @param jsonString
     * @param sScenaTestName -
     * @return
     * @throws IOException
     * @throws ParseException
     */
    public String WriteJsonOutputBodyToFile(String jsonString, String sScenaTestName)
            throws IOException, ParseException {
        JSONObject jsonBodyOb;
        JSONArray jsonBodyArr;
        JSONParser parser = new JSONParser();
        JSONObject jsonBody = (JSONObject) parser.parse(jsonString);
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String jsonStringFormatted = gson.toJson(jsonBody);
        System.out.println(jsonStringFormatted);
        // Write JSON file
        FileWriter file = new FileWriter(
                System.getProperty("user.dir") + "/JSONOutputData/" + sScenaTestName + "-response.json");

        if (jsonString != "") {
            if (jsonString.charAt(0) == '{') {

                jsonBodyOb = (JSONObject) parser.parse(jsonString);

                /*Gson gson = new GsonBuilder().setPrettyPrinting().create();*/

                jsonStringFormatted = gson.toJson(jsonBodyOb);

            } else if (jsonString.charAt(0) == '[') {

                jsonBodyArr = (JSONArray) parser.parse(jsonString);

                /*Gson gson = new GsonBuilder().setPrettyPrinting().create();*/

                jsonStringFormatted = gson.toJson(jsonBodyArr);
            }
        }

        file.write(jsonStringFormatted);
        file.close();
        return file.toString();

    }

    /**
     * Reads json file and gets value from object key provided
     *
     * @param jsonObjectKey
     * @param sScenaTestName
     * @return
     */
    public String GetResponseObjectValueFromFile(String jsonObjectKey, String sScenaTestName) {
        JSONParser parser = new JSONParser();
        String value = null;
        try (Reader reader = new FileReader(
                System.getProperty("user.dir") + "/JSONOutputData/" + sScenaTestName + "-response.json")) {

            JSONObject jsonObject = (JSONObject) parser.parse(reader);
            // TODO update to search through all json paths. Currently only replaces at top
            // level
            value = (String) jsonObject.get(jsonObjectKey);

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        return value;
    }

    /**
     * Replaces JSON body values based of Hashmap provided
     *
     * @param jsonBody : { "otp": 737796, "target": { "reference":
     *                 "1827eea2-15d0-446e-828c-4a8c2a7a0af5", "identifier":
     *                 "+27170647961", "type": "SMS" } }
     * @param map      : Map<String, Object> map = new HashMap<String, Object>();
     *                 map.put("target.reference",
     *                 5f17dafb-f99b-4e27-b148-b0db05915f26); map.put("otp", 12345);
     * @return : { "otp": 12345, "target": { "reference":
     * "5f17dafb-f99b-4e27-b148-b0db05915f26", "identifier": "+27170647961",
     * "type": "SMS" } }
     * @throws ParseException
     */
    public String ReplaceBodyValuesJsonPath(String jsonBody, Map<String, Object> map) throws ParseException {
        Iterator<Map.Entry<String, Object>> it = map.entrySet().iterator();
        String updatedJson = null;
        while (it.hasNext()) {
            Map.Entry<String, Object> pairs = it.next();
            updatedJson = JsonPath.using(configuration).parse(jsonBody).set("$." + pairs.getKey(), pairs.getValue())
                    .jsonString();
            jsonBody = updatedJson;
        }
        JSONParser parser = new JSONParser();
        JSONObject jsonObject = (JSONObject) parser.parse(updatedJson);
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String jsonStringFormatted = gson.toJson(jsonObject);
        System.out.println(jsonStringFormatted);
        return jsonStringFormatted;
    }

    /** Website to assist in get JsonPath
     * http://jsonpath.com/
     *  https://goessner.net/articles/JsonPath/index.html#e2
     * */
    public List<Map<String, Object>> getValuesFromJson(String json, String key) {
            return JsonPath.parse(json).read("$." + key);
    }

    public String PrettifyJson(String jsonString) throws ParseException {
        String jsonStringFormatted = null;
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JSONParser parser = new JSONParser();
        String sTypeResponse = null;
        sTypeResponse = jsonString.substring(0, 1);
        if (sTypeResponse.equals("[")) {
            JSONArray jsonArrayPayload = (JSONArray) parser.parse(jsonString);
            jsonStringFormatted = jsonArrayPayload.toString();
        } else {
            JSONObject jsonPayload = (JSONObject) parser.parse(jsonString);
            jsonStringFormatted = gson.toJson(jsonPayload);
        }

        return jsonStringFormatted;
    }

    public String PrettifyXml(String xml) throws Exception {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        transformerFactory.setAttribute("indent-number", 2);

        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        StringWriter stringWriter = new StringWriter();
        StreamResult xmlOutput = new StreamResult(stringWriter);

        Source xmlInput = new StreamSource(new StringReader(xml));
        transformer.transform(xmlInput, xmlOutput);

        return xmlOutput.getWriter().toString();
    }

    public String ReadJsonModel(String jsonBodyFile) throws IOException, ParseException {
        File f1;
        FileReader fr = null;

        JSONParser parser = new JSONParser();
        try {
            f1 = new File(FilePathHandler.GetResourceFolderPath() + File.separator + "JSON-Body-Models" + File.separator + jsonBodyFile);
            fr = new FileReader(f1);
            Object obj = parser.parse(fr);
            JSONObject jsonObject = (JSONObject) obj;
            // System.out.print(jsonObject);
            return jsonObject.toString();
        } finally {
            try {
                ArrayList<String> lines = new ArrayList<>();
                lines.clear();
                Objects.requireNonNull(fr).close();

                // out.close();

            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }

    public String ReadXmlModel(String xmlBodyFile) throws Exception {
        try {
            File fXmlFile = new File(FilePathHandler.GetResourceFolderPath() + File.separator + "XML-Body-Models" + File.separator + xmlBodyFile);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);

            DOMSource domSource = new DOMSource(doc);
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            StringWriter sw = new StringWriter();
            StreamResult sr = new StreamResult(sw);
            transformer.transform(domSource, sr);

            return sw.toString();
        } catch (SAXException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String RemoveElementsJson(String json, String key) {
        return JsonPath.parse(json).delete("$." + key).jsonString();
    }

    public String ReplaceBodyValues(String jsonModel, String[] valuesToUpdate, String[] dataValues) {
        String jsonReplaced = jsonModel;
        for (int i = 0; i < valuesToUpdate.length; i++) {
            if (jsonModel.contains(valuesToUpdate[i])) {
                jsonReplaced = jsonReplaced.replace(valuesToUpdate[i], dataValues[i]);
            }
        }
        return jsonReplaced;
    }

    public String ReplaceBodyValuesfromMap(String jsonModel, HashMap<Object, Object> map) {
        final String[] jsonReplaced = {jsonModel};
        map.forEach((k,v) -> {
            jsonReplaced[0] = jsonReplaced[0].replace(k.toString(), String.valueOf(v));
        });
        return jsonReplaced[0];
    }

    public String ReplaceBodyValuesXML(String xmlModel, String[] valuesToUpdate, String[] dataValues) {
        String xmlReplaced = xmlModel;
        for (int i = 0; i < valuesToUpdate.length; i++) {
            if (xmlModel.contains(valuesToUpdate[i])) {
                xmlReplaced = xmlReplaced.replace(valuesToUpdate[i], dataValues[i]);
            }
        }
        return xmlReplaced;
    }

    public String ReplaceBodyValuesXMLfromMap(String xmlModel, HashMap<Object, Object> map) {
        final String[] xmlReplaced = {xmlModel};
        map.forEach((k,v) -> {
            xmlReplaced[0] = xmlReplaced[0].replace(k.toString(),  String.valueOf(v));
        });
        return xmlReplaced[0];
    }

    public Properties ReadPropertiesFile(String PropertiesFileName) throws IOException {
        Properties prop = new Properties();
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(PropertiesFileName);
        if (inputStream != null){
            prop.load(inputStream);
        } else {
            throw new FileNotFoundException("properties file"+ PropertiesFileName +" not found!");
        }
        return prop;
    }

    public String addCodeMarkUpToReport(String code, String type) {
        Markup m = MarkupHelper.createCodeBlock(code, CodeLanguage.valueOf(type.toUpperCase()));
        return m.getMarkup();
    }
}