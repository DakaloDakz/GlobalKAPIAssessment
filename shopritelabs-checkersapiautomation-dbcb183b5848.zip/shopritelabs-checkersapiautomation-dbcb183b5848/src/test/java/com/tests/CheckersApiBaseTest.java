package com.tests;

import com.aventstack.extentreports.ExtentTest;
import com.epam.reportportal.annotations.TestCaseId;
import com.epam.reportportal.annotations.TestCaseIdKey;
import ilab.checkers.api.TestBase;
import ilab.checkers.models.ApiActionsModel;
import ilab.checkers.models.ApiControllerModel;
import ilab.checkers.reporting.ExtentManager;
import ilab.checkers.reporting.ExtentTestManager;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;


public class CheckersApiBaseTest extends TestBase implements ITest {
    public final ThreadLocal<String> newTestName = new ThreadLocal<>();
    private static ThreadLocal<ApiControllerModel> apiModel = new ThreadLocal<>();
    private ThreadLocal<String> testCaseName;

    @DataProvider(name = "CheckersAPIWebFlowsFromExcel", parallel = true)
    public Iterator<Object[]> createArrayMapFromExcel() {
        return testCaseArray.get().entrySet().stream().map(input -> new Object[]{input.getKey(), input.getValue()}).iterator();
    }

    @BeforeMethod
    public void BeforeMethod(Method method, Object[] testData, ITestContext ctx) {
        if (testData.length > 0) {
            newTestName.set(testData[0].toString());
            ctx.setAttribute("testName", newTestName.get());
        } else
            ctx.setAttribute("testName", method.getName());
    }

    @TestCaseId(parametrized = true)
    @Test(dataProvider = "CheckersAPIWebFlowsFromExcel")
    public void WebsiteStepsExecutor(@TestCaseIdKey String testName, ApiControllerModel testFlow, ITestContext context) throws Exception {

        ExtentTest extentTestCase = ExtentTestManager.getTest();
        extentTestCase.getModel().setName(getTestName());
        context.setAttribute("testName", getTestName());
        extentTestCase.getModel().setStartTime(Calendar.getInstance().getTime());
        SoftAssert assertion = new SoftAssert();
        for (ApiActionsModel testStep : testFlow.ApiActions) {
            apiFlowExecution.WebStepExecutor(extentTestCase, testStep, assertion, context);
        }
        assertion.assertAll();
        extentTestCase.getModel().setEndTime(Calendar.getInstance().getTime());
    }

    @Override
    public String getTestName() {
        this.testCaseName = newTestName;
        return this.testCaseName.get();
    }
}
