# DSL API Automation Test Framework

This project is a comprehensive test framework for DSL and CIAM APIs. It is built using Jest, a delightful JavaScript
Testing Framework with a focus on simplicity. It includes a variety of tests, from unit tests to end-to-end tests, and
utilizes several libraries and tools such as Jest, Axios, and Chalk.

## Build Status

![Build Status](https://dev.azure.com/shopriteqa/dsl-api-automation/_apis/build/status/scheduled/shopritelabs.testautomationdsl.prep?branchName=master)

## Getting Started

To get started with this project, clone the repository to your local machine and install the necessary dependencies.

### Test Results

Test results are stored in the [reports](reports/) folder.

### Test Source

All tests and related functions should be in the [src/__tests__](src/__tests__) folder.

### Configurations

All config files related to Jest should be in the [config](.config) folder.

## Documentation

- [Jest Docs](https://jestjs.io/docs/getting-started)
- [Jest Cheat Sheet](https://github.com/sapegin/jest-cheat-sheet)
- [Lodash](https://lodash.com/docs/4.17.15)

## Prerequisites

This project requires Node.js and npm to be installed on your machine. You can check if you have Node.js installed by
running `node -v` in your terminal. Similarly, check if npm is installed by running `npm -v`.

## Installing

After cloning the repository, navigate to the project directory and run `npm install` to install the necessary
dependencies.

## Running the tests

To run the tests, use the command `npm test`.

## Code Examples

Here are some code examples from the project:

### Making API Calls

This project uses Axios for making API calls. Here's an example of a POST request:

```javascript
const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
```

### Custom Jest Environment

The project includes a custom Jest environment for setting up and tearing down the test environment:

```javascript
class CustomEnvironment extends TestEnvironment {
    constructor(config, context) {
        super(config, context);
        this.testPath = context.testPath;
        this.docblockPragmas = context.docblockPragmas;
    }

    //...
}
```

### Test Cases

The project includes a variety of test cases. Here's an example of a test case:

```javascript
test('created partial customer', async () => {
    const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
    const headers = {
        Authorization: `Bearer ${cognitoDSLToken}`,
        'x-api-key': process.env.DSLCIAMApiKey,
        'Content-Type': 'application/json'
    };
    const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
    expect(response.status).toBe(200);
    expect(response.data.response.uuid).not.toBeNull();
    uuid = response.data.response.uuid;
});
```

## Built With

* [Node.js](https://nodejs.org/)
* [Jest](https://jestjs.io/)
* [Axios](https://axios-http.com/)
* [Chalk](https://www.npmjs.com/package/chalk)

## Authors

* **Your Name** - *Initial work* - [YourGithubUsername](https://github.com/YourGithubUsername)

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.

## Contact

Your Name - gacombrink@shoprite.co.za

Project
Link: [https://bitbucket.org/shopritelabs/testautomationdsl/src/master/](https://bitbucket.org/shopritelabs/testautomationdsl/src/master/)
