let environment = process.argv.filter((x) => x.includes('-environment='))[0].split('=')[1];
let system = process.argv.filter((x) => x.includes('-system='))[0].split('=')[1];
let isCI = !!process.argv.includes('--ci');
const os = require('os');

module.exports = {
    testRunner: "jest-circus/runner",
    clearMocks: true,
    verbose: true,
    maxWorkers: os.cpus().length,
    testEnvironment: '<rootDir>/.config/.scripts/jest.environment.js',
    globals: {
        environment: environment,
        cardIndex: 0,
        usedCardService: false,
        logToConsole: !isCI
    },
    roots: ["<rootDir>/src"],
    setupFiles: [
        `<rootDir>/.config/.env/${environment.toLowerCase()}-environment.js`
    ],
    setupFilesAfterEnv: [`<rootDir>/.config/.scripts/setUp.global.js`],
    // Use this configuration option to add custom reporters to Jest
    reporters: ['default', ["jest-html-reporters", {
        "publicPath": `./reports/${system.toLowerCase()}_${environment.toLowerCase()}-report`,
        "pageTitle": `${system.toUpperCase()} ${environment.toUpperCase()} Automation Results`,
        "filename": `index.html`,
        "expand": false,
        "openReport": false,
        "includeConsoleLog": true
    }], ['jest-junit', {
        outputDirectory: 'reports',
        outputName: `junit-${environment.toLowerCase()}.xml`
    }], [
        "<rootDir>/lib/json-jest-reporter/index.js",
        {outputFile: `reports/result-${environment.toLowerCase()}.json`}
    ]],
    testMatch: [
        /*CUSTOMER*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/create_customer.partial.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/create_customer.partial.asm.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/patch_customer.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/patch_customer.asm.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/patch_customer.moneymarket.pos.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/verify_customer.new.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/verify.mobile.customer.new.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/customer.search.by.mobile.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/set.customer.preferred.store.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/get.customer.preferred.store.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/get.customer.cards.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/get.customer.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/get.customer.lifetimesavings.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/get.trusted.customer.lifetimesavings.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/get.customer.asm.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/loginbymobile.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/loginbymobile.verify.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/login.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/customer.user.type.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/password/password.management.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/password/create_customer.partial_password.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/validate_customer.new.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/hpe/add.customers.audiences.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/hpe/hpe_everlytic.e2e.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/get.customer.ibm.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/verify_member.test.js`,
        /*CUSTOMER NON-REWARDS*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/non.rewards.customer.e2e.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/create_customer.partial.non.rewards.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/get.customer.non.rewards.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/consents/get.customer.non.rewards.consents.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/consents/customer.non.rewards.consents.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/preferences/customer.non.rewards.contact.preferences.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/preferences/get.customer.non.rewards.contact.preferences.test.js`,
        /*PROMOTIONS*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/promotions/rankedpromotions.test.js`,
        /*PREFERENCES*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/preferences/customer.contact.preferences.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/preferences/customer.interests.preferences.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/preferences/get.customer.contact.preferences.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/preferences/get.customer.personal.interests.test.js`,
        /*CONSENTS*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/consents/customer.consents.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/consents/customer.xstra.savings.consents.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/consents/get.customer.consents.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/consents/customer.xstra.savings.plus.consents.test.js`,
        /*DIGITALPRODUCTS*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/digital.products/get.voucher.categories.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/digital.products/get.voucher.list.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/digital.products/get.voucher.status.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/digital.products/get.voucher.redemption.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/digital.products/voucher.code.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/digital.products/voucher.resendcode.test.js`,
        /*CARDS*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/cards/validate.card.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/cards/add.stop.card.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/cards/add.stop.card.asm.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/cards/send.sms.card.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer/cards/add.digital.card.test.js`,
        /*OTHER*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/claims.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/customer.service.messagetypes.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/customer.service.servicedomains.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/receive.sms.preferences.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/customer.service.ticket.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/loyalty.services.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/transactions.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/digital.till.slip.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/savings.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/products&promotions/*.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/stores.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/get.page.details.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/other/post.page.components.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/clpe/clpe.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/clpe/clpe.new.env.test.js`,
        /*CIAM TESTS*/
        `<rootDir>/src/__tests__/ciam/${environment.toLowerCase()}/customer/get_customer.test.js`,
        `<rootDir>/src/__tests__/ciam/${environment.toLowerCase()}/customer/search_customer.test.js`,
        `<rootDir>/src/__tests__/ciam/${environment.toLowerCase()}/customer/consents/consents.test.js`,
        `<rootDir>/src/__tests__/ciam/${environment.toLowerCase()}/customer/preferences/preferences.test.js`,
        `<rootDir>/src/__tests__/ciam/${environment.toLowerCase()}/webhooks/c4c/c4c_webhook.test.js`,
        `<rootDir>/src/__tests__/ciam/${environment.toLowerCase()}/webhooks/lpro/lpro_webhook.test.js`,
        /*E2E*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/partial.customer.e2e.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/full.customer.e2e.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/customer.moneymarket.pos.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/international.numbers.test.js`,
        /*XS PLUS*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/xtraSavingsPlus/activate_deactivate.entitlements.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/xtraSavingsPlus/get.customer.entitlements.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/xtraSavingsPlus/xtra.saving.plus.register.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/xtraSavingsPlus/xtra.saving.plus.get.profile.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/xtraSavingsPlus/xtra.saving.plus.update.profile.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/xtraSavingsPlus/xtra.saving.plus.subscription.reactivate.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/xtraSavingsPlus/xtra.saving.plus.webhook.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/xtraSavingsPlus/xtra.saving.plus.subscription.cancel.test.js`,
        /*INSIDER*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.checkers.customer.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.shoprite.customer.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.petshop.customer.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.checkers.customer.preferences.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.shoprite.customer.preferences.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.to.ciam.checkers.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.to.ciam.shoprite.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.to.ciam.petshop.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.customerv2.cards.test.js`,

        /*Discovery*/
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.activation.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.deactivation.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.verification.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.enrolment.test.js`,
        `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.update.test.js`,
    ],
    rootDir: '../',
    testPathIgnorePatterns: [
        '\\\\node_modules\\\\',
        '\\\\docs\\\\'
    ],
    transform: {
        "^.+\\.js?$": "babel-jest"
    },
    globalTeardown: '<rootDir>/.config/.scripts/tearDown.global.js',
    transformIgnorePatterns: [
        "node_modules/(?!@ngrx|(?!deck.gl)|ng-dynamic)"
    ],
    //This is to keep the older version of snapshots valid
    snapshotFormat: {
        escapeString: true,
        printBasicPrototype: true
    }
};
