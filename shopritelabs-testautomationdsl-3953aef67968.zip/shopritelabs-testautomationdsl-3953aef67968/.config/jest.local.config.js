let environment = process.argv.filter((x) => x.includes('-environment='))[0].split('=')[1];
let system = process.argv.filter((x) => x.includes('-system='))[0].split('=')[1];
let isCI = !!process.argv.includes('--ci');
const os = require('os');

module.exports = {
    testRunner: "jest-circus/runner",
    clearMocks: true,
    verbose: true,
    maxWorkers: os.cpus().length,
    testEnvironment: '<rootDir>/.config/.scripts/jest.environment.js',
    globals: {
        environment: environment,
        cardIndex: 0,
        usedCardService: false,
        logToConsole: !isCI
    },
    roots: ["<rootDir>/src"],
    setupFiles: [
        `<rootDir>/.config/.env/${environment.toLowerCase()}-environment.js`
    ],
    setupFilesAfterEnv: [`<rootDir>/.config/.scripts/setUp.global.js`],
    // Use this configuration option to add custom reporters to Jest
    reporters: ['default',
        ["jest-html-reporters", {
            "publicPath": `./reports/${system.toLowerCase()}_${environment.toLowerCase()}-report`,
            "pageTitle": `${system.toUpperCase()} ${environment.toUpperCase()} Automation Results`,
            "filename": `index.html`,
            "expand": false,
            "openReport": false,
            "inlineSource": true
        }],
        [
            "<rootDir>/lib/json-jest-reporter/index.js",
            {outputFile: `reports/result-${environment.toLowerCase()}.json`}
        ]
        // ["<rootDir>/lib/influxReporter.js", {}]
    ],
    testMatch: [
        // `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/insider/insider.to.ciam.petshop.test.js`,
        // `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.activation.test.js`,
        // `<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.deactivation.test.js`,
        `<!--<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.verification.test.js-->`,
        `<!--<rootDir>/src/__tests__/dsl/${environment.toLowerCase()}/discovery/vitality.enrolment.test.js-->`,
        `<rootDir>/src/__tests__/dsl/prep/customer/preferences/get.customer.non.rewards.contact.preferences.test.js`
    ],
    rootDir: '../',
    testPathIgnorePatterns: [
        '\\\\node_modules\\\\',
        '\\\\docs\\\\'
    ],
    transform: {
        "^.+\\.js?$": "babel-jest"
    },
    globalTeardown: '<rootDir>/.config/.scripts/tearDown.global.js',
    transformIgnorePatterns: [
        "node_modules/(?!@ngrx|(?!deck.gl)|ng-dynamic)"
    ],
    snapshotFormat: {
        escapeString: true,
        printBasicPrototype: true
    }
};
