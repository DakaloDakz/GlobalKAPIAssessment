import {faker} from '@faker-js/faker';
import * as fs from 'fs';
import MicrosoftUtil from "../../src/services/microsoft/microsoftUtils";
import console from "console";
import DataHelpers from "../../src/__tests__/__utils__/data_helpers";

let ms = new MicrosoftUtil();
let dataHelpers = new DataHelpers();
//Remove the unnecessary console.log from the terminal output
global.console = console;
global.faker = faker;
global.fs = fs;

beforeAll(async () => {
    globalThis.checkersCards = require(`${process.cwd()}/cards/${globalThis.environment}_checkers_new.json`);
    globalThis.shopriteCards = require(`${process.cwd()}/cards/${globalThis.environment}_shoprite_new.json`);
});

afterAll(async () => {
    console.log('afterAll');
    if (globalThis.usedCardService && globalThis.checkersCards !== undefined) {
        await fs.writeFileSync(`./cards/${globalThis.environment}_checkers_new.json`, JSON.stringify(globalThis.checkersCards, null, 2));
        await fs.writeFileSync(`./cards/${globalThis.environment}_shoprite_new.json`, JSON.stringify(globalThis.shopriteCards, null, 2));
    }
});
