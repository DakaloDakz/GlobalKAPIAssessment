import * as https from "https";
import MicrosoftUtil from "../../src/services/microsoft/microsoftUtils";
import S3FileManager from "../../src/__tests__/__utils__/aws/aws_s3";
import {accessKeyId, secretAccessKey} from "../.env/secrets";
import * as path from "node:path";

const axios = require("axios");
const moment = require("moment");
const tz = require("moment-timezone");
const chalk = require("chalk");
const zipdir = require('zip-dir');

let ms = new MicrosoftUtil();
let environment = process.argv.filter((x) => x.includes('-environment='))[0].split('=')[1];
let system = process.argv.filter((x) => x.includes('-system='))[0].split('=')[1];
let publish = process.argv.filter((x) => x.includes('-publish='))[0].split('=')[1];
let buildId;
if (process.argv.filter((x) => x.includes('-buildId='))[0] !== undefined) {
    buildId = process.argv.filter((x) => x.includes('-buildId='))[0].split('=')[1] || '0';
}

let json = require(`../../reports/result-${environment.toLowerCase()}.json`);

module.exports = async () => {
    console.log(chalk.blueBright("**************************************************************"));
    console.log(chalk.blueBright('Uploading updated Rewards Cards JSON files to S3'));
    console.log(chalk.blueBright("**************************************************************"));
    const s3FileManager = new S3FileManager('dsl-qa-automation-results', accessKeyId, secretAccessKey);
    await s3FileManager.uploadCardsFilesS3();
    console.log(chalk.blueBright("**************************************************************"));

    if (publish === 'true') {
        let zipFileName = `report-${environment}-${moment(new Date()).format('YYYY-MM-DD')}.zip`;
        await zipdir('./reports', {saveTo: `./reports/${zipFileName}`}, function (err, buffer) {
            if (err) console.log(err);
        });
        console.log(chalk.greenBright("**************************************************************"));
        console.log(chalk.greenBright('Publishing test results to MS Teams!'));
        console.log(chalk.greenBright("**************************************************************"));
        let startTimeString = moment(new Date()).tz('Africa/Johannesburg').format("dddd, DD MMMM YYYY hh:mm:ss");
        let startTime = moment(new Date(json.startTime));
        let endTime = moment(new Date());
        let duration = moment.duration(endTime.diff(startTime));
        const padNumber = (number, minLength = 2) => {
            const len = number.toString().length;
            if (len < minLength) {
                return '0'.repeat(minLength - len) + number;
            }
            return number;
        };
        const min = padNumber(duration.minutes());
        const sec = padNumber(duration.seconds());
        await new Promise(resolve => setTimeout(resolve, 30000)); // 30 sec
        await s3FileManager.uploadFileS3(`./reports`, zipFileName, 'reports/');
        const HOOK_URL = "https://shoprite.webhook.office.com/webhookb2/bc9ecde7-3035-480c-b0d8-eb20b8056180@6515e1d4-4651-4a9f-8a0b-838e05cb3ef7/IncomingWebhook/542fa70079a64d5ba1e78db67301c1a6/a7b69978-23d9-448a-914b-ef810f09045d";
        let teams_message = {
            "@context": "https://schema.org/extensions",
            "@type": "MessageCard",
            "themeColor": "#15cebf",
            "title": `${json.pageTitle}`,
            "text": `Result upload UTC time of <strong style=\"color:dodgerblue\">${startTimeString}</strong>`,
            "sections": [
                {
                    "facts": [
                        {
                            "name": "System:",
                            "value": `<strong style=\"color:dodgerblue\">${system.toUpperCase()}</strong>`
                        },
                        {
                            "name": "Azure Build Number:",
                            "value": `<strong style=\"color:dodgerblue\">${buildId}</strong>`
                        },
                        {
                            "name": "Environment:",
                            "value": `<strong style=\"color:dodgerblue\">${environment.toUpperCase()}</strong>`
                        },
                        {
                            "name": "Passed:",
                            "value": `<strong style=\"color:green\">${json.numPassedTests}</strong>`
                        },
                        {
                            "name": "Failed:",
                            "value": `<strong style=\"color:red\">${json.numFailedTests}</strong>`
                        },
                        {
                            "name": "Skipped:",
                            "value": `<strong style=\"color:yellow\">${json.numSkippedTests}</strong>`
                        },
                        {
                            "name": "Duration(minutes):",
                            "value": `<strong style=\"color:dodgerblue\">${min}:${sec}</strong>`
                        }
                    ],
                    "images": [
                        {
                            "image": path.resolve(__dirname, `../../reports/${environment}.results.chart.png`),
                            "title": json.pageTitle
                        }
                    ],
                    "markdown": true
                }
            ],
            "potentialAction": [
                {
                    "@type": "OpenUri",
                    "name": "Download Report",
                    "targets": [{
                        "os": "default",
                        "uri": `https://dev.azure.com/shopriteqa/dsl-api-automation/_build/results?buildId=${buildId}&view=artifacts&pathAsName=false&type=publishedArtifacts`
                    }]
                },
                {
                    "@type": "OpenUri",
                    "name": "Open Azure Pipeline",
                    "targets": [{
                        "os": "default",
                        "uri": `https://dev.azure.com/shopriteqa/dsl-api-automation/_build/results?buildId=${buildId}&view=results`
                    }]
                },
                {
                    "@type": "OpenUri",
                    "name": "Open Metabase DSL Dashboard",
                    "targets": [{
                        "os": "default",
                        "uri": `http://atsproddb1:3000/dashboard/42-dsl-dashboard`
                    }]
                }
            ]
        };
        const instance = axios.create({
            // ... other options ...
            httpsAgent: new https.Agent({
                rejectUnauthorized: false
            })
        });
        await instance.post(HOOK_URL, teams_message, {
            headers: {
                'Content-Type': 'application/json'
            }
        }).then((response) => {
            console.log(chalk.blue(`Message published to Teams with Status ${chalk.green(response.status)}`));
        }).catch((error) => {
            console.log(chalk.red(`Error--->: ${error}`));
        });
    } else {
        console.log(chalk.greenBright('Nothing to do here. Exiting. Goodbye!'));
    }
};
