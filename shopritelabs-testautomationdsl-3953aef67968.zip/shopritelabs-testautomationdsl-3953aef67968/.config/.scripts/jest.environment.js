import {stringify} from "qs";
import axios from "axios";
import S3FileManager from "../../src/__tests__/__utils__/aws/aws_s3";
import chalk from "chalk";
import {accessKeyId, secretAccessKey} from "../.env/secrets";

const {TestEnvironment} = require('jest-environment-node');

/**
 * CustomEnvironment class extends the TestEnvironment class from jest-environment-node.
 * It provides setup and teardown methods for the test environment, as well as methods to get Cognito tokens and download files from S3.
 */
class CustomEnvironment extends TestEnvironment {
    /**
     * Constructor for the CustomEnvironment class.
     * @param {Object} config - Jest configuration object.
     * @param {Object} context - Context object containing information about the test environment.
     */
    constructor(config, context) {
        super(config, context);
        this.testPath = context.testPath;
        this.docblockPragmas = context.docblockPragmas;
    }

    /**
     * Setup method for the test environment.
     * It sets up the global variables for the Cognito tokens and downloads the card files from S3.
     */
    setup = async () => {
        await super.setup();
        this.global.cognitoDSLToken = await this.getCognitoToken('DSL');
        this.global.cognitoCIAMToken = await this.getCognitoToken('CIAM');
        this.global.cognitoDSLFoxToken = await this.getCognitoToken('DSLFOX');
        this.global.cognitoAEMToken = await this.getCognitoToken('AEM');
        await this.downloadCardsFilesS3();
    };

    /**
     * Teardown method for the test environment.
     */
    teardown = async () => {
        await super.teardown();
    };

    /**
     * Method to get a Cognito token.
     * @param {string} type - The type of the Cognito token to get.
     * @returns {Promise<string>} The Cognito token.
     */
    getCognitoToken = async (type) => {
        const config = {
            DSL: {
                qa: {
                    authUrl: 'https://ciamdslqa.auth.eu-west-1.amazoncognito.com/oauth2/token',
                    clientId: '19fgg12t3aq49138vpujf2mncu',
                    clientSecret: 'b3jg045msv41cmb1t0lo7ab0d45v8kbdor1nrmro6cchntqpd4t'
                },
                prep: {
                    authUrl: 'https://ciamdslprep.auth.eu-west-1.amazoncognito.com/oauth2/token',
                    clientId: '5egcbpivnl9t87ocq375e781cm',
                    clientSecret: '1krqb06kdiamu6rlgbup4q4d0c1j6grbl3o7lp9ua2r7gt8rjnks'
                }
            },
            CIAM: {
                qa: {
                    authUrl: 'https://ciamqa.auth.eu-west-1.amazoncognito.com/oauth2/token',
                    clientId: 'q0s6b9ughi2ogt3904uulpahe',
                    clientSecret: '11g1g57110hdauk8cujm2uc2m4vufmsijeha0tt9189pcp9hcsp8'
                },
                prep: {
                    authUrl: 'https://ciamprep.auth.eu-west-1.amazoncognito.com/oauth2/token',
                    clientId: '66fkrie24cenlumpgv8kus0klu',
                    clientSecret: '1rv00q1tf6535tbj2him0pmvqbrljov8do4mh0qviq7ar2jrb2fv'
                }
            },
            AEM: {
                qa: {
                    authUrl: 'https://dslqa.auth.eu-west-1.amazoncognito.com/oauth2/token',
                    clientId: '1lc6ns00ds0tm550b4sncdf3be',
                    clientSecret: '1d7k7r4649icri05c7l3v7p7gc4c5mo8gav59dk9qoreg2b1jktk'
                },
                prep: {
                    authUrl: 'https://dslprep.auth.eu-west-1.amazoncognito.com/oauth2/token',
                    clientId: '5mrissc65hq5rglluonivrnq9s',
                    clientSecret: 'am8itqm5iah9dpj5ch38cm1faiiuedrtk0hlrtcnfcajkcmv2np'
                }
            },
            DSLFOX: {
                qa: {
                    authUrl: 'https://dslqa.auth.eu-west-1.amazoncognito.com/oauth2/token',
                    clientId: '1lc6ns00ds0tm550b4sncdf3be',
                    clientSecret: '1d7k7r4649icri05c7l3v7p7gc4c5mo8gav59dk9qoreg2b1jktk'

                },
                prep: {
                    authUrl: 'https://dslprep.auth.eu-west-1.amazoncognito.com/oauth2/token',
                    clientId: '5mrissc65hq5rglluonivrnq9s',
                    clientSecret: 'am8itqm5iah9dpj5ch38cm1faiiuedrtk0hlrtcnfcajkcmv2np'

                }
            }
        };

        console.log(chalk.magentaBright(`Getting Cognito token for ${type} environment: ${this.context.environment}`));
        const {
            authUrl,
            clientId,
            clientSecret
        } = config[type][this.context.environment];
        const credential = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        try {
            let access = await axios.post(authUrl, stringify(data), {headers});
            return access.data.access_token;
        } catch (error) {
            console.error(`Error getting Cognito token: ${error}`);
        }
    };

    /**
     * Method to download card files from S3.
     * @returns {Promise<void>}
     */
    downloadCardsFilesS3 = async () => {
        console.log(chalk.magentaBright('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&'));
        console.log(chalk.magentaBright('***Downloading XS Cards File***'));
        console.log(chalk.magentaBright('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n'));
        const s3FileManager = new S3FileManager('dsl-qa-automation-results', accessKeyId, secretAccessKey);
        return await s3FileManager.downloadCardsFilesS3();
    };
}

module.exports = CustomEnvironment;
