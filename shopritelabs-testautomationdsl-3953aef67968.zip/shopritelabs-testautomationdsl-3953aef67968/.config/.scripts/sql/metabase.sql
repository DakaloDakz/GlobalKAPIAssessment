USE AutomationResults
EXECUTE dbo.sp_CreateExecutionRunTable @SCHEMA = 'C4C'
EXECUTE dbo.sp_CreateResultsTable @SCHEMA = 'C4C'
EXECUTE dbo.sp_CreateScenarioTable @SCHEMA = 'C4C'
EXECUTE dbo.sp_CreateTestcasesTable @SCHEMA = 'C4C'
GO
