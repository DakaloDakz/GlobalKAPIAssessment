module.exports = {
    clearMocks: true,
    verbose: true,
    maxWorkers: 2,
    globals: {
        "environment": environment
    },
    roots: ["<rootDir>/src"],
    setupFiles: [
        `<rootDir>/.config/.env/prod-environment.js`
    ],
    reporters: ['default', ["jest-html-reporters", {
        "publicPath": `./reports/dsl_prod-report`,
        "pageTitle": `${system.toUpperCase()}  ${environment.toUpperCase()} Automation Results`,
        "filename": `index.html`,
        "expand": false,
        "openReport": false
    }], ['jest-junit', {
        outputDirectory: 'reports',
        outputName: `junit-prod.xml`
    }],
        [
            "<rootDir>/lib/json-jest-reporter/index.js",
            {outputFile: `reports/result-prod.json`}
        ]
    ],
    testMatch: [
        /*CUSTOMER*/
        `<rootDir>/src/__tests__/dsl/prod/customer/create_customer.partial.test.js`,
        `<rootDir>/src/__tests__/dsl/prod/customer/create_customer.full.new.test.js`
    ],
    rootDir: '../',
    testPathIgnorePatterns: [
        '\\\\node_modules\\\\',
        '\\\\docs\\\\'
    ],
    globalTeardown: '<rootDir>/.config/.scripts/tearDown.global.js'
};
