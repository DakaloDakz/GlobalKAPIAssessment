module.exports = {
    extends: ["plugin:jest/recommended", "plugin:jest/style"],
    parser: "@babel/eslint-parser",
    parserOptions: {
        "ecmaVersion": 6,
        "sourceType": "module",
        "ecmaFeatures": {
            "experimentalObjectRestSpread": true
        }
    },
    settings: {
        jest: {
            version: require('jest/package.json').version
        }
    },
    env: {
        "jest/globals": true
    },
    overrides: [
        {
            files: "**/src/**/*.test.js",
            plugins: ["jest"],
            env: {
                jest: true
            },
            rules: {
                "jest/no-disabled-tests": "off",
                "jest/no-focused-tests": "error",
                "jest/no-identical-title": "error",
                "jest/prefer-to-have-length": "warn",
                "jest/valid-expect": "error",
                "jest/no-duplicate-hooks": "error",
                "jest/no-test-return-statement": "off",
                "jest/consistent-test-it": ["error", {
                    "fn": "test",
                    "withinDescribe": "test"
                }],
                "jest/no-standalone-expect": "off",
                "jest/no-conditional-expect": "off",
                "jest/no-commented-out-tests": "off"
            }
        },
        {
            files: "**/src/**/*.test.js",
            plugins: ["jest-formatting"],
            rules: {
                "jest-formatting/padding-around-test-blocks": 2
            }
        }
    ]
};
