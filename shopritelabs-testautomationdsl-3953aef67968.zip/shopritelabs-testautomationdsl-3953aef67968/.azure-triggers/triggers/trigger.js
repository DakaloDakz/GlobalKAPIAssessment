const axios = require('axios');

let organization = 'shopriteqa';
let project = 'dsl-api-automation';
let number = '17';
let url = `https://dev.azure.com/${organization}/${project}/_apis/build/builds?api-version=6.0-preview.6`;
axios.post(url, {
    "parameters": "{\"environment\":  \"qa\",\"metabase\":  \"false\"}",
    "definition": {
        "id": number
    }
})
    .then(function (response) {
        console.log(response);
    })
    .catch(function (error) {
        console.log(error);
    });
