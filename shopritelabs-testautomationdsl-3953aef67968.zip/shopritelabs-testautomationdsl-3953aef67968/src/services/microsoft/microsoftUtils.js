import console from "console";
import "isomorphic-fetch";
import {password, username} from "../../../.config/.env/secrets";
import {SPPull} from "sppull";
import {spsave} from "spsave";

const fs = require("fs");
const fsPromise = require("fs/promises");

export default class MicrosoftUtil {
    /**
     * Uploads a file to a SharePoint folder.
     * @param {string} LOCAL_FILE_PATH - The local file path of the file to upload.
     * @param {string} UPLOAD_FOLDER - The name of the SharePoint folder to upload the file to.
     * @param {string} FILE_NAME_WITH_EXTENSION - The name of the file to upload, including its extension.
     */
    upload = async (LOCAL_FILE_PATH, UPLOAD_FOLDER, FILE_NAME_WITH_EXTENSION) => {
        const coreOptions = {
            siteUrl:
                "https://shoprite-my.sharepoint.com/personal/dautomation_shoprite_co_za"
        };
        const credentials = {
            username: username,
            password: password
        };
        const file = fs.readFileSync(`${LOCAL_FILE_PATH}`);

        const fileOptions = {
            folder: `/Documents/Automation/${UPLOAD_FOLDER}`,
            fileName: FILE_NAME_WITH_EXTENSION,
            fileContent: file
        };
        await spsave(coreOptions, credentials, fileOptions)
            .then(() => {
                console.log("saved");
            })
            .catch((err) => {
                console.log(err);
            });
    };

    /**
     * Downloads a file from OneDrive to a local directory.
     * @param {string} ONEDRIVE_FILE_PATH - The OneDrive file path of the file to download.
     * @param {string} DOWNLOAD_PATH - The local directory to download the file to.
     */
    downloadFile = async (ONEDRIVE_FILE_PATH, DOWNLOAD_PATH) => {
        const context = {
            siteUrl:
                "https://shoprite-my.sharepoint.com/personal/dautomation_shoprite_co_za",
            creds: {
                username: username,
                password: password,
                online: true
            }
        };
        const options = {
            spRootFolder: ONEDRIVE_FILE_PATH,
            dlRootFolder: DOWNLOAD_PATH
        };

        await SPPull.download(context, options)
            .then((downloadResults) => {
                console.log("Files are downloaded");
            })
            .catch((err) => {
                console.log("Core error has happened", err);
            });
    };

    /**
     * Downloads a file from SharePoint to a local directory.
     */
    downloadCardsFile = async () => {
        const context = {
            siteUrl:
                "https://shoprite-my.sharepoint.com/personal/dautomation_shoprite_co_za",
            creds: {
                username: username,
                password: password,
                online: true
            }
        };
        const options = {
            spRootFolder: "/Documents/Automation/DSL/cards",
            dlRootFolder: "./cards"
        };

        SPPull.download(context, options)
            .then((downloadResults) => {
                console.log("Files are downloaded");
            })
            .catch((err) => {
                console.log("Core error has happened", err);
            });
    };

    /**
     * Checks if a directory exists at the specified path.
     * @param {string} path - The path to the directory to check.
     * @returns {boolean} - Returns true if the directory exists, false otherwise.
     */
    isExistsDirectory = async (path) => {
        try {
            await fsPromise.access(path, fs.constants.F_OK);
            return true;
        } catch {
            return false;
        }
    };
}
