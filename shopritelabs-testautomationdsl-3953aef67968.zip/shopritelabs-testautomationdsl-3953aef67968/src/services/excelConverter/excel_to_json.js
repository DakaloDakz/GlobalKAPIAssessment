const xlsxj = require("xlsx-to-json-lc");

xlsxj({
    input: "C:\\shoprite\\repos\\dsl-ciam-api-test-framework\\src\\services\\excelConverter\\Checkers-DSL-API-QA.xlsx",
    output: "PartialUserUSSD.json",
    sheet: "PartialUserUSSD",
    lowerCaseHeaders: true
}, function (err, result) {
    if (err) {
        console.error(err);
    } else {
        console.log(result);
    }
});