import ApiMethodUtil from '../../api_method_util';

const api = new ApiMethodUtil();
export const get_otp_reference = async (env, mobileNumber, access_token) => {
    let url = `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`;
    let api_key = process.env.DSLCIAMApiKey;

    let headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${access_token}`,
        'x-api-key': `${api_key}`
    };
    const params = {mobileNumber: `${mobileNumber}`};
    let {data} = await api.GET(url, headers, params);
    return data.response.reference;

};
export const get_otp = async (env, reference) => {
    let url = `https://m73lrxwau3.execute-api.eu-west-1.amazonaws.com/dev/getotp`;
    let headers = {
        'Content-Type': 'application/json'
    };

    const params = {reference: `${reference}`};
    let {data} = await api.GET(url, headers, params);
    return data.substring(0, 4);
};