import qs from 'qs';
import {encode} from '../../encryption.util';
import ApiMethodUtil from '../../api_method_util';
import {get_otp, get_otp_reference} from "./otp";

const apiCall = new ApiMethodUtil();
export default class Authentication {
    /**
     *
     * @returns {Promise<AxiosResponse<*>|*>}
     */
    dslCognitoAuth = async () => {
        const authUrl = process.env.DSLCognitoUrl;
        const clientId = process.env.DSLCognitoClientId;
        const clientSecret = process.env.DSLCognitoClientSecret;
        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            Authorization: `Basic ${credential}`
        };
        const params = {
            grant_type: 'client_credentials',
            scope: ''
        };

        let {data} = await apiCall.POST(authUrl, qs.stringify(params), headers);
        return data.access_token;
    };
    authenticate_via_otp = async (env, mobileNumber) => {
        let url;
        let api_key;
        let otp;
        let access_token = await this.dslCognitoAuth();

        let reference = await get_otp_reference(env, mobileNumber, access_token);
        if (env.includes("qa")) {
            url = `${process.env.DSL}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`;
            api_key = "BjPWvvF2Vr5BcW1iPw2hD4VVVBefrFem1sra63RH";
            otp = await get_otp(env, reference);
        }
        if (env.includes("prep")) {
            url = `${process.env.DSL}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`;
            api_key = "K85RaNLMSg6MQ9SLBBD6DeNrW0tQONctZh5C8kb0";
            otp = `42e7a7a2-0b1a-11ec-9a03-0242ac130003`;
        }

        let headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${access_token}`,
            'x-api-key': `${api_key}`
        };

        let body = `{
              "otp": "${otp}",
              "target": {
                "reference": "${reference}",
                "identifier": "${mobileNumber}",
                "type": "SMS"
              }
            }`;
        let {data} = await apiCall.POST(url, body, headers);
        return data.response;
    };
}
