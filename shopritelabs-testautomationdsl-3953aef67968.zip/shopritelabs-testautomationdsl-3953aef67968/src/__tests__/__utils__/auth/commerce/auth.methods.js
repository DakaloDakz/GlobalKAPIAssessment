import qs from 'qs';
import {encode} from '../../encryption.util';
import ApiMethodUtil from '../../api_method_util';

const apiCall = new ApiMethodUtil();
export default class Authentication {
    /**
     *
     * @returns {Promise<AxiosResponse<*>|*>}
     */
    commerceCognitoAuth = async () => {
        const authUrl = process.env.CommerceCognitoUrl;
        const clientId = process.env.CommerceCognitoClientId;
        const clientSecret = process.env.CommerceCognitoClientSecret;
        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            Authorization: `Basic ${credential}`
        };
        const params = {
            grant_type: 'client_credentials',
            scope: ''
        };

        let {data} = await apiCall.POST(authUrl, qs.stringify(params), headers);
        return data.access_token;
    };

    commerceAuth = async () => {
        let occAuthUserName = process.env.OCCClientID;
        let occAuthPassword = process.env.OCCClientSecret;
        const authUrl = `${process.env.CommerceUrl}/authorizationserver/oauth/token`;
        const credential = encode(`${occAuthUserName}:${occAuthPassword}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            Authorization: `Basic ${credential}`
        };
        const params = {
            grant_type: 'client_credentials',
            scope: ''
        };
        let {data} = await apiCall.POST(authUrl, qs.stringify(params), headers);
        return data.access_token;
    };
}
