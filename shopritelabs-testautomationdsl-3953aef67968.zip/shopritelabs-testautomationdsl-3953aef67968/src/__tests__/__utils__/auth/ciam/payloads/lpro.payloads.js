export default class LproPayloads {
    loginPayload = async () => {
        return `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:hql="http://www.retalix.com/HQLWebServices">
                   <soapenv:Header/>
                   <soapenv:Body>
                      <hql:UserLogin>
                         <!--Optional:-->
                         <hql:in_UserName>SAPCommerce</hql:in_UserName>
                         <!--Optional:-->
                         <hql:in_Password>$@P(omM3rcE</hql:in_Password>
                      </hql:UserLogin>
                   </soapenv:Body>
                </soapenv:Envelope>`;
    };
    getDemographic = async (identifier) => {
        return `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:hql="http://www.retalix.com/HQLWebServices">
                <soapenv:Header/>
                <soapenv:Body>
                    <hql:GetDemographic>
                        <hql:in_ClubCardId>${identifier}</hql:in_ClubCardId>
                    </hql:GetDemographic>
                </soapenv:Body>
            </soapenv:Envelope>`;
    };
}