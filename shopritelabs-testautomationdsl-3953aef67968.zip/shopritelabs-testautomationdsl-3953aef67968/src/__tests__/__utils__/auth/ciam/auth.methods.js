import qs from 'qs';
import {encode} from '../../encryption.util';
import ApiMethodUtil from '../../api_method_util';

const apiCall = new ApiMethodUtil();
/**
 * Authentication methods for CIAM
 */
export default class Authentication {

    /**
     * eCommerce Cognito authentication method
     * @param {string} url
     * @returns {Promise<AxiosResponse<any>|*|undefined>}
     */
    eCommerceCognitoAuth = async (url) => {
        const authUrl = process.env.CIAMDSLCognitoUrl;
        let clientId = process.env.PetShopScienceCognitoId;
        let clientSecret = process.env.PetShopScienceCognitoSecret;

        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        return await apiCall.POST(authUrl, qs.stringify(data), headers);
    };

    /**
     * PetShopScience Cognito authentication method
     * @param {string} url
     * @returns {Promise<AxiosResponse<any>|*|undefined>}
     */
    petShopScienceCognitoAuth = async (url) => {
        const authUrl = process.env.CIAMDSLCognitoUrl;
        let clientId = process.env.PetShopScienceCognitoId;
        let clientSecret = process.env.PetShopScienceCognitoSecret;

        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        return await apiCall.POST(authUrl, qs.stringify(data), headers);
    };

    /**
     * CIAM Cognito authentication method
     * @param {string} url
     * @returns {Promise<AxiosResponse<any>|*|undefined>}
     */
    ciamFNBCognitoAuth = async (url) => {
        const authUrl = process.env.CIAMDSLCognitoUrl;
        let clientId = process.env.CIAMFNBCognitoClientId;
        let clientSecret = process.env.CIAMFNBCognitoClientSecret;

        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        return await apiCall.POST(authUrl, qs.stringify(data), headers);
    };

    /**
     * CIAM Cognito authentication method
     * @param {string} url
     * @returns {Promise<AxiosResponse<any>|*|undefined>}
     */
    ciamASMCognitoAuth = async (url) => {
        const authUrl = process.env.CIAMDSLCognitoUrl;
        let clientId = process.env.CIAMASMCognitoClientId;
        let clientSecret = process.env.CIAMASMCognitoClientSecret;

        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        return await apiCall.POST(authUrl, qs.stringify(data), headers);
    };

    /**
     * CIAM Cognito authentication method
     * @param {string} url
     * @returns {Promise<AxiosResponse<any>|*|undefined>}
     */
    ciamC4CCognitoAuth = async (url) => {
        const authUrl = process.env.CIAMDSLCognitoUrl;
        let clientId = process.env.C4CLCognitoClientId;
        let clientSecret = process.env.C4CCognitoClientSecret;

        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        return await apiCall.POST(authUrl, qs.stringify(data), headers);
    };

    ciamMoneyMarketPOSCognitoAuth = async (url) => {
        const authUrl = process.env.CIAMDSLCognitoUrl;
        let clientId = process.env.MoneyMarketPOSCognitoClientId;
        let clientSecret = process.env.MoneyMarketPOSCognitoClientSecret;

        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        return await apiCall.POST(authUrl, qs.stringify(data), headers);
    };

    ciamMoneyMarketCognitoAuth = async (url) => {
        const authUrl = process.env.CIAMDSLCognitoUrl;
        let clientId = process.env.MoneyMarketCognitoClientId;
        let clientSecret = process.env.MoneyMarketCognitoClientSecret;

        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        return await apiCall.POST(authUrl, qs.stringify(data), headers);
    };

    /**
     * @param {string} RequestUrl
     * @param {string} identifier
     * @param {string} system
     * @returns {Promise<AxiosResponse<any>|*|undefined>}
     */
    ciam_trusted_auth = async (RequestUrl, identifier, system) => {
        let auth_url = "";
        let apiKeyValue = "";
        let url = `${process.env.CIAM}/ciam/user/login`;
        if (identifier === undefined) {
            return;
        }

        if (identifier.includes("+")) {
            auth_url = `${url}/phoneNumber/${identifier}`;
        } else if (identifier.includes("@")) {
            auth_url = `${url}/email/${identifier}`;
        } else {
            auth_url = `${url}/idNumber/${identifier}`;
        }

        if (system.includes("dsl")) {
            apiKeyValue = process.env.CIAMDSLApiKey;
        }
        if (system.includes("c4c")) {
            apiKeyValue = process.env.CIAMC4CApiKey;
        }
        if (system.includes("sixty60")) {
            apiKeyValue = process.env.CIAMSixty60ApiKey;
        }

        const headers = {
            'Content-Type': 'application/json',
            'x-api-key': apiKeyValue,
            'Authorization': `Bearer ${globalThis.cognitoCIAMToken}`
        };

        let response = await apiCall.GET(auth_url, headers, null);
        if (response.status === 404) {
            console.log(`retry getting AccessToken for ${identifier}`);
            await new Promise(resolve => setTimeout(resolve, 30000)); // 30 sec
            response = await apiCall.GET(auth_url, headers, null);
        }
        return response;
    };

    /**
     * @returns {Promise<{Authorization: string, Accept: string, UIUser: string, ContractID: string}>}
     */
    c4c_auth = async () => {
        const c4cAuthUserName = process.env.C4CClientID;
        const c4cAuthPassword = process.env.C4CClientSecret;
        let credential = encode(c4cAuthUserName + ":" + c4cAuthPassword);
        return {
            'Accept': 'application/json',
            'ContractID': '9bac3c4b-2957-4132-854c-f2b310572b98',
            'UIUser': 'caapi_mrkt_contacts',
            'Authorization': `Basic ${credential}`
        };
    };

    occ_auth = async () => {
        const clientId = 'dslClient';
        const clientSecret = 'secret';
        const credential = encode(`${clientId}:${clientSecret}`);
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data = {
            grant_type: 'client_credentials',
            scope: ''
        };

        return await apiCall.POST('https://rewardsapi.prep.shopritelabs.co.za/authorizationserver/oauth/token', qs.stringify(data), headers);
    };

    lpro_session_key_auth = async (payload, env) => {
        let url, contractID;
        if (env === 'qa') {
            url = `${process.env.LPRO}/login/service`;
            contractID = process.env.LPROLoginContractID;
        }
        if (env === 'prep') {
            url = `${process.env.LPRO}/login/service`;
            contractID = process.env.LPROLoginContractID;
        }
        let lproAuthUserName = process.env.LPROClientID;
        let lproAuthPassword = process.env.LPROClientSecret;
        let credentials = encode(`${lproAuthUserName}:${lproAuthPassword}`);

        const headers = {
            'Content-Type': 'text/xml',
            Authorization: "Basic " + credentials,
            ContractID: contractID,
            UIUser: "ncrlpro_login"
        };
        let {data} = await apiCall.POST(url, payload, headers);
        const parseString = require('xml2js').parseString;
        let response;
        parseString(data, async function (err, result) {
            response = JSON.stringify(result, null, 2);
        });
        let json = JSON.parse(response);
        return json['soap:Envelope']['soap:Body'][0]['UserLoginResponse'][0]['out_SessionKey'].toString();
    };
}
