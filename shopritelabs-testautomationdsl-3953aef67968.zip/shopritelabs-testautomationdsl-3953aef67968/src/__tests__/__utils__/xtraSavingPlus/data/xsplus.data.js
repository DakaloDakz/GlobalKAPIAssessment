'use strict';
export default class XsplusData {
    registerCustomerSubscription = (uid, email, mobileNumber, paymentCardToken, subscriptionItemId, couponId) => {
        return {
            "uid": uid,
            "email": email,
            "mobileNumber": mobileNumber,
            "paymentCardToken": paymentCardToken,
            "subscriptionItemId": subscriptionItemId,
            "couponId": couponId
        };
    };
    patchBillingInformation = (email, mobileNumber, paymentCardToken, termEndDate) => {
        return {
            "email": email,
            "mobileNumber": mobileNumber,
            "paymentCardToken": paymentCardToken,
            "termEndDate": termEndDate
        };
    };
    addSubscriptions = (uid, subscriptionItemId, couponId) => {
        return {
            "uid": uid,
            "subscriptionItemId": subscriptionItemId,
            "couponId": couponId
        };
    };
}