import fsPromise from "fs/promises";
import AkamaiGetEntity from "./akamai.get.entity";
import ApiMethodUtil from "../../__utils__/api_method_util";

const apiCall = new ApiMethodUtil(false);
const akamaiGetEntity = new AkamaiGetEntity();

export default class CardService {
    constructor() {
        this.cache = {};
    }

    getCardOffline = async (used = false, brand) => {
        const cards = await this.getCards(brand);
        const index = this.getUnusedCardIndex(cards);
        return this.processCards(cards, index, used, brand);
    };

    getCards = async (brand) => {
        let cards;
        const fileExists = async path => !!(await fsPromise.stat(path).catch(e => false));
        if (brand === 'shoprite') {
            cards = globalThis.shopriteCards;
            if (cards === undefined && await fileExists(`${process.cwd()}/cards/${globalThis.environment}_shoprite_new.json`)) {
                cards = require(`${process.cwd()}/cards/${globalThis.environment}_shoprite_new.json`);
            }
        }
        if (brand === 'checkers') {
            cards = globalThis.checkersCards;
            if (cards === undefined && await fileExists(`${process.cwd()}/cards/${globalThis.environment}_checkers_new.json`)) {
                cards = require(`${process.cwd()}/cards/${globalThis.environment}_checkers_new.json`);
            }
        }
        return cards;
    };

    getUnusedCardIndex = (cards) => {
        return cards.findIndex((element) => {
            return element.used === false;
        });
    };

    processCards = async (cards, index, used, brand) => {
        if (index !== -1) {
            if (used === true) {
                return cards[0].number;
            }
            for (let i = index; i < cards.length; i++) {
                let isValidCard = await this.#checkCardValidity(cards[i].number, brand);
                if (used === false && isValidCard === false) {
                    cards[i].used = true;
                }
                if (isValidCard) {
                    cards[i].used = true;
                    let akamaiCheck = await akamaiGetEntity.getEntityCards(cards[i].number, brand);
                    if (akamaiCheck > 0) {
                        continue;
                    }
                    console.log(`***Valid Card - ${cards[i].number}***`);
                    return cards[i].number;
                }
            }
        } else {
            throw Error("No Valid Cards found");
        }
        return "00000000000000000000000";
    };

    /**
     * Checks the validity of a card number.
     * @async
     * @private
     * @param {string} number - The card number to check.
     * @param brand
     * @returns {promise<boolean>} - Whether the card is valid or not.
     */
    async #checkCardValidity(number, brand) {
        if (this.cache[number] !== undefined) {
            return this.cache[number];
        }
        const body = {cardNumber: number};
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            "x-api-key": process.env.DSLCIAMApiKey,
            "Content-Type": "application/json"
        };
        const response = await apiCall.POST(
            `${process.env.DSLGroup}/dsl/brands/${brand}/countries/za/users/card/validate`,
            body,
            headers
        );
        const isValid = response.status === 200 && response.data.response === "Valid card";
        this.cache[number] = isValid;
        return isValid;
    }
}
