import ApiMethodUtil from "../api_method_util";
import {parseString} from "xml2js";

const apiCall = new ApiMethodUtil();

export default class GetCardsFromLPRO {
    async getSessionKey(env) {
        let url;
        if (env.includes("prep")) {
            url = 'http://lprqaweb3.qa.shoprite.co.za/HQCoreWS/Authorization/Login.asmx';
        }
        if (env.includes("qa")) {
            url = 'http://ilb-lpr-int-web01.shopint.co.za/HQCoreWS/Authorization/Login.asmx';
        }
        let xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:hql="http://www.retalix.com/HQLWebServices">
                   <soapenv:Header/>
                   <soapenv:Body>
                      <hql:UserLogin>
                         <!--Optional:-->
                         <hql:in_UserName>SAPCommerce</hql:in_UserName>
                         <!--Optional:-->
                         <hql:in_Password>$@P(omM3rcE</hql:in_Password>
                      </hql:UserLogin>
                   </soapenv:Body>
                </soapenv:Envelope>`;
        const headers = {
            'Content-Type': 'text/xml'
        };
        let {data} = await apiCall.POST(url, xml, headers);
        console.log(data);
        const parseString = require('xml2js').parseString;
        let sessionKey;
        parseString(data, async function (err, result) {
            sessionKey = JSON.stringify(result, null, 2);
        });
        let json = JSON.parse(sessionKey);
        return json['soap:Envelope']['soap:Body'][0]['UserLoginResponse'][0]['out_SessionKey'].toString();
    }

    async getListOfCards(env, session_key, brandCode, binRange, numberOfCards) {
        let url;
        if (env.includes("prep")) {
            url = "http://lprqaweb3.qa.shoprite.co.za/XtraSavingsCards/XtraSavingsCards.svc";
        }
        if (env.includes("qa")) {
            url = "http://lprintweb1.shopint.co.za/XtraSavingsCards/XtraSavingsCards.svc";
        }
        let xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
           <soapenv:Header/>
           <soapenv:Body>
              <tem:CreateNumbersToResults>
                 <!--Optional:-->
                 <tem:sessionKey>${session_key}</tem:sessionKey>
                 <!--Optional:-->
                 <tem:brand>${brandCode}</tem:brand>
                 <tem:binRange>${binRange}</tem:binRange>
                 <!--Optional:-->
                 <tem:minRange>0</tem:minRange>
                 <!--Optional:-->
                 <tem:maxRange>${numberOfCards}</tem:maxRange>
                 <!--Optional:-->
                 <tem:unAssignedOnly>true</tem:unAssignedOnly>
                 <!--Optional:-->
                 <tem:includeHeader>false</tem:includeHeader>
                 <!--Optional:-->
                 <tem:delimiter>|</tem:delimiter>
              </tem:CreateNumbersToResults>
           </soapenv:Body>
        </soapenv:Envelope>`;
        const headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'http://tempuri.org/IXtraSavingsCards/CreateNumbersToResults'
        };
        let cards;
        let {data} = await apiCall.POST(url, xml, headers);
        parseString(data, async function (err, result) {
            cards = JSON.stringify(result, null, 2);
            console.log(cards);
        });
        let json = JSON.parse(cards);
        return json['s:Envelope']['s:Body'][0]['CreateNumbersToResultsResponse'][0]['CreateNumbersToResultsResult'][0];
    }
}