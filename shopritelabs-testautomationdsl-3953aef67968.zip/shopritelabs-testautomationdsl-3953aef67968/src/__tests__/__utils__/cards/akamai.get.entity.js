import ApiMethodUtil from "../../__utils__/api_method_util";
import {encode} from "../encryption.util";

const apiCall = new ApiMethodUtil(false);

export default class AkamaiGetEntity {
    username;
    password;

    async getEntityCards(cardNumber, brand) {
        const {
            registration_realm,
            username,
            password
        } = this.getEnvironmentDetails();
        const credential = encode(`${username}:${password}`);
        const url = `https://${registration_realm}.janraincapture.com/entity.find?include_record=true&type_name=user&filter=cards.za.rewards.${brand}.number=\'${cardNumber}\'`;
        const headers = {'Authorization': `Basic ${credential}`};
        const response = await apiCall.GET(url, headers, null);
        return response.data.result_count;
    }

    async akamaiFindCustomerUsingFilter(filter) {
        const {
            registration_realm,
            username,
            password
        } = this.getEnvironmentDetails();
        const credential = encode(`${username}:${password}`);
        const url = `https://${registration_realm}.janraincapture.com/entity.find?include_record=true&type_name=user&filter=${filter}`;
        const headers = {'Authorization': `Basic ${credential}`};
        const response = await apiCall.GET(url, headers, null);
        return response.data;
    }

    async akamaiFindCustomerByUUID(uuid) {
        const customer = await this.akamaiFindCustomerUsingFilter(`uuid='${uuid}'`);
        return customer.results[0];
    }

    getEnvironmentDetails() {
        const {
            akamaiRealm: registration_realm,
            akamaiUsername: username,
            akamaiPassword: password
        } = process.env;
        return {
            registration_realm,
            username,
            password
        };
    }
}
