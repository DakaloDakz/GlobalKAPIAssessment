import axios from 'axios';
import * as AxiosLogger from 'axios-logger';
import {setGlobalConfig} from 'axios-logger';
/**
 * Utility class for making API calls.
 */
export default class ApiMethodUtil {
    /**
     * Constructor for the ApiMethodUtil class.
     * @param {boolean} logToConsole - Whether to log API responses to the console.
     */
    constructor(logToConsole = globalThis.logToConsole) {
        setGlobalConfig({
            prefixText: this.constructor.name,
            logger: console.error,
            params: true,
            statusText: false,
            dateFormat: 'HH:MM:ss'
        });
        this.instance = axios.create({
            headers: {'Content-Type': 'application/json'},
            timeout: 60000
        });
        this.addInterceptors(logToConsole);
    }

    /**
     * Adds interceptors to the axios instance for logging and measuring request duration.
     * @param {boolean} logToConsole - Whether to log API responses to the console.
     */
    addInterceptors(logToConsole) {
        this.instance.interceptors.request.use((config) => {
            config.headers['request-startTime'] = new Date().getTime();
            return config;
        });
        this.instance.interceptors.response.use((response) => {
            response.headers['request-duration'] = new Date().getTime() - response.config.headers['request-startTime'];
            return response;
        });
        if (logToConsole) {
            this.instance.interceptors.response.use(AxiosLogger.responseLogger, AxiosLogger.errorLogger);
        }
    }

    /**
     * Sends a request to the specified URL with the provided method, data, headers, and params.
     * @async
     * @param {string} method - The HTTP method to use for the request.
     * @param {string} url - The URL to send the request to.
     * @param {Object} data - The data to send in the body of the request.
     * @param {Object} headers - The headers to include in the request.
     * @param {Object} params - The parameters to include in the request.
     * @returns {Promise<Object>} The response from the server.
     */
    async sendRequest(method, url, data, headers, params) {
        try {
            return await this.instance({
                method,
                maxBodyLength: Infinity,
                url,
                data,
                headers,
                params
            });
        } catch (error) {
            return error.response;
        }
    }

    /**
     * Sends a POST request to the specified URL with the provided data and headers.
     * @async
     * @param {string} url - The URL to send the request to.
     * @param {Object} data - The data to send in the body of the request.
     * @param {Object} headers - The headers to include in the request.
     * @returns {Promise<Object>} The response from the server.
     */
    POST = async (url, data, headers) => this.sendRequest('post', url, data, headers);

    /**
     * Sends a PATCH request to the specified URL with the provided data and headers.
     * @async
     * @param {string} url - The URL to send the request to.
     * @param {Object} data - The data to send in the body of the request.
     * @param {Object} headers - The headers to include in the request.
     * @returns {Promise<Object>} The response from the server.
     */
    PATCH = async (url, data, headers) => this.sendRequest('patch', url, data, headers);

    /**
     * Sends a PUT request to the specified URL with the provided data and headers.
     * @async
     * @param {string} url - The URL to send the request to.
     * @param {Object} data - The data to send in the body of the request.
     * @param {Object} headers - The headers to include in the request.
     * @returns {Promise<Object>} The response from the server.
     */
    PUT = async (url, data, headers) => this.sendRequest('put', url, data, headers);

    /**
     * Sends a GET request to the specified URL with the provided headers and parameters.
     * @async
     * @param {string} url - The URL to send the request to.
     * @param {Object} headers - The headers to include in the request.
     * @param {Object} params - The parameters to include in the request.
     * @returns {Promise<Object>} The response from the server.
     */
    GET = async (url, headers, params) => this.sendRequest('get', url, null, headers, params);

    /**
     * Sends a DELETE request to the specified URL with the provided data and headers.
     * @async
     * @param {string} url - The URL to send the request to.
     * @param {Object} data - The data to send in the body of the request.
     * @param {Object} headers - The headers to include in the request.
     * @returns {Promise<Object>} The response from the server.
     */
    DELETE = async (url, data, headers) => this.sendRequest('delete', url, data, headers);
}
