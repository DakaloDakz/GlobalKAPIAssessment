import ApiMethodUtil from "./api_method_util";
import {encode} from "./encryption.util";

// Use the API method utility
const apiCall = new ApiMethodUtil();

/**
 * InsiderApi class for handling API calls to the Insider API.
 */
export default class InsiderApi {
    // Define the events related to the customer identity and access management (CIAM)
    ciamEvents = {
        CREATE_USER: "user_created",
        CARD_REGISTERED: "rewards_card_registered",
        MARKETING_CONSENT: "marketing_consent_updated",
        BENEFITS_UPDATED: "benefit_updated",
        CARD_CANCELLED: "rewards_card_cancelled"
    };

    /**
     * Constructor for the InsiderApi class.
     * @param {string} brand - The brand name.
     */
    constructor(brand) {
        this.X_PARTNER_NAME = process.env[`INSIDER_${brand.toUpperCase()}_PARTNER_NAME`];
        this.credentials = encode(`${process.env.INSIDER_USERNAME}:${process.env.INSIDER_PASSWORD}`);
    }

    /**
     * Upsert a customer to the Insider API.
     * @param {string} uuid - The unique identifier of the customer.
     * @param {Object} data - The data of the customer.
     * @returns {Promise} The response from the API call.
     */
    async upsertCustomer(uuid, data) {
        const config = this._getConfig('post', process.env.INSIDER_GET_UPSERT_URL, data);
        return apiCall.POST(config.url, config.data, config.headers);
    }

    /**
     * Get a customer from the Insider API.
     * @param {Object} identifierObject - The identifier object of the customer.
     * @param {Array} events - The events related to the customer.
     * @returns {Promise} The response from the API call.
     */
    async getCustomerInsider(identifierObject, events) {
        const data = this._getCustomerInsiderData(identifierObject, events);
        const config = this._getConfig('post', process.env.INSIDER_GET_PROFILE_URL, data);
        return apiCall.POST(config.url, config.data, config.headers);
    }

    /**
     * Delete a customer from the Insider API.
     * @param {string} email - The email of the customer.
     * @returns {Promise} The response from the API call.
     */
    async deleteCustomer(email) {
        const data = {"identifiers": {"email": email}};
        const config = this._getConfig('delete', 'https://unification.useinsider.com/api/user/v1/identity', data);
        return apiCall.DELETE(config.url, config.headers, config.data);
    }

    /**
     * Get the configuration for an API call.
     * @param {string} method - The HTTP method of the API call.
     * @param {string} url - The URL of the API call.
     * @param {Object} data - The data of the API call.
     * @returns {Object} The configuration for the API call.
     * @private
     */
    _getConfig(method, url, data) {
        return {
            method: method,
            maxBodyLength: Infinity,
            url: url,
            headers: {
                Authorization: `Basic ${this.credentials}`,
                ContractID: process.env.INSIDER_CONTRACT_ID,
                'X-PARTNER-NAME': this.X_PARTNER_NAME,
                'Content-Type': 'application/json',
                'Accept-Encoding': 'none'
            },
            data: data
        };
    }

    /**
     * Get the data for a getCustomerInsider API call.
     * @param {Object} identifierObject - The identifier object of the customer.
     * @param {Array} events - The events related to the customer.
     * @returns {string} The data for the API call.
     * @private
     */
    _getCustomerInsiderData(identifierObject, events) {
        let d = new Date();
        d.setDate(d.getDate() - 5);
        return JSON.stringify({
            "identifiers": identifierObject,
            "attributes": ["*"],
            "events": {
                "start_date": Math.floor(d.getTime() / 1000.0),
                "end_date": Math.floor(new Date().getTime() / 1000.0),
                "wanted": events
            }
        });
    }
}
