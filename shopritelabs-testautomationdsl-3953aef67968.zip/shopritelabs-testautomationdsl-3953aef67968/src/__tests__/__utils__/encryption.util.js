const crypto = require("crypto");
const algorithm = "aes-256-gcm";
const initVector = crypto.randomBytes(16);
const securityKey = crypto.randomBytes(32);

const encrypt = (data) => {
    const cipher = crypto.createCipheriv(algorithm, securityKey, initVector);
    let encryptedData = cipher.update(data, "utf-8", "hex");
    encryptedData += cipher.final("hex");
    const authTag = cipher.getAuthTag().toString('hex');
    return {
        encryptedData,
        authTag
    };
};

const decrypt = (data) => {
    const decipher = crypto.createDecipheriv(algorithm, securityKey, initVector);
    return decipher.update(data, "hex", "utf-8") + decipher.final("utf8");
};

const encode = (data) => Buffer.from(data).toString('base64');
const decode = (data) => Buffer.from(data, 'base64');
module.exports = {
    encode,
    decode,
    encrypt,
    decrypt
};
