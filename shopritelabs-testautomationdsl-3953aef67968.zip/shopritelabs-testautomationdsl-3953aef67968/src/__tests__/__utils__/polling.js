import chalk from "chalk";

export async function poll(func, timeout, interval, maxAttempts, ...funcArgs) {
    let attempts = 0;

    const executePoll = async () => {
        try {
            const result = await func(...funcArgs);
            attempts++;
            console.log(chalk.red(`Polling attempt ${attempts}`));
            if (result !== undefined && result !== null || result?.data !== 200) {
                return result;
            } else if (attempts === maxAttempts) {
                throw new Error('Maximum attempts reached');
            } else {
                setTimeout(executePoll, interval);
            }
        } catch (error) {
            console.error(`Error occurred during polling: ${error}`);
            throw error;
        }
    };

    await new Promise(resolve => setTimeout(resolve, timeout));
    return executePoll();
}

export async function func(uuid, expectedValue, insiderPanel) {
    let identifierObj = {
        "uuid": uuid
    };
    let events = [
        {
            "event_name": "user_created",
            "params": [
                "timestamp",
                "event_params",
                "custom"
            ]
        }
    ];

   let result =  await insiderPanel.getCustomerInsider(identifierObj, events);

   if(result.status === 200 && findValue(result.data, expectedValue.toLowerCase())) {
       return result;
   }else {
       return undefined;
   }
}

function findValue(obj, value) {
    for (let key in obj) {
        if (obj[key] === value) {
            return true;
        }
        if (typeof obj[key] === 'object' || Array.isArray(obj[key])) {
            if (findValue(obj[key], value)) {
                return true;
            }
        }
    }
    return false;
}
