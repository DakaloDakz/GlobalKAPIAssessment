import _ from 'lodash';
import {diff} from "jest-diff";
import {getType} from "jest-get-type";
import {format as prettyFormat} from 'pretty-format';
import {parseString} from "xml2js";
import {csv2json} from "csv2json";
import * as fs from "fs";
import xmlFormat from 'xml-formatter';
import * as util from "util";
import Duration from "duration-js";
import crypto from "crypto";

const phoneUtil = require('google-libphonenumber').PhoneNumberUtil.getInstance();

const Ajv = require("ajv");
const ajv = new Ajv();
const fsPromise = require('fs/promises');

/* https://lodash.com/docs/4.17.15 */

/**
 * This class contains helper functions for working with data.
 */
export default class DataHelpers {

    /**
     * This function replaces the value of the supplied keys with text: [SANITIZED]
     * @param {object} data - The object to sanitize
     * @param {array} keys - The keys to sanitize
     * @returns {*}
     */
    sanitize(data, keys) {
        return keys.reduce((result, key) => {
            const val = _.get(result, key);
            if (!val || _.isArray(val) || _.isObject(val)) {
                return result;
            }
            return _.set(_.cloneDeep(result), key, '[SANITIZED]');
        }, data);
    }

    /**
     * The function returns the value for a specific key in an object
     * @param {object} data
     * @param {string} path
     * @returns {*}
     */
    getValueFromJson(data, path) {
        return _.get(data, path);
    }

    /**
     * This function updates the value for a specific key in an object
     * @param {object} data
     * @param {string} key
     * @param {any} value
     * @returns {*}
     */
    setValueInJson(data, key, value) {
        return _.set(data, key, value);
    }

    /**
     * The function removed the specified field from the object
     * @param {object} data
     * @param {string} key
     * @returns {Pick<object, Exclude<keyof object, [*[]][number]>>}
     */
    removeObjectInJson(data, key) {
        return _.omit(data, [key]);
    }

    /**
     * Returns the data type of the input supplied
     * @param {*} input
     * @returns {*}
     */
    getDataType(input) {
        return getType(input);
    }

    /**
     *  This function returns the difference between two objects
     * @param {object} a
     * @param {object} b
     * @returns {string}
     */
    diffBetweenObjects(a, b) {
        return diff(a, b);
    }

    /**
     * This function prettifies JSON data
     * @param {object} json - The JSON data to prettify
     * @returns {string} - The prettified JSON data
     */
    prettify(json) {
        return prettyFormat(json);
    }

    /**
     * This function prettifies XML data
     * @param {string} xml - The XML data to prettify
     * @returns {string} - The prettified XML data
     */
    prettifyXML(xml) {
        return xmlFormat(xml);
    }

    /**
     * This function logs data to the console
     * @param {*} data - The data to log
     */
    log(data) {
        return console.log(data);
    }

    /**
     * This function converts XML data to JSON
     * @param {string} data - The XML data to convert
     * @returns {object} - The converted JSON data
     */
    xml2json(data) {
        let response;
        parseString(data, async function (err, result) {
            response = JSON.stringify(result, null, 2);
        });
        return JSON.parse(response);
    }

    /**
     * This function converts CSV data to JSON
     * @param {string} input - The input CSV file path
     * @param {string} output - The output JSON file path
     */
    csv2json(input, output) {
        fs.createReadStream(input)
            .pipe(csv2json({
                // Defaults to comma.
                separator: ','
            }))
            .pipe(fs.createWriteStream(output));
    }

    /**
     * This function validates the given data against the provided JSON schema.
     * @param {object} schema - The JSON schema to validate against.
     * @param {object} data - The data to validate.
     * @returns {object} - An object containing a success flag and any validation errors.
     */
    validateSchema(schema, data) {
        const validate = ajv.compile(schema);
        const valid = validate(data);
        return {
            success: valid,
            errors: validate.errors
        };
    }

    /**
     * This function generates a random international phone number unless isSouthAfrican is set to true
     * @param {boolean} isSouthAfrican - If true, generates a South African phone number.
     * Otherwise, it generates a random international phone number.
     * @returns {string} - The generated phone number.
     */
    generatePhoneNumber(isSouthAfrican = false) {
        let array = new Uint32Array(1);
        const DialingCodes = isSouthAfrican ? ["+27"] : ["+61", "+267", "+264", "+1", "+44"];
        let phoneNumber;
        do {
            crypto.randomFillSync(array);
            const dialingCode = DialingCodes[array[0] % DialingCodes.length];
            crypto.randomFillSync(array);
            const areaCode = array[0] % 1000;
            crypto.randomFillSync(array);
            const localNumber = array[0] % 10000000;
            phoneNumber = `${dialingCode}${areaCode}${localNumber}`;
        } while (!phoneUtil.isValidNumber(phoneUtil.parse(phoneNumber)));
        return phoneNumber;
    }

    /**
     * Determines the gender from a South African ID number.
     * The 7th to 10th digits of the ID number represent the gender.
     * A number from 0000 to 4999 indicates a female, and a number from 5000 to 9999 indicates a male.
     *
     * @param {string} idNumber - The South African ID number.
     * @returns {string} - The gender ("Female" or "Male") determined from the ID number.
     */
    getGenderFromIDNumber(idNumber) {
        const genderDigits = idNumber.slice(6, 10);
        return genderDigits <= 4999 ? "Female" : "Male";
    }

    /**
     * This function checks if a file is older than the provided duration
     * @param {string} filename - The path to the file to check
     * @param {*} duration - The duration to check against. Can be a string in the format "1d 2h 30m", or an object with properties "days", "hours", "minutes", "seconds", and "milliseconds".
     * @returns {boolean} - True if the file is older than the provided duration, false otherwise
     */
    fileOlderThan = async (filename, duration) => {
        let stats;
        try {
            stats = fs.statSync(filename);
        } catch (e) {
            return true;
        }
        const fileDate = new Date(util.inspect(stats.mtime));
        const parsed = Duration.parse(duration);
        return new Date() - parsed > fileDate;
    };

    /**
     * This function checks if a file exists at the given path
     * @param {string} path - The path to check for the file
     * @returns {boolean} - True if the file exists, false otherwise
     */
    fileExists = async path => !!(await fsPromise.stat(path).catch(e => false));

    randomDate = async () => {
        const start = new Date(2000, 0, 1);
        const end = new Date();
        const timeDifference = end.getTime() - start.getTime();
        const randomTime = this.generateRandomNumber(timeDifference.toString().length, 0, timeDifference);
        const randomDate = new Date(start.getTime() + Number(randomTime));
        const year = randomDate.getFullYear();
        const month = String(randomDate.getMonth() + 1).padStart(2, '0');
        const day = String(randomDate.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    };

    generateRandomNumber = (min = 0, max = 9) => {
        let randomNumber = '';
        const digit = crypto.randomInt(min, max + 1);
        randomNumber += digit.toString();
        // Ensure the number does not exceed max
        return parseInt(randomNumber) > max ? max : randomNumber;
    };
}
