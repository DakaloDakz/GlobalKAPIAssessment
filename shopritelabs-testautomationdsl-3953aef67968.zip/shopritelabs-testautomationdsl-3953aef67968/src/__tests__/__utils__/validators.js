module.exports = {
    validateTruthiness: (received) => {
        expect(received).not.toBeNull();
        expect(received).toBeTruthy();
    },
    validateBooleanValues: (received, boolean) => {
        expect(received).not.toBe(!boolean);
        expect(received).toBe(boolean);
    }
};