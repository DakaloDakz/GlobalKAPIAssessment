const Aws_s3 = require('aws-sdk');
const fs = require('fs');
const path = require('path');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
export default class S3FileManager {
    constructor(bucketName, accessKeyId, secretAccessKey) {
        this.bucketName = bucketName;
        this.accessKeyId = accessKeyId;
        this.secretAccessKey = secretAccessKey;
        this.allKeys = [];
        this.s3 = new Aws_s3.S3({
            accessKeyId: this.accessKeyId,
            secretAccessKey: this.secretAccessKey,
            region: 'eu-west-1',
            signatureVersion: 'v2'
        });
    }

    async getListFilesS3() {
        let token = undefined;
        const params = {
            Bucket: this.bucketName,
            Delimiter: '/',
            Prefix: 'ciam/outbound/cloudbi/customer/',
            ContinuationToken: token
        };

        try {
            do {
                const data = await this.s3.listObjectsV2(params).promise();
                token = data.NextContinuationToken;
                params.ContinuationToken = token;
                this.allKeys = this.allKeys.concat(data.Contents.map((file) => file.Key));
            } while (token !== undefined);
            return this.allKeys;
        } catch (err) {
            console.error(err);
            return [];
        }
    }

    /**
     * Downloads card files from S3.
     * @async
     * @method
     * @throws {Error} If there's an error while downloading and writing the file.
     */
    async downloadCardsFilesS3() {
        try {
            await this.downloadAndWriteFile("cards/prep_checkers_new.json");
            await this.downloadAndWriteFile("cards/prep_shoprite_new.json");
            await this.downloadAndWriteFile("cards/qa_checkers_new.json");
            await this.downloadAndWriteFile("cards/qa_shoprite_new.json");
        } catch (e) {
            console.log(e.stack);
        }
    }

    /**
     * Downloads a file from S3 and writes it to the local file system.
     * @async
     * @method
     * @param {string} key - The key of the file to be downloaded from S3.
     * @throws {Error} If there's an error while downloading the file from S3 or writing it to the local file system.
     */
    async downloadAndWriteFile(key) {
        let file = await this.s3.getObject({
            Bucket: this.bucketName,
            Key: key
        }).promise();
        await fs.writeFileSync(key, file.Body);
    }

    async downloadFilesS3() {
        let files = await this.getListFilesS3();
        files = files.reverse();
        let data = await this.s3.getObject({
            Bucket: this.bucketName,
            Key: files[0]
        }).promise();
        console.log(data.Body.toString());
        try {
            await fs.writeFileSync('downloadedFile.txt', data.Body);
        } catch (e) {
            console.log(e.stack);
        }
    }

    async uploadCardsFilesS3() {
        const files = fs.readdirSync(`${process.cwd()}/cards/`);
        const directoryPath = 'cards/';
        for (const file of files) {
            const filePath = path.join(directoryPath, file);
            const fileContent = fs.readFileSync(filePath);

            const params = {
                Bucket: this.bucketName,
                Key: directoryPath + file,
                Body: fileContent
            };

            try {
                let data = await this.s3.upload(params).promise();
                console.log(`Successfully uploaded ${filePath} to ${data.Location}`);
            } catch (e) {
                console.log(`Error uploading ${filePath}: ${e}`);
            }
        }
    }

    async uploadFileS3(fileDirectoryPath, fileName, uploadDirectoryPath) {
        const filePath = path.join(fileDirectoryPath, fileName);
        const fileContent = fs.readFileSync(filePath);

        const params = {
            Bucket: this.bucketName,
            Key: uploadDirectoryPath + fileName,
            Body: fileContent
        };

        try {
            let data = await this.s3.upload(params).promise();
            console.log(`Successfully uploaded ${filePath} to ${data.Location}`);
            return data.Location;
        } catch (e) {
            console.log(`Error uploading ${filePath}: ${e}`);
        }

    }
}



