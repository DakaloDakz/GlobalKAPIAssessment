'use strict';
export default class DSLOther {
    device_token_mkt = (fcmToken, firstName, lastName, mobileNumber, emailAddress) => {
        return {
            "fcmToken": fcmToken,
            "firstName": firstName,
            "lastName": lastName,
            "mobileNumber": mobileNumber,
            "emailAddress": emailAddress,
            "optOut": true
        };
    };
}