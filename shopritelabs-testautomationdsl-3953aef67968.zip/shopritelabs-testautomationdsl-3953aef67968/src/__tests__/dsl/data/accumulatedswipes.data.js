'use strict';
export default class DSLAccumulated {
    get_accumulatedswipes_payload = (uid, accountId) => {
        return {
            "uid": uid,
            "accountId": accountId
        };
    };
}