'use strict';
import {faker} from '@faker-js/faker';
import moment from "moment";
import fakeSaIdGenerator from 'south-african-fake-id-generator';
import CardService from "../../__utils__/cards/cardService";
import DataHelpers from "../../__utils__/data_helpers";
import CIAMAuth from "../../__utils__/auth/ciam/auth.methods";
import ApiMethodUtil from "../../__utils__/api_method_util";
import _ from "lodash";

const cardService = new CardService();
const dataHelpers = new DataHelpers();
const ciamAuth = new CIAMAuth();
const apiCall = new ApiMethodUtil();

export default class DSLCustomer {
    /**
     * Create DSL Customer
     * @param name
     * @param surname
     * @param email
     * @param mobileNumber
     * @param saIdNumber
     * @param birthDate
     * @param titleCode
     * @param cardNumber
     * @param password
     * @returns {Object} {preferredStoreId: string, firstName, lastName, uid, password: string, mobileNumber, saIdNumber, birthDate, titleCode}
     */
    create_customer_full = (name, surname, email, mobileNumber, saIdNumber, birthDate, titleCode, cardNumber, password) => {
        return {
            "preferredStoreId": "1103",
            "firstName": name,
            "lastName": surname,
            "uid": email,
            "mobileNumber": mobileNumber,
            "saIdNumber": saIdNumber,
            "birthDate": birthDate,
            "titleCode": titleCode,
            "cardNumber": `${cardNumber}`,
            "password": password
        };
    };

    /**
     * Create DSL Customer
     * @param name
     * @param surname
     * @param email
     * @param mobileNumber
     * @param saIdNumber
     * @param birthDate
     * @param cardNumber
     * @param type
     * @returns {Object} {preferredStoreId: string, firstName, lastName, uid, password: string, mobileNumber, saIdNumber, birthDate, titleCode}
     */
    create_customer_partial = (name, surname, email, mobileNumber, saIdNumber, birthDate, cardNumber, type) => {
        return {
            "identity": [
                {
                    "type": "SAID",
                    "value": saIdNumber
                }
            ],
            "userDetails": {
                "firstName": name,
                "lastName": surname,
                "type": type,
                "birthDate": birthDate
            },
            "contactDetails": [
                {
                    "description": "Contact Type by Automation",
                    "id": "05",
                    "type": "Mobile",
                    "value": mobileNumber
                }
            ],
            "foxCard": {
                "active": true,
                "cardNumber": `${cardNumber}`
            }
        };
    };

   /**
 * This asynchronous function is used to create a full customer with valid data.
 *
 * @async
 * @function create_customer_valid_full
 * @param {string} brand - The brand for which the customer is being created.
 * @param {boolean} [positive=false] - A flag indicating whether to generate a card number.
 * @param {boolean} [passportEmpty=true] - A flag indicating whether to generate a passport number.
 * @returns {Object} - An object representing a customer with the following properties:
 *   @property {string} preferredStoreId - The ID of the preferred store for the customer.
 *   @property {string} firstName - The first name of the customer.
 *   @property {string} lastName - The last name of the customer.
 *   @property {string} email - The email of the customer.
 *   @property {string} mobileNumber - The mobile number of the customer.
 *   @property {string} saIdNumber - The South African ID number of the customer.
 *   @property {string} birthDate - The birth date of the customer in 'DD/MM/YYYY' format.
 *   @property {string} titleCode - The title of the customer (e.g., 'mr').
 *   @property {string} cardNumber - The card number of the customer.
 *   @property {string} passportNumber - The passport number of the customer.
 */
create_customer_valid_full = async (brand, positive = false, passportEmpty = true) => {
    let cardNumber;
    if (positive) {
        cardNumber = await cardService.getCardOffline(false, brand);
    } else {
        cardNumber = "";
    }
    let name = _.startCase(_.toLower(faker.name.firstName()));
    let surname = _.startCase(_.toLower(faker.name.lastName()));
    let email = `${faker.internet.userName(name, surname)}@shoprite-testautomation.com`;
    let mobileNumber = dataHelpers.generatePhoneNumber(true);
    let birthDate = faker.date.between('1910-01-01', '2001-01-01');
    let dob = moment(new Date(birthDate)).format('DD/MM/YYYY');
    let saIdNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
        min: 18,
        max: 99
    }));
    let title = "mr";
    let passport;
    if (passportEmpty) {
        passport = '';
    } else {
        passport = faker.internet.password(15, false, /[0-9A-Z]/);
    }
    //let password = encode(faker.internet.password())
    return {
        "preferredStoreId": "1103",
        "firstName": name,
        "lastName": surname,
        "email": email,
        "mobileNumber": mobileNumber,
        "saIdNumber": saIdNumber,
        "birthDate": dob,
        "titleCode": title,
        "cardNumber": `${cardNumber}`,
        "passportNumber": passport
    };
};

    /**
     * Creat full customer with random data
     * @returns {{preferredStoreId: string, firstName: (*), lastName: (*), uid, mobileNumber, saIdNumber: string, birthDate: string, titleCode: string, cardNumber: string}}
     */
    create_customer_valid_full_uid = async (brand, positive = false) => {
        let cardNumber;
        if (positive) {
            cardNumber = await cardService.getCardOffline(false, brand);
        }
        let name = _.startCase(_.toLower(faker.name.firstName()));
        let surname = _.startCase(_.toLower(faker.name.lastName()));
        let email = `${faker.internet.userName(name, surname)}@shoprite-testautomation.com`;
        let mobileNumber = dataHelpers.generatePhoneNumber(true);
        let birthDate = faker.date.between('1910-01-01', '2001-01-01');
        let dob = moment(new Date(birthDate)).format('DD/MM/YYYY');
        let saIdNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        let title = "mr";
        // let passport = ${fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({min:18, max:99}))}
        //let password = encode(faker.internet.password())
        return {
            "preferredStoreId": "1103",
            "firstName": name,
            "lastName": surname,
            "uid": email,
            "mobileNumber": mobileNumber,
            "saIdNumber": saIdNumber,
            "birthDate": dob,
            "titleCode": title,
            "cardNumber": cardNumber,
            "passport": ''
        };
    };

    create_customer_valid_partial = async (brand, withCard, isSouthAfrican = true) => {
        let cardNumber;
        if (withCard) {
            cardNumber = await cardService.getCardOffline(false, brand);
        }
        let name = _.startCase(_.toLower(faker.name.firstName()));
        let surname = _.startCase(_.toLower(faker.name.lastName()));
        let mobileNumber = dataHelpers.generatePhoneNumber(isSouthAfrican);
        let saIdNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        let date = saIdNumber.substring(0, 6);
        let dob;
        if (date.startsWith('0')) {
            dob = `${date.charAt(4)}${date.charAt(5)}/${date.charAt(2)}${date.charAt(3)}/20${date.charAt(0)}${date.charAt(1)}`;
        } else {
            dob = `${date.charAt(4)}${date.charAt(5)}/${date.charAt(2)}${date.charAt(3)}/19${date.charAt(0)}${date.charAt(1)}`;
        }
        let json = {
            "identity": [
                {
                    "type": "SAID",
                    "value": saIdNumber
                }
            ],
            "userDetails": {
                "firstName": name,
                "lastName": surname,
                "type": "ussd",
                "birthDate": dob
            },
            "contactDetails": [
                {
                    "description": "Contact Type by Automation",
                    "id": "05",
                    "type": "Mobile",
                    "value": mobileNumber
                }
            ],
            "foxCard": {
                "active": true,
                "cardNumber": `${cardNumber}`
            }
        };
        if (!withCard) {
            json = dataHelpers.removeObjectInJson(json, 'foxCard');
            json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        }
        return json;
    };

    create_customer_valid_partial_web = async (brand, isSouthAfrican = true) => {
        let name = _.startCase(_.toLower(faker.name.firstName()));
        let surname = _.startCase(_.toLower(faker.name.lastName()));
        let mobileNumber = dataHelpers.generatePhoneNumber(isSouthAfrican);
        let saIdNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        let date = saIdNumber.substring(0, 6);
        let dob;
        if (date.startsWith('0')) {
            dob = `${date.charAt(4)}${date.charAt(5)}/${date.charAt(2)}${date.charAt(3)}/20${date.charAt(0)}${date.charAt(1)}`;
        } else {
            dob = `${date.charAt(4)}${date.charAt(5)}/${date.charAt(2)}${date.charAt(3)}/19${date.charAt(0)}${date.charAt(1)}`;
        }
        return {
            "identity": [
                {
                    "type": "SAID",
                    "value": saIdNumber
                }
            ],
            "userDetails": {
                "firstName": name,
                "lastName": surname,
                "type": "web",
                "birthDate": dob
            },
            "contactDetails": [
                {
                    "description": "Contact Type by Automation",
                    "id": "05",
                    "type": "Mobile",
                    "value": mobileNumber
                },
                {
                    "description": "Contact Type by Automation",
                    "id": "05",
                    "type": "EMAIL",
                    "value": `${faker.internet.userName(name, surname)}@shoprite-testautomation.com`
                }
            ]
        };
    };

    /**
     * Generate invalid South African ID Number
     * @returns {string}
     */
    invalidIdNumber = () => {
        return fakeSaIdGenerator.generateInvalidFakeId();
    };

    createPartialComplete = async (brand, withCard = true) => {
        let json = await this.create_customer_valid_partial(brand, withCard);
        let response;
        let firstName;
        let lastName;
        let cardNumber;
        let mobileNumber;
        let retryCount = 0;
        do {
            retryCount++;
            const headers = {
                Authorization: `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            mobileNumber = json.contactDetails[0].value;
            if (withCard) {
                cardNumber = json.foxCard.cardNumber;
            } else {
                cardNumber = 'No Card';
            }
            firstName = json.userDetails.firstName;
            lastName = json.userDetails.lastName;
            response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/${brand}/countries/za/users/partialuser`, json, headers);
            await new Promise((r) => setTimeout(r, 10000));
        } while (response.status !== 200 && retryCount < 2);
        if (response.status !== 200) {
            throw new Error(`Failed to create customer after ${retryCount} retries`);
        }
        return {
            uuid: response.data.response.uuid,
            firstName: firstName,
            lastName: lastName,
            mobileNumber: mobileNumber,
            cardNumber: cardNumber
        };
    };

    createFullComplete = async (brand) => {
        let json = this.create_customer_valid_full(false, true);
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        let mobileNumber = json.mobileNumber;
        let cardNumber = json.cardNumber;
        let firstName = json.firstName;
        let lastName = json.lastName;
        let response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/${brand}/countries/za/users/full`, json, headers);
        return {
            uuid: response.data.response.uuid,
            firstName: firstName,
            lastName: lastName,
            mobileNumber: mobileNumber,
            cardNumber: cardNumber ?? 'No CARD'
        };
    };
}
