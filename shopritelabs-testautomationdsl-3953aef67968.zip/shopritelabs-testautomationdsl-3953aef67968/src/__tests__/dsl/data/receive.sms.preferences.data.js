'use strict';
export default class DSLRecievesms {
    get_receivesms_payload = (connectAccount, phoneNumber, optOut, sid, payloadVariables) => {
        return {

            "connectAccount": connectAccount,
            "phoneNumber": phoneNumber,
            "optOut": optOut,
            "sid": sid,
            "payloadVariables": payloadVariables
        };
    };
}