export default class DSLPageComponents {
    /**
     * Create DSL component
     */
    create_page_components = () => {
        return {
            "componentIds": []
        };

    };
}
