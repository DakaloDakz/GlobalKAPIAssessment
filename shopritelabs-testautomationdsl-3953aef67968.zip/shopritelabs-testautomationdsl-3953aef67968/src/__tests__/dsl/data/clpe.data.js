'use strict';
export default class DSLPreferences {
    /**
     * Create DSL Customer Consent
     */
    create_valid_user_consents = (consentTemplateId) => {
        return [
            {
                "consentTemplateId": consentTemplateId,
                "consentTemplateVersion": "1",
                "granted": true
            }
        ];
    };
    /**
     * Create DSL Customer Consent
     */
    create_user_consents = (consentTemplateId, consentTemplateVersion, granted) => {
        return [
            {
                "consentTemplateId": consentTemplateId,
                "consentTemplateVersion": consentTemplateVersion,
                "granted": granted
            }
        ];
    };
}