'use strict';
export default class ValueAddedServices {
    /**
     * Create DSL Customer Preference
     */
    message = (marketingArea, messageTemplateId, reference, mobileNumber, payloadVariable, buttonType, buttonValue) => {
        return {
            "marketingArea": marketingArea,
            "messageTemplateId": messageTemplateId,
            "reference": reference,
            "mobileNumber": mobileNumber,
            "payloadVariables": [
                payloadVariable
            ],
            "buttonType": buttonType,
            "buttonValues": [
                buttonValue
            ]
        };
    };

    messageStatus = () => {
        return {
            "client_reference": "5a05269531b04bdc9174024c043c45b5",
            "server_reference": "218ec066c4164be881c8486218fe48df",
            "status": "delivered",
            "date_at": "2020-05-03 17:34:12"
        };
    };

    services = (uid, status, service) => {
        return {
            "uid": uid,
            "status": status,
            "service": service
        };
    };
}