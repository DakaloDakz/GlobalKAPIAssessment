import moment from "moment";
import _ from "lodash";
import {faker} from "@faker-js/faker";
import fakeSaIdGenerator from "south-african-fake-id-generator";
import DataHelpers from "../../__utils__/data_helpers";

const dataHelpers = new DataHelpers();

class DiscoveryData {
    activation = (effectiveDateTime, legalRefNumber, legalRefType, dob) => ({
        effectiveDateTime,
        legalRefNumber,
        legalRefType,
        dob
    });

    deactivate = (effectiveDateTime, customerNumber) => ({
        effectiveDateTime,
        customerNumber
    });

    enrolment = (effectiveDateTime, legalRefNumber, legalRefType, firstName, lastName, dob, cellPhoneNumber, emailAddress, consentTemplateId, consentGranted, contactPreferenceCode, contactPreferenceActive) => ({
        effectiveDateTime,
        legalRefNumber,
        legalRefType,
        firstName,
        lastName,
        dob,
        cellPhoneNumber,
        emailAddress,
        consent: [{
            consentTemplateId: consentTemplateId,
            consentTemplateVersion: "1",
            granted: consentGranted
        }],
        contactPreferences: [{
            active: contactPreferenceActive,
            code: contactPreferenceCode
        }]
    });

    enrolmentValidDetails = (legalRefType = "IDN") => {
        let effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        let firstName = _.startCase(_.toLower(faker.name.firstName()));
        let lastName = _.startCase(_.toLower(faker.name.lastName()));
        let cellPhoneNumber = dataHelpers.generatePhoneNumber(true);
        let emailAddress = `${faker.internet.userName(firstName, lastName)}@shoprite-testautomation.com`;
        let dob;
        let date;
        let legalRefNumber;
        if (legalRefType === "IDN") {
            legalRefNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
                min: 18,
                max: 99
            }));
            date = legalRefNumber.substring(0, 6);
            if (date.startsWith('0')) {
                dob = `20${date.charAt(0)}${date.charAt(1)}-${date.charAt(2)}${date.charAt(3)}-${date.charAt(4)}${date.charAt(5)}`;
            } else {
                dob = `19${date.charAt(0)}${date.charAt(1)}-${date.charAt(2)}${date.charAt(3)}-${date.charAt(4)}${date.charAt(5)}`;
            }
        } else {
            do {
                dob = faker.date.past(dataHelpers.generateRandomNumber(18, 100)).toISOString().substring(0, 10);
            } while (moment().diff(moment(dob), 'years') < 18);
            legalRefNumber = faker.internet.password(15, false, /[0-9A-Z]/);
        }

        return {
            effectiveDateTime,
            legalRefNumber,
            legalRefType,
            firstName,
            lastName,
            dob,
            cellPhoneNumber,
            emailAddress,
            consent: [
                {
                    consentTemplateId: "checkers-za-marketing-consent",
                    consentTemplateVersion: "1",
                    granted: true
                },
                {
                    consentTemplateId: "checkers-za-rewards-consent",
                    consentTemplateVersion: "1",
                    granted: true
                }
            ],
            contactPreferences: [
                {
                    active: true,
                    code: "SMS"
                },
                {
                    active: true,
                    code: "EMAIL"
                },
                {
                    active: true,
                    code: "WHATSAPP"
                }]
        };
    };

    verification = (effectiveDateTime, legalRefNumber, legalRefType, dob) => ({
        effectiveDateTime,
        legalRefNumber,
        legalRefType,
        dob
    });

    benefit = (customerNumber, activateStatus, healthyFoodOnline, healthyFoodInStore, changeOnline, changeInStore) => ({
        customerNumber,
        activateStatus,
        healthyFoodOnline,
        healthyFoodInStore,
        changeOnline,
        changeInStore
    });
}

export default DiscoveryData;
