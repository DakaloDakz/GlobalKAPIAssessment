'use strict';
export default class DSLPreferences {
    /**
     * Create DSL Customer Preference
     */
    create_user_contact_preference = () => {
        return [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
    };

    create_petshop_contact_preference = () => {
        return [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
    };
    create_user_personal_preference = (name, status) => {
        return [
            {
                "active": status,
                "name": name
            }
        ];
    };
}
