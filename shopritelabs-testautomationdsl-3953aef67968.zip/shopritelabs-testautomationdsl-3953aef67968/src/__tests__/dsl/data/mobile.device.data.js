'use strict';
export default class DSLMobileDevice {
    create_mobileDevice_payload = (operatingSystem, operatingSystemVersion, appVersion, instanceId, channel) => {
        return {
            "operatingSystem": operatingSystem,
            "operatingSystemVersion": operatingSystemVersion,
            "appVersion": appVersion,
            "instanceId": instanceId,
            "channel": channel
        };
    };
}