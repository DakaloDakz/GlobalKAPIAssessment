'use strict';
export default class DSLClaims {
    get_claims_payload = (idNumber, mobileNumber) => {
        return {

            "idNumber": idNumber,
            "mobileNumber": mobileNumber
        };
    };
}