export default class DSLReceiver {
    /**
     * Create DSL Customer Preference
     */
    create_delivery_report = (dlr, da, userid) => {
        return {
            "dlr": dlr,
            "da": da,
            "userid": userid
        };

    };
}
