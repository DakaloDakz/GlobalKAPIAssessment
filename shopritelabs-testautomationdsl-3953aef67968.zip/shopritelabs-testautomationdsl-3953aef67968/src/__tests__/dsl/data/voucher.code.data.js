'use strict';
export default class DSLVoucherCode {
    /**
     * Create DSL Customer Preference
     */
    create_voucher = (voucherId, mobileNumber, sendCode, generateBarcodeImage, requestId) => {
        return [
            {
                "voucherId": "188",
                "mobileNumber": "0761234567",
                "sendCode": true,
                "generateBarcodeImage": false,
                "requestId": "1252553"
            }
        ];
    };
}