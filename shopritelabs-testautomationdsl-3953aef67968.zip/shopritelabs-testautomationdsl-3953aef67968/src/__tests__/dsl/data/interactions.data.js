'use strict';
export default class DSLInteractions {
    /**
     * Create DSL Customer Preference
     */
    create_interaction = (token, communicationMedium, type, marketingArea, rainmakerId) => {
        return {
            "interactions": [
                {
                    "idToken": token,
                    "communicationMedium": communicationMedium,
                    "type": type,
                    "timeStampUTC": "2020-10-13T06:22:49",
                    "marketingArea": marketingArea,
                    "rainmakerId": rainmakerId,
                    "products": [
                        {
                            "product": "1234567EA"
                        }
                    ]
                }
            ]
        };
    };
}