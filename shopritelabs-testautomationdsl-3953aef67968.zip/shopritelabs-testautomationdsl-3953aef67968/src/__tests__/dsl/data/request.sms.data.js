'use strict';
export default class DSLRequestsms {
    get_requestsms_payload = (uid, requester, transactionId) => {
        return {

            "uid": uid,
            "requester": requester,
            "transactionId": transactionId

        };
    };
}
