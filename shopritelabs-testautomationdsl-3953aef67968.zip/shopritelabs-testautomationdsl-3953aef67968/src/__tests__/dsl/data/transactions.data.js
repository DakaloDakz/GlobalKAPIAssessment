'use strict';
export default class DSLTransactions {
    get_transactions_payload = (uid, startDate, endDate, maxRows) => {
        return {
            "uid": uid,
            "startDate": startDate,
            "endDate": endDate,
            "maxRows": maxRows
        };
    };

    get_digital_tillslip_payload = (tranId, posId, totalAmount, startDateTime, card, posDateTime, storeId) => {
        return {
            "tranId": tranId,
            "posId": posId,
            "totalAmount": totalAmount,
            "startDateTime": startDateTime,
            "clubCardId": card,
            "updatedBy": "1",
            "posDateTime": posDateTime,
            "storeId": storeId
        };
    };
}