'use strict';
export default class DSLServiceTicket {
    /**
     * Create DSL Customer Consent
     */
    create_service_ticket = (name, surname, email, domainId, domainName, referenceId, referenceName, messageTypeId, messageTypeName, subjectName, messageContent, storeId) => {
        return {
            "device": [
                {
                    "key": "string",
                    "value": "string"
                }
            ],
            "contact": [
                {
                    "name": name,
                    "surname": surname,
                    "contactDetails": [
                        {
                            "name": "EmailName",
                            "type": "email",
                            "value": email
                        }
                    ]
                }
            ],
            "domain": {
                "id": domainId,
                "name": domainName,
                "referenceTypes": [
                    {
                        "id": referenceId,
                        "name": referenceName,
                        "value": "8745478321"
                    }
                ]
            },
            "message": {
                "type": {
                    "id": messageTypeId,
                    "name": messageTypeName
                },
                "subject": subjectName,
                "content": messageContent
            },
            "store": {
                "id": storeId
            },
            "attachments": [
                {
                    "binary": "SGVsbG8gd29ybGQ=",
                    "name": "test.txt",
                    "type": "text/plain"
                }
            ]
        };
    };
}