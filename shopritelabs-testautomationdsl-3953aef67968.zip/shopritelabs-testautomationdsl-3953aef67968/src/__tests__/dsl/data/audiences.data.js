'use strict';
export default class DSLAudiences {
    get_audiences_payload = (uid, brand, optin, system) => {
        return [
            {
                "uid": uid,
                "brand": brand,
                "optin": optin,
                "system": system
            }
        ];
    };
}
