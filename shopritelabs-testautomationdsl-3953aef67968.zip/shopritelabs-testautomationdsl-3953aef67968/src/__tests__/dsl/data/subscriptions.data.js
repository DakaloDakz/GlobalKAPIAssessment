'use strict';
export default class DSLSubscriptions {
    create_Subscriptions_payload = (onDuplicate, email, mobileNumber, firstName, lastName, birthdate, gender, companyName, address, city, country, postalCode, province, loyaltyCard, createNotification, id, status) => {
        return {
            "onDuplicate": onDuplicate,
            "email": email,
            "mobileNumber": mobileNumber,
            "firstName": firstName,
            "lastName": lastName,
            "birthdate": birthdate,
            "gender": gender,
            "companyName": companyName,
            "address": address,
            "city": city,
            "postalCode": postalCode,
            "country": country,
            "province": province,
            "loyaltyCard": loyaltyCard,
            "createNotification": createNotification,
            "subscriptionList": [
                {
                    "id": id,
                    "status": status
                }
            ],
            "tags": [
                "Tag1",
                "Tag2"
            ],
            "customFields": [
                {
                    "key": "cfv_shoprite55",
                    "value": "Shoprite OK"
                }
            ]
        };
    };
}
