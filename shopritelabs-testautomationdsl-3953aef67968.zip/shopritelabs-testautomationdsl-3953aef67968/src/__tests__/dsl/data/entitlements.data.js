'use strict';
export default class DSLEntilements {
    get_entitlements_payload = (uid, entitlementName, enable) => {
        return {
            "uid": uid,
            "entitlementName": entitlementName,
            "enable": enable
        };
    };
}