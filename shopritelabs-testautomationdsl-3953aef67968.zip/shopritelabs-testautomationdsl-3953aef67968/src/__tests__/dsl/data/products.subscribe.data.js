'use strict';
export default class DSLProductsSubscribe {
    get_productsubscribe_payload = (product) => {
        return {
            "oauthCredentials": {
                "authenticationEndpoint": "https://rewardsapi.qa.shopritelabs.co.za/authorizationserver/oauth/token",
                "clientId": "dslClient",
                "clientSecret": "secret",
                "scope": ""
            },

            "endpointURL": "https://test.com/product/update",
            "product": product,
            "delete": false,
            "systemName": "HPE_DEV"

        };
    };

    get_productunsubscribe_payload = (product) => {
        return {
            "oauthCredentials": {
                "authenticationEndpoint": "https://rewardsapi.qa.shopritelabs.co.za/authorizationserver/oauth/token",
                "clientId": "dslClient",
                "clientSecret": "secret",
                "scope": ""
            },

            "endpointURL": "https://test.com/product/update",
            "product": product,
            "delete": true,
            "systemName": "HPE_DEV"

        };
    };
}
