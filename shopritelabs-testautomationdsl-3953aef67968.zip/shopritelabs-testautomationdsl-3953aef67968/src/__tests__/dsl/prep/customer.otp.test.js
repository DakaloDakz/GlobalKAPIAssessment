import ApiMethodUtil from '../../__utils__/api_method_util';
import DataHelpers from '../../__utils__/data_helpers';
import DSLCustomer from '../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../__utils__/auth/ciam/auth.methods";

// jest.retryTimes(1);
describe('MoneyMarketPOS - Customer endpoints E2E', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();

    let token, email, mobileNumberNew, uuid, mobileNumber, firstName, lastName;
    beforeAll(async () => {
        token = await ciamAuth.ciamMoneyMarketPOSCognitoAuth(process.env.CIAM);
        token = await token.data.access_token;

    });

    test('create customer', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers');
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };

        mobileNumber = json.contactDetails[0].value;
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        let response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        expect(response.data.response.uuid).toBeDefined();
        uuid = response.data.response.uuid;
    });

    test('login with OTP and check if mobileNumberVerified = true', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: mobileNumber};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        console.log(reference);

        const paramsVerify = {
            "target": {
                "type": "SMS",
                "identifier": mobileNumber,
                "reference": reference
            },
            "otp": 0
        };
        const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
        await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
        expect(responseVerify.status).toBe(200);

        const headersGetCustomer = {
            'access_token': `${responseVerify.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const responseGetCustomer = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headersGetCustomer, null);
        await addMsg({message: JSON.stringify(responseGetCustomer.data, null, 2)});
        expect(response.status).toBe(200);
        expect(responseGetCustomer.data.response.user.uuid).toBeDefined();
        expect(responseGetCustomer.data.response.user.mobileNumberVerified).toBe("true");
    });

    test('with mobileNumber and check if mobileNumberVerified = false', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        mobileNumberNew = dataHelpers.generatePhoneNumber(true);
        const json = {
            "mobileNumber": mobileNumberNew
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 5000));

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberNew, 'dsl');

        const headersGetCustomer = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const responseGetCustomer = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headersGetCustomer, null);
        await addMsg({message: JSON.stringify(responseGetCustomer.data, null, 2)});
        expect(response.status).toBe(200);
        expect(responseGetCustomer.data.response.user.uuid).toBeDefined();
        expect(responseGetCustomer.data.response.user.mobileNumberVerified).toBe("false");
    });

    test('login with new mobileNumber and check if mobileNumberVerified = true', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: mobileNumberNew};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        console.log(reference);

        const paramsVerify = {
            "target": {
                "type": "SMS",
                "identifier": mobileNumberNew,
                "reference": reference
            },
            "otp": 0
        };
        const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
        await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
        expect(responseVerify.status).toBe(200);
        await new Promise((r) => setTimeout(r, 5000));

        const headersGetCustomer = {
            'access_token': `${responseVerify.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const responseGetCustomer = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headersGetCustomer, null);
        await addMsg({message: JSON.stringify(responseGetCustomer.data, null, 2)});
        expect(response.status).toBe(200);
        expect(responseGetCustomer.data.response.user.uuid).toBeDefined();
        expect(responseGetCustomer.data.response.user.mobileNumberVerified).toBe("true");
    });
});
