import ApiMethodUtil from '../../../../__utils__/api_method_util';
import DataHelpers from '../../../../__utils__/data_helpers';
import DSLCustomer from '../../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import {faker} from '@faker-js/faker';

jest.retryTimes(1);
describe('DSL - Create Customer with Password (/users/partialuser)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();

    beforeAll(async () => {

    });

    test('with valid password', async () => {
        let password = faker.internet.password(33, false, /[A-Za-z\d#?!@$%^&*-]/g);

        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let emailAddress = `${firstName}-${lastName}@shoprite-testautomation.com`;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": emailAddress
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersPartial = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': password
        };
        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headersPartial);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();

        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': password,
            'email': emailAddress
        };
        await addMsg({message: JSON.stringify(headers, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.accessToken).toBeDefined();
        expect(response.data.response.refreshToken).toBeDefined();
        let accessToken = response.data.response.accessToken;
        let refreshToken = response.data.response.refreshToken;
        const headersGetCustomer = {
            'access_token': `${accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const responseGetCustomer = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headersGetCustomer, null);
        await addMsg({message: JSON.stringify(responseGetCustomer.data, null, 2)});
        let {data} = responseGetCustomer;
        expect(responseGetCustomer.status).toBe(200);
        expect(data.response.user.email).toBe(emailAddress);
        expect(data.response.user.mobileNumber).toBe(mobileNumber);
        expect(data.response.user.firstName).toBe(firstName);
        expect(data.response.user.lastName).toBe(lastName);
    });

    test('with password and no email', async () => {
        let password = faker.internet.password(13, false, /[A-Za-z\d#?!@$%^&*-]/g);

        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;

        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersPartial = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': password
        };
        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headersPartial);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(400);
        let {data} = responsePartial;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with password less than 8', async () => {
        let password = faker.internet.password(7, false, /[A-Za-z\d#?!@$%^&*-]/g);

        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        let emailAddress = `${firstName}-${lastName}@shoprite-testautomation.com`;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": emailAddress
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersPartial = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': password
        };
        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headersPartial);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(400);
        let {data} = responsePartial;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with password less more 128', async () => {
        let password = faker.internet.password(129, false, /[A-Za-z\d#?!@$%^&*-]/g);

        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        let emailAddress = `${firstName}-${lastName}@shoprite-testautomation.com`;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": emailAddress
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersPartial = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': password
        };
        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headersPartial);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(400);
        let {data} = responsePartial;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty password', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        let emailAddress = `${firstName}-${lastName}@shoprite-testautomation.com`;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": emailAddress
        };
        json.contactDetails.push(email);
        const headersPartial = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': ''
        };

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: JSON.stringify(headersPartial, null, 2)});
        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headersPartial);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).toBeDefined();
    });

    test('with password no special characters', async () => {
        let password = faker.internet.password(31, false, /[A-Za-z\d]/g);

        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        let emailAddress = `${firstName}-${lastName}@shoprite-testautomation.com`;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": emailAddress
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersPartial = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': password
        };
        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headersPartial);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(400);
        let {data} = responsePartial;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with password no uppercase letters', async () => {
        let password = faker.internet.password(50, false, /[A-Za-z\d#?!@$%^&*-]/g).toLowerCase();

        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        let emailAddress = `${firstName}-${lastName}@shoprite-testautomation.com`;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": emailAddress
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersPartial = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': password
        };
        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headersPartial);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(400);
        let {data} = responsePartial;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with password no lowercase letters', async () => {
        let password = faker.internet.password(50, false, /[A-Za-z\d#?!@$%^&*-]/g).toUpperCase();

        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        let emailAddress = `${firstName}-${lastName}@shoprite-testautomation.com`;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": emailAddress
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersPartial = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'password': password
        };
        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headersPartial);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(400);
        let {data} = responsePartial;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});