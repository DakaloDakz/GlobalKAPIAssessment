import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe('DSL - Update Customer preferred store (/preferredstore)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;
    let uuid;
    let email;

    beforeAll(async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        expect(newCustomer.uuid).toBeDefined();
        await new Promise((r) => setTimeout(r, 10000));
        email = newCustomer.email;
        uuid = newCustomer.uuid;
    });

    test('with valid input data using cognito - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "preferredStoreId": "3301"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferredstore?uid=${uuid}`});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferredstore?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        const response1 = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferredstore?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        response1.data = dataHelpers.sanitize(response1.data, ['serverTime', 'requestId']);
        expect(response1.data).toMatchSnapshot();
    });

    test('with valid input data using cognito - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "preferredStoreId": "3301"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferredstore?uid=${uuid}`});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferredstore?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        const response1 = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferredstore?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});

        expect(response1.status).toBe(200);
        response1.data = dataHelpers.sanitize(response1.data, ['serverTime', 'requestId']);
        expect(response1.data).toMatchSnapshot();
    });

    test('with valid input data using access token - checkers', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/preferredstore`});
        let json = {
            "preferredStoreId": "abcd"
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/preferredstore`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        const response1 = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/preferredstore`, headers, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        let {data1} = response1;
        expect(response1.status).toBe(200);
        response1.data = dataHelpers.sanitize(response1.data, ['serverTime', 'requestId']);
        expect(response1.data).toMatchSnapshot();
    });

    test('with valid input data using access token - shoprite', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferredstore`});
        let json = {
            "preferredStoreId": "efgh"
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferredstore`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        const response1 = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferredstore`, headers, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});

        expect(response1.status).toBe(200);
        response1.data = dataHelpers.sanitize(response1.data, ['serverTime', 'requestId']);
        expect(response1.data).toMatchSnapshot();
    });

    test('with invalid access token', async () => {
        const headers = {
            'access_token': `123`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "preferredStoreId": "2701"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferredstore?uid=${uuid}`});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferredstore?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(401);
        expect(data).toMatchSnapshot();
    });

    test('with invalid customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "preferredStoreId": "2701"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferredstore?uid=123`});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferredstore?uid=123`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with missing customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "preferredStoreId": "2701"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferredstore`});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferredstore`, json, headers);

        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand in URL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "preferredStoreId": "2701"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/preferredstore?uid=${uuid}`});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/preferredstore?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code in URL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "preferredStoreId": "2701"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/preferredstore?uid=${uuid}`});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/preferredstore?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty body', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {};
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/ZA/preferredstore?uid=${uuid}`});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferredstore?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
