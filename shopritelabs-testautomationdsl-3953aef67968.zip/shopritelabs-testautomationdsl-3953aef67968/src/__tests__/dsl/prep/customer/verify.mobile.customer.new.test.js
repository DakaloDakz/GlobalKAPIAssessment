import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import DSLCustomer from '../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";

jest.retryTimes(1);
describe('DSL - Verify Mobile (/dsl/brands/checkers/countries/za/users/verifymobile)', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const ciamAuth = new CIAMAuth();
    let token;
    let access;
    let reference;
    beforeAll(async () => {

        // reference = await get_otp_reference(process.env.DSLGroup, "+27833915802", access)
    });

    test('add mobile verified', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        // let otp = {
        //     "target": {
        //         "type": "SMS",
        //         "identifier": "+27833915802",
        //         "targetIsVerified": true
        //     },
        //     "action": "verify"
        // }
        // const responseOTP = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/generate`, otp, headers);
        // await addMsg({message: JSON.stringify(responseOTP.data, null, 2)});
        // console.log(responseOTP.data)
        // expect(responseOTP.status).toBe(200);

        let json = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": ''
            },
            "otp": 4745
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });

    test('empty identifier', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "target": {
                "type": "SMS",
                "identifier": '',
                "reference": reference
            },
            "otp": 7114
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let data = dataHelpers.sanitize(response.data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty reference', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "target": {
                "type": "SMS",
                "identifier": '+27833915802',
                "reference": ''
            },
            "otp": 7114
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let data = dataHelpers.sanitize(response.data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty otp', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "target": {
                "type": "SMS",
                "identifier": '+27833915802',
                "reference": '99af76a8-43f1-474f-b02b-990c9e458224'
            },
            "otp": ''
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let data = dataHelpers.sanitize(response.data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid identifier', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "target": {
                "type": "SMS",
                "identifier": '27833915802',
                "reference": '99af76a8-43f1-474f-b02b-990c9e458224'
            },
            "otp": 7114
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let data = dataHelpers.sanitize(response.data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid reference', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "target": {
                "type": "SMS",
                "identifier": '+27833915802',
                "reference": 'abs'
            },
            "otp": 7114
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let data = dataHelpers.sanitize(response.data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid otp', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "target": {
                "type": "SMS",
                "identifier": '+27833915802',
                "reference": '99af76a8-43f1-474f-b02b-990c9e458224'
            },
            "otp": 'abc'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let data = dataHelpers.sanitize(response.data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});

