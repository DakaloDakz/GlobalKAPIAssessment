import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import DSLCustomer from '../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import {faker} from '@faker-js/faker';
import {encode} from "../../../__utils__/encryption.util";
import LproPayloads from "../../../__utils__/auth/ciam/payloads/lpro.payloads";
import fakeSaIdGenerator from "south-african-fake-id-generator";

jest.retryTimes(1);
describe('DSL - Patch Customer common data (/users)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const lproPayloads = new LproPayloads();
    const auth = new Authentication();

    let token, email, emailNew, uuid, mobileNumber, mobileNumberNew, firstName, firstNameNew, lastName, lastNameNew,
        credentials, sessionKey, checkersCustomer;
    beforeAll(async () => {
        checkersCustomer = await dSLCustomer.createPartialComplete('checkers', false);
        mobileNumber = checkersCustomer.mobileNumber;
        firstName = checkersCustomer.firstName;
        lastName = checkersCustomer.lastName;
        uuid = checkersCustomer.uuid;
        token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');

        let occAuthUserName = process.env.LPROClientID;
        let occAuthPassword = process.env.LPROClientSecret;
        credentials = encode(`${occAuthUserName}:${occAuthPassword}`);
        let payload = await lproPayloads.loginPayload();
        sessionKey = await auth.lpro_session_key_auth(payload, 'prep');
        await new Promise((r) => setTimeout(r, 10000));
    });

    test('with no changes', async () => {
        const json = {
            "firstName": firstName,
            "lastName": lastName,
            "mobileNumber": mobileNumber,
            "email": email
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
    });

    test('with updated email', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        emailNew = `${faker.internet.userName(faker.name.firstName(), faker.name.lastName())}@shoprite-testautomation.com`;
        const json = {
            "email": emailNew
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 5000));
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.email).toEqual(emailNew);
    });

    test('with empty firstName', async () => {
        const json = {
            "firstName": ""
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty lastName', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const json = {
            "lastName": ""
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty mobileNumber', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const json = {
            "mobileNumber": ""
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty email', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const json = {
            "email": ""
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty body', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const json = {};
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with updated firstName', async () => {
        firstNameNew = faker.name.firstName();
        const json = {
            "firstName": firstNameNew
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        // let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber,'dsl')
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.givenName).toEqual(firstNameNew);
    });

    test('with updated lastName', async () => {
        lastNameNew = faker.name.lastName();
        const json = {
            "lastName": lastNameNew
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        // let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber,'dsl')
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.familyName).toEqual(lastNameNew);
    });

    test('with updated mobileNumber', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        mobileNumberNew = dataHelpers.generatePhoneNumber(true);
        const json = {
            "mobileNumber": mobileNumberNew
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 5000));
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumberNew);
        expect(response1.data.response.givenName).toEqual(firstNameNew);
        expect(response1.data.response.familyName).toEqual(lastNameNew);
    });

    test('with updated email - invalid format', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        if (tk === undefined) {
            tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        }
        let email = `${faker.internet.userName(faker.name.firstName(), faker.name.lastName())}shoprite-testautomation.com`;
        const json = {
            "email": email
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        let {data} = response;
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with updated mobileNumber - invalid format', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        let mobileNumber = faker.phone.number('278########');
        const json = {
            "mobileNumber": mobileNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        let {data} = response;
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid firstName', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const json = {
            "firstName": "12345678"
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        let {data} = response;
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid lastName', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const json = {
            "lastName": "1234567890"
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        let {data} = response;
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with updated ID Number - Sixty60', async () => {
        let idNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        const json = {
            "saIdNumber": idNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with updated ID Number - Sixty60 User Authenticated', async () => {
        let idNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        const json = {
            "saIdNumber": idNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });
});
