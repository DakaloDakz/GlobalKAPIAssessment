import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import Authentication from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import LproPayloads from "../../../../__utils__/auth/ciam/payloads/lpro.payloads";
import {encode} from "../../../../__utils__/encryption.util";
import 'jest-matcher-one-of';
import DSLCustomer from "../../../data/customer.data";
import CardService from "../../../../__utils__/cards/cardService";

// jest.retryTimes(1);
describe('DSL - Add Digital Card (/card/digital)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const lproPayloads = new LproPayloads();
    const dSLCustomer = new DSLCustomer();
    const auth = new Authentication();
    const cardService = new CardService();
    let uuidCHWithoutCard;
    let uuidCHWithCard;
    let mobileNumberCH;
    let credentials;
    let mobileNumberSixty60;
    let uuidSixty60WithoutCard;
    let sessionKey;

    let mobileNumberMakeBetter;
    let uuidMakeBetterWithoutCard;
    let mobileNumberSuperApp;
    let uuidSuperAppWithoutCard;
    beforeAll(async () => {
        let occAuthUserName = process.env.LPROClientID;
        let occAuthPassword = process.env.LPROClientSecret;
        credentials = encode(`${occAuthUserName}:${occAuthPassword}`);
        let payload = await lproPayloads.loginPayload();
        sessionKey = await auth.lpro_session_key_auth(payload, 'prep');
        let checkersCustomerWithoutCard = await dSLCustomer.createPartialComplete('checkers', false);
        mobileNumberCH = checkersCustomerWithoutCard.mobileNumber;
        uuidCHWithoutCard = checkersCustomerWithoutCard.uuid;
        expect(uuidCHWithoutCard).not.toBeNull();

        let sixty60CustomerWithoutCard = await dSLCustomer.createPartialComplete('checkers', false);
        mobileNumberSixty60 = sixty60CustomerWithoutCard.mobileNumber;
        uuidSixty60WithoutCard = sixty60CustomerWithoutCard.uuid;
        expect(uuidSixty60WithoutCard).not.toBeNull();

        let makeBetterCustomerWithoutCard = await dSLCustomer.createPartialComplete('checkers', false);
        mobileNumberMakeBetter = makeBetterCustomerWithoutCard.mobileNumber;
        uuidMakeBetterWithoutCard = makeBetterCustomerWithoutCard.uuid;
        expect(uuidMakeBetterWithoutCard).not.toBeNull();

        let superAppCustomerWithoutCard = await dSLCustomer.createPartialComplete('checkers', false);
        mobileNumberSuperApp = superAppCustomerWithoutCard.mobileNumber;
        uuidSuperAppWithoutCard = superAppCustomerWithoutCard.uuid;
        expect(uuidSuperAppWithoutCard).not.toBeNull();
    });

    test('customer with no checkers card and digitalCard = false', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": false
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeUndefined();
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBeUndefined();
    });

    test('customer with no checkers card and digitalCard = null', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": null
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeUndefined();
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBeUndefined();
    });

    test('customer with no checkers card and digitalCard = empty string', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": ""
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeUndefined();
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBeUndefined();
    });

    test('customer with no checkers card and empty string body', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {};
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeUndefined();
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBeUndefined();
    });

    test('customer with no checkers card and empty string body and digitalCard = null and cardNumber provided in payload', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": '9710084091031878',
            "digitalCard": false
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeUndefined();
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBeUndefined();
    });

    test('customer with no checkers card and digitalCard = true', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidCHWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        let digitalCard = response1.data.response.cards.za.rewards.checkers.number;
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidCHWithoutCard);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === digitalCard) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('add digitalCard to Shoprite brand', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/digital?uid=${uuidCHWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/digital?uid=${uuidCHWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        let digitalCardCheckers = response1.data.response.cards.za.rewards.checkers.number;
        let digitalCardShoprite = response1.data.response.cards.za.rewards.shoprite.number;
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidCHWithoutCard);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === digitalCardCheckers) {
                expect(card['$']['CardStatus']).toBe('1');
            }
            if (card['$']['Id'] === digitalCardShoprite) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('customer already has an active card - checkers', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=14be5e6d-7647-4ba4-9d0d-8fdad138730e`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=14be5e6d-7647-4ba4-9d0d-8fdad138730e`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('customer already has an active card - shoprite', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/digital?uid=14be5e6d-7647-4ba4-9d0d-8fdad138730e`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/digital?uid=14be5e6d-7647-4ba4-9d0d-8fdad138730e`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('customer with no checkers card and digitalCard = true - Sixty60 API Key', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidSixty60WithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidSixty60WithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberSixty60, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.checkers.number).toContain('97100843');
        let digitalCard = response1.data.response.cards.za.rewards.checkers.number;
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidSixty60WithoutCard);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === digitalCard) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('customer with no checkers card and digitalCard = true - Make Better API Key', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCHWithoutCard).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.makeBetterApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidMakeBetterWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidMakeBetterWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberMakeBetter, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.checkers.number).toContain('97100843');
        let digitalCard = response1.data.response.cards.za.rewards.checkers.number;
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidMakeBetterWithoutCard);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === digitalCard) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('customer with no checkers card and digitalCard = true - Super App API Key', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.superAppApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidSuperAppWithoutCard}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuidSuperAppWithoutCard}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberSuperApp, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.checkers.number).toContain('97100843');
        let digitalCard = response1.data.response.cards.za.rewards.checkers.number;
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidSuperAppWithoutCard);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": `Basic ${credentials}`,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === digitalCard) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('partial register with digital card - whatsapp', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'foxCard.digitalCard', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.data.response.cards.za.rewards.checkers.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.checkers.number).toContain('97100843');
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('partial register with digital card - ussd', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'foxCard.digitalCard', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'ussd');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.data.response.cards.za.rewards.checkers.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.checkers.number).toContain('97100843');
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('partial register with digital card - web', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'foxCard.digitalCard', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.data.response.cards.za.rewards.checkers.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.checkers.number).toContain('97100843');
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('partial register with digital card - web shoprite', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'foxCard.digitalCard', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBeDefined();
        expect(response1.data.response.cards.za.rewards.shoprite.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toContain('97100843');
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('partial register with digital card - web Make Better API key', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'foxCard.digitalCard', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.makeBetterApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.data.response.cards.za.rewards.checkers.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.checkers.number).toContain('97100843');
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('partial register with digital card - web Super App API key', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'foxCard.digitalCard', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.superAppApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.data.response.cards.za.rewards.checkers.number).toHaveLength(16);
        expect(response1.data.response.cards.za.rewards.checkers.number).toContain('97100843');
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    let uuid;
    let mobileNumber;

    test('replace stopped card with digital card - checkers', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation-cards.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.superAppApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        uuid = response.data.response.uuid;

        /*Stop Card*/
        let jsonStopCard = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/stop?uid=${uuid}`});

        const responseStopCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/stop?uid=${uuid}`, jsonStopCard, headers);
        await addMsg({message: JSON.stringify(responseStopCard.data, null, 2)});
        expect(responseStopCard.status).toBe(200);

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const responseAfterStop = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(responseAfterStop.data, null, 2)});
        expect(responseAfterStop.status).toBe(200);
        expect(responseAfterStop.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(responseAfterStop.data.response.cards.za.rewards.checkers.status).toBe('inactive');

        /*Add Digital Card*/
        let jsonAddCard = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(jsonAddCard, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuid}`});

        const responseAddCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuid}`, jsonAddCard, headers);
        await addMsg({message: JSON.stringify(responseAddCard.data, null, 2)});
        expect(responseAddCard.status).toBe(200);

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam2 = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headersCiam2, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.user.loyaltyCards.cards[0].cardNumber).toBeDefined();
        expect(response1.data.response.user.loyaltyCards.cards[0].cardNumber).toHaveLength(16);
        expect(response1.data.response.user.loyaltyCards.cards[0].cardNumber).toContain('97100843');
        expect(response1.data.response.user.loyaltyCards.cards[0].theme).toBe('Checkers');
        expect(response1.data.response.user.loyaltyCards.cards[0].active).toBe(true);
        expect(response1.data.response.user.customerId).toBe(response.data.response.uuid);
    });

    test('replace stopped card with digital card - shoprite', async () => {
        const cardNumber = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.superAppApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);

        /*Stop Card*/
        let jsonStopCard = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/stop?uid=${uuid}`});

        const responseStopCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/stop?uid=${uuid}`, jsonStopCard, headers);
        await addMsg({message: JSON.stringify(responseStopCard.data, null, 2)});
        expect(responseStopCard.status).toBe(200);

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const responseAfterStop = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(responseAfterStop.data, null, 2)});
        expect(responseAfterStop.status).toBe(200);
        expect(responseAfterStop.data.response.cards.za.rewards.shoprite.number).toBe(cardNumber);
        expect(responseAfterStop.data.response.cards.za.rewards.shoprite.status).toBe('inactive');

        /*Add Digital Card*/
        let jsonAddCard = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(jsonAddCard, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/digital?uid=${uuid}`});

        const responseAddCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/digital?uid=${uuid}`, jsonAddCard, headers);
        await addMsg({message: JSON.stringify(responseAddCard.data, null, 2)});
        expect(responseAddCard.status).toBe(200);

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam2 = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`, headersCiam2, null);
        await addMsg({message: JSON.stringify(response1.data.response.cards, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.user.loyaltyCards.cards[1].cardNumber).toBeDefined();
        expect(response1.data.response.user.loyaltyCards.cards[1].cardNumber).toHaveLength(16);
        expect(response1.data.response.user.loyaltyCards.cards[1].cardNumber).toContain('97100843');
        expect(response1.data.response.user.loyaltyCards.cards[1].theme).toBe('Shoprite');
        expect(response1.data.response.user.loyaltyCards.cards[1].active).toBe(true);
    });
});
