import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import Authentication from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";
import CardService from "../../../../__utils__/cards/cardService";
import LproPayloads from "../../../../__utils__/auth/ciam/payloads/lpro.payloads";
import {encode} from "../../../../__utils__/encryption.util";
import 'jest-matcher-one-of';
import DSLCustomer from "../../../data/customer.data";

jest.retryTimes(1);
describe('ASM - Add Stop Card (/card)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const lproPayloads = new LproPayloads();
    const dSLCustomer = new DSLCustomer();
    const auth = new Authentication();
    const cardService = new CardService();
    const cIAMCustomer = new CIAMCustomer();

    let access;
    let uuidCH;
    let uuidSH;
    let mobileNumberSH;
    let mobileNumberCH;
    let cardNumberOriginalCH;
    let cardNumberOriginalSH;
    let credentials;
    let sessionKey;
    let firstNameCH;
    let lastNameCH;
    let firstNameSH;
    let lastNameSH;
    let newCardCH;
    let newCardSH;

    beforeAll(async () => {
        access = await ciamAuth.ciamASMCognitoAuth(process.env.CIAM);
        access = access.data.access_token;

        let occAuthUserName = process.env.LPROClientID;
        let occAuthPassword = process.env.LPROClientSecret;
        credentials = encode(`${occAuthUserName}:${occAuthPassword}`);
        let payload = await lproPayloads.loginPayload();
        sessionKey = await auth.lpro_session_key_auth(payload, 'prep');
    });

    test('create customer seed data', async () => {
        let checkersCustomer = await dSLCustomer.createPartialComplete('checkers', true);
        await new Promise((r) => setTimeout(r, 1000));
        mobileNumberCH = checkersCustomer.mobileNumber;
        cardNumberOriginalCH = checkersCustomer.cardNumber;
        firstNameCH = checkersCustomer.firstName;
        lastNameCH = checkersCustomer.lastName;
        uuidCH = checkersCustomer.uuid;
        expect(uuidCH).not.toBeNull();
        await addMsg({message: `Checkers UUID: ${uuidCH}`});

        let shopriteCustomer = await dSLCustomer.createPartialComplete('shoprite', true);
        await new Promise((r) => setTimeout(r, 1000));
        mobileNumberSH = shopriteCustomer.mobileNumber;
        cardNumberOriginalSH = shopriteCustomer.cardNumber;
        firstNameSH = shopriteCustomer.firstName;
        lastNameSH = shopriteCustomer.lastName;
        uuidSH = shopriteCustomer.uuid;
        expect(uuidSH).not.toBeNull();
        await addMsg({message: `Shoprite UUID: ${uuidSH}`});
    });

    test('add card - shoprite', async () => {
        expect(mobileNumberSH).toBeDefined();
        expect(uuidSH).toBeDefined();
        newCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: `${JSON.stringify(json)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuidCH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuidCH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toEqual(newCardSH);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidCH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === newCardSH) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('add card - checkers', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCH).toBeDefined();
        newCardCH = await cardService.getCardOffline(false, 'checkers');
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardCH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuidSH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuidSH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberSH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(newCardCH);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidSH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === newCardCH) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('stop card - checkers', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCH).toBeDefined();
        let tokenCH = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');

        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumberOriginalCH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/stop?uid=${uuidCH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/stop?uid=${uuidCH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        const headersCiam = {
            'accessToken': `${tokenCH.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(cardNumberOriginalCH);
        expect(response1.data.response.cards.za.rewards.checkers.status).toBe('inactive');
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidCH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        await addMsg({message: dataHelpers.prettifyXML(response2.data, null, 2)});
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];
        expect(lpro_firstName).toEqual(firstNameCH);
        expect(lpro_lastName).toEqual(lastNameCH);
        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === cardNumberOriginalCH) {
                expect(card['$']['CardStatus']).toBe('2');
            }
        }
    });

    test('stop card - shoprite', async () => {
        expect(mobileNumberSH).toBeDefined();
        expect(uuidSH).toBeDefined();
        let tokenSH = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberSH, 'dsl');

        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumberOriginalSH
        };
        await addMsg({message: JSON.stringify(headers, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/stop?uid=${uuidSH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card/stop?uid=${uuidSH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        const headersCiam = {
            'accessToken': `${tokenSH.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toEqual(cardNumberOriginalSH);
        expect(response1.data.response.cards.za.rewards.shoprite.status).toBe('inactive');
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidSH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        await addMsg({message: dataHelpers.prettifyXML(response2.data, null, 2)});
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];
        expect(lpro_firstName).toEqual(firstNameSH);
        expect(lpro_lastName).toEqual(lastNameSH);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === cardNumberOriginalSH) {
                expect(card['$']['CardStatus']).toBe('2');
            }
        }
    });

    test('stop card - card already inactive', async () => {
        let uuid = 'ed60537a-f219-4e22-b9a7-7a6b7c6d50df';
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": '9710084459009656'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/stop?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/stop?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
