import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import Authentication from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";
import CardService from "../../../../__utils__/cards/cardService";
import LproPayloads from "../../../../__utils__/auth/ciam/payloads/lpro.payloads";
import {encode} from "../../../../__utils__/encryption.util";
import 'jest-matcher-one-of';
import DSLCustomer from "../../../data/customer.data";

jest.retryTimes(1);
describe('DSL - Add Stop Card (/card)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const lproPayloads = new LproPayloads();
    const dSLCustomer = new DSLCustomer();
    const auth = new Authentication();
    const cardService = new CardService();
    const cIAMCustomer = new CIAMCustomer();

    let access;
    let uuidCH;
    let uuidSH;
    let mobileNumberSH;
    let mobileNumberCH;
    let cardNumberOriginalCH;
    let cardNumberOriginalSH;
    let credentials;
    let sessionKey;
    let firstNameCH;
    let lastNameCH;
    let firstNameSH;
    let lastNameSH;
    let newCardCH;
    let newCardSH;

    beforeAll(async () => {

        let occAuthUserName = process.env.LPROClientID;
        let occAuthPassword = process.env.LPROClientSecret;
        credentials = encode(`${occAuthUserName}:${occAuthPassword}`);
        let payload = await lproPayloads.loginPayload();
        sessionKey = await auth.lpro_session_key_auth(payload, 'prep');
    });

    test('create customer seed data', async () => {
        let checkersCustomer = await dSLCustomer.createPartialComplete('checkers', true);
        mobileNumberCH = checkersCustomer.mobileNumber;
        cardNumberOriginalCH = checkersCustomer.cardNumber;
        firstNameCH = checkersCustomer.firstName;
        lastNameCH = checkersCustomer.lastName;
        uuidCH = checkersCustomer.uuid;
        expect(uuidCH).not.toBeNull();
        await addMsg({message: `Checkers UUID: ${uuidCH}`});
        await new Promise((r) => setTimeout(r, 1000));
        let shopriteCustomer = await dSLCustomer.createPartialComplete('shoprite', true);
        mobileNumberSH = shopriteCustomer.mobileNumber;
        cardNumberOriginalSH = shopriteCustomer.cardNumber;
        firstNameSH = shopriteCustomer.firstName;
        lastNameSH = shopriteCustomer.lastName;
        uuidSH = shopriteCustomer.uuid;
        expect(uuidSH).not.toBeNull();
        await addMsg({message: `Shoprite UUID: ${uuidSH}`});
        await new Promise((r) => setTimeout(r, 1000));
    });

    test('with valid number using cognito - checkers', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCH).toBeDefined();
        newCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuidCH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuidCH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toEqual(newCardSH);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidCH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === newCardSH) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('with already active card - shoprite', async () => {
        expect(mobileNumberSH).toBeDefined();
        expect(uuidSH).toBeDefined();
        newCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuidCH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuidCH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid number using cognito - shoprite', async () => {
        expect(mobileNumberSH).toBeDefined();
        expect(uuidSH).toBeDefined();
        newCardCH = await cardService.getCardOffline(false, 'checkers');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardCH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuidSH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuidSH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberSH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(newCardCH);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidSH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === newCardCH) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('with already active card - checkers', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCH).toBeDefined();
        newCardCH = await cardService.getCardOffline(false, 'checkers');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardCH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuidSH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuidSH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid number using access token - checkers', async () => {
        expect(mobileNumberCH).toBeDefined();
        expect(uuidCH).toBeDefined();
        let jsonFull = dSLCustomer.create_customer_valid_full();
        jsonFull = dataHelpers.setValueInJson(jsonFull, 'cardNumber', '');
        const firstName = jsonFull.firstName;
        const lastName = jsonFull.lastName;
        const email = jsonFull.email;
        const headersFull = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseFull = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, jsonFull, headersFull);
        expect(responseFull.status).toBe(200);
        let uuidFull = responseFull.data.response.uuid;
        let cardNumber = await cardService.getCardOffline(false, 'checkers');
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(cardNumber);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidFull);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        await addMsg({message: JSON.stringify(response2.data, null, 2)});
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];

        expect(lpro_firstName).toEqual(firstName);
        expect(lpro_lastName).toEqual(lastName);
        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === cardNumber) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('with valid number using access token - shoprite', async () => {
        expect(mobileNumberSH).toBeDefined();
        expect(uuidSH).toBeDefined();
        let jsonFull = dSLCustomer.create_customer_valid_full();
        jsonFull = dataHelpers.setValueInJson(jsonFull, 'cardNumber', '');
        const firstName = jsonFull.firstName;
        const lastName = jsonFull.lastName;
        const email = jsonFull.email;
        let cardNumber = await cardService.getCardOffline(false, 'shoprite');
        const headersFull = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseFull = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/full`, jsonFull, headersFull);
        expect(responseFull.status).toBe(200);
        let uuidFull = responseFull.data.response.uuid;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toEqual(cardNumber);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidFull);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        await addMsg({message: JSON.stringify(response2.data, null, 2)});
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];
        expect(lpro_firstName).toEqual(firstName);
        expect(lpro_lastName).toEqual(lastName);
        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === cardNumber) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('with valid number USED - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": "9710085600032455"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid number USED - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": "9710085426246701"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": "9710085900013474"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": ""
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty body', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {};
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {};
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {};
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('stop card - checkers', async () => {
        let tokenCH = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');

        const headers = {
            'access_token': `${tokenCH.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumberOriginalCH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/stop`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/stop`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        const headersCiam = {
            'accessToken': `${tokenCH.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(cardNumberOriginalCH);
        expect(response1.data.response.cards.za.rewards.checkers.status).toBe('inactive');
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidCH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        await addMsg({message: dataHelpers.prettifyXML(response2.data, null, 2)});
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];
        expect(lpro_firstName).toEqual(firstNameCH);
        expect(lpro_lastName).toEqual(lastNameCH);
        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === cardNumberOriginalCH) {
                expect(card['$']['CardStatus']).toBe('2');
            }
        }
    });

    test('stop card - shoprite', async () => {
        let tokenSH = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberSH, 'dsl');

        const headers = {
            'access_token': `${tokenSH.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumberOriginalSH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card/stop`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card/stop`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        const headersCiam = {
            'accessToken': `${tokenSH.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toEqual(cardNumberOriginalSH);
        expect(response1.data.response.cards.za.rewards.shoprite.status).toBe('inactive');
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidSH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        await addMsg({message: dataHelpers.prettifyXML(response2.data, null, 2)});
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];
        expect(lpro_firstName).toEqual(firstNameSH);
        expect(lpro_lastName).toEqual(lastNameSH);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === cardNumberOriginalSH) {
                expect(card['$']['CardStatus']).toBe('2');
            }
        }
    });

    test('replace inactive card - checkers', async () => {
        let replaceCardCH = await cardService.getCardOffline(false, 'checkers');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": replaceCardCH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuidCH} \n ${replaceCardCH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuidCH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(replaceCardCH);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidCH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === replaceCardCH) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('replace inactive card - shoprite', async () => {
        let replaceCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": replaceCardSH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuidSH}\n ${replaceCardSH}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuidSH}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberSH, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toEqual(replaceCardSH);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidSH);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === replaceCardSH) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    let uuidFull, cardNumber, mobileNumber;

    test('with valid number using access token - ByteOrbit API Key', async () => {
        const headersFull = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let checkersCustomer = await dSLCustomer.createPartialComplete('checkers', false);
        uuidFull = checkersCustomer.uuid;
        cardNumber = await cardService.getCardOffline(false, 'checkers');
        const firstName = checkersCustomer.firstName;
        const lastName = checkersCustomer.lastName;
        mobileNumber = checkersCustomer.mobileNumber;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.byteOrbitApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(cardNumber);
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuidFull);
        let headers2 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response2 = await apiCall.POST(url, body, headers2);
        let responseJson = dataHelpers.xml2json(response2.data);
        await addMsg({message: JSON.stringify(response2.data, null, 2)});
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);

        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];

        expect(lpro_firstName).toEqual(firstName);
        expect(lpro_lastName).toEqual(lastName);
        let cards = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'];
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i];
            if (card['$']['Id'] === cardNumber) {
                expect(card['$']['CardStatus']).toBe('1');
            }
        }
    });

    test('stop card - ByteOrbit API Key', async () => {
        let tokenCH = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');

        const headers = {
            'access_token': `${tokenCH.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/stop`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/stop`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        const headersCiam = {
            'accessToken': `${tokenCH.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(cardNumber);
        expect(response1.data.response.cards.za.rewards.checkers.status).toBe('inactive');
    });
});
