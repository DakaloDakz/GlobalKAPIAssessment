import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import DSLConsent from '../../../data/consents.data';
import {addMsg} from "jest-html-reporters/helper";

jest.retryTimes(1);
describe('DSL - Add XstraSavings Consents to Customer (/consent)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLConsent = new DSLConsent();
    let access;

    beforeAll(async () => {

    });

    test('sixty60 rewards consents', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('sixty60-za-rewards-xtrasavings-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.rewards.xtraSavings.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.rewards.xtraSavings.consentName')).toBe('sixty60-za-rewards-xtrasavings-consent');
    });

    test('sixty60 rewards consents - access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('sixty60-za-rewards-xtrasavings-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.rewards.xtraSavings.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.rewards.xtraSavings.consentName')).toBe('sixty60-za-rewards-xtrasavings-consent');
    });

    test('moneyMarket rewards consents - checkers', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.moneyMarketApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('moneyMarket-za-checkers-rewards-xtrasavings-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.checkers.consents.rewards.xtraSavings.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.checkers.consents.rewards.xtraSavings.consentName')).toBe('moneyMarket-za-checkers-rewards-xtrasavings-consent');
    });

    test('moneyMarket rewards consents - checkers ByteOrbit', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('moneyMarket-za-checkers-rewards-xtrasavings-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.checkers.consents.rewards.xtraSavings.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.checkers.consents.rewards.xtraSavings.consentName')).toBe('moneyMarket-za-checkers-rewards-xtrasavings-consent');
    });

    test('moneyMarket rewards consents - shoprite', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.moneyMarketApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('moneyMarket-za-shoprite-rewards-xtrasavings-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.shoprite.consents.rewards.xtraSavings.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.shoprite.consents.rewards.xtraSavings.consentName')).toBe('moneyMarket-za-shoprite-rewards-xtrasavings-consent');
    });

    test('moneyMarket rewards consents - shoprite ByteOrbit', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('moneyMarket-za-shoprite-rewards-xtrasavings-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.shoprite.consents.rewards.xtraSavings.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.shoprite.consents.rewards.xtraSavings.consentName')).toBe('moneyMarket-za-shoprite-rewards-xtrasavings-consent');
    });

    test('moneyMarket rewards consents with Sixty60 API Key', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('moneyMarket-za-shoprite-rewards-xtrasavings-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('sixty60 rewards consents with MoneMarket API Key', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.moneyMarketApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('sixty60-za-rewards-xtrasavings-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
