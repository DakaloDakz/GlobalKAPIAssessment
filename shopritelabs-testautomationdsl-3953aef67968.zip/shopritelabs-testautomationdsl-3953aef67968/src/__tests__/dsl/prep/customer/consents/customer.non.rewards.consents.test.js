import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import DSLConsent from '../../../data/consents.data';
import {addMsg} from "jest-html-reporters/helper";
import _ from "lodash";

jest.retryTimes(1);
describe('DSL - Add PetShop Science consent to Customer (/consent)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLConsent = new DSLConsent();
    let access;
    let customer;
    let email;

    beforeAll(async () => {
        access = await ciamAuth.petShopScienceCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
        customer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        email = customer.email;
    });

    test('petSHopScience customer - SignUp consent', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.consentName')).toBe('petshopScience-za-terms-and-conditions-consent');
    });

    test('petSHopScience customer - Marketing consent', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.marketing.consentName')).toBe('petshopScience-za-marketing-consent');
    });

    test('petSHopScience customer - Marketing and SignUp consent', async () => {
        let newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let signup = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let json = _.union(signup, marketing);

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, newCustomer.email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.marketing.consentName')).toBe('petshopScience-za-marketing-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.consentName')).toBe('petshopScience-za-terms-and-conditions-consent');

    });

    test('petSHopScience customer - Marketing and SignUp consent with access_token', async () => {
        let newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, newCustomer.email, 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let signup = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let json = _.union(signup, marketing);

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/consent`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.marketing.consentName')).toBe('petshopScience-za-marketing-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.consentName')).toBe('petshopScience-za-terms-and-conditions-consent');
    });

    test('petSHopScience customer set granted false', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_user_consents('petshopScience-za-terms-and-conditions-consent', '2', false);

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.consentVersion')).toBe('2');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.consentName')).toBe('petshopScience-za-terms-and-conditions-consent');
    });

    test('get consent for checkers', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });

    test('with Sixty60 api key', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get consent with access_token', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/consent`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/consent`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });

    test('signUp consent invalid consentTemplateId', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('ShopriteScience-za-signup-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty consent array', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: JSON.stringify([], null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${customer.uuid}`, [], headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add consent - Usave', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceUsaveApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('usave-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('usave-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.usave.za.shoprite.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.usave.za.shoprite.consents.termsOfService.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.usave.za.shoprite.consents.termsOfService.consentName')).toBe('usave-za-termsandconditions-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.usave.za.shoprite.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.usave.za.shoprite.consents.marketing.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.usave.za.shoprite.consents.marketing.consentName')).toBe('usave-za-marketing-consent');
    });

    test('add consent - Medirite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceMediriteApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('medirite-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('medirite-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/medirite/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/medirite/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.medirite.za.shopriteGroup.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.medirite.za.shopriteGroup.consents.termsOfService.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.medirite.za.shopriteGroup.consents.termsOfService.consentName')).toBe('medirite-za-termsandconditions-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.medirite.za.shopriteGroup.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.medirite.za.shopriteGroup.consents.marketing.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.medirite.za.shopriteGroup.consents.marketing.consentName')).toBe('medirite-za-marketing-consent');
    });

    test('add consent - LiquorShop Shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('liquorshop-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('liquorshop-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.consents.termsOfService.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.consents.termsOfService.consentName')).toBe('liquorshop-za-termsandconditions-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.consents.marketing.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.consents.marketing.consentName')).toBe('liquorshop-za-marketing-consent');
    });

    test('add consent - LiquorShop Checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('liquorshop-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('liquorshop-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.consents.termsOfService.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.consents.termsOfService.consentName')).toBe('liquorshop-za-termsandconditions-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.consents.marketing.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.consents.marketing.consentName')).toBe('liquorshop-za-marketing-consent');
    });

    test('add consent - HouseAndHome', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceHouseAndHomeApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('houseAndHome-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('houseAndHome-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/househome/countries/za/consent?uid=${customer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/househome/countries/za/consent?uid=${customer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.houseAndHome.za.shopriteGroup.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.houseAndHome.za.shopriteGroup.consents.termsOfService.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.houseAndHome.za.shopriteGroup.consents.termsOfService.consentName')).toBe('houseAndHome-za-termsandconditions-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.houseAndHome.za.shopriteGroup.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.houseAndHome.za.shopriteGroup.consents.marketing.consentVersion')).toBe('1');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.houseAndHome.za.shopriteGroup.consents.marketing.consentName')).toBe('houseAndHome-za-marketing-consent');
    });
});
