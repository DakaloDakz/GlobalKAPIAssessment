import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import DSLConsent from '../../../data/consents.data';
import {addMsg} from "jest-html-reporters/helper";
import _ from "lodash";

jest.retryTimes(1);
describe('DSL - Add Consents to Customer (/consent)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLConsent = new DSLConsent();
    let access;

    beforeAll(async () => {

    });

    test('with valid input data using cognito Sixty60', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('sixty60-za-termsandconditions');
        let marketing = dSLConsent.create_valid_user_consents('sixty60-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.marketing.consentName')).toBe('sixty60-za-marketing-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.marketing.consentVersion')).toBe("1");
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.termsOfService.consentName')).toBe('sixty60-za-termsandconditions');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.consents.termsOfService.consentVersion')).toBe("1");
    });

    test('with valid input data using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.consentName')).toBe('checkers-za-marketing-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.consentVersion')).toBe("1");
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName')).toBe('checkers-za-rewards-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.termsOfService.consentVersion')).toBe("1");
    });

    test('with checkers consent but shoprite brand in URL', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using access token -Shoprite', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('shoprite-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.termsOfService.consentName')).toBe('shoprite-za-rewards-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.termsOfService.consentVersion')).toBe("1");
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.marketing.consentName')).toBe('shoprite-za-marketing-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.marketing.consentVersion')).toBe("1");

    });

    test('with shoprite consent but checkers brand in URL', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('shoprite-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with only one consent using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');

        await addMsg({message: JSON.stringify(rewards, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${newCustomer.uuid}`, rewards, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.termsOfService.consentName')).toBe('shoprite-za-rewards-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.consents.termsOfService.consentVersion')).toBe("1");
    });

    test('with only one contact preference  using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        await addMsg({message: JSON.stringify(marketing, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, marketing, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.consentName')).toBe('checkers-za-marketing-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.consentVersion')).toBe("1");
    });

    test('with invalid consentTemplateId using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consents",
                "consentTemplateVersion": "1",
                "granted": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid consentTemplateId using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consents",
                "consentTemplateVersion": "1",
                "granted": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with no consentTemplateId using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateVersion": "1",
                "granted": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with no consentTemplateId using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateVersion": "1",
                "granted": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid consentTemplateVersion using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consent",
                "consentTemplateVersion": "abc",
                "granted": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(200);
        expect(data).toMatchSnapshot();
    });

    test('with invalid consentTemplateVersion using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consent",
                "consentTemplateVersion": "!@#",
                "granted": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(200);
        expect(data).toMatchSnapshot();
    });

    test('with no consentTemplateVersion using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consent",
                "granted": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with no consentTemplateVersion using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consent",
                "granted": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid granted using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consent",
                "consentTemplateVersion": "1",
                "granted": 'true'
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(200);
        expect(data).toMatchSnapshot();
    });

    test('with invalid granted using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consent",
                "consentTemplateVersion": "1",
                "granted": 'false'
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(200);
        expect(data).toMatchSnapshot();
    });

    test('with no granted using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consent",
                "consentTemplateVersion": "1"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with no granted using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "consentTemplateId": "checkers-za-rewards-consent",
                "consentTemplateVersion": "1"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with empty consent array using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with empty consent array using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid uid using cognito', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${123}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${123}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with missing uid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid cognito token', async () => {
        const headers = {
            Authorization: `Bearer ${123}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(401);
        expect(data).toMatchSnapshot();
    });

    test('with invalid access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `123`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid countryCode', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/consent?uid=${newCustomer.uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/consent?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
