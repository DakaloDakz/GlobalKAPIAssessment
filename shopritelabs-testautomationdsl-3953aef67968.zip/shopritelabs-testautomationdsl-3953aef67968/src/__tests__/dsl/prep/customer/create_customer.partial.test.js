import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import DSLCustomer from '../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import {faker} from '@faker-js/faker';
import _ from "lodash";
import CardService from "../../../__utils__/cards/cardService";

jest.retryTimes(1);
describe('DSL - Create Customer (/users/partialuser)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const cardService = new CardService();

    beforeAll(async () => {

    });

    test('with valid input data - USSD', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with valid input data - USSD Shoprite', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('shoprite', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBe(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with valid input data - USSD with passport', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'identity[0].type', 'PASSPORT');
        // json = dataHelpers.setValueInJson(json, 'identity[0].value', '7700225VH');
        json = dataHelpers.setValueInJson(json, 'identity[0].value', faker.internet.password(15, false, /[0-9A-Z]/));
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.personalIdentifications.passport.number).toBe('ZZ-' + idNumber);
    });

    test('with valid input data - WHATSAPP', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with valid input data - WHATSAPP Shoprite', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('shoprite', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBe(cardNumber);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with valid input data - WHATSAPP without Card', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        json = dataHelpers.removeObjectInJson(json, 'foxCard');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with valid input data - WEB', async () => {

        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('WEB');
    });

    test('with valid input data - WEB Shoprite', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('shoprite', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'web');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);

        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.registrationChannel).toBe('WEB');
    });

    test('with valid input data - WEB UpperCase', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('WEB');
    });

    test('with valid input data - WEB CamelCase', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WeB');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('WEB');
    });

    test('with valid input data - WEB without Card', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'web');
        json = dataHelpers.removeObjectInJson(json, 'foxCard');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with valid input data - WEB without Email', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'web');
        json = dataHelpers.removeObjectInJson(json, 'foxCard');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });

    test('with valid input data - MONEYMARKET', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'money_market');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with valid input data - MONEYMARKET without card', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'money_market');
        json = dataHelpers.removeObjectInJson(json, 'foxCard');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const mobileNumber = json.contactDetails[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid id number', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'identity[0].value', dSLCustomer.invalidIdNumber());
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid id type', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'identity[0].type', 'ZAID');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no id type', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'identity[0].type');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid EMAIL and MOBILE contact', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        let email = `${faker.internet.userName()}@shoprite-testautomation.com`;

        let contact = {
            "description": "Contact Type by Automation",
            "id": "01",
            "type": "EMAIL",
            "value": email
        };
        json.contactDetails.push(contact);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 1000));
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.email).toBe(email);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with valid EMAIL contact', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].id', '01');
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].type', 'EMAIL');
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].value', `${faker.internet.userName()}@shoprite-testautomation.com`);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'web');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const email = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 1000));
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.email).toBe(email);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with invalid EMAIL address', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].id', '01');
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].type', 'EMAIL');
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].value', `${faker.internet.userName()}shoprite-testautomation.com`);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no contact value', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'contactDetails[0].value');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no contact type', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'contactDetails[0].type');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no contact id', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'contactDetails[0].id');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test('with no contact description', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'contactDetails[0].description');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test('with no contact details', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'contactDetails');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty contact value', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].value', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty contact type', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].type', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid contact value', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].value', 'Gc@123.com');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid contact type', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].type', 'TikTok');
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'web');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });

    test('with no user details', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'userDetails');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no user firstName', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'userDetails.firstName');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no user lastName', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'userDetails.lastName');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no user type', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'userDetails.type');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no user birth date', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'userDetails.birthDate');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test('with empty user firstName', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.firstName', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with firstName less than 2 in length', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.firstName', 'a');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with firstName more than 255 in length', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.firstName', 'gdfgdfsgdfgdsfgdhdfhdfhdfhfdhdfhdfhdfhdfhdfhfdhdfhfdhdfhdfhfdhfdhfhdhfythhhfgjhgjyjtyjrtjrjrtjtjjjrttjjrtjtjtrjrjtrjtrjrtjtrjrjtrjwtwersdafafffafsdfsdfsdfahjhjhjjhkasdasffafasxasxsaxasassaafsgtjytktjrtetertwrwegrehrththerrgweqefergerherhherhrhrherrererrrs');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with empty user lastName', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.lastName', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with lastName less than 2 in length', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.lastName', 'a');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with lastName equal to 2 in length', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.lastName', 'Ed');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test('with lastName more than 255 in length', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.lastName', 'gdfgdfsgdfgdsfgdhdfhdfhdfhfdhdfhdfhdfhdfhdfhfdhdfhfdhdfhdfhfdhfdhfhdhfythhhfgjhgjyjtyjrtjrjrtjtjjjrttjjrtjtjtrjrjtrjtrjrtjtrjrjtrjwtwersdafafffafsdfsdfsdfahjhjhjjhkasdasffafasxasxsaxasassaafsgtjytktjrtetertwrwegrehrththerrgweqefergerherhherhrhrherrererrrs');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with lastName equal to 255 in length', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.lastName', 'gdfgdfsgdfgdsfgdhdfhdfhdfhfdhdfhdfhdfhdfhdfhfdhdfhfdhdfhdfhfdhfdhfhdhfythhhfgjhgjyjtyjrtjrjrtjtjjjrttjjrtjtjtrjrjtrjtrjrtjtrjrjtrjwtwersdafafffafsdfsdfsdfahjhjhjjhkasdasffafasxasxsaxasassaafsgtjytktjrtetertwrwegrehrththerrgweqefergerherhherhrhrherrererrr');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with empty user type', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty user birth date', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.birthDate', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.uuid']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid user type', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'TikTok');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid user birth date', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.birthDate', '19751231');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.uuid']);
        expect(data).toMatchSnapshot();
    });

    test('with no fox card', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'foxCard');
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'ussd');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty fox card number', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'foxCard.cardNumber', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid fox card number', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'foxCard.cardNumber', '78945613302123');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no fox card number', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.removeObjectInJson(json, 'foxCard.cardNumber');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty body', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, JSON.stringify({}), headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand in URL', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid countryCode in URL', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with random fake data', async () => {
        let rubbish = require('../../../__utils__/blns.json');

        let json = dSLCustomer.create_customer_partial(_.sample(rubbish), _.sample(rubbish), `${faker.internet.userName()}@shoprite-testautomation.com`, _.sample(rubbish), _.sample(rubbish), _.sample(rubbish), _.sample(rubbish), _.sample(rubbish), _.sample(rubbish));
        json = dataHelpers.setValueInJson(json, 'saIdNumber', dSLCustomer.invalidIdNumber());
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });

    test('with passport and no Date of Birth', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'identity[0].type', 'PASSPORT');
        json = dataHelpers.removeObjectInJson(json, 'userDetails.birthDate');
        json = dataHelpers.setValueInJson(json, 'identity[0].value', faker.internet.password(15, false, /[0-9A-Z]/));
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('dob younger than 18 but with valid ID Number', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        json = dataHelpers.setValueInJson(json, 'userDetails.birthDate', '01/07/2009');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test('dob younger than 18 - PASSPORT', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        json = dataHelpers.setValueInJson(json, 'identity[0].type', 'PASSPORT');
        json = dataHelpers.removeObjectInJson(json, 'userDetails.birthDate');
        json = dataHelpers.setValueInJson(json, 'identity[0].value', faker.internet.password(15, false, /[0-9A-Z]/));
        json = dataHelpers.setValueInJson(json, 'userDetails.birthDate', '01/07/2010');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid input data - Moya Checkers', async () => {

        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'Moya');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('MOYA');
    });

    test('with valid input data - Moya Shoprite', async () => {

        let json = await dSLCustomer.create_customer_valid_partial('shoprite', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'Moya');
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const idNumber = json.identity[0].value;
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('MOYA');
    });

    test('Yonder payload - cards as an array', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        await dataHelpers.removeObjectInJson(json, 'foxCard');
        json.foxCard = [
            {
                "cardNumber": await cardService.getCardOffline(false, 'checkers'),
                "active": true
            }
        ];

        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard[0].cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('Yonder payload - 2 cards in the array', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        await dataHelpers.removeObjectInJson(json, 'foxCard');
        json.foxCard = [
            {
                "cardNumber": await cardService.getCardOffline(false, 'checkers'),
                "active": true
            },
            {
                "cardNumber": "",
                "active": true
            }
        ];

        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard[0].cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });
});
