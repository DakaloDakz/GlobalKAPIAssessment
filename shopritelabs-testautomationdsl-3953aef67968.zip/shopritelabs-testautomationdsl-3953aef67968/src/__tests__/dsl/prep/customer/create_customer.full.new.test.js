import ApiMethodUtil from '../../../__utils__/api_method_util';
import Authentication from '../../../__utils__/auth/ciam/auth.methods';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import DSLCustomer from '../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import _ from "lodash";
import {faker} from '@faker-js/faker';

jest.retryTimes(1);
describe('DSL - Create Customer (/dsl/brands/checkers/countries/za/users/full)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const ciamAuth = new CIAMAuth();

    beforeAll(async () => {

    });

    test('with valid input data - checkers', async () => {
        const json = dSLCustomer.create_customer_valid_full('checkers', true);
        const firstName = json.firstName;
        const lastName = json.lastName;
        const cardNumber = json.cardNumber;
        const idNumber = json.saIdNumber;
        const mobileNumber = json.mobileNumber;
        const email = json.email;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toEqual(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toEqual('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('APP');
    });

    test('with valid input data - shoprite', async () => {
        const json = dSLCustomer.create_customer_valid_full('checkers', true);
        const firstName = json.firstName;
        const lastName = json.lastName;
        const cardNumber = json.cardNumber;
        const idNumber = json.saIdNumber;
        const mobileNumber = json.mobileNumber;
        const email = json.email;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toEqual(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.memberId).toEqual(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toEqual('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.registrationChannel).toBe('APP');
    });

    test('with valid input data using uid - checkers', async () => {
        const json = dSLCustomer.create_customer_valid_full_uid('checkers', true);
        const firstName = json.firstName;
        const lastName = json.lastName;
        const cardNumber = json.cardNumber;
        const idNumber = json.saIdNumber;
        const mobileNumber = json.mobileNumber;
        const email = json.uid;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toEqual(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toEqual('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('APP');
    });

    test('with valid input data using uid - shoprite', async () => {
        const json = dSLCustomer.create_customer_valid_full_uid('shoprite', true);
        const firstName = json.firstName;
        const lastName = json.lastName;
        const cardNumber = json.cardNumber;
        const idNumber = json.saIdNumber;
        const mobileNumber = json.mobileNumber;
        const email = json.uid;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toEqual(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.memberId).toEqual(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toEqual('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.registrationChannel).toBe('APP');
    });

    test('with empty cardNumber', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', true);
        json = dataHelpers.setValueInJson(json, 'cardNumber', '');
        const firstName = json.firstName;
        const lastName = json.lastName;
        const email = json.email;
        const cardNumber = json.cardNumber;
        const idNumber = json.saIdNumber;
        const mobileNumber = json.mobileNumber;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBeUndefined();
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toEqual(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toEqual('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('APP');
    });

    test('with missing cardNumber', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', true);
        json = dataHelpers.removeObjectInJson(json, 'cardNumber');
        const firstName = json.firstName;
        const lastName = json.lastName;
        const email = json.email;
        const cardNumber = json.cardNumber;
        const idNumber = json.saIdNumber;
        const mobileNumber = json.mobileNumber;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.cards.za.rewards.checkers.number).toEqual(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toEqual(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toEqual('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('APP');
    });

    test('with empty preferredStoreId', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'preferredStoreId', '');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with empty firstName', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'firstName', '');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty lastName', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'lastName', '');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty email', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'email', '');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with empty mobileNumber', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'mobileNumber', '');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty saIdNumber', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'saIdNumber', '');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty birthDate and valid Passport', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'birthDate', '');
        json = dataHelpers.setValueInJson(json, 'passportNumber', faker.internet.password(15, false, /[0-9A-Z]/));
        json = dataHelpers.setValueInJson(json, 'saIdNumber', '');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty birthDate and valid valid SAID', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'birthDate', '');
        // json = dataHelpers.removeObjectInJson(json, 'passportNumber');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with empty titleCode', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'titleCode', '');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with missing preferredStoreId', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'preferredStoreId');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const email = dataHelpers.getValueFromJson(json, 'uid');
        const mobileNumber = dataHelpers.getValueFromJson(json, 'mobileNumber');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with missing firstName', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'firstName');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with missing lastName', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'lastName');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with missing email', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'email');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with missing mobileNumber', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'mobileNumber');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with missing saIdNumber', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'saIdNumber');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with missing birthDate', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'birthDate');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const email = dataHelpers.getValueFromJson(json, 'uid');
        const mobileNumber = dataHelpers.getValueFromJson(json, 'mobileNumber');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with missing titleCode', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'titleCode');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const email = dataHelpers.getValueFromJson(json, 'uid');
        const mobileNumber = dataHelpers.getValueFromJson(json, 'mobileNumber');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with missing passportNumber', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.removeObjectInJson(json, 'passportNumber');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('with invalid id number', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'saIdNumber', dSLCustomer.invalidIdNumber());
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with random fake data', async () => {
        let rubbish = require('../../../__utils__/blns.json');

        let json = dSLCustomer.create_customer_full(_.sample(rubbish), _.sample(rubbish), `${faker.internet.userName()}@shoprite-testautomation.com`, _.sample(rubbish), _.sample(rubbish), _.sample(rubbish), _.sample(rubbish), _.sample(rubbish), _.sample(rubbish));
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });

    test('with empty body', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, JSON.stringify({}), headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with birthDate and valid Passport', async () => {
        let json = dSLCustomer.create_customer_valid_full('checkers', false);
        json = dataHelpers.setValueInJson(json, 'saIdNumber', '');
        json = dataHelpers.setValueInJson(json, 'passportNumber', faker.internet.password(15, false, /[0-9A-Z]/));
        const passport = json.passportNumber;
        const email = json.email;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toEqual(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.passport.number).toEqual('ZZ-' + passport);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('APP');
    });
});
