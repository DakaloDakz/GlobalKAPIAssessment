import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

jest.retryTimes(1);
describe('ASM - Get Customer', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;
    let uuid;
    let email;

    beforeAll(async () => {
        access = await ciamAuth.ciamASMCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('with valid input data using access token - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=503c327d-a514-4ea5-8b46-28d5d8ea3211`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=503c327d-a514-4ea5-8b46-28d5d8ea3211`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using C4C access token - checkers', async () => {
        let accessC4C = await ciamAuth.ciamC4CCognitoAuth(process.env.CIAM);
        accessC4C = accessC4C.data.access_token;
        const headers = {
            Authorization: `Bearer ${accessC4C}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=503c327d-a514-4ea5-8b46-28d5d8ea3211`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=503c327d-a514-4ea5-8b46-28d5d8ea3211`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using access token - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=503c327d-a514-4ea5-8b46-28d5d8ea3211`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=503c327d-a514-4ea5-8b46-28d5d8ea3211`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created on Commerce', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=6ed760f8-d098-47c0-a751-97bf7cbe2373`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=6ed760f8-d098-47c0-a751-97bf7cbe2373`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=21ae11fc-cdf6-41fe-a4d5-06ef8b604c7b`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=21ae11fc-cdf6-41fe-a4d5-06ef8b604c7b`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint with 255 char lastName', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=21ae11fc-cdf6-41fe-a4d5-06ef8b604c7b`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=21ae11fc-cdf6-41fe-a4d5-06ef8b604c7b`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint with 255 char firstName', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=553c5b35-17b3-497a-92be-acb7edde6338`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=553c5b35-17b3-497a-92be-acb7edde6338`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('customer with no card number', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=ec5b0545-5959-4d28-849e-b94ca213757c`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=ec5b0545-5959-4d28-849e-b94ca213757c`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid access token', async () => {
        const headers = {
            'access_token': `123`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(401);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand in URL', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za?uid=${uuid}`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code in URL', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk?uid=${uuid}`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
