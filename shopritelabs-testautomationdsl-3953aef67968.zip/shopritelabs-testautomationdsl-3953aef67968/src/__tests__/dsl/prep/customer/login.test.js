import ApiMethodUtil from '../../../__utils__/api_method_util';
import Authentication from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import DSLCustomer from '../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('DSL - Login by Card Number (dsl/brands/checkers/countries/za/users/login)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();

    beforeAll(async () => {

    });

    test('Login with Valid card number only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '+27833915802'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'expiry.value', 'reference']);
        // expect(data).toMatchSnapshot();
        let json = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": data.response.reference
            },
            "otp": "0000"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response1 = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, json, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        console.log(response1.data);
        expect(response1.status).toBe(200);
        expect(response1.data.response.accessToken).toBeDefined();
        expect(response1.data.response.refreshToken).toBeDefined();

        const responseRefresh = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tokens?refreshToken=${response1.data.response.refreshToken}`, headers, null);
        await addMsg({message: JSON.stringify(responseRefresh.data, null, 2)});
        expect(responseRefresh.status).toBe(200);
    });
    //
    // test('Login with mobile number only', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //     };
    //     const params = {query: '+27833915802'};
    //     const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(200);
    //     let {data} = response;
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.expiry.value', 'response.reference']);
    //     expect(data).toMatchSnapshot();
    // });
    //
    // test('Login with email only', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //     };
    //     const params = {query: 'gacombrink@shoprite.co.za'};
    //     const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(200);
    //     let reference = response.data.response.reference
    //     expect(response.data.response.reference).toBeDefined()
    //     let {data} = response;
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.expiry.value', 'response.reference']);
    //     expect(data).toMatchSnapshot();
    //     const paramsVerify = {
    //         "target": {
    //             "type": "EMAIL",
    //             "identifier": "gacombrink@shoprite.co.za",
    //             "reference": reference
    //         },
    //         "otp": 6536
    //     };
    //     const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
    //     await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
    //     expect(responseVerify.status).toBe(400);
    //     data = dataHelpers.sanitize(responseVerify.data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    test('Login with invalid card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: 'dakaloa'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with card number that does not exist', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '276587745595'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with card number that start with 0', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '0647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with blank card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid brand and blank card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/OkFood/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid country code and blank card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/nb/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '+27647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/OkFood/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '+27647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/nb/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
