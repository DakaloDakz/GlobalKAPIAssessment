import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe('DSL - Get Customer (/users)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;
    let uuid;
    let email;

    beforeAll(async () => {
        access = await ciamAuth.ciamASMCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('petShopScience customer using petshop url', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27801090714', 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('petShopScience customer using xtraSavings url', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27801090714', 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('petShopScience customer with xtraSavings consent added later - petShop URL', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za?uid=9d75264d-d01f-4605-adbd-6b26cbf0adf6`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za?uid=9d75264d-d01f-4605-adbd-6b26cbf0adf6`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('petShopScience customer with xtraSavings consent added later - xstraSavings URL', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=4536df65-fc53-433f-84c2-19de9b594c7c`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=4536df65-fc53-433f-84c2-19de9b594c7c`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get using UUID', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za?uid=5bec3c65-9484-4eee-bece-6a3f1db09fe3`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za?uid=5bec3c65-9484-4eee-bece-6a3f1db09fe3`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get using UID(HybrisID)', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=5000ABCD`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=5000ABCD`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(500);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get Sixty60 customer', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27889815220', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using access token - MoneyMarketPos', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27830572903', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
