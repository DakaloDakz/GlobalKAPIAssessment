import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import DSLCustomer from '../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import {faker} from '@faker-js/faker';

jest.retryTimes(1);
describe('ASM - Create Customer (/users/partialuser)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const auth = new Authentication();
    let token;

    beforeAll(async () => {
        token = await auth.ciamASMCognitoAuth(process.env.DSLGroup);
        token = token.data.access_token;
    });

    test('with valid input data - customer_centre', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'customer_centre');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('CUSTOMER_CENTRE');
    });

    test('with valid input data with email - customer_centre', async () => {
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${faker.internet.userName(faker.name.firstName(), faker.name.lastName())}@shoprite-testautomation.com`
        };
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'customer_centre');
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('CUSTOMER_CENTRE');
    });

    test('with type not customer_centre', async () => {
        let email = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${faker.internet.userName(faker.name.firstName(), faker.name.lastName())}@shoprite-testautomation.com`
        };
        let json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'web');
        json.contactDetails.push(email);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const firstName = json.userDetails.firstName;
        const lastName = json.userDetails.lastName;
        const dob = json.userDetails.birthDate.split('/').reverse().join('-');
        const mobileNumber = json.contactDetails[0].value;
        const cardNumber = json.foxCard.cardNumber;
        const idNumber = json.identity[0].value;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
        expect(response1.data.response.birthday).toBe(dob);
        expect(response1.data.response.cards.za.rewards.checkers.number).toBe(cardNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(response.data.response.uuid);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('WEB');
    });

    test('without a card - customer_centre', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'customer_centre');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });
});
