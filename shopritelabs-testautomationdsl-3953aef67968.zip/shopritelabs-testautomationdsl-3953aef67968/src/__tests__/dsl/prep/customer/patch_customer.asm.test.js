import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import DSLCustomer from '../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import {faker} from '@faker-js/faker';
import LproPayloads from "../../../__utils__/auth/ciam/payloads/lpro.payloads";
import fakeSaIdGenerator from 'south-african-fake-id-generator';

jest.retryTimes(1);
describe('ASM - Patch Customer common data (/users)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const lproPayloads = new LproPayloads();
    const auth = new Authentication();

    let token, email, emailNew, uuid, mobileNumber, firstName, lastName;
    beforeAll(async () => {
        token = await auth.ciamASMCognitoAuth(process.env.DSLGroup);
        token = await token.data.access_token;
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        mobileNumber = json.contactDetails[0].value;
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        let response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        uuid = response.data.response.uuid;
    });

    test('with no changes', async () => {
        const json = {
            "firstName": firstName,
            "lastName": lastName,
            "mobileNumber": mobileNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
    });

    test('with updated email', async () => {
        emailNew = `${faker.internet.userName(faker.name.firstName(), faker.name.lastName())}@shoprite-testautomation.com`;
        const json = {
            "email": emailNew
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.email).toEqual(emailNew);
    });

    test('with updated date of birth', async () => {
        let passportNumber = faker.internet.password(15, false, /[0-9A-Z]/);
        let jsonCustomer = await dSLCustomer.create_customer_valid_partial('checkers', false);
        jsonCustomer = dataHelpers.setValueInJson(jsonCustomer, 'identity[0].type', 'PASSPORT');
        jsonCustomer = dataHelpers.setValueInJson(jsonCustomer, 'identity[0].value', passportNumber);
        const headersCustomer = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        let mobileNumberCustomer = jsonCustomer.contactDetails[0].value;
        let responseCustomer = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, jsonCustomer, headersCustomer);
        let uuidCustomer = responseCustomer.data.response.uuid;
        const json = {
            "birthDate": '31/12/1975'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuidCustomer}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumberCustomer, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.personalIdentifications.passport.number).toBe('ZZ-' + passportNumber);
        expect(response1.data.response.birthday).toBe('1975-12-31');
    });

    test('update date of birth for customer with ID Number', async () => {
        const json = {
            "birthDate": '31/12/1975'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.birthday).toBe('1975-12-31');
    });

    test('with updated ID Number', async () => {
        let idNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        const json = {
            "saIdNumber": idNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
    });

    test('with updated ID Number and birth Date', async () => {
        let idNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        const json = {
            "saIdNumber": idNumber,
            "birthDate": '31/12/1983'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe('ZA-' + idNumber);
        expect(response1.data.response.birthday).not.toBe('1983-12-31');
    });

    test('with updated Passport', async () => {
        let passport = faker.internet.password(15, false, /[0-9A-Z]/);
        const json = {
            "passportNumber": passport,
            "birthDate": '31/12/1975'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.personalIdentifications.passport.number).toBe('ZZ-' + passport);
    });

    test('update date of birth with invalid format', async () => {
        const json = {
            "birthDate": '31-12-1975'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        expect(response.data.exception).toBe('[{name=birthDate, reason=Please ensure that you have entered a valid date of birth (dd/mm/yyyy)}]');
    });

    test('update ID Number with invalid format', async () => {
        const json = {
            "saIdNumber": '31-12-1975'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        expect(response.data.exception).toBe('[{name=saIdNumber, reason=Please ensure that you have entered a valid South African Id number}]');
    });

    test('update Passport Number with invalid format- starting with 0', async () => {
        let passport = faker.internet.password(15, false, /[0-9A-Z]/);
        const json = {
            "passportNumber": '0' + passport
        };
        await addMsg({message: JSON.stringify(json, null, 2)});

        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.personalIdentifications.passport.number).toBe('ZZ-0' + passport);
    });

    test('update Passport Number with invalid format - starting with 9', async () => {
        let passport = faker.internet.password(15, false, /[0-9A-Z]/);
        const json = {
            "passportNumber": '9' + passport
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.personalIdentifications.passport.number).toBe('ZZ-9' + passport);
    });

    test('update Passport Number with number less than 6 characters', async () => {
        let passport = faker.internet.password(5, false, /[0-9A-Z]/);
        const json = {
            "passportNumber": passport
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update Passport Number with number more than 20 characters', async () => {
        let passport = faker.internet.password(21, false, /[0-9A-Z]/);
        const json = {
            "passportNumber": passport
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
