import ApiMethodUtil from '../../../__utils__/api_method_util';
import DSLCustomer from '../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - Update customer user type (/users/type)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dSLCustomer = new DSLCustomer();
    const auth = new Authentication();

    let checkersCustomer, token, access, uuid, mobileNumber, firstName, lastName;
    beforeAll(async () => {
        checkersCustomer = await dSLCustomer.createPartialComplete('checkers', false);
        mobileNumber = checkersCustomer.mobileNumber;
        firstName = checkersCustomer.firstName;
        lastName = checkersCustomer.lastName;
        uuid = checkersCustomer.uuid;
        token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');

    });

    let types = ['web', 'app', 'whatsapp', 'ussd', 'money_market', 'customer_centre', 'pos'];

    test.each(types)('update registration channel to %s using cognito  - checkers', async (type) => {
        const json = {
            "type": type
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/type?uid=${uuid}`});
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/type?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe(type.toUpperCase());
    });

    test.each(types)('update registration channel to %s using cognito  - shoprite', async (type) => {
        const json = {
            "type": type
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/type?uid=${uuid}`});
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/type?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.registrationChannel).toBe(type.toUpperCase());
    });

    test.each(types)('update registration channel to %s using access_token  - checkers', async (type) => {
        const json = {
            "type": type
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/type`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe(type.toUpperCase());
    });

    test.each(types)('update registration channel to %s using access_token  - shoprite', async (type) => {
        const json = {
            "type": type
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/type`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.registrationChannel).toBe(type.toUpperCase());
    });

    test('invalid type', async () => {
        const json = {
            "type": 'tiktok'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/type`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });
});
