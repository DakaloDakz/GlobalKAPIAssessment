import ApiMethodUtil from '../../../../__utils__/api_method_util';
import Authentication from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import DSLCustomer from '../../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";

describe('DSL - Ranked Promotions (dsl/brands/checkers/countries/za/promotions/ranked)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();

    beforeAll(async () => {

    });

    test('Retrieves a list of personalised deals of the customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: 'c9b7f073-a073-49b2-9def-6f223db7ebe7',
            scenarioType: 'CHECKERS_RES',
            channel: 'WEB'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of Xtra-Savings Promotion of the customer - SHOPRITE', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5009I0RU',
            scenarioType: 'CHECKERS_RES',
            channel: 'WHATSAPP',
            tacticId: 'GEN'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of Relevant Promotion of the customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '500B4209',
            scenarioType: 'CHECKERS_ROF',
            channel: 'WEB',
            tacticId: 'EAS'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('USING Email Retrieves a list of Relevant Promotion of the customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: 'lele@gmail.com',
            scenarioType: 'CHECKERS_ROF',
            channel: 'WHATSAPP',
            tacticId: 'EAS'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    });

    test('Retrieves a list of personalised deals and offer with user that does not exist', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '40000NXl',
            scenarioType: 'Personalised Promotion',
            tacticId: 'GEN',
            channel: 'ALL'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with invalid UID', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '*******',
            scenarioType: 'Personalised Promotion',
            tacticId: 'GEN',
            channel: 'ALL'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with invalid scenarioType', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: 'Dakalo',
            channel: 'Whatsapp'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with invalid tacticId', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: 'CHECKERS_RES',
            tacticId: 'test',
            channel: 'Whatsapp'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with invalid channel', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: 'CHECKERS_RES',
            tacticId: 'GEN',
            channel: 'testInvalid'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with invalid countrycode', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: 'CHECKERS_RES',
            tacticId: 'GEN',
            channel: 'Whatsapp'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/NB/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with invalid brand', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: 'CHECKERS_RES',
            tacticId: 'GEN',
            channel: 'Whatsapp'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/okfoods/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with missing UID', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '',
            scenarioType: 'Personalised Promotion',
            tacticId: 'GEN',
            channel: 'ALL'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with missing scenarioType', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: '',
            channel: 'Whatsapp'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with missing tacticId', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: 'CHECKERS_RES',
            tacticId: '',
            channel: 'Whatsapp'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with missing channel', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '4000B4H1',
            scenarioType: 'CHECKERS_RES',
            tacticId: 'GEN',
            channel: ''
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Retrieves a list of personalised deals and offer with missing countrycode', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: 'CHECKERS_RES',
            tacticId: 'GEN',
            channel: 'Whatsapp'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(403);
    });

    test('Retrieves a list of personalised deals and offer with missing brand', async () => {

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            uid: '5001MMC8',
            scenarioType: 'CHECKERS_RES',
            tacticId: 'GEN',
            channel: 'Whatsapp'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/countries/za/promotions/ranked`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(403);
    });
});
