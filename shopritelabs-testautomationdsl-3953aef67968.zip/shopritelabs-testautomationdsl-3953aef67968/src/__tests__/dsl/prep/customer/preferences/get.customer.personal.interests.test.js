import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";
import DSLPreferences from "../../../data/preferences.data";

jest.retryTimes(1);
describe('DSL - Get Customer personal interests preferences (/preferences)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLPreferences = new DSLPreferences();
    let access;
    let uuid;
    let email;
    let interests = require('./data/personal.interests.json');

    beforeAll(async () => {

    });

    test('create seed data', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        email = newCustomer.email;
        uuid = newCustomer.uuid;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('cfsb2b', true);
        for (let i = 1; i < interests.checkers.length; i++) {
            json.push({
                "active": true,
                "name": interests.checkers[i].name
            });
        }
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        expect(response.status).toBe(200);
        let jsonSH = dSLPreferences.create_user_personal_preference('srInFamilyMeals', true);
        for (let i = 1; i < interests.shoprite.length; i++) {
            if (interests.shoprite[i].name !== 'srSwipeForCover' && interests.shoprite[i].name !== 'srAutoAirtime') {
                jsonSH.push({
                    "active": true,
                    "name": interests.shoprite[i].name
                });
            }
        }
        const response1 = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`, jsonSH, headers);
        expect(response1.status).toBe(200);
    });

    test('with valid input data using cognito - checkers', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});
        await addMsg({message: `Shoprite - ${interests.shoprite.length}`});
        await addMsg({message: `Checkers - ${interests.checkers.length}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.preferences).toHaveLength(interests.checkers.length);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.preferences.length; i++) {
            if (typeof data.response.preferences[i].updated !== "undefined") {
                data.response.preferences[i].updated = '[SANITIZED]';
            }
        }
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using cognito - shoprite', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.preferences).toHaveLength(interests.shoprite.length);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.preferences.length; i++) {
            if (typeof data.response.preferences[i].updated !== "undefined") {
                data.response.preferences[i].updated = '[SANITIZED]';
            }
        }
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using access token - checkers', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let emailNew = newCustomer.email;
        await addMsg({message: `${email}`});
        expect(newCustomer.uuid).toBeDefined();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, emailNew, 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('chbabyandparenting', true);
        json.push({
            "active": true,
            "name": 'inhealthandbeauty'
        });
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/preferences`, json, headers);
        expect(response.status).toBe(200);

        const response1 = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/preferences`, headers, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        let {data} = response1;
        expect(response1.status).toBe(200);
        expect(data.response.preferences).toHaveLength(interests.checkers.length);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.preferences.length; i++) {
            if (typeof data.response.preferences[i].updated !== "undefined") {
                data.response.preferences[i].updated = '[SANITIZED]';
            }
        }
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using access token - shoprite', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        expect(newCustomer.uuid).toBeDefined();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        await addMsg({message: newCustomer.uuid});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('sringroceryessentials', true);
        json.push({
            "active": false,
            "name": 'srinpartiesandtreats'
        });
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences`});

        const response1 = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences`, headers, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        let {data} = response1;
        expect(response1.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.preferences.length; i++) {
            if (typeof data.response.preferences[i].updated !== "undefined") {
                data.response.preferences[i].updated = '[SANITIZED]';
            }
        }
        expect(data).toMatchSnapshot();
    });

    test('with invalid access token', async () => {
        const headers = {
            'access_token': `123`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=123`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=123`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with missing customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand in URL', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/preferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/preferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code in URL', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/preferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/preferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
