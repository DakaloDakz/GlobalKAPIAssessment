import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import DSLPreferences from '../../../data/preferences.data';
import {addMsg} from "jest-html-reporters/helper";
import _ from "lodash";

jest.retryTimes(1);
describe('DSL - Add Contact Preferences to Customer (/contactPreferences)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLPreferences = new DSLPreferences();
    let access;

    beforeAll(async () => {

    });

    test('with valid input data using cognito - Checkers', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data.response.retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted')).toBe(true);

        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.contactPreferences.sms.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.contactPreferences.mobileApp.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.sixty60.za.checkers.contactPreferences.email.granted')).toBe(true);

        // expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.contactPreferences.whatsApp.granted')).toBe(false);
        // expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.contactPreferences.sms.granted')).toBe(true);
        // expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.contactPreferences.mobileApp.granted')).toBe(true);
        // expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.checkers.contactPreferences.email.granted')).toBe(true);

        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.checkers.contactPreferences.mobileApp.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.checkers.contactPreferences.email.granted')).toBe(true);
    });

    test('with valid input data using cognito - Shoprite', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data.response.retailServices.xtraSavings.za.shoprite.contactPreferences, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.contactPreferences.whatsApp.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.contactPreferences.sms.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.contactPreferences.mobileApp.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.contactPreferences.email.granted')).toBe(true);

        // expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.contactPreferences.whatsApp.granted')).toBe(false);
        // expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.contactPreferences.sms.granted')).toBe(true);
        // expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.contactPreferences.mobileApp.granted')).toBe(true);
        // expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.liquorShop.za.shoprite.contactPreferences.email.granted')).toBe(true);

        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.shoprite.contactPreferences.whatsApp.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.shoprite.contactPreferences.sms.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.shoprite.contactPreferences.mobileApp.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.moneyMarket.za.shoprite.contactPreferences.email.granted')).toBe(true);
    });

    test('with valid input data using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data.response.retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted')).toBe(true);
    });

    test('with only one contact preference using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        let single = _.pullAt(json, [0]);
        await addMsg({message: JSON.stringify(single, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`, single, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data.response.retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted')).toBe(true);
    });

    test.skip('with only MOYA contact preference using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        let single = _.pullAt(json, [4]);
        await addMsg({message: JSON.stringify(single, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`, single, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data.response.retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted')).toBeUndefined();
    });

    test('with only one contact preference  using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        let single = _.pullAt(json, [0]);
        await addMsg({message: JSON.stringify(single, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, single, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data.response.retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted')).toBeUndefined();
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted')).toBe(true);
    });

    test('with invalid code using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "emails",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid code using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "emails",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with no code using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with no code using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid active using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": 'trues'
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid active using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": 'trues'
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with no active using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with no active using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with empty preference array using cognito', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${newCustomer.uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with empty preference array using access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid uid using cognito', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${123}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${123}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with missing uid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid cognito token', async () => {
        const headers = {
            Authorization: `Bearer ${123}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(401);
        expect(data).toMatchSnapshot();
    });

    test('with invalid access token', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `123`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/users/contactPreference`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid countryCode', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });

    test('with invalid body', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            null
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toBe(400);
        expect(data).toMatchSnapshot();
    });
});
