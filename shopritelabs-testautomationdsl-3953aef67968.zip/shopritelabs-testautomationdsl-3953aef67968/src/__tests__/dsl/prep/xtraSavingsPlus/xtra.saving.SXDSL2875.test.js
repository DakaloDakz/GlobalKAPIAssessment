import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import DSLEntilements from "../../data/entitlements.data";

describe('DSL - XS Plus SXDSL2875', () => {
    const apiCall = new ApiMethodUtil();
    const entitlements = new DSLEntilements();
    let paymentCardToken = '64369e765d3452d4845038b0/658E69F8-867A-43C3-BACB-7FA26BE29FCA';

    beforeAll(async () => {

    });

    test('get valid auth', async () => {
        const headers = {
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let data = require(`${__dirname}/car-payload-sample.json`);
        await addMsg({message: `${process.env.DSLGroup}/dsl/savings`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/savings`, data, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test.skip('get customer profile - with savings and discountRedeemed false', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=e46a6226-676a-48d2-81ce-de3b42126f4b`, headers, null);
        // const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=757376f9-f6a8-4bb7-81f5-dedf559e3d7f`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('get customer profile - with savings and discountRedeemed true', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=34f0876e-ed26-4661-a140-6f7a2ba04788`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('get customer profile - ACTIVE with 202305 CAR data and 203306 billing period', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=ca1a1390-f361-48ed-a6a0-d88370b01389`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('get customer profile - ACTIVE with 202305 CAR data and 203305 billing period', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=a7b8a6fb-f4e7-487b-8995-c5c4298d9ae0`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('get customer profile - NON-RENEWAL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=309f7654-0ae2-41a5-afed-6cd26b7229eb`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('get customer profile - CANCELLED', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=ab22f343-0796-4b28-88e1-deaf28d050ce`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('get customer profile - in Chargebee with no subscription', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=01491262-7495-412f-9c47-f585a1653506`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('get customer profile - in CIAM but not in Chargebee', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=0b6acf7e-0613-48c7-8285-188b6032871f`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('get customer profile - invalid UUID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=0b6acf7e-0613-48c7-8285-188b6032871`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
    });

    test('check 10% Discount not available in LPRO - 34f0876e-ed26-4661-a140-6f7a2ba04788', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: '34f0876e-ed26-4661-a140-6f7a2ba04788'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        expect((response.data.exception)).toBe('10% Discount not available');
    });

    test('check 10% Discount available in LPRO - a6fe7db2-16d9-43b8-bb98-e112612e979a', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: 'a6fe7db2-16d9-43b8-bb98-e112612e979a'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect((response.data.response[0])).toStrictEqual({
            "entitlementName": "Discount10",
            "enable": false
        });
    });
});
