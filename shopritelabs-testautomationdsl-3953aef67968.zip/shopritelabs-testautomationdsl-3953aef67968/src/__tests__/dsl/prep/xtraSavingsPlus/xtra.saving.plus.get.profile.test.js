import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../__utils__/data_helpers";
import responseSchema from "../../../__utils__/xtraSavingPlus/schemas/customer.schema.json";

jest.retryTimes(1);
describe.skip('DSL - XSPlus GET Customer Subscriptions(/xsplus/register)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();

    beforeAll(async () => {

    });

    test('get customer profile', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=f421bda9-7461-4327-900b-c5470d7ec012`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect('f421bda9-7461-4327-900b-c5470d7ec012').toBe(data.response.uuid);
        expect('Reilly-Pagac@shoprite-testautomation.com').toBe(data.response.email);
        expect('Reilly').toBe(data.response.firstName);
        expect('Pagac').toBe(data.response.lastName);
        expect('+27803780195').toBe(data.response.mobileNumber);
        expect('4608075792081').toBe(data.response.saIdNumber);
        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "cancelled",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "couponId": "R50DISCOUNTCOUPON"
            }]
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            // "consentTemplateVersion": "1.0",
            "updated": expect.any(String),
            "granted": false
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "firstName": "Reilly",
            "lastName": "Pagac",
            "mobileNumber": "+27803780195",
            "email": "Reilly-Pagac@shoprite-testautomation.com"
        });
        expect(data.response.xtraSavingsPlus.savings).toMatchObject({
            "billingPeriod": "",
            "monthlySavingsAmount": "0",
            "monthlyFreeDeliverySavings": "0",
            "monthlyFreeDeliveryCount": "0",
            "monthlyDiscountSavings": "0",
            "monthlyExtraSavings": "0",
            "discountRedeemed": false
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('get customer profile - with CAR savings', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=eeb567d9-ca2a-4208-ba65-e320bb018528`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect('eeb567d9-ca2a-4208-ba65-e320bb018528').toBe(data.response.uuid);
        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "cancelled",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "couponId": "R50DISCOUNTCOUPON"
            }]
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            // "consentTemplateVersion": "1.0",
            "updated": expect.any(String),
            "granted": expect.any(Boolean)
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "email": "Abigale-Cummerata@shoprite-testautomation.com",
            "firstName": "Abigale",
            "lastName": "Cummerata",
            "mobileNumber": "+27895980740"
        });
        expect(data.response.xtraSavingsPlus.savings).toMatchObject({
            "billingPeriod": "202303",
            "monthlySavingsAmount": "1036.63",
            "monthlyFreeDeliverySavings": "34.99",
            "monthlyFreeDeliveryCount": "1",
            "monthlyDiscountSavings": "245.00",
            "monthlyExtraSavings": "756.64",
            "discountRedeemed": true
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('get customer profile - with CAR savings over 2 periods', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=2c65d4da-fcae-4578-85f8-8b6777a80743`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect('2c65d4da-fcae-4578-85f8-8b6777a80743').toBe(data.response.uuid);
        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-Plan-Daily-ZAR-Daily"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "active",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "couponId": "R50DISCOUNTCOUPON"
            }]
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            // "consentTemplateVersion": "1.0",
            "updated": expect.any(String),
            "granted": expect.any(Boolean)
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "email": "faithxsplus@yopmail.com",
            "firstName": "Faith",
            "lastName": "Xs Plus",
            "mobileNumber": "+27643872079"
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('get customer profile for customer in CIAM but not in Chargebee', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let uuid = '88fce063-f483-42ec-991b-c24f24081803';
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response).toMatchObject({
            "birthDate": "15/05/1942",
            "cards": [
                {
                    "cardNumber": "9710084459047417",
                    "theme": "Checkers",
                    "active": true
                }
            ],
            "emailVerified": "false",
            "firstName": "Aric",
            "lastName": "Larkin",
            "mobileNumber": "+27820422167",
            "mobileNumberVerified": "true",
            "passportNumber": "M0CPRC0HK5MGPQE",
            "uid": "88fce063-f483-42ec-991b-c24f24081803",
            "uuid": "88fce063-f483-42ec-991b-c24f24081803",
            "xtraSavingsPlus": {
                "consents": [
                    {}
                ],
                "billingInformation": {},
                "subscriptions": [
                    {}
                ]
            }
        });
    });

    test('with invalid uuid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=1299999`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/xsplus/profile?uid=f421bda9-7461-4327-900b-c5470d7ec012`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with Shoprite brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/xsplus/profile?uid=f421bda9-7461-4327-900b-c5470d7ec012`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid countryCode', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/xsplus/profile?uid=f421bda9-7461-4327-900b-c5470d7ec012`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
