import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import DataHelpers from "../../../__utils__/data_helpers";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import XsplusData from "../../../__utils__/xtraSavingPlus/data/xsplus.data";
import XtraSavingsPlusCustomer from "../../../__utils__/xtraSavingPlus/lib/customer";
import ChargebeeSubscriptions from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.subscriptions.sdk";
import PaymentCards from "../../../__utils__/xtraSavingPlus/lib/paymentCards";
import {validate} from "uuid";

jest.retryTimes(1);
describe.skip('DSL -Cancel Customer Subscriptions', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const chargebeeSubscription = new ChargebeeSubscriptions();
    const customerXtraSavings = new XtraSavingsPlusCustomer();
    const xsPlus = new XsplusData();
    const card = new PaymentCards();
    let headers;
    let subscriptionID;
    beforeAll(async () => {
        headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
    });

    test('valid customer with active subscription after first month', async () => {
        let resp = await chargebeeSubscription.getCustomersWithActiveSubscriptions('R149-plan-ZAR-Monthly');
        let customerOlderThanMonth;
        let subscriptionID;
        for (let i = 0; i < resp.list.length; i++) {
            const respElement = resp.list[i];
            if (validate(respElement.customer.id)) {
                customerOlderThanMonth = respElement.customer.id;
                subscriptionID = respElement.subscription.id;
                break;
            }
        }

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customerOlderThanMonth}&subscriptionId=${subscriptionID}`, null, headers);
        await addMsg(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customerOlderThanMonth}&subscriptionId=${subscriptionID}`);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(customerOlderThanMonth);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('cancelled');
        let cbCreditNoteResponse = await chargebeeSubscription.getCustomersInvoice(customerOlderThanMonth);
        await addMsg({message: JSON.stringify(cbCreditNoteResponse, null, 2)});
        expect(cbCreditNoteResponse.list[0].invoice.issued_credit_notes[0]).toMatchObject({
            "cn_id": expect.any(String),
            "cn_reason_code": "other",
            "cn_create_reason_code": "Other",
            "cn_date": expect.any(Number),
            "cn_total": 9900,
            "cn_status": "refunded"
        });
        let visa = await card.getVisaCard();
        let inputDataPatch = {
            paymentCardToken: visa
        };
        await addMsg({message: JSON.stringify(inputDataPatch, null, 2)});
        const responsePatch = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customerOlderThanMonth}`, inputDataPatch, headers);
        await addMsg({message: JSON.stringify(responsePatch.data, null, 2)});
        expect(responsePatch.status).toBe(200);

        let inputData = xsPlus.addSubscriptions(customerOlderThanMonth, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const responseAddSubscription = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(responseAddSubscription.data, null, 2)});
        expect(responseAddSubscription.status).toBe(200);
        let cbSubscription = await chargebeeSubscription.getCustomerSubscriptions(customerOlderThanMonth);
        await addMsg({message: JSON.stringify(cbSubscription, null, 2)});
        let newSubscriptionID = cbSubscription.list[0].subscription.id;
        expect(cbSubscription.list[0].subscription.subscription_items[0].item_price_id).toBe('R149-plan-ZAR-Monthly');
        expect(cbSubscription.list[0].subscription.status).toBe('active');
        expect(cbSubscription.list[0].subscription.coupon).toBe('R50DISCOUNTCOUPON');
        expect(cbSubscription.list[0].subscription.subscription_items[0]).toMatchObject({
            "item_price_id": "R149-plan-ZAR-Monthly",
            "item_type": "plan",
            "quantity": 1,
            "unit_price": 14900,
            "amount": 14900,
            "free_quantity": 0,
            "object": "subscription_item"
        });
        const responseCancel = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customerOlderThanMonth}&subscriptionId=${newSubscriptionID}`, null, headers);
        await addMsg(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customerOlderThanMonth}&subscriptionId=${newSubscriptionID}`);
        await addMsg({message: JSON.stringify(responseCancel.data, null, 2)});
        expect(responseCancel.status).toBe(200);
        let cbSubscription2Response = await chargebeeSubscription.getCustomerSubscriptions(customerOlderThanMonth);
        await addMsg({message: JSON.stringify(cbSubscription2Response, null, 2)});
        expect(cbSubscription2Response.list[0].subscription.status).toBe('cancelled');
    });

    test('valid customer with active subscription within first month', async () => {
        let visa = await card.getVisaCard();
        let customer = await customerXtraSavings.createCustomer(true);
        let inputData = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const responseCustomer = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(responseCustomer.data, null, 2)});
        subscriptionID = responseCustomer.data.response.xtraSavingsPlus.subscriptions[0].subscriptionId;

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customer.uuid}&subscriptionId=${subscriptionID}`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(customer.uuid);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('cancelled');
        let cbCreditNoteResponse = await chargebeeSubscription.getCustomersInvoice(customer.uuid);
        await addMsg({message: JSON.stringify(cbCreditNoteResponse, null, 2)});
        expect(cbCreditNoteResponse.list[0].invoice.issued_credit_notes[0]).toMatchObject({
            "cn_id": expect.any(String),
            "cn_reason_code": "other",
            "cn_create_reason_code": "Other",
            "cn_date": expect.any(Number),
            "cn_total": 9900,
            "cn_status": "refunded"
        });
    });

    test('subscription already cancelled', async () => {
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=dc6897af-3901-47a9-8a49-eda015dce200&subscriptionId=Azz5iPTP7ilxa8jNK`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no subscriptionId', async () => {
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=78d2bd03-ef06-4d47-9bf3-27d318bad762`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no uid', async () => {
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?subscriptionId=16BS0vTNFtKDSkwK`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid subscriptionId', async () => {
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=78d2bd03-ef06-4d47-9bf3-27d318bad762&subscriptionId=169ljHTP7ig0i8mTNabc`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid uid', async () => {
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=78d2bd03-ef06-4d47-9bf3-27d318bad999&subscriptionId=16BS0vTNFtKDSkwKabc`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand', async () => {
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/xsplus/cancel?uid=16463cf0-a7f2-48d3-a071-1ab275e05b88&subscriptionId=16BS0vTNFtKDSkwK`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code', async () => {
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/xsplus/cancel?uid=16463cf0-a7f2-48d3-a071-1ab275e05b88&subscriptionId=169lu5TP9Kkd3EpF`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
