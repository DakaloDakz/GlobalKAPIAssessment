import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DSLEntilements from "../../data/entitlements.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(0);
describe.skip('DSL - get customer Entitlement', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const entitlements = new DSLEntilements();
    let access;
    let token;

    beforeAll(async () => {

    });

    test('valid uid activate', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        let json = entitlements.get_entitlements_payload('69ceca31-ed77-4b2d-a477-91e56073c142', 'discount10', 'true');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, json, headers);
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('GET valid uid activate', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: 'ecd594cd-def4-4fc3-88be-7019785116aa'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('valid uid deactivate', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        let json = entitlements.get_entitlements_payload('69ceca31-ed77-4b2d-a477-91e56073c142', 'discount10', 'false');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('GET valid uid deactivate', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: 'ecd594cd-def4-4fc3-88be-7019785116aa'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('With Customer not subscribed', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: 'f5f699d3-f0a7-4f83-967b-33783d700226'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid uid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: 'ndoudakalo@yahoo.com'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Blank uid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: ''
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: 'ecd594cd-def4-4fc3-88be-7019785116aa'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/okfood/countries/za/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('INvalid countrycode', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            uid: 'ecd594cd-def4-4fc3-88be-7019785116aa'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/entitlements`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/zim/entitlements`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
