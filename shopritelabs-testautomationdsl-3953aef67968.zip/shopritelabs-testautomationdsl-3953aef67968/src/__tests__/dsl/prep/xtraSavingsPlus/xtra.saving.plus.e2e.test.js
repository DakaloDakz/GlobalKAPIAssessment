import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import DataHelpers from "../../../__utils__/data_helpers";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import XsplusData from "../../../__utils__/xtraSavingPlus/data/xsplus.data";
import XtraSavingsPlusCustomer from "../../../__utils__/xtraSavingPlus/lib/customer";
import ChargebeeCustomer from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.customer.sdk";
import ChargebeeSubscriptions from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.subscriptions.sdk";

describe('DSL - XS Plus End2End', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const chargebeeCustomer = new ChargebeeCustomer();
    const chargebeeSubscription = new ChargebeeSubscriptions();
    const customerXtraSavings = new XtraSavingsPlusCustomer();
    const xsPlus = new XsplusData();
    let customerNegativeTests;
    let customerVisa;
    let idSubcription;

    beforeAll(async () => {

    });

    test('subscription registration with Visa card', async () => {
        customerVisa = await customerXtraSavings.createCustomer(true);
        expect(customerVisa.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerVisa.uuid, customerVisa.email, customerVisa.mobileNumber, '64369e765d3452d4845038b0/658E69F8-867A-43C3-BACB-7FA26BE29FCA', 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(customerVisa.uuid).toBe(data.response.uuid);
        expect(customerVisa.email).toBe(data.response.email);
        expect(customerVisa.firstName).toBe(data.response.firstName);
        expect(customerVisa.lastName).toBe(data.response.lastName);
        expect(customerVisa.mobileNumber).toBe(data.response.mobileNumber);
        expect(customerVisa.idNumber).toBe(data.response.saIdNumber);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customerVisa.firstName, customerVisa.lastName, customerVisa.email, customerVisa.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customerVisa.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customerVisa.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customerVisa.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customerVisa.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(cbCustomerResponse.list[0].customer.id);
        idSubcription = cbSubscriptionResponse.list[0].subscription.id;
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0].item_price_id).toBe('R149-plan-ZAR-Monthly');
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('active');
        expect(cbSubscriptionResponse.list[0].subscription.coupon).toBe('R50DISCOUNTCOUPON');
    });

    test('update within first month', async () => {
        await addMsg({message: JSON.stringify(customerVisa, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let date = new Date();
        let termEndDate = new Date(date.getFullYear(), date.getMonth() + 1, 0).toISOString().slice(0, 10);
        let inputData = xsPlus.patchBillingInformation(customerVisa.email, customerVisa.mobileNumber, null, termEndDate);
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customerVisa.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(411);
    });

    test('EndTerm updates current month after next billing cycle', async () => {
        let subscriptionId = '16CJAuTYNSruz5gr6';
        let email = 'gogoxsplus@yopmail.com';
        let mobileNumber = '+27617152008';
        let firstName = 'Gogo';
        let lastName = 'Xs Plus';
        let uuid = 'e7c161bb-a446-4f00-a2c5-5942f099f579';
        let date = new Date();
        let cbSubscriptionOriginal = await chargebeeSubscription.getCustomerSubscriptions(uuid);
        let metaDate = new Date(date.getFullYear(), date.getMonth() - 3, date.getDate()).toISOString().slice(0, 10);
        let originalEpoch = Math.floor(new Date(date.getFullYear(), date.getMonth() + 1, date.getDate() + 9).getTime() / 1000.0);
        let updateMetaData = await chargebeeSubscription.updateSubscriptionMetaData(subscriptionId, "{\"BillingDateChanged\":\"" + metaDate + "\"}");
        // let updateTermEnd = await chargebeeSubscription.updateSubscriptionTermEnd(subscriptionId, originalEpoch )
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const rndInt = dataHelpers.generateRandomNumber(1, 6);
        let termEndDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate() + 3).toISOString().slice(0, 10);
        let inputData = xsPlus.patchBillingInformation(email, mobileNumber, '645100712567587aa39275b5/C0EB1D9C-A698-431A-9772-7B9382DF8B9D', termEndDate);
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(firstName, lastName, email, mobileNumber);
        let id = cbCustomerResponse.list[0].customer.id;
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(uuid);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        let termEndSubscription = new Date(cbSubscriptionResponse.list[0].subscription.next_billing_at * 1000).toISOString().slice(0, 10);
        let termEndSubscriptionOriginal = new Date(cbSubscriptionOriginal.list[0].subscription.next_billing_at * 1000).toISOString().slice(0, 10);
        let expectedDate = new Date(termEndDate).setMonth(date.getMonth() + 1);
        expect(termEndSubscription).toBe(new Date(expectedDate).toISOString().slice(0, 10));
        const responseGet = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=${uuid}`, headers, null);
        await addMsg({
            message: JSON.stringify({
                "original": termEndSubscriptionOriginal,
                "setValue": termEndDate,
                "billingDate": termEndSubscription
            }, null, 2)
        });
        expect(responseGet.status).toBe(200);
        expect(termEndSubscription).toBe(responseGet.data.response.xtraSavingsPlus.subscriptions[0].nextBillingAt.slice(0, 10));
    });
});
