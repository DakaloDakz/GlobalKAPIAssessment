import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - GET on /savings/auth', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    let access;

    beforeAll(async () => {

    });

    test('get valid auth', async () => {
        let uuid = '';
        let year = new Date().getFullYear();
        let month = new Date().getMonth() + 1;
        month = month.length !== 2 ? '0' + month : month;
        let period = `${year}${month}`;
        let payload = {
            "UUID": "eeb567d9-ca2a-4208-ba65-e320bb018528",
            "TimeStamp": "/Date(1675326911999)/",
            "Customers": [{
                "CustomerId": "eeb567d9-ca2a-4208-ba65-e320bb018528",
                "HouseholdId": "",
                "MarketingAreaId": "ZCHECKERS_ZA",
                "Period": "202303",
                "FirstSwipe_Timestamp": "20230125173016",
                "AutoOptIn": true,
                "TranTsMin": "20230125173016",
                "TranTsMax": "20230128102506",
                "Lifetime_SavingsAmount": "1036.63",
                "Lifetime_Swipes": "22",
                "Monthly_SavingsAmount": "1036.63",
                "Monthly_Swipes": "22",
                "Monthly_SwipeForGood": "0",
                "SFC_IND": false,
                "Categories": [{
                    "Id": "9003",
                    "SavingsAmount": "0.00",
                    "Swipes": "3"
                }, {
                    "Id": "9006",
                    "SavingsAmount": "210.03",
                    "Swipes": "17"
                }, {
                    "Id": "9008",
                    "SavingsAmount": "0.00",
                    "Swipes": "3"
                }, {
                    "Id": "9009",
                    "SavingsAmount": "41.91",
                    "Swipes": "3"
                }, {
                    "Id": "9011",
                    "SavingsAmount": "244.96",
                    "Swipes": "22"
                }, {
                    "Id": "9013",
                    "SavingsAmount": "539.73",
                    "Swipes": "3"
                }],
                "Segments": [{
                    "Id": "1001",
                    "ZBON": "",
                    "BillingPer": "",
                    "SavingsAmount": "76.91",
                    "Swipes": "4"
                }, {
                    "Id": "1003",
                    "ZBON": "",
                    "BillingPer": "",
                    "SavingsAmount": "94.97",
                    "Swipes": "4"
                }, {
                    "Id": "1004",
                    "ZBON": "",
                    "BillingPer": "",
                    "SavingsAmount": "334.85",
                    "Swipes": "4"
                }, {
                    "Id": "1005",
                    "ZBON": "",
                    "BillingPer": "",
                    "SavingsAmount": "189.94",
                    "Swipes": "5"
                }, {
                    "Id": "1006",
                    "ZBON": "",
                    "BillingPer": "",
                    "SavingsAmount": "59.97",
                    "Swipes": "3"
                }, {
                    "Id": "1007",
                    "ZBON": "14",
                    "BillingPer": "202302",
                    "SavingsAmount": "245.00",
                    "Swipes": "1"
                }, {
                    "Id": "1007",
                    "ZBON": "15",
                    "BillingPer": "202302",
                    "SavingsAmount": "34.99",
                    "Swipes": "1"
                }, {
                    "Id": "1007",
                    "ZBON": "14",
                    "BillingPer": "202303",
                    "SavingsAmount": "245.00",
                    "Swipes": "1"
                }, {
                    "Id": "1007",
                    "ZBON": "15",
                    "BillingPer": "202303",
                    "SavingsAmount": "34.99",
                    "Swipes": "1"
                }]
            }]
        };
        const headers = {
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/savings`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/savings`, payload, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    // test('get customer profile - with CAR savings', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json'
    //     };
    //
    //     const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=984d79a3-392e-4df6-90a6-50949a150ade`, headers, null);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(200);
    //     let {data} = response;
    //     expect('984d79a3-392e-4df6-90a6-50949a150ade').toBe(data.response.uuid);
    //     expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
    //         "createdAt": expect.any(String),
    //         "subscriptionItems": [{
    //             "unitPrice": "149.00",
    //             "amount": "149.00",
    //             "itemPriceId": "R149-Plan-Daily-ZAR-Daily"
    //         }],
    //         "currentTermStart": expect.any(String),
    //         "currentTermEnd": expect.any(String),
    //         "subscriptionStatus": "cancelled",
    //         "subscriptionId": expect.any(String),
    //         "couponItems": [{
    //             "couponId": "R50DISCOUNTCOUPON"
    //         }]
    //     });
    //     expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
    //         "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
    //         // "consentTemplateVersion": "1.0",
    //         "updated": expect.any(String),
    //         "granted": true
    //     });
    //     expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
    //         "email": "Pattie-Feest@shoprite-testautomation.com",
    //         "firstName": "Pattie",
    //         "lastName": "Feest",
    //         "mobileNumber": "+27815499635"
    //     });
    //     expect(data.response.xtraSavingsPlus.savings).toMatchObject({
    //         "billingPeriod": "202303",
    //         "monthlySavingsAmount": "1036.63",
    //         "monthlyFreeDeliverySavings": "34.99",
    //         "monthlyFreeDeliveryCount": "1",
    //         "monthlyDiscountSavings": "295.00",
    //         "monthlyExtraSavings": "756.64",
    //         "discountRedeemed": true
    //     });
    //     let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
    //     if (!isResponseValid.success) {
    //         await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
    //         throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
    //     }
    //     expect(isResponseValid.success).toBe(true);
    // });

});
