# Customer ID: 5e4e87b6-6d95-4d35-ac61-74144d424fc1

# Scenario 1

> CAR period 202305 </br>
> Renewal Period 202306

```json
"savings": {
    "billingPeriod": "",
    "monthlySavingsAmount": "0",
    "monthlyFreeDeliverySavings": "0",
    "monthlyFreeDeliveryCount": "0",
    "monthlyDiscountSavings": "0",
    "monthlyExtraSavings": "0",
    "discountRedeemed": false
}
```

# Scenario 2

> CAR period 202305 </br>
> Renewal Period 202305

```json
"savings": {
    "billingPeriod": "202305",
    "monthlySavingsAmount": "1035",
    "monthlyFreeDeliverySavings": "34",
    "monthlyFreeDeliveryCount": "1",
    "monthlyDiscountSavings": "245",
    "monthlyExtraSavings": "756",
    "discountRedeemed": true
}
```

# Scenario 3

> CAR period 202306</br>
> Renewal Period 202306 - Discount used

```json
"savings": {
    "billingPeriod": "202306",
    "monthlySavingsAmount": "1035",
    "monthlyFreeDeliverySavings": "34",
    "monthlyFreeDeliveryCount": "0",
    "monthlyDiscountSavings": "245",
    "monthlyExtraSavings": "756",
    "discountRedeemed": true
}
```

# Scenario 4

> CAR period 202306</br>
> Renewal Period 202306 - Discount not used

```json
"savings": {
    "billingPeriod": "202306",
    "monthlySavingsAmount": "1035",
    "monthlyFreeDeliverySavings": "34",
    "monthlyFreeDeliveryCount": "1",
    "monthlyDiscountSavings": "245",
    "monthlyExtraSavings": "756",
    "discountRedeemed": false
}
```

# Scenario 5

> CAR period 202306</br>
> Renewal Period 202305

```json
"savings": {
    "billingPeriod": "202306",
    "monthlySavingsAmount": "1035",
    "monthlyFreeDeliverySavings": "34",
    "monthlyFreeDeliveryCount": "1",
    "monthlyDiscountSavings": "245",
    "monthlyExtraSavings": "756",
    "discountRedeemed": false
}
```

# Scenario 6

> CAR period 202306</br>
> No Renewal Data exists

```json
"savings": {
    "billingPeriod": "202306",
    "monthlySavingsAmount": "1035",
    "monthlyFreeDeliverySavings": "34",
    "monthlyFreeDeliveryCount": "1",
    "monthlyDiscountSavings": "245",
    "monthlyExtraSavings": "756",
    "discountRedeemed": false
}
```

# Scenario 7

> No CAR data</br>
> No Renewal Data exists

```json
"savings": {
    "billingPeriod": "",
    "monthlySavingsAmount": "0",
    "monthlyFreeDeliverySavings": "0",
    "monthlyFreeDeliveryCount": "0",
    "monthlyDiscountSavings": "0",
    "monthlyExtraSavings": "0",
    "discountRedeemed": false
}
```

# Scenario 8

> No CAR data</br>
> Renewal Period 202306

```json
"savings": {
    "billingPeriod": "",
    "monthlySavingsAmount": "0",
    "monthlyFreeDeliverySavings": "0",
    "monthlyFreeDeliveryCount": "0",
    "monthlyDiscountSavings": "0",
    "monthlyExtraSavings": "0",
    "discountRedeemed": false
}
```
