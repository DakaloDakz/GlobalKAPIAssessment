import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DSLProductsSubscribe from "../../data/products.subscribe.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - Subscribe to a product enhancement process', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const productsubscribe = new DSLProductsSubscribe();

    beforeAll(async () => {

    });

    test('Subscribe to a valid Checkers product', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`});
        let json = productsubscribe.get_productsubscribe_payload('10407762EA');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('Subscribe to a valid shoprite product', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/subscribe`});
        let json = productsubscribe.get_productsubscribe_payload('10112836EA');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('Subscribe to a valid product that has already subscribe', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`});
        let json = productsubscribe.get_productsubscribe_payload('10407762EA');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('Subscribe to a invalid product', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`});
        let json = productsubscribe.get_productsubscribe_payload('Dakalo');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
    });

    test('Subscribe to a product without a payload', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`});
        let json = '';
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
    });

    test('delete a valid checkers product subcription', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`});
        let json = productsubscribe.get_productunsubscribe_payload('10407762EA');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('delete a valid shoprite product subcription', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/subscribe`});
        let json = productsubscribe.get_productunsubscribe_payload('10112836EA');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('valid product subcription with invalid brand', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/subscribe`});
        let json = productsubscribe.get_productunsubscribe_payload('10112836EA');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/okfood/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
    });

    test('valid product subcription with invalid country code', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/subscribe`});
        let json = productsubscribe.get_productunsubscribe_payload('10112836EA');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/nb/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
    });

});
