import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - Get Products Carousel (/products/carousel)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();

    beforeAll(async () => {

    });

    test('get carousel with valid id - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_00096014`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_00096014`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.products.length).toBeGreaterThan(0);
    });

    test('get carousel with valid id and store id - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_00096014?preferredStoreId=1103`});
        let params = {preferredStoreId: '1103'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_00096014`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.products.length).toBeGreaterThan(0);
    });

    test('get carousel with valid id - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/carousel/cmsitem_00093002`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/carousel/cmsitem_00093002`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.products.length).toBeGreaterThan(0);
    });

    test('get carousel with valid id and store id - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/carousel/cmsitem_00093002?preferredStoreId=1006`});
        let params = {preferredStoreId: '1006'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/carousel/cmsitem_00093002`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.products.length).toBeGreaterThan(0);
    });

    test('get carousel with invalid id', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_000960149`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_000960149`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get carousel with valid id and invalid store id', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_00096014?preferredStoreId=1103`});
        let params = {preferredStoreId: '9999'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_00096014`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('checkers carousel with shoprite brand in URL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/carousel/cmsitem_00096014`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/carousel/cmsitem_00096014`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('shoprite carousel with checkers brand in URL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_00093002`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/carousel/cmsitem_00093002`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/products/carousel/cmsitem_00093002`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/products/carousel/cmsitem_00093002`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/products/carousel/cmsitem_00093002`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/products/carousel/cmsitem_00093002`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
