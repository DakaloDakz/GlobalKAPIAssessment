import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import Authentication from "../../../__utils__/auth/dsl/auth.methods";
import ValueAddedServices from "../../data/value.added.services.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - Loyalty Services(/loyaltyservices)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const vas = new ValueAddedServices();
    const ciamAuth = new CIAMAuth();
    let access;

    beforeAll(async () => {

    });

    test('LoyaltyServices update Lname and Fname', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "GymsUpdated",
                "lastName": "KimyeUpdated",
                "mobileNumber": "+27717850087"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices/SwipeForCover?uid=76a5e71e-5e8a-41ff-aa60-fe731acd1d3a`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices for customer after PUT', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices?uid=76a5e71e-5e8a-41ff-aa60-fe731acd1d3a`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.details[0].updatedDate']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices update with brand checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "GymsUpdated",
                "lastName": "KimyeUpdated",
                "mobileNumber": "+27717850087"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loyaltyservices/SwipeForCover?uid=76a5e71e-5e8a-41ff-aa60-fe731acd1d3a`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices revert back Lname and Fname', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Gyms",
                "lastName": "Kimye",
                "mobileNumber": "+27717850087"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices/SwipeForCover?uid=76a5e71e-5e8a-41ff-aa60-fe731acd1d3a`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices for customer after PUT revert', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices?uid=76a5e71e-5e8a-41ff-aa60-fe731acd1d3a`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.details[0].updatedDate']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices invalid customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Dakalo",
                "lastName": "Nduo",
                "mobileNumber": "+27647572677"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices/SwipeForCover?uid=dakalo.ndou`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(404);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices with no UID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Dakalo",
                "lastName": "Nduo",
                "mobileNumber": "+27647572677"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices/SwipeForCover`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices for customer with checkers brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loyaltyservices?uid=df3ae0e8-2ab7-4291-9f51-34dc5ffe43ed`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.details[0].updatedDate']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices put with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Dakalo",
                "lastName": "Nduo",
                "mobileNumber": "+27647572677"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/loyaltyservices/SwipeForCover?uid=df3ae0e8-2ab7-4291-9f51-34dc5ffe43ed`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices put with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Dakalo",
                "lastName": "Nduo",
                "mobileNumber": "+27647572677"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/loyaltyservices/SwipeForCover?uid=df3ae0e8-2ab7-4291-9f51-34dc5ffe43ed`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/loyaltyservices?uid=df3ae0e8-2ab7-4291-9f51-34dc5ffe43ed`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/loyaltyservices?uid=df3ae0e8-2ab7-4291-9f51-34dc5ffe43ed`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
