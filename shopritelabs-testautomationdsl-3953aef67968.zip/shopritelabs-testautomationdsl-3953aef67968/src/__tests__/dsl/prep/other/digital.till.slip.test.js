import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addAttach, addMsg} from "jest-html-reporters/helper";
import DSLTransactions from "../../data/transactions.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - Get Customer digital till slips (/tillslip)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const transactions = new DSLTransactions();
    let access;
    let token;

    beforeAll(async () => {

    });

    test('get till slip for xxxx@xxx.com - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let buff = new Buffer.from(data.response, 'base64');
        await addAttach({
            attach: buff,
            description: 'Digital Tillslip Image'
        });
    });

    test('get till slip for xxxx@xxx.com - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '61.9500', '2022-02-28T11:50:24', '9710085090004303', '2022-02-28', '91702');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let buff = new Buffer.from(data.response, 'base64');
        await addAttach({
            attach: buff,
            description: 'Digital Tillslip Image'
        });
    });

    test('empty body', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/tillslip`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/tillslip`, {}, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty tranId', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('', '1', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty posId', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty totalAmount', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty startDateTime', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty cardNumber', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '2022-02-28T11:58:07', '', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty posDateTime', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty storeId', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid tranId', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('100', '1', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid posId', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '100', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid totalAmount', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '089.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid startDateTime', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '2022-02-99T11:58:07', '9710084090015526', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        expect(response.status).toBe(400);
        expect(response.data.exception).toBe('status code: 400, reason phrase: Unexpected response from Lpro There is an error in XML document (6, 13).&#xD;&#xA;The string \'2022-02-99T11:58:07\' is not a valid AllXsd value.');
    });

    test('invalid cardNumber', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '2022-02-28T11:58:07', '971008409009999', '2022-02-28', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid posDateTime', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-99', '87802');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        expect(response.status).toBe(400);
        expect(response.data.exception).toBe('status code: 400, reason phrase: Unexpected response from Lpro There is an error in XML document (3, 13).&#xD;&#xA;String was not recognized as a valid DateTime.');
    });

    test('invalid storeId', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`});
        let json = transactions.get_digital_tillslip_payload('1', '1', '89.5900', '2022-02-28T11:58:07', '9710084090015526', '2022-02-28', 'abc');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/tillslip`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
