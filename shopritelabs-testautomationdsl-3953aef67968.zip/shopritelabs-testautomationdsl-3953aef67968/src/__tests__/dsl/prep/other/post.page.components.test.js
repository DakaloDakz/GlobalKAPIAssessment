import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DSLPageComponents from "../../data/page.componets.data";

describe('Returns cms components by the specified Component IDs)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const dslPageComponents = new DSLPageComponents();

    beforeAll(async () => {

    });

    test('Returns cms components by one specified Component IDs', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('getMoreWithUsCarouselComponent');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.componentObject.component.length).toBeGreaterThan(0);
    });

    test('Returns cms components by one specified Component IDs in checkers brand', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('termsAndConditionsTitleParagraph', 'getMoreWithUsCarouselComponent');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/components`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.componentObject.component.length).toBeGreaterThan(0);
    });

    test('Returns cms components by the specified Component IDs', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('termsAndConditionsSection3', 'getMoreWithUsCarouselComponent', 'ShrFooterComponent');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/components`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.componentObject.component.length).toBeGreaterThan(0);
    });

    test('Returns cms components with 3 specified Component IDs', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('ShrFooterComponent', 'getMoreWithUsCarouselComponent', 'termsAndConditionsTitleParagraph');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/components`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.componentObject.component.length).toBeGreaterThan(0);
    });

    test('Returns cms components with no specified Component IDs', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.componentObject.component.length).toBeGreaterThan(0);
    });

    test('Returns cms components by the specified Component IDs and currentPage=1 &pageSize=5', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('termsAndConditionsSection3', 'Terms and Conditions Section 3');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components?currentPage=1&pageSize=5`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('Returns cms components by the specified Component IDs and currentPage=1', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('termsAndConditionsSection3', 'Terms and Conditions Section 3');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components?currentPage=1`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('Returns cms components by the specified Component IDs and pageSize=5', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('termsAndConditionsSection3', 'Terms and Conditions Section 3');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components?pageSize=5`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.componentObject.component.length).toBeGreaterThan(0);
    });

    test('Returns cms components by one specified Component IDs invalid brand', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('termsAndConditionsTitleParagraph');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/components`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('Returns cms components by one specified Component IDs invlad country code', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('termsAndConditionsTitleParagraph');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/nb/components`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('Returns cms components by one specified Component IDs invalid url', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/components`});
        let json = dslPageComponents.create_page_components();
        json.componentIds.push('termsAndConditionsTitleParagraph');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/Components`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
    });

});

