import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DSLServiceTicket from "../../data/service.ticket.data";

describe('DSL - Get All Domains', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const ticket = new DSLServiceTicket();
    let access;

    beforeAll(async () => {

    });

    test('Get All Domains valid', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicedomains`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/customerservices/servicedomains`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        //expect(data).toMatchSnapshot();
    });

    test('with invalid token', async () => {
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicedomains`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/customerservices/servicedomains`);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });
});
