import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DSLMobileDevice from "../../data/mobile.device.data";
import Authentication from '../../../__utils__/auth/ciam/auth.methods';

jest.retryTimes(1);
describe('DSL - Get Customer accumulated swipes', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const mobileDevice = new DSLMobileDevice();

    beforeAll(async () => {

    });

    test('Register a customer mobile device Valid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'uid': '8aea73fc-4199-407d-a4a9-3ef8231c330c'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('Android', '1.0.3', '2.4', '1234567', 'sixty60 app');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

    test('Register a customer mobile device with invalid uid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'uid': '136d6d48-2a85-4648-a295-a5fcb5209'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('Android', '1.0.3', '2.4', '1234567', 'sixty60 app');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

    test('Register a customer mobile device without uid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('Android', '1.0.3', '2.4', '1234567', 'sixty60 app');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

    test('Register a customer mobile device without operating system', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('', '1.0.3', '2.4', '1234567', 'sixty60 app');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

    test('Register a customer mobile device without operating system version', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('Android', '', '2.4', '1234567', 'sixty60 app');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

    test('Register a customer mobile device without app version', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('Android', '1.0.3', '', '1234567', 'sixty60 app');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

    test('Register a customer mobile device without instance Id', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('Android', '1.0.3', '2.4', '', 'sixty60 app');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

    test('Register a customer mobile device without channel', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('Android', '1.0.3', '2.4', '1234567', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();

    });

    test('Register a customer mobile device without payload', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json',
            'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`});
        let json = mobileDevice.create_mobileDevice_payload('', '', '', '', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/mobileDevices`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

});