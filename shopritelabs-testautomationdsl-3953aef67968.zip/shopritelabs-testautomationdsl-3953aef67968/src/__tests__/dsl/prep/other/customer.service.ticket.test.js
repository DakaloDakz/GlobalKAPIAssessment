import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DSLServiceTicket from "../../data/service.ticket.data";
import {faker} from '@faker-js/faker';

describe('DSL - Create Authenticated Customer Service Ticket (/dsl/customerservices/servicetickets@email/servicetickets)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const ticket = new DSLServiceTicket();
    let access;

    beforeAll(async () => {

    });

    test.skip('valid Sixty60 ticket', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test.skip('valid Sixty60 ticket with double quotes', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, "Sixty60", "Sixty60", "rewards_card", "rewards_card", "complaint", "complaint", "Adding a Complaint - Sixty60", "This is a complaint about Sixty60", "checkers_canal_walk");

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid token', async () => {
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, {});
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('no email address', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, '', 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('no store Id', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('no message content', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', '', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('no subject name', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', '', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('no message type name', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', '', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('no message type Id', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', '', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test.skip('no reference name', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', 'rewards_card', '', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test.skip('no reference Id', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', 'Sixty60', '', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('no domain name', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, 'Sixty60', '', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('no domain Id', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, surname, email, '', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('no name', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket('', surname, email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('no surname', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `narsareddy.baddam@shoprite.co.za`;
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/servicetickets`});
        let json = ticket.create_service_ticket(name, '', email, 'Sixty60', 'Sixty60', 'rewards_card', 'rewards_card', 'complaint', 'complaint', 'Adding a Complaint - Sixty60', 'This is a complaint about Sixty60', 'checkers_canal_walk');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customerservices/servicetickets`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
