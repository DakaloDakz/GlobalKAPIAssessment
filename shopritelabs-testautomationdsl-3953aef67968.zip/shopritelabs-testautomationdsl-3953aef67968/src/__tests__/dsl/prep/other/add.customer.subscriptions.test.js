import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import Authentication from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import DSLSubscriptions from "../../data/subscriptions.data";
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";
import {stringify} from "qs";

describe('DSL - Add a customer to a newsletter subscription', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const subscriptions = new DSLSubscriptions();
    let access;

    beforeAll(async () => {
        let authUrl;
        let clientId;
        let clientSecret;

        if (environment === 'qa') {
            authUrl = 'https://dslqa.auth.eu-west-1.amazoncognito.com/oauth2/token';
            clientId = '1lc6ns00ds0tm550b4sncdf3be';
            clientSecret = '1d7k7r4649icri05c7l3v7p7gc4c5mo8gav59dk9qoreg2b1jktk';
        }
        if (environment === 'prep') {
            authUrl = 'https://dslprep.auth.eu-west-1.amazoncognito.com/oauth2/token';
            clientId = '5mrissc65hq5rglluonivrnq9s';
            clientSecret = 'am8itqm5iah9dpj5ch38cm1faiiuedrtk0hlrtcnfcajkcmv2np';
        }
        const credential = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
        const headers1 = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${credential}`
        };
        const data1 = {
            grant_type: 'client_credentials',
            scope: ''
        };
        access = await apiCall.POST(authUrl, stringify(data1), headers1);
        access = access.data.access_token;
    });

    test('Add a customer to a newsletter subscription with valid parameters', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.OkFoodsEverlyticApiKey,
            'Content-Type': 'application/json',
            'uid': '3ea08a02-e4ed-439c-a7a1-4c95d4a61b19'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
        let json = subscriptions.create_Subscriptions_payload('update', 'Colleen-Feil@shoprite-testautomation.com', '+27845830031', 'Colleen', 'Feil', '12/05/1990', 'female', 'private', '1 street', 'cape town', '8000', 'South Africa', 'Western Cape', 'Yes', 'yes', '10', 'subscribed');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    // test('Add a customer to a newsletter subscription with valid parameters loyalty =no', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '3ea08a02-e4ed-439c-a7a1-4c95d4a61b19'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('Taylor61@shoprite-testautomation.com', '+27839060430', 'Taylor', 'South Africa', 'Western Cape', 'No', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(200);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with valid parameters status = unsubscribed', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '3ea08a02-e4ed-439c-a7a1-4c95d4a61b19'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('Marcelle-Koss@shoprite-testautomation.com', '+27828859340', 'Marcelle', 'South Africa', 'Western Cape', 'Yes', '10', 'unsubscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(200);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add invalid customer to a newsletter subscription', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb5209200'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('dakalo@yopmail.com', '+27825555550', 'dakalo Bongi', 'South Africa', 'Western Cape', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with invalid email', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('121', '+27825555554', 'Venus Bongi', 'South Africa', 'Western Cape', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with invalid mobile number', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '25555554', 'Venus Bongi', 'South Africa', 'Western Cape', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with invalid first name', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', '55555', 'South Africa', 'Western Cape', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with invalid country', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'Lwamondo', 'Western Cape', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with invalid province', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'South Africa', 'jhb', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with invalid loyalty', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'South Africa', 'Western Cape', 'dk', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with invalid ID', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'South Africa', 'Western Cape', 'Yes', 'no', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with invalid status', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'South Africa', 'Western Cape', 'Yes', '10', 'not');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with blank email', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('', '+27825555554', 'Venus Bongi', 'South Africa', 'Western Cape', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with blank mobile number', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '', 'Venus Bongi', 'South Africa', 'Western Cape', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with blanks first name', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', '', 'South Africa', 'Western Cape', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with blank country', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'Lwamondo', '', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with blank province', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'South Africa', '', 'Yes', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with blank loyalty', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'South Africa', 'Western Cape', '', '10', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with blank ID', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'South Africa', 'Western Cape', 'Yes', '', 'subscribed');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with Blank status', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('venus@yopmail.com', '+27825555554', 'Venus Bongi', 'South Africa', 'Western Cape', 'Yes', '10', '');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

    // test('Add a customer to a newsletter subscription with Blank parameters', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json',
    //         'uid': '136d6d48-2a85-4648-a295-a5fcb52092c2'
    //     };

    //     await addMsg({message: `${process.env.DSLGroup}/dsl/subscriptions/newsletters`});
    //     let json = subscriptions.create_Subscriptions_payload('', '', '', '', '', '', '', '');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/subscriptions/newsletters`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     let {data} = response;
    //     expect(response.status).toBe(400);
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     expect(data).toMatchSnapshot();
    // });

});
