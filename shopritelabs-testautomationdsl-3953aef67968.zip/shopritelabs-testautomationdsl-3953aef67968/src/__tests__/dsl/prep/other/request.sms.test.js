import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DSLRequestsms from "../../data/request.sms.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('Receive a request from the requesting system to send out a SMS via a communication channel', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const requestsms = new DSLRequestsms();
    let access;
    let token;

    beforeAll(async () => {

    });

    test('Send a valid sms', async () => {
        const headers = {
            // Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.omniscientApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
        let json = requestsms.get_requestsms_payload('1601153d-f117-4c0e-ab43-e9da0ce50b8c', 'Standard Bank', '7C9D8907-3CED-40B3-ACCC-F136C6C5E86D');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

//    test('Send a valid sms to user with invalid number', async () => {
//            const headers = {
//               // Authorization: `Bearer ${cognitoDSLToken}`,
//                'x-api-key': process.env.omniscientApiKey,
//                'Content-Type': 'application/json'
//            };
//            await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
//            let json = requestsms.get_requestsms_payload('79788eda-820e-482e-b2eb-bcf4ee63a1ce', 'Standard Bank', '0A46A072-82D2-4BF1-8BD2-327C77368DB7');
//            await addMsg({message: JSON.stringify(json, null, 2)});
//            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
//            await addMsg({message: JSON.stringify(response.data, null, 2)});
//            expect(response.status).toBe(200);
//            let {data} = response;
//            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
//            //expect(data).toMatchSnapshot();
//        });
//
//    test('invalid uid', async () => {
//        const headers = {
//           // Authorization: `Bearer ${cognitoDSLToken}`,
//            'x-api-key': process.env.omniscientApiKey,
//            'Content-Type': 'application/json'
//        };
//        await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
//        let json = requestsms.get_requestsms_payload('b5c9faf2-2d20-42e0-a189-2ae84c4c2134', 'Standard Bank', '3fa85f64-5717-4562-b3fc-2c963f66afa6');
//        await addMsg({message: JSON.stringify(json, null, 2)});
//        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
//        await addMsg({message: JSON.stringify(response.data, null, 2)});
//        expect(response.status).toBe(404);
//        let {data} = response;
//        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
//        //expect(data).toMatchSnapshot();
//    });
//
//    test('invalid requester', async () => {
//        const headers = {
//          //  Authorization: `Bearer ${cognitoDSLToken}`,
//            'x-api-key': process.env.omniscientApiKey,
//            'Content-Type': 'application/json'
//        };
//        await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
//        let json = requestsms.get_requestsms_payload('b5c9faf2-2d20-42e0-a189-2ae84c4c212e', 'Dakalo', '3fa85f64-5717-4562-b3fc-2c963f66afa6');
//        await addMsg({message: JSON.stringify(json, null, 2)});
//        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
//        await addMsg({message: JSON.stringify(response.data, null, 2)});
//        expect(response.status).toBe(200);
//        let {data} = response;
//        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
//        //expect(data).toMatchSnapshot();
//    });
//
//    test('invalid transactionId', async () => {
//        const headers = {
//           // Authorization: `Bearer ${cognitoDSLToken}`,
//            'x-api-key': process.env.omniscientApiKey,
//            'Content-Type': 'application/json'
//        };
//        await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
//        let json = requestsms.get_requestsms_payload('b5c9faf2-2d20-42e0-a189-2ae84c4c212e', 'Standard Bank', 'Dakalo');
//        await addMsg({message: JSON.stringify(json, null, 2)});
//        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
//        await addMsg({message: JSON.stringify(response.data, null, 2)});
//        expect(response.status).toBe(400);
//        let {data} = response;
//        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
//        //expect(data).toMatchSnapshot();
//    });
//
//    test('blank uid', async () => {
//            const headers = {
//               // Authorization: `Bearer ${cognitoDSLToken}`,
//                'x-api-key': process.env.omniscientApiKey,
//                'Content-Type': 'application/json'
//            };
//            await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
//            let json = requestsms.get_requestsms_payload('', 'Standard Bank', '3fa85f64-5717-4562-b3fc-2c963f66afa6');
//            await addMsg({message: JSON.stringify(json, null, 2)});
//            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
//            await addMsg({message: JSON.stringify(response.data, null, 2)});
//            expect(response.status).toBe(400);
//            let {data} = response;
//            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
//            //expect(data).toMatchSnapshot();
//        });
//
//        test('blank requester', async () => {
//                const headers = {
//                   // Authorization: `Bearer ${cognitoDSLToken}`,
//                    'x-api-key': process.env.omniscientApiKey,
//                    'Content-Type': 'application/json'
//                };
//                await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
//                let json = requestsms.get_requestsms_payload('b5c9faf2-2d20-42e0-a189-2ae84c4c2134', '', '3fa85f64-5717-4562-b3fc-2c963f66afa6');
//                await addMsg({message: JSON.stringify(json, null, 2)});
//                const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
//                await addMsg({message: JSON.stringify(response.data, null, 2)});
//                expect(response.status).toBe(400);
//                let {data} = response;
//                data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
//                //expect(data).toMatchSnapshot();
//            });
//
//      test('Blank transactionId', async () => {
//              const headers = {
//                 // Authorization: `Bearer ${cognitoDSLToken}`,
//                  'x-api-key': process.env.omniscientApiKey,
//                  'Content-Type': 'application/json'
//              };
//              await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
//              let json = requestsms.get_requestsms_payload('b5c9faf2-2d20-42e0-a189-2ae84c4c2134', 'Standard Bank', '');
//              await addMsg({message: JSON.stringify(json, null, 2)});
//              const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
//              await addMsg({message: JSON.stringify(response.data, null, 2)});
//              expect(response.status).toBe(400);
//              let {data} = response;
//              data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
//              //expect(data).toMatchSnapshot();
//          });
//
//       test('blank payload', async () => {
//               const headers = {
//                  // Authorization: `Bearer ${cognitoDSLToken}`,
//                   'x-api-key': process.env.omniscientApiKey,
//                   'Content-Type': 'application/json'
//               };
//               await addMsg({message: `${process.env.DSLGroup}/dsl/request/sms`});
//               let json = requestsms.get_requestsms_payload('', '', '');
//               await addMsg({message: JSON.stringify(json, null, 2)});
//               const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/request/sms`, json, headers);
//               await addMsg({message: JSON.stringify(response.data, null, 2)});
//               expect(response.status).toBe(400);
//               let {data} = response;
//               data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
//               //expect(data).toMatchSnapshot();
//           });
});
