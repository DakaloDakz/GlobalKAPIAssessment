import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DiscoveryData from "../../data/discovery.data";
import moment from "moment";
import AkamaiGetEntity from "../../../__utils__/cards/akamai.get.entity";

const testIf = (condition, ...args) =>
    // eslint-disable-next-line jest/expect-expect,jest/valid-title
    condition ? test(...args) : test.skip(...args);

jest.retryTimes(1);
describe('Discovery - Get Vitality Verification', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();
    const discoveryData = new DiscoveryData();
    const akamaiGetEntity = new AkamaiGetEntity();
    let headers, customerIdNumber, customerPassportNumber, effectiveDateTime, customerShoprite, customerPetShop,
        akamaiPetShopCustomer;

    beforeAll(async () => {
        headers = {
            'x-api-key': process.env.DiscoveryApiKey,
            'Content-Type': 'application/json'
        };

        let filterIdNumber = encodeURIComponent(`externalPartners.discoveryVitality is null and personalIdentifications.nationalIdentification.number is not null and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted='true' and cards.za.rewards.checkers.status='Active'`);
        let filterPassport = encodeURIComponent(`externalPartners.discoveryVitality is null and personalIdentifications.passport.number is not null and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted='true' and cards.za.rewards.checkers.status='Active'`);
        let filterShoprite = encodeURIComponent(`retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted='true' and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted is null and retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted='true' and personalIdentifications.nationalIdentification.number is not null and cards.za.rewards.shoprite.number is not null and cards.za.rewards.shoprite.status='Active'`);
        let filterPetShop = encodeURIComponent(`personalIdentifications.nationalIdentification.number is not null and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted is null and cards.za.rewards.checkers.status='Active' and retailServices.xtraSavings.za.checkers.memberInfo.memberId is null and retailServices.petshopScience.za.shopriteGroup.memberInfo.memberId is not null and created`);
        let akamaiCustomersWithIdNumber = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterIdNumber);
        let akamaiShopriteCustomers = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterShoprite);
        let akamaiPetShopCustomers = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterPetShop);
        if (akamaiPetShopCustomers.results !== undefined && akamaiPetShopCustomers.results.length > 0) {
            const rndIntPetShop = parseInt(dataHelpers.generateRandomNumber(0, akamaiPetShopCustomers.results.length));
            akamaiPetShopCustomer = akamaiPetShopCustomers.results[rndIntPetShop];
            customerPetShop = {
                uuid: akamaiPetShopCustomer.uuid,
                idNumber: akamaiPetShopCustomer.personalIdentifications.nationalIdentification.number.replace('ZA-', ''),
                dob: akamaiPetShopCustomer.birthday,
                mobileNumber: akamaiPetShopCustomer.mobileNumber,
                memberId: akamaiPetShopCustomer.retailServices.petshopScience.za.shopriteGroup.memberInfo.memberId
            };
        } else {
            customerPetShop = {
                uuid: "",
                idNumber: "",
                dob: "",
                mobileNumber: "",
                memberId: ""
            };
        }
        let akamaiCustomersWithPassport = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterPassport);
        const rndIntIdNumber = parseInt(dataHelpers.generateRandomNumber(0, akamaiCustomersWithIdNumber.results.length));
        const rndIntPassport = parseInt(dataHelpers.generateRandomNumber(0, akamaiCustomersWithPassport.results.length));
        const rndIntShoprite = parseInt(dataHelpers.generateRandomNumber(0, akamaiShopriteCustomers.results.length));

        let akamaiCustomerWithIdNumber = akamaiCustomersWithIdNumber.results[rndIntIdNumber];
        let akamaiCustomerWithPassport = akamaiCustomersWithPassport.results[rndIntPassport];
        let akamaiShopriteCustomer = akamaiShopriteCustomers.results[rndIntShoprite];

        customerIdNumber = {
            uuid: akamaiCustomerWithIdNumber.uuid,
            mobileNumber: akamaiCustomerWithIdNumber.mobileNumber,
            idNumber: akamaiCustomerWithIdNumber.personalIdentifications.nationalIdentification.number.replace('ZA-', ''),
            memberId: akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.memberInfo.memberId,
            dob: akamaiCustomerWithIdNumber.birthday
        };
        customerShoprite = {
            uuid: akamaiShopriteCustomer.uuid,
            idNumber: akamaiShopriteCustomer.personalIdentifications.nationalIdentification.number.replace('ZA-', ''),
            dob: akamaiShopriteCustomer.birthday,
            mobileNumber: akamaiShopriteCustomer.mobileNumber,
            memberId: akamaiShopriteCustomer.retailServices.xtraSavings.za.shoprite.memberInfo.memberId
        };
        customerPassportNumber = {
            uuid: akamaiCustomerWithPassport.uuid,
            mobileNumber: akamaiCustomerWithPassport.mobileNumber,
            passport: akamaiCustomerWithPassport.personalIdentifications.passport.number.replace('ZZ-', ''),
            memberId: akamaiCustomerWithPassport.retailServices.xtraSavings.za.checkers.memberInfo.memberId,
            dob: akamaiCustomerWithPassport.birthday
        };
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        await addMsg({message: 'customerIdNumber\n' + JSON.stringify(customerIdNumber, null, 2)});
        await addMsg({message: 'customerPassportNumber\n' + JSON.stringify(customerPassportNumber, null, 2)});
    });

    test('verification of valid customer with ID Number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerIdNumber.idNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer with no checkers consent or XS card', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', '9210222931087', 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer with checkers terms consent false and a valid XS card', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', '5810223279180', 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer with checkers terms consent true and XS card inactive', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', '5507132100081', 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer with Shoprite consent and valid Checkers XS card', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', '5311021352089', 'IDN', '1950-01-28');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer with no consent and valid Checkers XS card', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', '3108029918180', 'IDN', '1950-01-28');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid Shoprite customer with ID Number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerShoprite.idNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    testIf(akamaiPetShopCustomer !== undefined, 'verification of valid PetShop customer with ID Number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerPetShop.idNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer ID Number not in CIAM', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', '5411100000000', 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer with Passport Number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerPassportNumber.passport, 'PS', customerPassportNumber.dob);
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer Passport Number not in CIAM', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', '5411100000000', 'PS', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification of valid customer with correct Passport Number but incorrect Date of Birth', async () => {
        await addMsg({message: JSON.stringify(customerPassportNumber, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerPassportNumber.passport, 'PS', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with invalid effectiveDateTime', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('testing', customerIdNumber.idNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with future effectiveDateTime', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2029-12-30 14:44:58', customerIdNumber.idNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with effectiveDateTime before implementation', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('1929-12-30 14:44:58', customerIdNumber.idNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with invalid effectiveDateTime format', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30T14:44:58', customerIdNumber.idNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with empty effectiveDateTime', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('', customerIdNumber.idNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with invalid legalRefNumber', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', 'test', 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with empty legalRefNumber', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', '', 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with invalid legalRefType', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerIdNumber.idNumber, 'IDNumber', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with empty legalRefType', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerIdNumber.idNumber, '', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with invalid Date of Birth', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerPassportNumber.passport, 'PS', '1900/12/31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with empty Date of Birth', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerPassportNumber.passport, 'PS', '');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with invalid Date of Birth format', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', customerPassportNumber.passport, 'PS', '1999/12/31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('verification with empty input params', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = {};
        await addMsg({message: JSON.stringify(params, null, 2)});
        const response = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
