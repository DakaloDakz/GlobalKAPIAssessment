import ApiMethodUtil from "../../../__utils__/api_method_util";
import DataHelpers from "../../../__utils__/data_helpers";
import {addMsg} from "jest-html-reporters/helper";
import DiscoveryData from "../../data/discovery.data";
import AkamaiGetEntity from "../../../__utils__/cards/akamai.get.entity";

jest.retryTimes(1);
describe("Discovery - Vitality Update Discovery Member Benefit.", () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();
    const discoveryData = new DiscoveryData();
    const akamaiGetEntity = new AkamaiGetEntity();
    let headers, customer;

    beforeAll(async () => {
        headers = {
            "x-api-key": process.env.DiscoveryApiKey,
            "Content-Type": "application/json"
        };
        let maxAttempts = 5;
        let attempt = 0;

        while (attempt < maxAttempts) {
            let filterIdNumber = encodeURIComponent(`externalPartners.discoveryVitality is not null`);
            let akamaiCustomersWithIdNumber = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterIdNumber);
            const rndInt = parseInt(dataHelpers.generateRandomNumber(0, akamaiCustomersWithIdNumber.results.length));
            let akamaiCustomerWithIdNumber = akamaiCustomersWithIdNumber.results[rndInt];

            if (akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.memberInfo.memberId) {
                customer = {
                    uuid: akamaiCustomerWithIdNumber.uuid,
                    mobileNumber: akamaiCustomerWithIdNumber.mobileNumber,
                    memberId: akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.memberInfo.memberId
                };
                break;
            }
            attempt++;
        }

        if (!customer) {
            console.log('Failed to get a customer with a valid uuid after ' + maxAttempts + ' attempts');
        }
    });

    test("update of valid customer with status Pre-Active and all true", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        await addMsg({message: JSON.stringify(customer, null, 2)});
        let json = discoveryData.benefit(
            customer.memberId,
            "Pre-Activated",
            true,
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe("Pre-Activated");
        expect(response1.results[0].externalPartners.discoveryVitality[0].healthyFoodOnline).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].healthyFoodInStore).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].changeOnline).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].changeInStore).toBe(true);
    });

    test("update of valid customer with status Activated", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            true,
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe("Activated");
    });

    test("update of valid customer with healthyFoodOnline as false", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            false,
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe("Activated");
        expect(response1.results[0].externalPartners.discoveryVitality[0].healthyFoodOnline).toBe(false);
    });

    test("update of valid customer with healthyFoodInStore as false", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            true,
            false,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe("Activated");
        expect(response1.results[0].externalPartners.discoveryVitality[0].healthyFoodInStore).toBe(false);
    });

    test("update of valid customer with changeOnline as false", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            true,
            true,
            false,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe("Activated");
        expect(response1.results[0].externalPartners.discoveryVitality[0].changeOnline).toBe(false);
    });

    test("update of valid customer with changeInStore as false", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            true,
            true,
            true,
            false
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe("Activated");
        expect(response1.results[0].externalPartners.discoveryVitality[0].changeInStore).toBe(false);
    });

    test("update with customer not activated Discovery Vitality", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            "35a8b544-6490-4881-9393-85216b39b953",
            "Activated",
            false,
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with customer thar does not exist", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            "d8c9a2a6-ccf4-4889-b1d0-6cc9ce88d62b",
            "Activated",
            false,
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with invalid customer", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            "8dc909bd-c25a-",
            "Activated",
            false,
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with invalid status", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "pending",
            false,
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with blank customeId", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit("", "pending", false, true, true, true);

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with blank status", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "",
            false,
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with invalid healthyFoodOnline", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            "",
            true,
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with blank healthyFoodInStore", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            true,
            "",
            true,
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with blank changeOnline", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            true,
            true,
            "",
            true
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });

    test("update with blank changeInStore", async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit`});
        let json = discoveryData.benefit(
            customer.memberId,
            "Activated",
            true,
            true,
            true,
            ""
        );

        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.PATCH(`${process.env.DSLGroup}/discovery/benefit`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ["serverTime", "requestId"]);
        expect(data).toMatchSnapshot();
    });
});
