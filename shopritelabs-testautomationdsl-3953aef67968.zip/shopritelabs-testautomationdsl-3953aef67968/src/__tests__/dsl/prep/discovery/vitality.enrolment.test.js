import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DiscoveryData from "../../data/discovery.data";
import moment from "moment";
import AkamaiGetEntity from "../../../__utils__/cards/akamai.get.entity";

jest.retryTimes(1);
describe('Discovery - Get Vitality Verification', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();
    const discoveryData = new DiscoveryData();
    const akamaiGetEntity = new AkamaiGetEntity();
    let headers, customerIdNumber, customerPassport, effectiveDateTime, customerShoprite;

    beforeAll(async () => {
        headers = {
            'x-api-key': process.env.DiscoveryApiKey,
            'Content-Type': 'application/json'
        };
        const createFilter = (conditions) => encodeURIComponent(conditions.join(' and '));
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        const filters = {
            idNumber: [
                'externalPartners.discoveryVitality is null',
                'personalIdentifications.nationalIdentification.number is not null',
                'retailServices.xtraSavings.za.checkers.consents.termsOfService.granted is null'
            ],
            passportNumber: [
                'externalPartners.discoveryVitality is null',
                'personalIdentifications.passport.number is not null',
                'retailServices.xtraSavings.za.checkers.consents.termsOfService.granted is null'
            ],
            shoprite: [
                "retailServices.xtraSavings.za.checkers.consents.termsOfService.granted is null",
                "retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted='true'",
                "personalIdentifications.nationalIdentification.number is not null",
                "cards.za.rewards.shoprite.number is not null",
                "cards.za.rewards.shoprite.status='Active'"
            ]
        };

        let akamaiCustomersWithIdNumber = await akamaiGetEntity.akamaiFindCustomerUsingFilter(createFilter(filters.idNumber));
        let akamaiShopriteCustomers = await akamaiGetEntity.akamaiFindCustomerUsingFilter(createFilter(filters.shoprite));
        let akamaiCustomersWithPassportNumber = await akamaiGetEntity.akamaiFindCustomerUsingFilter(createFilter(filters.passportNumber));

        const getRandomIndex = (array) => parseInt(dataHelpers.generateRandomNumber(0, array.results.length));

        const rndIntIdNumber = getRandomIndex(akamaiCustomersWithIdNumber);
        const rndIntPassport = getRandomIndex(akamaiCustomersWithPassportNumber);
        const rndIntShoprite = getRandomIndex(akamaiShopriteCustomers);
        let akamaiCustomerIdNumber = akamaiCustomersWithIdNumber.results[rndIntIdNumber];
        let akamaiCustomerPassportNumber = akamaiCustomersWithPassportNumber.results[rndIntPassport];
        let akamaiShopriteCustomer = akamaiShopriteCustomers.results[rndIntShoprite];

        const createCustomerId = (source, memberIdPath) => ({
            uuid: source.uuid,
            firstName: source.givenName,
            lastName: source.familyName,
            email: source.email ?? '',
            mobileNumber: source.mobileNumber,
            idNumber: source.personalIdentifications.nationalIdentification.number.replace('ZA-', ''),
            memberId: source[memberIdPath],
            dob: source.birthday
        });

        const createCustomerPassport = (source, memberIdPath) => ({
            uuid: source.uuid,
            firstName: source.givenName,
            lastName: source.familyName,
            email: source.email ?? '',
            mobileNumber: source.mobileNumber,
            passport: source.personalIdentifications.passport.number.replace('ZZ-', ''),
            memberId: source[memberIdPath],
            dob: source.birthday
        });

        customerIdNumber = createCustomerId(akamaiCustomerIdNumber, 'retailServices.xtraSavings.za.checkers.memberInfo.memberId');
        customerPassport = createCustomerPassport(akamaiCustomerPassportNumber, 'retailServices.xtraSavings.za.checkers.memberInfo.memberId');
        customerShoprite = createCustomerId(akamaiShopriteCustomer, 'retailServices.xtraSavings.za.shoprite.memberInfo.memberId');
    });

    test('enrolment of new customer - ID number not in CIAM', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/enrolment`});
        let json = discoveryData.enrolmentValidDetails("IDN");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(encodeURIComponent(`mobileNumber='${json.cellPhoneNumber}'`));
        await addMsg({message: JSON.stringify(response1.results[0], null, 2)});
        expect(response1.results[0].givenName).toBe(json.firstName);
        expect(response1.results[0].familyName).toBe(json.lastName);
        expect(response1.results[0].email).toBe(json.emailAddress);
        expect(response1.results[0].birthday).toBe(json.dob);
        expect(response1.results[0].mobileNumber).toBe(json.cellPhoneNumber);
        expect(response1.results[0].personalIdentifications.nationalIdentification.number).toBe(`ZA-${json.legalRefNumber}`);
        expect(response1.results[0].cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.results[0].cards.za.rewards.checkers.status).toBe('active');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName).toBe('checkers-za-rewards-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.consentName).toBe('checkers-za-marketing-consent');
        expect(response1.results[0].retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.consents.marketing.consentName).toBe('moneyMarket-checkers-za-marketing-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('discoveryVitality');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBeDefined();
    });

    test('enrolment of new customer - Passport number not in CIAM', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/enrolment`});
        let json = discoveryData.enrolmentValidDetails("PS");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(encodeURIComponent(`mobileNumber='${json.cellPhoneNumber}'`));
        await addMsg({message: JSON.stringify(response1.results[0], null, 2)});
        expect(response1.results[0].givenName).toBe(json.firstName);
        expect(response1.results[0].familyName).toBe(json.lastName);
        expect(response1.results[0].email).toBe(json.emailAddress);
        expect(response1.results[0].birthday).toBe(json.dob);
        expect(response1.results[0].mobileNumber).toBe(json.cellPhoneNumber);
        expect(response1.results[0].personalIdentifications.passport.number).toBe(`ZZ-${json.legalRefNumber}`);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName).toBe('checkers-za-rewards-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.consentName).toBe('checkers-za-marketing-consent');
        expect(response1.results[0].retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.consents.marketing.consentName).toBe('moneyMarket-checkers-za-marketing-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('discoveryVitality');
    });

    test('enrolment of customer already in CIAM - ID number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/enrolment`});
        let json = discoveryData.enrolment(effectiveDateTime, customerIdNumber.idNumber, 'IDN', customerIdNumber.firstName, customerIdNumber.lastName,
            customerIdNumber.dob, customerIdNumber.mobileNumber, customerIdNumber.email, "checkers-za-rewards-consent", true, 'SMS', true);
        json.consent.push({
            "consentTemplateId": "checkers-za-marketing-consent",
            "consentTemplateVersion": "1",
            "granted": true
        });
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of customer already in CIAM - Passport number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/enrolment`});
        let json = discoveryData.enrolment(effectiveDateTime, customerPassport.passport, 'IDN', customerPassport.firstName, customerPassport.lastName,
            customerPassport.dob, customerPassport.mobileNumber, customerPassport.email, "checkers-za-rewards-consent", true, 'SMS', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of existing Shoprite customer in CIAM', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/enrolment`});
        let json = discoveryData.enrolment(effectiveDateTime, customerShoprite.idNumber, 'IDN', customerShoprite.firstName, customerShoprite.lastName,
            customerShoprite.dob, customerShoprite.mobileNumber, customerShoprite.email, "checkers-za-rewards-consent", true, 'SMS', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - missing legalRefNumber', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        delete json.legalRefNumber; // remove a required field
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - missing mobileNumber', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        delete json.cellPhoneNumber; // remove a required field
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - missing email address', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        delete json.emailAddress; // remove a required field
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(encodeURIComponent(`mobileNumber='${json.cellPhoneNumber}'`));
        await addMsg({message: JSON.stringify(response1.results[0], null, 2)});
        expect(response1.results[0].givenName).toBe(json.firstName);
        expect(response1.results[0].familyName).toBe(json.lastName);
        expect(response1.results[0].birthday).toBe(json.dob);
        expect(response1.results[0].mobileNumber).toBe(json.cellPhoneNumber);
        expect(response1.results[0].personalIdentifications.nationalIdentification.number).toBe(`ZA-${json.legalRefNumber}`);
        expect(response1.results[0].cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.results[0].cards.za.rewards.checkers.status).toBe('active');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName).toBe('checkers-za-rewards-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.consentName).toBe('checkers-za-marketing-consent');
        expect(response1.results[0].retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.consents.marketing.consentName).toBe('moneyMarket-checkers-za-marketing-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('discoveryVitality');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBeDefined();
    });

    test('enrolment of new customer - missing firstName', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        delete json.firstName; // remove a required field
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - missing lastName', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        delete json.lastName; // remove a required field
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - missing date of birth', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        delete json.dob; // remove a required field
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - empty consent array', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.consent = []; // remove a required field
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - missing terms consent in array', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.consent.splice(1, 1);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - missing marketing consent in array', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.consent.splice(0, 1);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - invalid consent consentTemplateId in array', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.consent = [];
        json.consent.push({
            consentTemplateId: "invalid-template-id",
            consentTemplateVersion: "1",
            granted: true
        });
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - invalid consent granted in array', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.consent[1].granted = false;
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - empty contactPreference array', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.contactPreferences = []; // remove a required field
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - invalid contactPreference in array', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.contactPreferences = [];
        json.contactPreferences.push({
            active: true,
            code: "invalid-code"
        });
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400-status code for missing required fields
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - invalid legalRefType', async () => {
        let json = discoveryData.enrolmentValidDetails("INVALID"); // use an invalid legalRefType
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400 status code for invalid legalRefType
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - invalid email address', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.emailAddress = 'invalid-email-address'; // use an invalid email address
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400 status code for invalid legalRefType
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - invalid mobileNumber', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.cellPhoneNumber = 'invalid-email-address';
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400 status code for invalid legalRefType
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - invalid mobileNumber(no +)', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.cellPhoneNumber = json.cellPhoneNumber.replace('+', '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400 status code for invalid legalRefType
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment of new customer - future effectiveDateTime', async () => {
        effectiveDateTime = moment().add(1, 'years').format('YYYY-MM-DD HH:mm:ss'); // use a future date
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.effectiveDateTime = effectiveDateTime;
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(encodeURIComponent(`mobileNumber='${json.cellPhoneNumber}'`));
        await addMsg({message: JSON.stringify(response1.results[0], null, 2)});
        expect(response1.results[0].givenName).toBe(json.firstName);
        expect(response1.results[0].familyName).toBe(json.lastName);
        expect(response1.results[0].email).toBe(json.emailAddress);
        expect(response1.results[0].birthday).toBe(json.dob);
        expect(response1.results[0].mobileNumber).toBe(json.cellPhoneNumber);
        expect(response1.results[0].personalIdentifications.nationalIdentification.number).toBe(`ZA-${json.legalRefNumber}`);
        expect(response1.results[0].cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.results[0].cards.za.rewards.checkers.status).toBe('active');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName).toBe('checkers-za-rewards-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.consentName).toBe('checkers-za-marketing-consent');
        expect(response1.results[0].retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.consents.marketing.consentName).toBe('moneyMarket-checkers-za-marketing-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('discoveryVitality');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBeDefined();
    });

    test('enrolment of new customer - past effectiveDateTime', async () => {
        effectiveDateTime = moment().subtract(1, 'years').format('YYYY-MM-DD HH:mm:ss'); // use a past date
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.effectiveDateTime = effectiveDateTime;
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(encodeURIComponent(`mobileNumber='${json.cellPhoneNumber}'`));
        await addMsg({message: JSON.stringify(response1.results[0], null, 2)});
        expect(response1.results[0].givenName).toBe(json.firstName);
        expect(response1.results[0].familyName).toBe(json.lastName);
        expect(response1.results[0].email).toBe(json.emailAddress);
        expect(response1.results[0].birthday).toBe(json.dob);
        expect(response1.results[0].mobileNumber).toBe(json.cellPhoneNumber);
        expect(response1.results[0].personalIdentifications.nationalIdentification.number).toBe(`ZA-${json.legalRefNumber}`);
        expect(response1.results[0].cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.results[0].cards.za.rewards.checkers.status).toBe('active');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName).toBe('checkers-za-rewards-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.consentName).toBe('checkers-za-marketing-consent');
        expect(response1.results[0].retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.consents.marketing.consentName).toBe('moneyMarket-checkers-za-marketing-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('discoveryVitality');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBeDefined();
    });

    test('should return 403 if no x-api-key in headers', async () => {
        const headersWithoutApiKey = {
            'Content-Type': 'application/json'
        };
        let json = discoveryData.enrolmentValidDetails("IDN");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headersWithoutApiKey);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(403); // expect a 403 status code for missing an API key
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('should return 403 if invalid x-api-key in headers', async () => {
        const headersWithInvalidApiKey = {
            'x-api-key': 'invalid-api-key',
            'Content-Type': 'application/json'
        };
        let json = discoveryData.enrolmentValidDetails("IDN");
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headersWithInvalidApiKey);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(403); // expect a 403 status code for invalid API key
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('should handle SQL Injection attack', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.legalRefNumber = "'; DROP TABLE users; --"; // SQL Injection attack
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400 status code for invalid input
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('should handle XSS attack', async () => {
        let json = discoveryData.enrolmentValidDetails("IDN");
        json.firstName = "<script>alert('XSS')</script>"; // XSS attack
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400); // expect a 400 status code for invalid input
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('should handle large payload gracefully', async () => {
        // Generate a large payload
        const largePayload = 'a'.repeat(1e6); // 1 million characters

        let json = discoveryData.enrolmentValidDetails("IDN");
        json.firstName = largePayload;
        json.lastName = largePayload;
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        // Depending on the API's implementation, it might return a 413 (Payload Too Large) status code,
        // or it might handle the large payload gracefully and return a 200-status code
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('enrolment and activation of new customer', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/enrolment`});
        let json = discoveryData.enrolmentValidDetails("IDN");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/enrolment`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(encodeURIComponent(`mobileNumber='${json.cellPhoneNumber}'`));
        await addMsg({message: JSON.stringify(response1.results[0], null, 2)});
        expect(response1.results[0].givenName).toBe(json.firstName);
        expect(response1.results[0].familyName).toBe(json.lastName);
        expect(response1.results[0].email).toBe(json.emailAddress);
        expect(response1.results[0].birthday).toBe(json.dob);
        expect(response1.results[0].mobileNumber).toBe(json.cellPhoneNumber);
        expect(response1.results[0].personalIdentifications.nationalIdentification.number).toBe(`ZA-${json.legalRefNumber}`);
        expect(response1.results[0].cards.za.rewards.checkers.number).toBeDefined();
        expect(response1.results[0].cards.za.rewards.checkers.status).toBe('active');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName).toBe('checkers-za-rewards-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.consentName).toBe('checkers-za-marketing-consent');
        expect(response1.results[0].retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.consents.marketing.consentName).toBe('moneyMarket-checkers-za-marketing-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.email.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted).toBe(true);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted).toBe(true);

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.registrationChannel).toBe('discoveryVitality');
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBeDefined();

        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/verification`});
        let params = discoveryData.verification('2023-12-30 14:44:58', json.legalRefNumber, 'IDN', '1999-12-31');
        await addMsg({message: JSON.stringify(params, null, 2)});
        const responseVerification = await apiCall.GET(`${process.env.DSLGroup}/discovery/benefit/verification`, headers, params);
        await addMsg({message: JSON.stringify(responseVerification.data, null, 2)});
        expect(responseVerification.status).toBe(200);

        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let activation = discoveryData.activation(effectiveDateTime, json.legalRefNumber, 'IDN', json.dob, "Activated", true, true);
        await addMsg({message: JSON.stringify(activation, null, 2)});
        const activationResponse = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, activation, headers);
        await addMsg({message: JSON.stringify(activationResponse.data, null, 2)});
        expect(activationResponse.status).toBe(200);
        expect(activationResponse.data.response.customerNumber).toEqual(response1.results[0].retailServices.xtraSavings.za.checkers.memberInfo.memberId);

        const response2 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${response1.results[0].uuid}'`);
        await addMsg({message: JSON.stringify(response2.results[0].externalPartners, null, 2)});
        expect(response2.results[0].mobileNumber).toEqual(response1.results[0].mobileNumber);
        expect(response2.results[0].externalPartners.discoveryVitality[0].country).toBe('za');
        expect(response2.results[0].externalPartners.discoveryVitality[0].effectiveDateTime).toBeDefined();
        expect(response2.results[0].externalPartners.discoveryVitality[0].brand).toBe('checkers');
        expect(response2.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response2.results[0].externalPartners.discoveryVitality[0].status).toBeNull();
    });
});
