import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import moment from "moment";
import DiscoveryData from "../../data/discovery.data";
import AkamaiGetEntity from "../../../__utils__/cards/akamai.get.entity";

const testIf = (condition, ...args) =>
    // eslint-disable-next-line jest/expect-expect,jest/valid-title
    condition ? test(...args) : test.skip(...args);

jest.retryTimes(1);
describe('Discovery - Post Vitality Activation', () => {
    const apiCall = new ApiMethodUtil();
    const discoveryData = new DiscoveryData();
    const dataHelpers = new DataHelpers();
    let effectiveDateTime, headers;
    const akamaiGetEntity = new AkamaiGetEntity();
    let customerWithIdNumber, customerWithPassport, originalEffectiveDateTime, customerShopriteIdNumber,
        akamaiShopriteCustomerIdNumber, akamaiCustomersWithIdNumber, akamaiCustomersWithPassport,
        akamaiShopriteCustomerPassport, customerShopritePassport, customerPetShop, akamaiPetShopCustomer,
        akamaiCustomerWithIdNumber;

    beforeAll(async () => {
        headers = {
            'x-api-key': process.env.DiscoveryApiKey,
            'Content-Type': 'application/json'
        };

        let filterIdNumber = encodeURIComponent(`externalPartners.discoveryVitality is null and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted='true' and personalIdentifications.nationalIdentification.number is not null and cards.za.rewards.checkers.number is not null and cards.za.rewards.checkers.status='Active'`);
        let filterShopriteIdNumber = encodeURIComponent(`externalPartners.discoveryVitality is null and retailServices.xtraSavings.za.checkers.memberInfo.memberId is null and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted is null and retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted='true' and personalIdentifications.nationalIdentification.number is not null and cards.za.rewards.shoprite.number is not null and cards.za.rewards.shoprite.status='Active'`);
        let filterShopriteIdPassport = encodeURIComponent(`externalPartners.discoveryVitality is null and retailServices.xtraSavings.za.checkers.memberInfo.memberId is null and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted is null and retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted='true' and personalIdentifications.passport.number is not null and cards.za.rewards.shoprite.number is not null and cards.za.rewards.shoprite.status='Active'`);
        let filterPetShop = encodeURIComponent(`personalIdentifications.nationalIdentification.number is not null and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted is null and cards.za.rewards.checkers.status='Active' and retailServices.xtraSavings.za.checkers.memberInfo.memberId is null and retailServices.petshopScience.za.shopriteGroup.memberInfo.memberId is not null`);
        let filterPassport = encodeURIComponent(`externalPartners.discoveryVitality is null and retailServices.xtraSavings.za.checkers.consents.termsOfService.granted='true' and personalIdentifications.passport.number is not null and cards.za.rewards.checkers.number is not null and cards.za.rewards.checkers.status='Active'`);
        akamaiCustomersWithIdNumber = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterIdNumber);
        let akamaiShopriteCustomersIdNumber = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterShopriteIdNumber);
        let akamaiShopriteCustomersPassport = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterShopriteIdPassport);
        let akamaiPetShopCustomers = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterPetShop);
        if (akamaiPetShopCustomers.results.length > 0) {
            const rndIntPetShop = parseInt(dataHelpers.generateRandomNumber(0, akamaiPetShopCustomers.results.length));
            akamaiPetShopCustomer = akamaiPetShopCustomers.results[rndIntPetShop];
            customerPetShop = {
                uuid: akamaiPetShopCustomer.uuid,
                idNumber: akamaiPetShopCustomer.personalIdentifications.nationalIdentification.number.replace('ZA-', ''),
                dob: akamaiPetShopCustomer.birthday,
                mobileNumber: akamaiPetShopCustomer.mobileNumber,
                memberId: akamaiPetShopCustomer.retailServices.petshopScience.za.shopriteGroup.memberInfo.memberId
            };
        } else {
            customerPetShop = {
                uuid: "",
                idNumber: "",
                dob: "",
                mobileNumber: "",
                memberId: ""
            };
        }
        akamaiCustomersWithPassport = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterPassport);
        const rndIntId = parseInt(dataHelpers.generateRandomNumber(0, akamaiCustomersWithIdNumber.results.length));
        const rndIntPassport = parseInt(dataHelpers.generateRandomNumber(0, akamaiCustomersWithPassport.results.length));
        const rndIntShopriteIdNumber = parseInt(dataHelpers.generateRandomNumber(0, akamaiShopriteCustomersIdNumber.results.length));
        const rndIntShopriteIdPassport = parseInt(dataHelpers.generateRandomNumber(0, akamaiShopriteCustomersPassport.results.length));

        akamaiCustomerWithIdNumber = akamaiCustomersWithIdNumber.results[rndIntId];
        let akamaiCustomerWithPassport = akamaiCustomersWithPassport.results[rndIntPassport];
        akamaiShopriteCustomerIdNumber = akamaiShopriteCustomersIdNumber.results[rndIntShopriteIdNumber];
        akamaiShopriteCustomerPassport = akamaiShopriteCustomersPassport.results[rndIntShopriteIdPassport];

        customerWithIdNumber = {
            uuid: akamaiCustomerWithIdNumber.uuid ?? '',
            idNumber: akamaiCustomerWithIdNumber.personalIdentifications.nationalIdentification.number.replace('ZA-', '') ?? '',
            dob: akamaiCustomerWithIdNumber.birthday ?? '',
            mobileNumber: akamaiCustomerWithIdNumber.mobileNumber ?? '',
            memberId: akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.memberInfo.memberId ?? ''
        };

        customerShopriteIdNumber = {
            uuid: akamaiShopriteCustomerIdNumber.uuid,
            idNumber: akamaiShopriteCustomerIdNumber.personalIdentifications.nationalIdentification.number.replace('ZA-', ''),
            dob: akamaiShopriteCustomerIdNumber.birthday,
            mobileNumber: akamaiShopriteCustomerIdNumber.mobileNumber,
            memberId: akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.memberInfo.memberId
        };

        customerShopritePassport = {
            uuid: akamaiShopriteCustomerPassport.uuid,
            passport: akamaiShopriteCustomerPassport.personalIdentifications.passport.number.replace('ZZ-', ''),
            dob: akamaiShopriteCustomerPassport.birthday,
            mobileNumber: akamaiShopriteCustomerPassport.mobileNumber,
            memberId: akamaiShopriteCustomerPassport.retailServices.xtraSavings.za.shoprite.memberInfo.memberId
        };

        customerWithPassport = {
            uuid: akamaiCustomerWithPassport.uuid,
            passport: akamaiCustomerWithPassport.personalIdentifications.passport.number.replace('ZZ-', ''),
            dob: akamaiCustomerWithPassport.birthday,
            mobileNumber: akamaiCustomerWithPassport.mobileNumber,
            memberId: akamaiCustomerWithPassport.retailServices.xtraSavings.za.checkers.memberInfo.memberId
        };
        await addMsg({message: 'customerIdNumber\n' + JSON.stringify(customerWithIdNumber, null, 2)});
        await addMsg({message: 'customerPassportNumber\n' + JSON.stringify(customerWithPassport, null, 2)});
    });

    test('activate of valid customer with ID Number', async () => {
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        await addMsg({message: JSON.stringify(customerWithIdNumber, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithIdNumber.idNumber, 'IDN', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.customerNumber).toEqual(customerWithIdNumber.memberId);

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customerWithIdNumber.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.checkers.consents, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(response1.results[0].mobileNumber).toEqual(customerWithIdNumber.mobileNumber);
        expect(response1.results[0].externalPartners.discoveryVitality[0].country).toBe('za');
        expect(response1.results[0].externalPartners.discoveryVitality[0].brand).toBe('checkers');
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBeNull();
        expect(response1.results[0].externalPartners.discoveryVitality[0].effectiveDateTime).toBeDefined();

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName).toBe('checkers-za-rewards-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.consentName).toBe('checkers-za-marketing-consent');
        expect(response1.results[0].retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.consents.marketing.consentName).toBe('moneyMarket-checkers-za-marketing-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted);

        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.email.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.sms.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted);

        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.email.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted);
        originalEffectiveDateTime = response1.results[0].externalPartners.discoveryVitality[0].effectiveDateTime;
    });

    test('activate of valid customer with Shoprite Card with IdNumber', async () => {
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        await addMsg({message: JSON.stringify(customerShopriteIdNumber, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerShopriteIdNumber.idNumber, 'IDN', customerShopriteIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.customerNumber).toEqual(customerShopriteIdNumber.memberId);

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customerShopriteIdNumber.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.checkers.consents, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.shoprite.consents, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(response1.results[0].mobileNumber).toEqual(customerShopriteIdNumber.mobileNumber);
        expect(response1.results[0].externalPartners.discoveryVitality[0].country).toBe('za');
        expect(response1.results[0].externalPartners.discoveryVitality[0].brand).toBe('checkers');
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBeNull();
        expect(response1.results[0].externalPartners.discoveryVitality[0].effectiveDateTime).toBeDefined();

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.consents.marketing.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.whatsApp.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.mobileApp.granted);
        expect(response1.results[0].retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.consents.marketing.consentName).toBe('moneyMarket-checkers-za-marketing-consent');

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.whatsApp.granted);

        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.email.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.sms.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.sixty60.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.whatsApp.granted);

        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.email.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.sms.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.moneyMarket.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiShopriteCustomerIdNumber.retailServices.xtraSavings.za.shoprite.contactPreferences.whatsApp.granted);
    });

    test('activate of valid customer with Shoprite Card with Passport', async () => {
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        await addMsg({message: JSON.stringify(customerShopritePassport, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerShopritePassport.passport, 'PS', customerShopritePassport.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.customerNumber).toEqual(customerShopritePassport.memberId);

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customerShopritePassport.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.checkers.consents, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.shoprite.consents, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(response1.results[0].mobileNumber).toEqual(customerShopritePassport.mobileNumber);
        expect(response1.results[0].externalPartners.discoveryVitality[0].country).toBe('za');
        expect(response1.results[0].externalPartners.discoveryVitality[0].brand).toBe('checkers');
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBeNull();
        expect(response1.results[0].externalPartners.discoveryVitality[0].effectiveDateTime).toBeDefined();

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.granted).toBe(akamaiShopriteCustomerPassport.retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.granted).toBe(akamaiShopriteCustomerPassport.retailServices.xtraSavings.za.shoprite.consents.marketing.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(akamaiShopriteCustomerPassport.retailServices.xtraSavings.za.shoprite.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(akamaiShopriteCustomerPassport.retailServices.xtraSavings.za.shoprite.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiShopriteCustomerPassport.retailServices.xtraSavings.za.shoprite.contactPreferences.whatsApp.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted).toBe(akamaiShopriteCustomerPassport.retailServices.xtraSavings.za.shoprite.contactPreferences.mobileApp.granted);
    });

    testIf(akamaiPetShopCustomer !== undefined, 'activate of valid PetShop customer', async () => {
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        await addMsg({message: JSON.stringify(customerPetShop, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerPetShop.idNumber, 'IDN', customerPetShop.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.customerNumber).toEqual(customerPetShop.memberId);

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customerPetShop.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.checkers.consents, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.shoprite.consents, null, 2)});
        await addMsg({message: JSON.stringify(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences, null, 2)});
        expect(response1.results[0].mobileNumber).toEqual(customerPetShop.mobileNumber);
        expect(response1.results[0].externalPartners.discoveryVitality[0].country).toBe('za');
        expect(response1.results[0].externalPartners.discoveryVitality[0].brand).toBe('checkers');
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBeNull();
        expect(response1.results[0].externalPartners.discoveryVitality[0].effectiveDateTime).toBeDefined();

        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.termsOfService.granted).toBe(akamaiPetShopCustomer.retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.consents.marketing.granted).toBe(akamaiPetShopCustomer.retailServices.xtraSavings.za.shoprite.consents.marketing.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.email.granted).toBe(akamaiPetShopCustomer.retailServices.xtraSavings.za.shoprite.contactPreferences.email.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted).toBe(akamaiPetShopCustomer.retailServices.xtraSavings.za.shoprite.contactPreferences.sms.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted).toBe(akamaiPetShopCustomer.retailServices.xtraSavings.za.shoprite.contactPreferences.whatsApp.granted);
        expect(response1.results[0].retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted).toBe(akamaiPetShopCustomer.retailServices.xtraSavings.za.shoprite.contactPreferences.mobileApp.granted);
    });

    test('activate of valid customer with Passport Number', async () => {
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        await addMsg({message: JSON.stringify(customerWithPassport, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithPassport.passport, 'PS', customerWithPassport.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.customerNumber).toEqual(customerWithPassport.memberId);

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customerWithPassport.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].mobileNumber).toEqual(customerWithPassport.mobileNumber);
        expect(response1.results[0].externalPartners.discoveryVitality[0].country).toBe('za');
        expect(response1.results[0].externalPartners.discoveryVitality[0].brand).toBe('checkers');
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBeNull();
        expect(response1.results[0].externalPartners.discoveryVitality[0].effectiveDateTime).toBeDefined();
    });

    test('activate with invalid effectiveDateTime', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation('2023-12-30T14:44:58', customerWithIdNumber.idNumber, 'IDN', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with invalid effectiveDateTime format', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation('testing', customerWithIdNumber.idNumber, 'IDN', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with empty effectiveDateTime', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation('', customerWithIdNumber.idNumber, 'IDN', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with future effectiveDateTime', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation('2030-03-20 08:34:07', customerWithIdNumber.idNumber, 'IDN', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.customerNumber']);
        expect(data).toMatchSnapshot();
    });

    test('activate with invalid legalRefNumber', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, 'testing', 'IDN', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with empty legalRefNumber', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, '', 'IDN', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with legalRefNumber not in CIAM', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, '', 'IDN', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with invalid legalRefType', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithIdNumber.idNumber, 'IDNS', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with empty legalRefType', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithIdNumber.idNumber, '', customerWithIdNumber.dob);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with invalid Date of Birth and ID Number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithIdNumber.idNumber, 'IDN', "test");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.customerNumber).toEqual(customerWithIdNumber.memberId);
    });

    test('activate with empty Date of Birth and ID Number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithIdNumber.idNumber, 'IDN', "", "Pre-Activated");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.customerNumber).toEqual(customerWithIdNumber.memberId);
    });

    test('activate with invalid Date of Birth format and ID Number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithIdNumber.idNumber, 'IDN', "1971/12/31");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.customerNumber).toEqual(customerWithIdNumber.memberId);
    });

    test('activate with invalid Date of Birth and Passport', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithPassport.passport, 'PS', "test");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with empty Date of Birth and passport', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithPassport.passport, 'PS', "");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with Date of Birth younger than 18 and passport', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithPassport.passport, 'PS', "2015-04-01");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with Date of Birth older than 99 and passport', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithPassport.passport, 'PS', "1915-04-01");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with invalid Date of Birth format and Passport', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = discoveryData.activation(effectiveDateTime, customerWithPassport.passport, 'PS', "1971/12/31");
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('activate with empty body', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let json = {};
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('deactivate of valid customer', async () => {
        let customer = akamaiCustomersWithIdNumber.results[dataHelpers.generateRandomNumber(1, 50)];
        let memberId = customer.retailServices.xtraSavings.za.checkers.memberInfo.memberId;
        let idNumber = customer.personalIdentifications.nationalIdentification.number.replace('ZA-', '');
        await addMsg({message: JSON.stringify(customer.externalPartners, null, 2)});
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let initialActivation = discoveryData.activation(effectiveDateTime, idNumber, 'IDN', '');
        await addMsg({message: JSON.stringify(initialActivation, null, 2)});
        const initialActivationResponse = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, initialActivation, headers);
        await addMsg({message: JSON.stringify(initialActivationResponse.data, null, 2)});
        expect(initialActivationResponse.status).toBe(200);

        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate(effectiveDateTime, memberId);

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].mobileNumber).toEqual(customer.mobileNumber);
        expect(response1.results[0].externalPartners.discoveryVitality[0].country).toBe('za');
        expect(response1.results[0].externalPartners.discoveryVitality[0].brand).toBe('checkers');
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(false);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe("De-Activated");

        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/activation`});
        let activation = discoveryData.activation(effectiveDateTime, idNumber, 'IDN', '');
        await addMsg({message: JSON.stringify(activation, null, 2)});
        const responseActivation = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, activation, headers);
        await addMsg({message: JSON.stringify(responseActivation.data, null, 2)});
        expect(responseActivation.status).toBe(200);
        expect(responseActivation.data.response.customerNumber).toEqual(memberId);

        const responseActivationCustomer = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(responseActivationCustomer.results[0].externalPartners, null, 2)});
        expect(responseActivationCustomer.results[0].mobileNumber).toEqual(customer.mobileNumber);
        expect(responseActivationCustomer.results[0].externalPartners.discoveryVitality[0].country).toBe('za');
        expect(responseActivationCustomer.results[0].externalPartners.discoveryVitality[0].brand).toBe('checkers');
        expect(responseActivationCustomer.results[0].externalPartners.discoveryVitality[0].activated).toBe(true);
        expect(responseActivationCustomer.results[0].externalPartners.discoveryVitality[0].status).toBe("De-Activated");
        expect(responseActivationCustomer.results[0].externalPartners.discoveryVitality[0].effectiveDateTime).toBeDefined();
    });

    test('XSS vulnerability test', async () => {
        // Define a payload that typically triggers XSS
        const xssPayload = "<img src='x' onerror='alert(1)' alt=''>";

        // Insert the payload into the data you're sending
        let json = discoveryData.activation(effectiveDateTime, xssPayload, 'IDN', customerWithIdNumber.dob);

        // Make the API request
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        expect(response.status).toBe(400);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        // Check if the payload is returned unchanged in the response
        expect(response.data).not.toContain(xssPayload);
    });

    test('Authorization test', async () => {
        // Define a payload for a normal request
        let json = discoveryData.activation(effectiveDateTime, customerWithIdNumber.idNumber, 'IDN', customerWithIdNumber.dob);

        // Make the API request without headers (i.e., without authorization)
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json);

        // Check if the server correctly rejects the request due to lack of authorization (status 401)
        expect(response.status).toBe(403);
    });

    test('SQL Injection vulnerability test', async () => {
        // Define a payload that typically triggers SQL Injection
        const sqlInjectionPayload = "' OR '1'='1";

        // Insert the payload into the data you're sending
        let json = discoveryData.activation(effectiveDateTime, sqlInjectionPayload, 'IDN', customerWithIdNumber.dob);

        // Make the API request
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);

        // Check if the payload causes an internal server error (status 500), which might indicate an SQL Injection vulnerability
        expect(response.status).not.toBe(500);
    });

    test('should handle large payload in unknown field gracefully', async () => {
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        // Generate a large payload
        const largePayload = 'a'.repeat(1e6); // 1 million characters

        const json = {
            ...discoveryData.activation(effectiveDateTime, customerWithIdNumber.idNumber, 'IDN', customerWithIdNumber.dob),
            largePayload
        };
        await addMsg({message: JSON.stringify(json, null, 2)});

        try {
            const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
        } catch (error) {
            // The API might also reject the request and throw an error
            await addMsg({message: error.message});
        }
    });

    test('should handle large payload in expected field gracefully', async () => {
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        // Generate a large payload
        const largePayload = 'a'.repeat(1e6); // 1 million characters

        const json = {
            ...discoveryData.activation(effectiveDateTime, customerWithPassport.passport, 'PS', largePayload)
        };
        await addMsg({message: JSON.stringify(json, null, 2)});

        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/activation`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });
});
