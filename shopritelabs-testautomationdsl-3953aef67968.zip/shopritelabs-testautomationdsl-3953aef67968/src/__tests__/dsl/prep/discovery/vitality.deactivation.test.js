import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DiscoveryData from "../../data/discovery.data";
import AkamaiGetEntity from "../../../__utils__/cards/akamai.get.entity";
import moment from "moment/moment";

jest.retryTimes(1);
describe('Discovery - Vitality Deactivate', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();
    const discoveryData = new DiscoveryData();
    const akamaiGetEntity = new AkamaiGetEntity();
    let headers, customer, effectiveDateTime;

    beforeAll(async () => {
        headers = {
            'x-api-key': process.env.DiscoveryApiKey,
            'Content-Type': 'application/json'
        };
        let maxAttempts = 5;
        let attempt = 0;
        let customer;

        while (attempt < maxAttempts) {
            let filterIdNumber = encodeURIComponent(`externalPartners.discoveryVitality is not null`);
            let akamaiCustomersWithIdNumber = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterIdNumber);
            const rndInt = parseInt(dataHelpers.generateRandomNumber(0, akamaiCustomersWithIdNumber.results.length));
            let akamaiCustomerWithIdNumber = akamaiCustomersWithIdNumber.results[rndInt];

            if (akamaiCustomerWithIdNumber.uuid) {
                customer = {
                    uuid: akamaiCustomerWithIdNumber.uuid,
                    mobileNumber: akamaiCustomerWithIdNumber.mobileNumber,
                    memberId: akamaiCustomerWithIdNumber.retailServices.xtraSavings.za.checkers.memberInfo.memberId
                };
                break;
            }
            attempt++;
        }

        if (!customer) {
            console.log('Failed to get a customer with a valid uuid after ' + maxAttempts + ' attempts');
        }
        effectiveDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
        await addMsg({message: 'customerIdNumber\n' + JSON.stringify(customer, null, 2)});
    });

    test('deactivate of valid customer', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate(effectiveDateTime, customer.memberId);

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(false);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe('De-Activated');
    });

    test('deactivate already deactivated customer', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate(effectiveDateTime, customer.memberId);

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        const response1 = await akamaiGetEntity.akamaiFindCustomerUsingFilter(`uuid='${customer.uuid}'`);
        await addMsg({message: JSON.stringify(response1.results[0].externalPartners, null, 2)});
        expect(response1.results[0].externalPartners.discoveryVitality[0].activated).toBe(false);
        expect(response1.results[0].externalPartners.discoveryVitality[0].status).toBe('De-Activated');
    });

    test('deactivate of valid customer number not in CIAM', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate('2023-12-30 14:44:58', '4dd4ad1b-4895-4ec9-a1b7-deec05d0a000');

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('deactivate with multiple customers with the same MemberId', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate('2023-12-30 14:44:58', '033592UU');

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('deactivate with empty customer number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate('2023-12-30 14:44:58', '');

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('deactivate with invalid customer number', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate('2023-12-30 14:44:58', 'testing');

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('deactivate with invalid effectiveDateTime', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate('testing', customer.memberId);

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('deactivate with empty effectiveDateTime', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate('', customer.memberId);

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('deactivate with invalid effectiveDateTime format', async () => {
        await addMsg({message: `${process.env.DSLGroup}/discovery/benefit/deactivate`});
        let json = discoveryData.deactivate('2023-12-30T14:44:58', '4dd4ad1b-4895-4ec9-a1b7-deec05d0a000');

        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/discovery/benefit/deactivate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
