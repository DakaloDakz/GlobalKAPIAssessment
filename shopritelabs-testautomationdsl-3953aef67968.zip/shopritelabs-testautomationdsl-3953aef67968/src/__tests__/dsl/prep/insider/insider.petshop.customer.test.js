import InsiderApi from '../../../__utils__/insider.api.integration';
import DataHelpers from "../../../__utils__/data_helpers";
import DSLCustomer from "../../data/customer.data";
import ApiMethodUtil from "../../../__utils__/api_method_util";
import chalk from "chalk";
import _ from "lodash";
import DSLConsent from "../../data/consents.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import CiamCustomerConsents from "../../../ciam/qa/data/consents.data";
import CardService from "../../../__utils__/cards/cardService";

const {faker} = require("@faker-js/faker");
const {addMsg} = require("jest-html-reporters/helper");

describe.skip('Insider API Tests - PetShopScience', () => {
    let email;
    let mobileNumber;
    let firstName;
    let lastName;
    let dob;
    let cardNumber;
    let idNumber;
    let uuid;
    let newEmail;
    let newFirstName;
    let newLastName;
    let newMobileNumber;

    let dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const apiCall = new ApiMethodUtil();
    const insiderPetShopApi = new InsiderApi('petshop');
    const insiderCheckersApi = new InsiderApi('checkers');
    const insiderShopriteApi = new InsiderApi('shoprite');
    const dSLConsent = new DSLConsent();
    const consent = new CiamCustomerConsents();
    const ciamAuth = new CIAMAuth();
    const cardService = new CardService();
    let headers;
    let accessTokenPetShop;
    let gender;

    beforeAll(async () => {
        accessTokenPetShop = await ciamAuth.petShopScienceCognitoAuth(process.env.CIAM);
        accessTokenPetShop = accessTokenPetShop.data.access_token;
        headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
    });

    test('create customer via DSL /partialuser endpoint', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        // cardNumber = json.foxCard.cardNumber;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        uuid = response.data.response.uuid;
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });

        let identifierObj = {
            "uuid": uuid
        };
        let events = [
            {
                "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                "params": [
                    "timestamp",
                    "event_params",
                    "custom"
                ]
            },
            {
                "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                "params": [
                    "timestamp",
                    "event_params",
                    "custom"
                ]
            }
        ];

        let insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.status).toBe(404);
    });

    test('add petshop rewards and marketing consent', async () => {
        let rewards = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let json = _.union(rewards, marketing);

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        /*Getting Customer Data from Insider API*/
        let identifierObj = {
            "uuid": uuid
        };
        let events = [
            {
                "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                "params": [
                    "timestamp",
                    "event_params",
                    "custom"
                ]
            },
            {
                "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                "params": [
                    "timestamp",
                    "event_params",
                    "custom"
                ]
            }
        ];
        do {
            console.log(`*****${retry}*******`);

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.status !== 200 || insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(firstName);
        expect(insiderResponse.data.attributes.surname).toBe(lastName);
        expect(insiderResponse.data.attributes.birthday).toBe(`${dob}T00:00:00Z`);
        expect(insiderResponse.data.attributes.gender).toBe(gender);
        expect(insiderResponse.data.attributes.language).toBe('EN_ZA');
        expect(insiderResponse.data.attributes.country).toBe('ZA');
        expect(insiderResponse.data.attributes.email_optin).toBe(false);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
        expect(insiderResponse.data.attributes.unique_user_id).toBe(uuid);
        expect(insiderResponse.data.attributes.c_idenfication_number).toBe(idNumber);
        expect(insiderResponse.data.events.user_created).toBeDefined();

        let insiderCheckersResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);
        expect(insiderCheckersResponse.status).toBe(404);

        let insiderShopriteResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);
        expect(insiderShopriteResponse.status).toBe(404);
    });

    test('add checkers rewards and marketing consent', async () => {
        const headersCheckers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, json, headersCheckers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.MARKETING_CONSENT,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
    });

    test('add Money Market consents - Checkers', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'MoneyMarketAccount marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        await addMsg({message: JSON.stringify(response.data, null, 2)});

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.MARKETING_CONSENT,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_terms_and_conditions_accepted === undefined || !insiderResponse.data.attributes.c_terms_and_conditions_accepted.includes('Money Market')) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_money_market_wallet).toBe(true);
    });

    test('add a Checkers xtraSavings Card', async () => {
        let newCardCH = await cardService.getCardOffline(false, 'checkers');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardCH
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_rewards_card_number === undefined || insiderResponse.data.events.rewards_card_registered === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(firstName);
        expect(insiderResponse.data.attributes.surname).toBe(lastName);
        expect(insiderResponse.data.attributes.birthday).toBe(`${dob}T00:00:00Z`);
        expect(insiderResponse.data.attributes.gender).toBe(gender);
        expect(insiderResponse.data.attributes.language).toBe('EN_ZA');
        expect(insiderResponse.data.attributes.country).toBe('ZA');
        expect(insiderResponse.data.attributes.email_optin).toBe(false);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
        expect(insiderResponse.data.attributes.unique_user_id).toBe(uuid);
        expect(insiderResponse.data.attributes.c_idenfication_number).toBe(idNumber);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(newCardCH);
        expect(insiderResponse.data.events.user_created).toBeDefined();
        expect(insiderResponse.data.events.rewards_card_registered).toBeDefined();
    });

    test('add a Shoprite xtraSavings Card', async () => {
        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_rewards_card_number === undefined || insiderResponse.data.events.rewards_card_registered === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(firstName);
        expect(insiderResponse.data.attributes.surname).toBe(lastName);
        expect(insiderResponse.data.attributes.birthday).toBe(`${dob}T00:00:00Z`);
        expect(insiderResponse.data.attributes.gender).toBe(gender);
        expect(insiderResponse.data.attributes.language).toBe('EN_ZA');
        expect(insiderResponse.data.attributes.country).toBe('ZA');
        expect(insiderResponse.data.attributes.email_optin).toBe(false);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.gdpr).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
        expect(insiderResponse.data.attributes.unique_user_id).toBe(uuid);
        expect(insiderResponse.data.attributes.c_idenfication_number).toBe(idNumber);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(newCardSH);
        expect(insiderResponse.data.events.user_created).toBeDefined();
        expect(insiderResponse.data.events.rewards_card_registered).toBeDefined();
    });

    test('add contact preferences - all true', async () => {
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": true
            },
            {
                "code": "sms",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        // Wait for Insider to process the request
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(true);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
    });

    test('add contact preferences - all false', async () => {
        let json = [
            {
                "code": "email",
                "active": false
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": false
            },
            {
                "code": "mobileApp",
                "active": false
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        // Wait for Insider to process the request
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email && insiderResponse.data.attributes.email_optin !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(false);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
    });

    test('update customer details mobileNumber, firstName and lastName', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        newFirstName = faker.name.firstName();
        newLastName = faker.name.lastName();
        newMobileNumber = dataHelpers.generatePhoneNumber();
        const json = {
            "firstName": newFirstName,
            "lastName": newLastName,
            "mobileNumber": newMobileNumber,
            "email": email
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright(`Waiting for 30s to allow Insider to process the request!`));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "benefit_name",
                        "event_params",
                        "timestamp"
                    ]
                }
            ];

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.phone_number !== newMobileNumber || insiderResponse.data.attributes.name !== newFirstName) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(newFirstName);
        expect(insiderResponse.data.attributes.surname).toBe(newLastName);
    });

    test('update customer email', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        newEmail = `${newFirstName}-${newLastName}@dsl-insider.automation.com`;
        const json = {
            "email": newEmail
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email !== newEmail.toLowerCase()) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(newFirstName);
        expect(insiderResponse.data.attributes.surname).toBe(newLastName);
    });
});
