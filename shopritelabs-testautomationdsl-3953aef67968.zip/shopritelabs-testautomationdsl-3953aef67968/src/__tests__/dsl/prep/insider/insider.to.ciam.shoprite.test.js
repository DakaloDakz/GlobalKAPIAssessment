import InsiderApi from '../../../__utils__/insider.api.integration';
import ApiMethodUtil from "../../../__utils__/api_method_util";
import chalk from "chalk";
import DSLConsent from "../../data/consents.data";
import DataHelpers from "../../../__utils__/data_helpers";

const {faker} = require("@faker-js/faker");
const {addMsg} = require("jest-html-reporters/helper");
const dSLConsent = new DSLConsent();

describe.skip('Insider Webhook to CIAM Tests - Shoprite', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelper = new DataHelpers();
    const insiderShopriteApi = new InsiderApi('shoprite');
    let uuid = '4952b012-04a2-4c43-9493-f0ae0f9b20bd';
    let email = 'monty-mayer@dsl-insider.automation.com';

    test('set sms_optin, email_optin and whatsapp_optin to true', async () => {
        let data = {
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "sms_optin": true,
                        "email_optin": true,
                        "whatsapp_optin": true
                    }
                }
            ]
        };
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderShopriteApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }

        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };
        const responseMoneyMarketPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersMoneyMarket, null);
        await addMsg({message: JSON.stringify(responseMoneyMarketPreferences.data, null, 2)});
        expect(responseMoneyMarketPreferences.status).toBe(200);
        for (let i = 0; i < responseMoneyMarketPreferences.data.response.contactPreferences.length; i++) {
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }

        const headersLiquorShop = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        const responseLiquorShopPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersLiquorShop, null);
        await addMsg({message: JSON.stringify(responseLiquorShopPreferences.data, null, 2)});
        expect(responseLiquorShopPreferences.status).toBe(200);
        for (let i = 0; i < responseLiquorShopPreferences.data.response.contactPreferences.length; i++) {
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }
    });

    test('set sms_optin, email_optin and whatsapp_optin to false', async () => {
        let data = {
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "sms_optin": false,
                        "email_optin": false,
                        "whatsapp_optin": false
                    }
                }
            ]
        };
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderShopriteApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }

        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };
        const responseMoneyMarketPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersMoneyMarket, null);
        await addMsg({message: JSON.stringify(responseMoneyMarketPreferences.data, null, 2)});
        expect(responseMoneyMarketPreferences.status).toBe(200);
        for (let i = 0; i < responseMoneyMarketPreferences.data.response.contactPreferences.length; i++) {
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }

        const headersLiquorShop = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        const responseLiquorShopPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersLiquorShop, null);
        await addMsg({message: JSON.stringify(responseLiquorShopPreferences.data, null, 2)});
        expect(responseLiquorShopPreferences.status).toBe(200);
        for (let i = 0; i < responseLiquorShopPreferences.data.response.contactPreferences.length; i++) {
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }
    });

    test('set email_optin = true', async () => {
        let data = {
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "email_optin": true
                    }
                }
            ]
        };
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderShopriteApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }

        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };
        const responseMoneyMarketPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersMoneyMarket, null);
        await addMsg({message: JSON.stringify(responseMoneyMarketPreferences.data, null, 2)});
        expect(responseMoneyMarketPreferences.status).toBe(200);
        for (let i = 0; i < responseMoneyMarketPreferences.data.response.contactPreferences.length; i++) {
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }

        const headersLiquorShop = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        const responseLiquorShopPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersLiquorShop, null);
        await addMsg({message: JSON.stringify(responseLiquorShopPreferences.data, null, 2)});
        expect(responseLiquorShopPreferences.status).toBe(200);
        for (let i = 0; i < responseLiquorShopPreferences.data.response.contactPreferences.length; i++) {
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }
    });

    test('set sms_optin = true', async () => {
        let data = {
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "sms_optin": true
                    }
                }
            ]
        };
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderShopriteApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }

        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };
        const responseMoneyMarketPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersMoneyMarket, null);
        await addMsg({message: JSON.stringify(responseMoneyMarketPreferences.data, null, 2)});
        expect(responseMoneyMarketPreferences.status).toBe(200);
        for (let i = 0; i < responseMoneyMarketPreferences.data.response.contactPreferences.length; i++) {
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }

        const headersLiquorShop = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        const responseLiquorShopPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersLiquorShop, null);
        await addMsg({message: JSON.stringify(responseLiquorShopPreferences.data, null, 2)});
        expect(responseLiquorShopPreferences.status).toBe(200);
        for (let i = 0; i < responseLiquorShopPreferences.data.response.contactPreferences.length; i++) {
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }
    });

    test('set whatsapp_optin = true', async () => {
        let data = {
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "whatsapp_optin": true
                    }
                }
            ]
        };
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderShopriteApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }

        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };
        const responseMoneyMarketPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersMoneyMarket, null);
        await addMsg({message: JSON.stringify(responseMoneyMarketPreferences.data, null, 2)});
        expect(responseMoneyMarketPreferences.status).toBe(200);
        for (let i = 0; i < responseMoneyMarketPreferences.data.response.contactPreferences.length; i++) {
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }

        const headersLiquorShop = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        const responseLiquorShopPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersLiquorShop, null);
        await addMsg({message: JSON.stringify(responseLiquorShopPreferences.data, null, 2)});
        expect(responseLiquorShopPreferences.status).toBe(200);
        for (let i = 0; i < responseLiquorShopPreferences.data.response.contactPreferences.length; i++) {
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }
    });

    test('set email_optin = false', async () => {
        let data = {
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "email_optin": false
                    }
                }
            ]
        };
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderShopriteApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }

        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };
        const responseMoneyMarketPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersMoneyMarket, null);
        await addMsg({message: JSON.stringify(responseMoneyMarketPreferences.data, null, 2)});
        expect(responseMoneyMarketPreferences.status).toBe(200);
        for (let i = 0; i < responseMoneyMarketPreferences.data.response.contactPreferences.length; i++) {
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }

        const headersLiquorShop = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        const responseLiquorShopPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersLiquorShop, null);
        await addMsg({message: JSON.stringify(responseLiquorShopPreferences.data, null, 2)});
        expect(responseLiquorShopPreferences.status).toBe(200);
        for (let i = 0; i < responseLiquorShopPreferences.data.response.contactPreferences.length; i++) {
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }
    });

    test('set sms_optin = false', async () => {
        let data = {
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "sms_optin": false
                    }
                }
            ]
        };
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderShopriteApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }

        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };
        const responseMoneyMarketPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersMoneyMarket, null);
        await addMsg({message: JSON.stringify(responseMoneyMarketPreferences.data, null, 2)});
        expect(responseMoneyMarketPreferences.status).toBe(200);
        for (let i = 0; i < responseMoneyMarketPreferences.data.response.contactPreferences.length; i++) {
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }

        const headersLiquorShop = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        const responseLiquorShopPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersLiquorShop, null);
        await addMsg({message: JSON.stringify(responseLiquorShopPreferences.data, null, 2)});
        expect(responseLiquorShopPreferences.status).toBe(200);
        for (let i = 0; i < responseLiquorShopPreferences.data.response.contactPreferences.length; i++) {
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }
    });

    test('set whatsapp_optin = false', async () => {
        let data = {
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "whatsapp_optin": false
                    }
                }
            ]
        };
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderShopriteApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }

        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };
        const responseMoneyMarketPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersMoneyMarket, null);
        await addMsg({message: JSON.stringify(responseMoneyMarketPreferences.data, null, 2)});
        expect(responseMoneyMarketPreferences.status).toBe(200);
        for (let i = 0; i < responseMoneyMarketPreferences.data.response.contactPreferences.length; i++) {
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseMoneyMarketPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseMoneyMarketPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }

        const headersLiquorShop = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        const responseLiquorShopPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, headersLiquorShop, null);
        await addMsg({message: JSON.stringify(responseLiquorShopPreferences.data, null, 2)});
        expect(responseLiquorShopPreferences.status).toBe(200);
        for (let i = 0; i < responseLiquorShopPreferences.data.response.contactPreferences.length; i++) {
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseLiquorShopPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseLiquorShopPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }
    });
});
