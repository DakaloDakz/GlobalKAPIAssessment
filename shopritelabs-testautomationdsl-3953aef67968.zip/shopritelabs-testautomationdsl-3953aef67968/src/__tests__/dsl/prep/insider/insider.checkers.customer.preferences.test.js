import InsiderApi from '../../../__utils__/insider.api.integration';
import DataHelpers from "../../../__utils__/data_helpers";
import DSLCustomer from "../../data/customer.data";
import ApiMethodUtil from "../../../__utils__/api_method_util";
import chalk from "chalk";

const {faker} = require("@faker-js/faker");
const {addMsg} = require("jest-html-reporters/helper");

describe.skip('Insider API Tests - Checkers', () => {
    let email;
    let mobileNumber;
    let firstName;
    let lastName;
    let dob;
    let cardNumber;
    let idNumber;
    let uuid;

    let dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const apiCall = new ApiMethodUtil();
    const insiderCheckersApi = new InsiderApi('checkers');

    let headers;
    let gender;

    beforeAll(() => {
        headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
    });

    test('create customer via DSL /partialuser endpoint', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        cardNumber = json.foxCard.cardNumber;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        uuid = response.data.response.uuid;

        await new Promise(resolve => {
            console.log(chalk.redBright(`Waiting for 10s to allow Insider to process the request!`));
            setTimeout(resolve, 10000);
        });

        test('add contact preferences XS and Sixty60 - All granted = true', async () => {
            // Adding XS Preferences
            let json = [
                {
                    "code": "email",
                    "active": true
                },
                {
                    "code": "whatsApp",
                    "active": true
                },
                {
                    "code": "sms",
                    "active": true
                },
                {
                    "code": "mobileApp",
                    "active": true
                }
            ];
            await addMsg({message: JSON.stringify(json, null, 2)});
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);

            /*
             * Adding Sixty60 Preferences
             */
            const headersSixty60 = {
                'x-api-key': process.env.CIAMSixty60ApiKey
            };
            let body = {
                "contactPreferences": [
                    {
                        "retailService": "Sixty60",
                        "contactPreferenceRole": "EMAIL",
                        "addressValue": "test@test.com",
                        "granted": true
                    },
                    {
                        "retailService": "Sixty60",
                        "contactPreferenceRole": "SMS",
                        "addressValue": "+27833965802",
                        "granted": true
                    },
                    {
                        "retailService": "Sixty60",
                        "contactPreferenceRole": "WHATSAPP",
                        "addressValue": "+27833965802",
                        "granted": true
                    }
                ]
            };
            await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`});
            await addMsg({message: JSON.stringify(body, null, 2)});
            const responseSixty60 = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headersSixty60);
            await addMsg({message: JSON.stringify(responseSixty60.data, null, 2)});
            expect(responseSixty60.status).toBe(200);

            // Wait for Insider to process the request
            await new Promise(resolve => {
                console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
                setTimeout(resolve, 10000);
            });
            let insiderResponse;
            let retry = 0;
            do {
                console.log(`*****${retry}*******`);
                /*Getting Customer Data from Insider API*/
                let identifierObj = {
                    "uuid": uuid
                };
                let events = [
                    {
                        "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                        "params": [
                            "timestamp",
                            "event_params",
                            "custom"
                        ]
                    },
                    {
                        "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                        "params": [
                            "timestamp",
                            "event_params",
                            "custom"
                        ]
                    }
                ];

                insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

                if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== true) {
                    await new Promise(resolve => {
                        let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                        console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                        setTimeout(resolve, waitPeriod * 2000);
                    });
                    expect(insiderResponse.status).toBe(200);
                } else {
                    break;
                }
                retry++;
            } while (retry <= 4);
            await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
            expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
            expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
            expect(insiderResponse.data.attributes.email_optin).toBe(true);
            expect(insiderResponse.data.attributes.sms_optin).toBe(true);
            expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
        });

        test('add contact preferences XS and Sixty60 - All granted = false', async () => {
            // Adding XS Preferences
            let json = [
                {
                    "code": "email",
                    "active": false
                },
                {
                    "code": "whatsApp",
                    "active": false
                },
                {
                    "code": "sms",
                    "active": false
                },
                {
                    "code": "mobileApp",
                    "active": false
                }
            ];
            await addMsg({message: JSON.stringify(json, null, 2)});
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);

            /*
             * Adding Sixty60 Preferences
             */
            const headersSixty60 = {
                'x-api-key': process.env.CIAMSixty60ApiKey
            };
            let body = {
                "contactPreferences": [
                    {
                        "retailService": "Sixty60",
                        "contactPreferenceRole": "EMAIL",
                        "addressValue": "test@test.com",
                        "granted": false
                    },
                    {
                        "retailService": "Sixty60",
                        "contactPreferenceRole": "SMS",
                        "addressValue": "+27833965802",
                        "granted": false
                    },
                    {
                        "retailService": "Sixty60",
                        "contactPreferenceRole": "WHATSAPP",
                        "addressValue": "+27833965802",
                        "granted": false
                    }
                ]
            };
            await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`});
            await addMsg({message: JSON.stringify(body, null, 2)});
            const responseSixty60 = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headersSixty60);
            await addMsg({message: JSON.stringify(responseSixty60.data, null, 2)});
            expect(responseSixty60.status).toBe(200);

            // Wait for Insider to process the request
            await new Promise(resolve => {
                console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
                setTimeout(resolve, 10000);
            });
            let insiderResponse;
            let retry = 0;
            do {
                console.log(`*****${retry}*******`);
                /*Getting Customer Data from Insider API*/
                let identifierObj = {
                    "uuid": uuid
                };
                let events = [
                    {
                        "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                        "params": [
                            "timestamp",
                            "event_params",
                            "custom"
                        ]
                    },
                    {
                        "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                        "params": [
                            "timestamp",
                            "event_params",
                            "custom"
                        ]
                    }
                ];

                insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

                if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== false) {
                    await new Promise(resolve => {
                        let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                        console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                        setTimeout(resolve, waitPeriod * 2000);
                    });
                    expect(insiderResponse.status).toBe(200);
                } else {
                    break;
                }
                retry++;
            } while (retry <= 4);
            await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
            expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
            expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
            expect(insiderResponse.data.attributes.email_optin).toBe(false);
            expect(insiderResponse.data.attributes.sms_optin).toBe(false);
            expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
        });

        // Wait for Insider to process the request
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(false);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
    });

    test('add contact preferences XS granted = true and Sixty60 granted = false', async () => {
        // Adding XS Preferences
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": true
            },
            {
                "code": "sms",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        /*
         * Adding Sixty60 Preferences
         */
        const headersSixty60 = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {
            "contactPreferences": [
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "EMAIL",
                    "addressValue": "test@test.com",
                    "granted": false
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "SMS",
                    "addressValue": "+27833965802",
                    "granted": false
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "WHATSAPP",
                    "addressValue": "+27833965802",
                    "granted": false
                }
            ]
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const responseSixty60 = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headersSixty60);
        await addMsg({message: JSON.stringify(responseSixty60.data, null, 2)});
        expect(responseSixty60.status).toBe(200);

        // Wait for Insider to process the request
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(true);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
    });

    test('add contact preferences XS granted = false and Sixty60 granted = true', async () => {
        // Adding XS Preferences
        let json = [
            {
                "code": "email",
                "active": false
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": false
            },
            {
                "code": "mobileApp",
                "active": false
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        /*
         * Adding Sixty60 Preferences
         */
        const headersSixty60 = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {
            "contactPreferences": [
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "EMAIL",
                    "addressValue": "test@test.com",
                    "granted": true
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "SMS",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "WHATSAPP",
                    "addressValue": "+27833965802",
                    "granted": true
                }
            ]
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const responseSixty60 = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headersSixty60);
        await addMsg({message: JSON.stringify(responseSixty60.data, null, 2)});
        expect(responseSixty60.status).toBe(200);

        // Wait for Insider to process the request
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(true);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
    });

    test('add contact preferences XS EMAIL=true, SMS=false, WHATSAPP=true and Sixty60 EMAIL=true, SMS=false, WHATSAPP=true', async () => {
        // Adding XS Preferences
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": true
            },
            {
                "code": "sms",
                "active": false
            },
            {
                "code": "mobileApp",
                "active": false
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        /*
         * Adding Sixty60 Preferences
         */
        const headersSixty60 = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {
            "contactPreferences": [
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "EMAIL",
                    "addressValue": "test@test.com",
                    "granted": true
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "SMS",
                    "addressValue": "+27833965802",
                    "granted": false
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "WHATSAPP",
                    "addressValue": "+27833965802",
                    "granted": true
                }
            ]
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const responseSixty60 = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headersSixty60);
        await addMsg({message: JSON.stringify(responseSixty60.data, null, 2)});
        expect(responseSixty60.status).toBe(200);

        // Wait for Insider to process the request
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
    });
});
