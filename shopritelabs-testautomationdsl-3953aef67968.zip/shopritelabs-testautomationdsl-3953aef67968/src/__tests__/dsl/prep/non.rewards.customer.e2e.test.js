import ApiMethodUtil from "../../__utils__/api_method_util";
import DataHelpers from '../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../__utils__/auth/ciam/auth.methods";
import DSLCustomer from "../data/customer.data";
import DSLPreferences from "../data/preferences.data";
import CIAMCustomer from "../../ciam/common/create_customer";
import _ from "lodash";
import DSLConsent from "../data/consents.data";
import CiamCustomerConsents from "../../ciam/qa/data/consents.data";
import CardService from "../../__utils__/cards/cardService";
import CiamCustomerPreferences from "../../ciam/qa/data/preferences.data";
import LproPayloads from "../../__utils__/auth/ciam/payloads/lpro.payloads";
import {encode} from "../../__utils__/encryption.util";
import interests from "./customer/preferences/data/personal.interests.json";
import {faker} from "@faker-js/faker";

jest.retryTimes(1);
describe('E2E - Partial Customer', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const ciamAuth = new CIAMAuth();
    const cIAMCustomer = new CIAMCustomer();
    const dSLCustomer = new DSLCustomer();
    const dSLPreferences = new DSLPreferences();
    const preferences = new CiamCustomerPreferences();
    const dSLConsent = new DSLConsent();
    const consent = new CiamCustomerConsents();
    const cardService = new CardService();
    const lproPayloads = new LproPayloads();
    let uuid;
    let mobileNumber;
    let firstName;
    let lastName;
    let credentials;
    let sessionKey;
    let accessTokenPetShop, tokenASM;
    beforeAll(async () => {
        accessTokenPetShop = await ciamAuth.petShopScienceCognitoAuth(process.env.CIAM);
        accessTokenPetShop = accessTokenPetShop.data.access_token;
        tokenASM = await auth.ciamASMCognitoAuth(process.env.DSLGroup);
        tokenASM = tokenASM.data.access_token;

        let occAuthUserName = process.env.LPROClientID;
        let occAuthPassword = process.env.LPROClientSecret;
        credentials = encode(`${occAuthUserName}:${occAuthPassword}`);
        let payload = await lproPayloads.loginPayload();
        sessionKey = await ciamAuth.lpro_session_key_auth(payload, 'prep');
    });

    test('created partial customer - PetShopScience', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        mobileNumber = json.contactDetails[0].value;
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        uuid = response.data.response.uuid;
    });

    test('add Passport number', async () => {
        let passport = faker.internet.password(15, false, /[0-9A-Z]/);
        const json = {
            "passportNumber": passport,
            "birthDate": '31/12/1975'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${tokenASM}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('add contact preferences - PetShopScience', async () => {
        expect(uuid).toBeDefined();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add xtra-saving consent - Checkers', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add xtra-saving consent - Shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('shoprite-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add xtra-saving contact preferences - Checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add xtra-saving contact preferences - Shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add xtra-savings plus consent', async () => {
        const headers = {
            Authorization: `Bearer ${tokenASM}`,
            'x-api-key': process.env.ASMXsPlusApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLConsent.create_valid_user_consents('checkers-za-xtrasavingsplus-consent');

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add consent - PetshopScience', async () => {
        expect(uuid).toBeDefined();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let signup = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let json = _.union(signup, marketing);

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/consent`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add Sixty60 consents', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createMultipleConsentPayload('Sixty60', 'sixty60-za-marketing-consent', '1', 'Sixty60 marketing consent', true,
            'Sixty60', 'sixty60-za-termsandconditions', '1', 'Sixty60 rewards consent', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add Money Market consents - Checkers', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'MoneyMarketAccount marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add Money Market consents - Shoprite', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'MoneyMarketAccount marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/shoprite/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add card - Shoprite', async () => {
        expect(uuid).toBeDefined();
        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add card - Checkers', async () => {
        expect(uuid).toBeDefined();
        let newCardSH = await cardService.getCardOffline(false, 'checkers');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add email to customer', async () => {
        expect(uuid).toBeDefined();
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const json = {
            "email": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test('add multiple Sixty60 preferences', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {
            "contactPreferences": [
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "SMS",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "WHATSAPP",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "MOBILEAPP",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "EMAIL",
                    "addressValue": "testautomation@auto.com",
                    "granted": true
                }
            ]
        };
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });

    test('add multiple MoneyMarketAccount preferences - Checkers', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {
            "contactPreferences": [
                {
                    "retailService": "MoneyMarketAccount",
                    "contactPreferenceRole": "SMS",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "MoneyMarketAccount",
                    "contactPreferenceRole": "WHATSAPP",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "MoneyMarketAccount",
                    "contactPreferenceRole": "MOBILEAPP",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "MoneyMarketAccount",
                    "contactPreferenceRole": "EMAIL",
                    "addressValue": "testautomation@auto.com",
                    "granted": true
                }
            ]
        };
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add multiple MoneyMarketAccount preferences - Shoprite', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {
            "contactPreferences": [
                {
                    "retailService": "MoneyMarketAccount",
                    "contactPreferenceRole": "SMS",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "MoneyMarketAccount",
                    "contactPreferenceRole": "WHATSAPP",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "MoneyMarketAccount",
                    "contactPreferenceRole": "MOBILEAPP",
                    "addressValue": "+27833965802",
                    "granted": true
                },
                {
                    "retailService": "MoneyMarketAccount",
                    "contactPreferenceRole": "EMAIL",
                    "addressValue": "testautomation@auto.com",
                    "granted": true
                }
            ]
        };
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/shoprite/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test(`add all checkers interests to customer`, async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('cfsb2b', true);
        for (let i = 1; i < interests.checkers.length; i++) {
            json.push({
                "active": true,
                "name": interests.checkers[i].name
            });
        }
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test(`add all shoprite interests to customer - Shoprite`, async () => {
            const headers = {
                Authorization: `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            let json = dSLPreferences.create_user_personal_preference('srInFamilyMeals', true);
            for (let i = 1; i < interests.shoprite.length; i++) {
                if (interests.shoprite[i].name !== 'srSwipeForCover' && interests.shoprite[i].name !== 'srAutoAirtime') {
                    json.push({
                        "active": true,
                        "name": interests.shoprite[i].name
                    });
                }
            }
            await addMsg({message: JSON.stringify(json, null, 2)});
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`});

            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`, json, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            let {data} = response;
            expect(response.status).toBe(200);
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        }
    );

    test('add SwipeForCover and AutoAirtimeInjection', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "active": true,
                "name": "srswipeforcover"
            }, {
                "active": true,
                "name": "srautoairtime"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuid);
        let headers1 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response1 = await apiCall.POST(url, body, headers1);
        let responseJson = dataHelpers.xml2json(response1.data);
        let respJson = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let aa = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'][0]['$']['Id'];
        let sfc = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'][1]['$']['Id'];
        let segments = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'];
        expect(segments).toHaveLength(2);
        expect(aa).toBe('1201');
        expect(sfc).toBe('1301');
    });

    test('add consent - Usave', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceUsaveApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('usave-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('usave-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add consent - Medirite', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceMediriteApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('medirite-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('medirite-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/medirite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/medirite/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add consent - LiquorShop Shoprite', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('liquorshop-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('liquorshop-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add consent - LiquorShop Checkers', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('liquorshop-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('liquorshop-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add consent - HouseAndHome', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceHouseAndHomeApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('houseAndHome-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('houseAndHome-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/househome/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/househome/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test.skip('add contact preferences - Usave', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceUsaveApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test.skip('add contact preferences - Medirite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceMediriteApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/medirite/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/medirite/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test.skip('add contact preferences - LiquorShop Checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test.skip('add contact preferences - LiquorShop Shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test.skip('add contact preferences - HouseAndHome', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceHouseAndHomeApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/househome/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/househome/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get Customer', async () => {
        expect(uuid).toBeDefined();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
    });
});
