import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('DSL -Returns a full status of all voucher status that have been created for a client', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;

    beforeAll(async () => {
        access = await ciamAuth.ciamFNBCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('Get all voucher status', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            voucherId: '1119',
            voucherCode: '9301101000006423',
            voucherCodeHash: '',
            requestId: '',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/status`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.voucherStatus']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher status with only voucherId and voucherCode', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            voucherId: '1119',
            voucherCode: '9301101000006423',
            voucherCodeHash: '',
            requestId: '',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/status`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.voucherStatus']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher categories with no params', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/status`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher status without voucherId', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {

            voucherCode: '9301101000006423',
            voucherCodeHash: '',
            requestId: '',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/status`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher status without voucherCode', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            voucherId: '1119',
            voucherCodeHash: '',
            requestId: '1252553',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/status`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher status without voucherCodeHash', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            voucherId: '1119',
            voucherCode: '9301101000006423',
            requestId: '',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/status`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher status without requestId', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            voucherId: '1119',
            voucherCodeHash: '6cb306c6625a02a20b135535f2df454687558e1752cd5d8217f7052d6c8e4870',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'

        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/status`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucherCode as required field', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            voucherId: '1119',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/status`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher status with invalid url', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            voucherId: '1119',
            voucherCode: '9301101000006423',
            requestId: '',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/status`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/Voucher/status`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
    });
});
