import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('DSL -Returns a full list of all voucher categories that have been created for a client', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;

    beforeAll(async () => {
        access = await ciamAuth.ciamFNBCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('Get all voucher categories DEMO', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            pageSize: '10',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/categories`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/categories`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher categories RainMaker AdOps', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            pageSize: '10',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/categories`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/categories`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher categories 6060', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            pageSize: '10',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/categories`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/categories`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher categories without  pageSize', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'

        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/categories`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/categories`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher categories without currentPage', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            pageSize: '10',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/categories`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/categories`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher categories with no params', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/categories`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/categories`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher categories with invalid url', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            pageSize: '10',
            clientKey: 'aaff5aaa812b2f6ee2e35fced28b8bce997f4e71'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/categories`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/Voucher/Categories`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
    });
});
