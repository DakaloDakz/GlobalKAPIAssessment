import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('DSL -Returns redemption information for all codes issued out in between the two dates', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;

    beforeAll(async () => {
        access = await ciamAuth.ciamFNBCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('Get all voucher redemptions', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            clientKey: '7235b37d1e5c88ee4ca5cdac0afd79158788456f',
            voucherId: '1129',
            startDate: '2021-12-12 13:30:00',
            endDate: '2022-12-12 13:30:00'

        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher redemptions without voucherId', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            clientKey: '8863ce916083a9adfbfcb2a01b32086ba226c527',
            voucherId: '',
            startDate: '2021-12-12 13:30:00',
            endDate: '2022-12-12 13:30:00'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher redemption with no params', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher redemptions without clientKey', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {

            clientKey: '',
            voucherId: '1119',
            startDate: '2021-12-12 13:30:00',
            endDate: '2021-12-12 13:30:00'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher redemptions without startDate', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            clientKey: '566DCB7C6D58CCB285B9FE00077C6A977B5A1',
            voucherId: '1119',
            startDate: '',
            endDate: '2021-12-12 13:30:00'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher redemptions without endDate', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            clientKey: '9dc69d64f9f8fee37a70eab6d918c6db8db41626',
            voucherId: '1119',
            startDate: '2021-12-12 13:30:00',
            endDate: ''
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher redemptions with invalid voucherId', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            clientKey: '8863ce916083a9adfbfcb2a01b32086ba226c527',
            voucherId: 'dalal',
            startDate: '2021-12-12 13:30:00',
            endDate: '2021-12-12 13:30:00'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all redemption with invalid startDate', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            clientKey: '566DCB7C6D58CCB285B9FE00077C6A977B5A1',
            voucherId: '131',
            startDate: 'teddhghj',
            endDate: '2021-12-12 13:30:00'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all redemption with invalid endDate', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            clientKey: '566DCB7C6D58CCB285B9FE00077C6A977B5A1',
            voucherId: '131',
            startDate: '2021-12-12 13:30:00',
            endDate: 'fdgfdgd'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher redemptions with invalid url', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            clientKey: '566DCB7C6D58CCB285B9FE00077C6A977B5A1',
            voucherId: '131',
            startDate: '2021-12-12 13:30:00',
            endDate: '2021-12-12 13:30:00'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/redemptions`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/Voucher/redemptions`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
    });
});
