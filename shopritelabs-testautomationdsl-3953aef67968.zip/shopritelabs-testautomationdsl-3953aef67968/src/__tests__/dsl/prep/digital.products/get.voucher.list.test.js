import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('DSL -Returns a full list of all voucher List that have been created for a client', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;

    beforeAll(async () => {
        access = await ciamAuth.ciamFNBCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('Get all voucher lists', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            pageSize: '10',
            categoryId: '3',
            clientKey: '7235b37d1e5c88ee4ca5cdac0afd79158788456f'
        };
        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/list`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/list`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher categories with no params', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/list`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/list`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher List without category ID', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            pageSize: '10',
            clientKey: '7235b37d1e5c88ee4ca5cdac0afd79158788456f'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/list`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/list`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher List without currentPage', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            pageSize: '10',
            categoryId: '3',
            clientKey: '7235b37d1e5c88ee4ca5cdac0afd79158788456f'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/list`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/list`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher List without pageSize', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            categoryId: '3',
            clientKey: '7235b37d1e5c88ee4ca5cdac0afd79158788456f'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/list`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/voucher/list`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get all voucher List with invalid url', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        const params = {
            currentPage: '0',
            pageSize: '10',
            clientKey: '7235b37d1e5c88ee4ca5cdac0afd79158788456f'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/list`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/products/digital/Voucher/list`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
    });
});
