import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DSLAudiences from "../../data/audiences.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import CIAMCustomer from "../../../ciam/common/create_customer";
import _ from "lodash";
import {faker} from "@faker-js/faker";
import DSLPreferences from "../../data/preferences.data";
import CardService from "../../../__utils__/cards/cardService";

jest.retryTimes(1);
describe.skip('DSL - Customer Profile to Everlytic', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const audiences = new DSLAudiences();
    const cIAMCustomer = new CIAMCustomer();
    const dSLPreferences = new DSLPreferences();
    const cardService = new CardService();
    let token, checkersCustomer, uuid, mobileNumber, firstName, lastName, email;

    beforeAll(async () => {
        checkersCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        uuid = checkersCustomer.uuid;
        mobileNumber = checkersCustomer.mobileNumber;
        firstName = checkersCustomer.firstName;
        lastName = checkersCustomer.lastName;
        email = checkersCustomer.email;
        token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
    });

    test('add customer to subscription table', async () => {
        await addMsg({message: 'Original Data: \n' + JSON.stringify(checkersCustomer, null, 2)});
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload(uuid, 'Checkers', true, 'HPE');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise((r) => setTimeout(r, 90000));
    });

    test('patch customer details - firstName', async () => {
        let firstNameUpdate = _.startCase(_.toLower(faker.name.firstName()));
        const json = {
            "firstName": firstNameUpdate
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
    });

    test('patch customer details - lastName', async () => {
        let lastNameUpdate = _.startCase(_.toLower(faker.name.lastName()));
        const json = {
            "lastName": lastNameUpdate
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
    });

    test('patch customer details - mobileNumber', async () => {
        let mobileNumberUpdate = dataHelpers.generatePhoneNumber(true);
        const json = {
            "mobileNumber": mobileNumberUpdate
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
    });

    test('patch customer details - emailAddress', async () => {
        let firstNameUpdate = _.startCase(_.toLower(faker.name.firstName()));
        let lastNameUpdate = _.startCase(_.toLower(faker.name.lastName()));
        let emailUpdate = `${firstNameUpdate}-${lastNameUpdate}@DSL-testautomation.com`;
        const json = {
            "email": emailUpdate
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
    });

    test('add contact preferences', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "sms",
                "active": false
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        await new Promise((r) => setTimeout(r, 30000));
    });

    test('add contact preferences - switch opt-ins', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('with valid number using cognito - checkers', async () => {
        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });
});
