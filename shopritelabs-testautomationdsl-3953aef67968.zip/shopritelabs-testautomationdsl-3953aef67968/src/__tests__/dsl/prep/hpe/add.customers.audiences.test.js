import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DSLAudiences from "../../data/audiences.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import {v4} from "uuid";
import _ from 'lodash';

jest.retryTimes(1);
describe.skip('DSL - POST Audiences', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const audiences = new DSLAudiences();
    let access;
    let token;

    beforeAll(async () => {

    });

    test('add customer to subscription table', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload('c4fcc2db-9d67-4d29-877f-23cd9c377392', 'Checkers', true, 'HPE');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('valid UUID not in CIAM', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload('ff5dac1c-6ffd-4cf1-ad45-abd8d3331358', 'Checkers', false, 'HPE');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty brand in body', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload('ff5dac1c-6ffd-4cf1-ad45-abd8d3331358', '', true, 'HPE');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid brand in body', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload('ff5dac1c-6ffd-4cf1-ad45-abd8d3331358', 'Shoppie', true, 'HPE');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty optin in body', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload('ff5dac1c-6ffd-4cf1-ad45-abd8d3331358', 'Checkers', '', 'HPE');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty system in body', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload('ff5dac1c-6ffd-4cf1-ad45-abd8d3331358', 'Checkers', true, '');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid system in body', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload('ff5dac1c-6ffd-4cf1-ad45-abd8d3331358', 'Checkers', true, 'HPQ');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid UID', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = audiences.get_audiences_payload('garth', 'Checkers', true, 'HPE');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('empty body', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = [];
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('multiple customers in array', async () => {
        let opt = _.sample([true, false]);
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = [
            {
                "uid": v4(),
                "brand": "Checkers",
                "optin": opt,
                "system": "HPE"
            },
            {
                "uid": v4(),
                "brand": "Checkers",
                "optin": true,
                "system": "HPE"
            },
            {
                "uid": "4000970Q",
                "brand": "Checkers",
                "optin": opt,
                "system": "HPE"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('multiple customers with one HybrisID in array', async () => {
        const headers = {
            'x-api-key': process.env.everlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customers/audiences`});
        let json = [
            {
                "uid": v4(),
                "brand": "Checkers",
                "optin": true,
                "system": "HPE"
            },
            {
                "uid": v4(),
                "brand": "Checkers",
                "optin": true,
                "system": "HPE"
            },
            {
                "uid": "garth",
                "brand": "Checkers",
                "optin": false,
                "system": "HPE"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/customers/audiences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
