import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";
import CardService from "../../../../__utils__/cards/cardService";

describe('DSL - Validate Card (/card/validate)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const cardService = new CardService();
    let access;
    let uuid;
    let email;

    beforeAll(async () => {

    });

    test('with valid number - checkers', async () => {
        let cardNumber = await cardService.getCardOffline(false, 'checkers');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid number - shoprite', async () => {
        let cardNumber = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid number USED - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": "9710085600032455"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid number USED - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": "9710084090008372"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": "97100859000134ab"
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(500);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with no card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": ""
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with empty body', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {};
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {};
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {};
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users/card/validate`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users/card/validate`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
