import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";
import DSLPreferences from "../../../data/preferences.data";

describe('DSL - Get Customer contact preferences (/contactPreferences)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLPreferences = new DSLPreferences();
    let access;
    let uuid;
    let email;

    beforeAll(async () => {

        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        email = newCustomer.email;
        uuid = newCustomer.uuid;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_petshop_contact_preference();
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${newCustomer.uuid}`, json, headers);
        expect(response.status).toBe(200);
    });

    test('with no changes - petshop', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.contactPreferences.length; i++) {
            data.response.contactPreferences[i].updated = '[SANITIZED]';
        }
        expect(data).toMatchSnapshot();
    });

    test('Usave retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceUsaveApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.contactPreferences.length; i++) {
            data.response.contactPreferences[i].updated = '[SANITIZED]';
        }
        expect(data).toMatchSnapshot();
    });

    test('Medirite retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceMediriteApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/medirite/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/medirite/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.contactPreferences.length; i++) {
            data.response.contactPreferences[i].updated = '[SANITIZED]';
        }
        expect(data).toMatchSnapshot();
    });

    test('LiquorShop Checkers retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        // data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        // for (let i = 0; i < data.response.contactPreferences.length; i++) {
        //     data.response.contactPreferences[i].updated = '[SANITIZED]';
        // }
        // expect(data).toMatchSnapshot();
    });

    test('LiquorShop Shoprite retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        // data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        // for (let i = 0; i < data.response.contactPreferences.length; i++) {
        //     data.response.contactPreferences[i].updated = '[SANITIZED]';
        // }
        // expect(data).toMatchSnapshot();
    });

    test('HouseAndHome retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceHouseAndHomeApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/househome/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/househome/countries/za/contactPreferences?uid=70d7e23a-6be1-4dc2-9c3a-86fcc7774e04`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.contactPreferences.length; i++) {
            data.response.contactPreferences[i].updated = '[SANITIZED]';
        }
        expect(data).toMatchSnapshot();
    });

    test('with WHATSAPP update - petshop', async () => {

        let json = [{
            "active": true,
            "code": "whatsApp"
        }];
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responsePOST = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(responsePOST.data, null, 2)});
        await addMsg({message: JSON.stringify(responsePOST.data, null, 2)});
        expect(responsePOST.status).toBe(200);
        await new Promise((r) => setTimeout(r, 10000));
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.contactPreferences.length; i++) {
            data.response.contactPreferences[i].updated = '[SANITIZED]';
        }
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using cognito - petshop', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.contactPreferences.length; i++) {
            data.response.contactPreferences[i].updated = '[SANITIZED]';
        }
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using access token - petshop', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/contactPreferences`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/contactPreferences`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.contactPreferences.length; i++) {
            data.response.contactPreferences[i].updated = '[SANITIZED]';
        }
        expect(data).toMatchSnapshot();
    });

    test('with invalid access token', async () => {
        const headers = {
            'access_token': `123`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/contactPreferences`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/contactPreferences`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=123`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=123`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with missing customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand in URL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/contactPreferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code in URL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/uk/contactPreferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/uk/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
