import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import DSLPreferences from '../../../data/preferences.data';
import {addMsg} from "jest-html-reporters/helper";
import {encode} from "../../../../__utils__/encryption.util";
import LproPayloads from "../../../../__utils__/auth/ciam/payloads/lpro.payloads";
import DSLCustomer from "../../../data/customer.data";
import 'jest-matcher-one-of';
import {faker} from '@faker-js/faker';

jest.retryTimes(1);
describe('DSL - Add Interests Preferences to Customer (/preferences)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLPreferences = new DSLPreferences();
    const dSLCustomer = new DSLCustomer();
    const lproPayloads = new LproPayloads();
    let access;
    let interests = require('./data/personal.interests.json');
    let uuid;
    let email;
    let credentials;
    let sessionKey;

    beforeAll(async () => {

        let occAuthUserName = process.env.LPROClientID;
        let occAuthPassword = process.env.LPROClientSecret;
        credentials = encode(`${occAuthUserName}:${occAuthPassword}`);
        let payload = await lproPayloads.loginPayload();
        sessionKey = await ciamAuth.lpro_session_key_auth(payload, 'qa');
    });

    test('create seed data', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        uuid = newCustomer.uuid;
        email = newCustomer.email;
        expect(uuid).toBeDefined();
    });

    test.each(interests.checkers)(`$name - add checkers preference to customer`, async ({
                                                                                            name,
                                                                                            identifier
                                                                                        }) => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference(name, true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(dataHelpers.getValueFromJson(response1.data, `response.retailServices.xtraSavings.za.checkers.personalInterests.${name}.optIn`)).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, `response.retailServices.xtraSavings.za.checkers.personalInterests.${name}.identifier`)).toBe(`${identifier}`);

    });

    test.each(interests.shoprite)(`$name - add shoprite preference to customer`, async ({
                                                                                            name,
                                                                                            identifier
                                                                                        }) => {
        if (name !== 'srSwipeForCover' && name !== 'srAutoAirtime') {
            const headers = {
                Authorization: `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            let json = dSLPreferences.create_user_personal_preference(name, true);
            await addMsg({message: JSON.stringify(json, null, 2)});
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`});

            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`, json, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            let {data} = response;
            expect(response.status).toBe(200);
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
            let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
            const headersCiam = {
                'accessToken': `${token.data.response.accessToken}`,
                'x-api-key': process.env.CIAMDSLApiKey,
                'Content-Type': 'application/json'
            };
            const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
            await addMsg({message: JSON.stringify(response1.data, null, 2)});
            expect(response1.status).toBe(200);
            expect(dataHelpers.getValueFromJson(response1.data, `response.retailServices.xtraSavings.za.shoprite.personalInterests.${name}.optIn`)).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, `response.retailServices.xtraSavings.za.shoprite.personalInterests.${name}.identifier`)).toBe(`${identifier}`);
        }
    });

    test(`add all checkers interests to customer`, async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('cfsb2b', true);
        for (let i = 1; i < interests.checkers.length; i++) {
            json.push({
                "active": true,
                "name": interests.checkers[i].name
            });
        }
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chLiquorshop.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inBaby.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.yrCBW.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chVineSociety.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inCat.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chWorldOfCheckersNewsletter.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inHealthAndBeauty.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inVegetarian.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inHealthyLiving.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.sfgFoodAndTreesForAfrica.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.cfsB2B.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.cfsB2C.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.sfgSPCA.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.sfgLunchboxFund.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chBackToSchool.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chClothAndFoot.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inWine.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inKids.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inDog.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inBraai.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.cfsNewsletter.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chBabyAndParenting.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inSpecialsAndPromotions.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chWhiskySociety.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inCoffee.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.sfgAACL.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chWorldofWhiskey.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chSurvey.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inLiquor.optIn')).toBe(true);
    });

    test(`add all shoprite interests to customer`, async () => {
            const headers = {
                Authorization: `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            let json = dSLPreferences.create_user_personal_preference('srInFamilyMeals', true);
            for (let i = 1; i < interests.shoprite.length; i++) {
                if (interests.shoprite[i].name !== 'srSwipeForCover' && interests.shoprite[i].name !== 'srAutoAirtime') {
                    json.push({
                        "active": true,
                        "name": interests.shoprite[i].name
                    });
                }
            }
            await addMsg({message: JSON.stringify(json, null, 2)});
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`});

            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`, json, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            let {data} = response;
            expect(response.status).toBe(200);
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();

            let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
            const headersCiam = {
                'accessToken': `${token.data.response.accessToken}`,
                'x-api-key': process.env.CIAMDSLApiKey,
                'Content-Type': 'application/json'
            };
            const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
            await addMsg({message: JSON.stringify(response1.data, null, 2)});
            expect(response1.status).toBe(200);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInFamilyMeals.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInGreatOutdoors.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInLookingGood.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.yrCBW.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srWine.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInPartiesAndTreats.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInWineLovers.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srWorldOfShoprite.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srSfgSanitary.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInHealthyLiving.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srLiquorshop.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInBraaiAndGrill.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInGroceryEssentials.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srBaby.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srHustle.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srBackToSchool.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srB2B.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInCleanhome.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInCat.optIn')).toBe(true);
            expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInHomebar.optIn')).toBe(true);
        }
    );

    test('with valid input data using access token - Checkers', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        await addMsg({message: newCustomer.uuid});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('chbabyandparenting', true);
        json.push({
            "active": false,
            "name": 'inhealthandbeauty'
        });
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/preferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/preferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chBabyAndParenting.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chBabyAndParenting.identifier')).toBe('7');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inHealthAndBeauty.optIn')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inHealthAndBeauty.identifier')).toBe('48');
    });

    test('with valid input data using access token - Shoprite', async () => {
        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        let email = newCustomer.email;
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        await addMsg({message: newCustomer.uuid});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('sringroceryessentials', true);
        json.push({
            "active": false,
            "name": 'srinpartiesandtreats'
        });
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInGroceryEssentials.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInGroceryEssentials.identifier')).toBe('90');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInPartiesAndTreats.optIn')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.shoprite.personalInterests.srInPartiesAndTreats.identifier')).toBe('111');
    });

    let customerUUID;

    test('add SwipeForCover and AutoAirtimeInjection', async () => {
        const cust = await dSLCustomer.create_customer_valid_partial('checkers', true);
        const mobileNumber = cust.contactDetails[0].value;
        const cardNumber = cust.foxCard.cardNo;
        await addMsg({message: JSON.stringify(cust, null, 2)});
        const hd = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const resp = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, cust, hd);
        await addMsg({message: JSON.stringify(resp.data, null, 2)});
        expect(resp.data.response.uuid).not.toBeNull();
        customerUUID = resp.data.response.uuid;
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "active": true,
                "name": "srswipeforcover"
            }, {
                "active": true,
                "name": "srautoairtime"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences?uid=${customerUUID}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${customerUUID}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(customerUUID);
        let headers1 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response1 = await apiCall.POST(url, body, headers1);
        let responseJson = dataHelpers.xml2json(response1.data);
        let respJson = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let aa = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'][0]['$']['Id'];
        let sfc = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'][1]['$']['Id'];
        let segments = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'];
        expect(segments).toHaveLength(2);
        expect(aa).toBe('1201');
        expect(sfc).toBe('1301');
    });

    test('remove SwipeForCover', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "active": false,
                "name": "srswipeforcover"
            }, {
                "active": true,
                "name": "srautoairtime"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences?uid=${customerUUID}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${customerUUID}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(customerUUID);
        let headers1 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response1 = await apiCall.POST(url, body, headers1);
        let responseJson = dataHelpers.xml2json(response1.data);
        let respJson = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let aa = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'][0]['$']['Id'];
        let segments = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'];
        expect(segments).toHaveLength(1);
        expect(aa).toBe('1201');
    });

    test('remove AutoAirtime and add SwipeForCover', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "active": true,
                "name": "srswipeforcover"
            }, {
                "active": false,
                "name": "srautoairtime"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences?uid=${customerUUID}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${customerUUID}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(customerUUID);
        let headers1 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response1 = await apiCall.POST(url, body, headers1);
        let responseJson = dataHelpers.xml2json(response1.data);
        let respJson = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let aa = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'][0]['$']['Id'];
        let segments = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'];
        expect(segments).toHaveLength(1);
        expect(aa).toBe('1301');
    });

    test('remove AutoAirtime and SwipeForCover', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "active": false,
                "name": "srswipeforcover"
            }, {
                "active": false,
                "name": "srautoairtime"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences?uid=${customerUUID}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${customerUUID}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(customerUUID);
        let headers1 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response1 = await apiCall.POST(url, body, headers1);
        let responseJson = dataHelpers.xml2json(response1.data);
        let respJson = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let segments = respJson['HouseHold']['HouseHoldSegments'];
        expect(segments).toBeUndefined();
    });

    test('with valid invalid interest', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('coolio', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add SwipeForCover on Customer with no ID Number', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('shoprite', true);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        json = dataHelpers.setValueInJson(json, 'identity[0].type', 'PASSPORT');
        json = dataHelpers.setValueInJson(json, 'identity[0].value', faker.internet.password(15, false, /[0-9A-Z]/));
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let jsonPreference = [
            {
                "active": true,
                "name": "srswipeforcover"
            }
        ];
        await addMsg({message: JSON.stringify(jsonPreference, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences?uid=${response.data.response.uuid}`});

        const responsePreference = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${response.data.response.uuid}`, jsonPreference, headers);
        await addMsg({message: JSON.stringify(responsePreference.data, null, 2)});
        let {data} = responsePreference;
        expect(responsePreference.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
