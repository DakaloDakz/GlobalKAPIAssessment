import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

jest.retryTimes(1);
describe('ASM - Get Customer', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;
    let uuid;
    let email;

    beforeAll(async () => {
        access = await ciamAuth.ciamASMCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('with valid input data using access token - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=48d992bf-7e6e-44a1-94b3-5fdf4683f5f0`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=48d992bf-7e6e-44a1-94b3-5fdf4683f5f0`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using C4C access token - checkers', async () => {
        let accessC4C = await ciamAuth.ciamC4CCognitoAuth(process.env.CIAM);
        accessC4C = accessC4C.data.access_token;
        const headers = {
            Authorization: `Bearer ${accessC4C}`,
            'x-api-key': process.env.C4CLCognitoApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=48d992bf-7e6e-44a1-94b3-5fdf4683f5f0`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=48d992bf-7e6e-44a1-94b3-5fdf4683f5f0`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using access token - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=48d992bf-7e6e-44a1-94b3-5fdf4683f5f0`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=48d992bf-7e6e-44a1-94b3-5fdf4683f5f0`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created on Commerce', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=67ce6d27-2d7e-4f90-aa27-f772af19c95f`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=67ce6d27-2d7e-4f90-aa27-f772af19c95f`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint with 255 char lastName', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=66efd3a7-bfbd-4b56-a91a-23cfc7606c81`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=66efd3a7-bfbd-4b56-a91a-23cfc7606c81`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint with 255 char firstName', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=5a6b57d8-cf94-4ae3-b67d-4c9fcdf963bf`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=5a6b57d8-cf94-4ae3-b67d-4c9fcdf963bf`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('customer with no card number', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=394f2553-aec6-4560-898f-ea04417d4730`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=394f2553-aec6-4560-898f-ea04417d4730`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid access token', async () => {
        const headers = {
            'access_token': `123`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(401);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand in URL', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za?uid=${uuid}`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code in URL', async () => {
        const headers = {
            Authorization: `Bearer ${access}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk?uid=${uuid}`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
