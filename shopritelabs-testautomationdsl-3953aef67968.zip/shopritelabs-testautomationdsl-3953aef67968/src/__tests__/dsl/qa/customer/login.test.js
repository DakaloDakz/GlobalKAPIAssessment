import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('DSL - Login by Card Number (dsl/brands/checkers/countries/za/users/login)', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();

    beforeAll(async () => {

    });

    test('Login with Valid mobile number only - ciam gateway', async () => {
        const headers = {
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const dataInput = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "targetIsVerified": true
            },
            "action": "verify"
        };

        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/login/otp/generate`, dataInput, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'expiry.value', 'reference']);
        expect(data).toMatchSnapshot();

        const headersOtp = {
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": response.data.reference
            },
            "otp": 0
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/login/otp/verify`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response1 = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/login/otp/verify`, json, headersOtp);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.accessToken).toBeDefined();
        expect(response1.data.response.refreshToken).toBeDefined();
    });

    test('Login with Valid card number only - dsl gateway', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '+27833915802'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.expiry.value', 'response.reference']);
        expect(data).toMatchSnapshot();
        let json = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": '89f4edbd-a689-4c0c-b590-90f9fb32e64f'
            },
            "otp": 8597
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response1 = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, json, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.accessToken).toBeDefined();
        expect(response1.data.response.refreshToken).toBeDefined();
    });

    test('Login with Valid card number only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '9710085460040580'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.expiry.value', 'response.reference']);
        expect(data).toMatchSnapshot();
        const headersOtp = {
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "target": {
                "type": "CARD",
                "identifier": "9710085460040580",
                "reference": data.response.reference
            },
            "otp": "abcde"
        };
        await addMsg({message: `${process.env.DSLGroup}/ciam/brands/checkers/countries/za/users/login/otp/verify`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response1 = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/verify`, json, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.accessToken).toBeDefined();
        expect(response1.data.response.refreshToken).toBeDefined();
    });

    test('Login with mobile number only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '+27833915802'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.expiry.value', 'response.reference']);
        expect(data).toMatchSnapshot();
    });

    test('Login with email only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: 'gacombrink@shoprites.co.za'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        expect(response.data.response.reference).toBeDefined();
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.expiry.value', 'response.reference']);
        expect(data).toMatchSnapshot();
        const paramsVerify = {
            "target": {
                "type": "EMAIL",
                "identifier": "gacombrink@shoprite.co.za",
                "reference": reference
            },
            "otp": 0
        };
        const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
        await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
        expect(responseVerify.status).toBe(400);
        data = dataHelpers.sanitize(responseVerify.data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: 'dakaloa'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with card number that does not exist', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '276587745595'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with card number that start with 0', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '0647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with blank card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid brand and blank card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/OkFood/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid country code and blank card number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/nb/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '+27647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/OkFood/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Login with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: '+27647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/nb/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
