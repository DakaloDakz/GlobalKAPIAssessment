import ApiMethodUtil from '../../../../__utils__/api_method_util';
import DataHelpers from '../../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import {faker} from '@faker-js/faker';
import CIAMCustomer from "../../../../ciam/common/create_customer";

jest.retryTimes(1);
describe('DSL - Password Management', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const cIAMCustomer = new CIAMCustomer();
    const dataHelpers = new DataHelpers();

    let token, access, accessToken, refreshToken, email, uuid, mobileNumber, firstName, lastName, checkersCustomer,
        password, newForgotPassword;
    beforeAll(async () => {

    });

    describe('Patch Password (/users/password)', () => {
        test('set password - checkers', async () => {
            checkersCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
            mobileNumber = checkersCustomer.mobileNumber;
            firstName = checkersCustomer.firstName;
            lastName = checkersCustomer.lastName;
            email = checkersCustomer.email;
            uuid = checkersCustomer.uuid;
            password = faker.internet.password(33, false, /[A-Za-z\d#?!@$%^&*-]/g);
            await new Promise(resolve => setTimeout(resolve, 30000));
            token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': password
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('set password - shoprite', async () => {
            password = faker.internet.password(33, false, /[A-Za-z\d#?!@$%^&*-]/g);
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': password
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('set password for unverified customer', async () => {
            let tokenUnverified = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27877062832', 'dsl');

            const headers = {
                'access_token': `${tokenUnverified.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': password
            };
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with password length 8', async () => {
            password = 'Test@123';
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': password
            };
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with password length 128', async () => {
            password = faker.internet.password(128, false, /[A-Za-z\d#?!@$%^&*-]/g);
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': password
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('set password on customer without email address', async () => {
            let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27855394572', 'dsl');
            const headers = {
                'access_token': `${access.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(33)
            };
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with password less than 8', async () => {
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(7, false, /[A-Za-z\d#?!@$%^&*-]/g)
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with password more than 128', async () => {
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(129, false, /[A-Za-z\d#?!@$%^&*-]/g)
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with password no uppercase letter', async () => {
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(50, false, /[A-Za-z\d#?!@$%^&*-]/g).toLowerCase()
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with password no lowercase letter', async () => {
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(50, false, /[A-Za-z\d#?!@$%^&*-]/g).toUpperCase()
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with password no special characters', async () => {
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(50, false, /[A-Za-z\d]/g)
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with password no numeric characters', async () => {
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(50, false, /[A-Za-z#?!@$%^&*-]/g)
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with empty password', async () => {
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': ''
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('with missing password', async () => {
            const headers = {
                'access_token': `${token.data.response.accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/password`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });
    });

    describe('Login by Email (/loginbyuser)', () => {
        test('login with email and password', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': password,
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, null);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            expect(response.data.response.accessToken).toBeDefined();
            expect(response.data.response.refreshToken).toBeDefined();
            accessToken = response.data.response.accessToken;
            refreshToken = response.data.response.refreshToken;
            const headersGetCustomer = {
                'access_token': `${accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

            const responseGetCustomer = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headersGetCustomer, null);
            await addMsg({message: JSON.stringify(responseGetCustomer.data, null, 2)});
            let {data} = responseGetCustomer;
            expect(responseGetCustomer.status).toBe(200);
            expect(responseGetCustomer.data.response.user.email).toBe(email);
            expect(responseGetCustomer.data.response.user.mobileNumber).toBe(mobileNumber);
            expect(responseGetCustomer.data.response.user.firstName).toBe(firstName);
            expect(responseGetCustomer.data.response.user.lastName).toBe(lastName);
        });

        test('login with valid email and invalid password', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': 'testing123',
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, null);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('login with valid email not in CIAM', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': password,
                'email': 'notinCiam@gmail.com'
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, null);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('login with no email', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': password
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, null);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('login with no password', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, null);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('login with no email or password', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, null);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('login with email and password in url path', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            let params = {
                'password': password,
                'email': email
            };
            const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, params);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

    });

    describe('Forgot Password (/forgotpassword)', () => {
        test('forgot password', async () => {
            newForgotPassword = faker.internet.password(33, false, /[A-Za-z\d#?!@$%^&*-]/g);
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': newForgotPassword,
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('login with email and password - updated via forgotPassword', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': newForgotPassword,
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headers, null);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            expect(response.data.response.accessToken).toBeDefined();
            expect(response.data.response.refreshToken).toBeDefined();
            accessToken = response.data.response.accessToken;
            refreshToken = response.data.response.refreshToken;
            const headersGetCustomer = {
                'access_token': `${accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

            const responseGetCustomer = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headersGetCustomer, null);
            await addMsg({message: JSON.stringify(responseGetCustomer.data, null, 2)});
            let {data} = responseGetCustomer;
            expect(responseGetCustomer.status).toBe(200);
            expect(responseGetCustomer.data.response.user.email).toBe(email);
            expect(responseGetCustomer.data.response.user.mobileNumber).toBe(mobileNumber);
            expect(responseGetCustomer.data.response.user.firstName).toBe(firstName);
            expect(responseGetCustomer.data.response.user.lastName).toBe(lastName);
        });

        test('forgot password with empty password', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': '',
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password with empty email', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': newForgotPassword,
                'email': ''
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password with no email or password', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password length less than 8', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(7, false, /[A-Za-z\d#?!@$%^&*-]/g),
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password length more than 128', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': faker.internet.password(129, false, /[A-Za-z\d#?!@$%^&*-]/g),
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password no uppercase characters', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': 'testing@123',
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password no lowercase characters', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': 'TESTING@123',
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password no special characters', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': 'Testing123',
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password no numeric characters', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': 'Testing!@#$%%',
                'email': email
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('email and password in url paramaters', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword?email=${email}&password=${faker.internet.password(12)}`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('forgot password for unverified customer', async () => {
            const headers = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': newForgotPassword,
                'email': 'Rosie-Schmeler@shoprite-testautomation.com'
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/forgotpassword`, null, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
            const headersLogin = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'password': newForgotPassword,
                'email': 'Rosie-Schmeler@shoprite-testautomation.com'
            };
            await addMsg({message: JSON.stringify(checkersCustomer, null, 2)});
            await addMsg({message: JSON.stringify(headers, null, 2)});
            const responseLogin = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loginbyuser`, headersLogin, null);
            await addMsg({message: JSON.stringify(responseLogin.data, null, 2)});
            expect(responseLogin.status).toBe(200);
            expect(responseLogin.data.response.accessToken).toBeDefined();
            expect(responseLogin.data.response.refreshToken).toBeDefined();
        });
    });

    describe('Logout customer (/logout)', () => {
        test('try to login with a logged out customer', async () => {
            const headersLogOut = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'uid': uuid
            };
            await addMsg({message: JSON.stringify(headersLogOut, null, 2)});
            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/logout`, null, headersLogOut);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            const headersGetCustomer = {
                'access_token': `${accessToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

            const responseGetCustomer = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headersGetCustomer, null);
            await addMsg({message: JSON.stringify(responseGetCustomer.data, null, 2)});
            expect(responseGetCustomer.status).toBe(404);
            let {data} = responseGetCustomer;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('logout with invalid uid', async () => {
            const headersLogOut = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'uid': '123'
            };
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/logout`});
            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/logout`, null, headersLogOut);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('logout with empty uid', async () => {
            const headersLogOut = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json',
                'uid': ''
            };
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/logout`});
            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/logout`, null, headersLogOut);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });

        test('logout with no uid', async () => {
            const headersLogOut = {
                'Authorization': `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/logout`});
            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/logout`, null, headersLogOut);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(400);
            let {data} = response;
            data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
            expect(data).toMatchSnapshot();
        });
    });
});
