import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('DSL - Login by Mobile (dsl/brands/checkers/countries/za/users/loginbymobile)', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();

    beforeAll(async () => {

    });

    test('Verify customer with Valid mobile number only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: '+27877349694'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.expiry.value', 'response.reference']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with invalid mobile number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: 'dakaloa'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with number that does not exist', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: '+276587745595'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with number that start with 0', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: '0647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with blank mobile number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with invalid brand and blank mobile number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/OkFood/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with invalid country code and blank mobile number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: ''};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/nb/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: '+27647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/OkFood/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: '+27647572677'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/nb/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
