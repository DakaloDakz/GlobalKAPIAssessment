import ApiMethodUtil from '../../../../__utils__/api_method_util';
import CIAMAuth from '../../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../../__utils__/data_helpers';
import CIAMCustomer from '../../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";
import DSLPreferences from "../../../data/preferences.data";

describe('DSL - Get Customer consent (/consent)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLPreferences = new DSLPreferences();
    let access;
    let uuid;
    let email;

    beforeAll(async () => {

    });

    test('PetShopScience retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });

    test('Usave retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceUsaveApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });

    test('XtraSavings Checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated', 'response.consents[2].updated']);
        expect(data).toMatchSnapshot();
    });

    test('XtraSavings Shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });

    test('Medirite retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceMediriteApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/medirite/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/medirite/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });

    test('LiquorShop Checkers retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });

    test('LiquorShop Shoprite retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });

    test('HouseAndHome retail service', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceHouseAndHomeApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/househome/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/househome/countries/za/consent?uid=6182c649-3db4-465e-be0b-683accec6b0e`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.consents[0].updated', 'response.consents[1].updated']);
        expect(data).toMatchSnapshot();
    });
});
