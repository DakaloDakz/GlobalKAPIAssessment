import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe('DSL - Get Customer (/users)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;
    let uuid;
    let email;

    beforeAll(async () => {

        const newCustomer = await cIAMCustomer.createValidCIAMCustomerMinimal();
        email = newCustomer.email;
        uuid = newCustomer.uuid;
    });

    test('with valid input data using access token - checkers', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, 'venus@yopmail.com', 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with valid input data using access token - shoprite', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, 'Mikel_Emmerich@shoprite-testautomation.com', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created on Commerce', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, 'daron.johnson@yahoo.com', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27803426015', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint with 255 char lastName', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27830908368', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('created via /partialuser endpoint with 255 char firstName', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27844178416', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('customer with no card number', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, 'Pink85@shoprite-testautomation.com', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid access token', async () => {
        const headers = {
            'access_token': `123`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand in URL', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid country code in URL', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
