import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe('DSL - Get customer lifetime savings', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let mobileNumber = '+27717850086';
    let tk;

    beforeAll(async () => {
        tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
    });

    test('Get valid customer lifetime savings', async () => {
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/lifetimesavings`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/lifetimesavings`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.timestamp']);
        expect(data).toMatchSnapshot();
    });

    test('Get valid customer lifetime savings with SFC = true', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27832990678', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/lifetimesavings`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/lifetimesavings`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });

    test('Get lifetime savings using invalid customer', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27833915802', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/lifetimesavings`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/lifetimesavings`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.timestamp']);
        expect(data).toMatchSnapshot();
    });

    test('Get lifetime savings using invalid country code', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27832990678', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/bm/users/lifetimesavings`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/bm/users/lifetimesavings`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Get lifetime savings using invalid brand', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27832990678', 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/Okfood/countries/za/users/lifetimesavings`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/Okfood/countries/za/users/lifetimesavings`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

});
