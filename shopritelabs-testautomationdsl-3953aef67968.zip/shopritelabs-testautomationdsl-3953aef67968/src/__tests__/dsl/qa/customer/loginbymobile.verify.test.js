import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import DataHelpers from "../../../__utils__/data_helpers";

describe.skip('DSL - Login by Mobile Verify (dsl/brands/checkers/countries/za/otp/loginbymobile/verify)', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();

    beforeAll(async () => {

    });

    test('Verify customer with Valid mobile number only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: '+27833915802'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        console.log(reference);

        const paramsVerify = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": reference
            },
            "otp": 0
        };
        const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
        await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
        expect(responseVerify.status).toBe(200);
        let {data} = responseVerify;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.accessToken', 'response.refreshToken']);
        expect(data).toMatchSnapshot();
    });

    test('empty OTP', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: '+27833915802'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        console.log(reference);

        const paramsVerify = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": reference
            },
            "otp": ""
        };
        const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
        await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
        expect(responseVerify.status).toBe(400);
        let {data} = responseVerify;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.accessToken', 'response.refreshToken']);
        expect(data).toMatchSnapshot();
    });

    test('invalid OTP', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: '+27833915802'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        console.log(reference);

        const paramsVerify = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": reference
            },
            "otp": "adcd"
        };
        const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
        await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
        expect(responseVerify.status).toBe(500);
        let {data} = responseVerify;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.accessToken', 'response.refreshToken']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with Valid email only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: 'gacombrink@shoprite.co.za'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        console.log(reference);

        const paramsVerify = {
            "target": {
                "type": "EMAIL",
                "identifier": "gacombrink@shoprite.co.za",
                "reference": reference
            },
            "otp": 0
        };
        const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
        await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
        expect(responseVerify.status).toBe(200);
        let {data} = responseVerify;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.accessToken', 'response.refreshToken']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with invalid mobile number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            "target": {
                "type": "SMS",
                "identifier": "27833915802",
                "reference": "ebdfa6fe-042f-4fb5-ad2d-815a29864ccb"
            },
            "otp": 5848
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, params, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with number that does not exist', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            "target": {
                "type": "SMS",
                "identifier": "+2783391999",
                "reference": "ebdfa6fe-042f-4fb5-ad2d-815a29864ccb"
            },
            "otp": 5848
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, params, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with number that start with 0', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            "target": {
                "type": "SMS",
                "identifier": "0833915802",
                "reference": "ebdfa6fe-042f-4fb5-ad2d-815a29864ccb"
            },
            "otp": 5848
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, params, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with blank mobile number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            "target": {
                "type": "SMS",
                "identifier": "",
                "reference": "ebdfa6fe-042f-4fb5-ad2d-815a29864ccb"
            },
            "otp": 5848
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, params, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with blank reference number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": ""
            },
            "otp": 5848
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, params, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": "ebdfa6fe-042f-4fb5-ad2d-815a29864ccb"
            },
            "otp": 5848
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/OkFood/countries/za/otp/loginbymobile/verify`, params, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Verify customer with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {
            "target": {
                "type": "SMS",
                "identifier": "+27833915802",
                "reference": "ebdfa6fe-042f-4fb5-ad2d-815a29864ccb"
            },
            "otp": 5848
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/nb/otp/loginbymobile/verify`, params, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
