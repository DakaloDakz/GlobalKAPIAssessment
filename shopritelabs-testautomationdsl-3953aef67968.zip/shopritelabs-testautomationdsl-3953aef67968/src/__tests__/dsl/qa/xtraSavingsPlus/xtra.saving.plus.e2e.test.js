import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import DataHelpers from "../../../__utils__/data_helpers";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import XsplusData from "../../../__utils__/xtraSavingPlus/data/xsplus.data";
import XtraSavingsPlusCustomer from "../../../__utils__/xtraSavingPlus/lib/customer";
import ChargebeeCustomer from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.customer.sdk";
import ChargebeeSubscriptions from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.subscriptions.sdk";
import PaymentCards from "../../../__utils__/xtraSavingPlus/lib/paymentCardsQA";

describe('DSL - XS Plus End2End', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const chargebeeCustomer = new ChargebeeCustomer();
    const chargebeeSubscription = new ChargebeeSubscriptions();
    const customerXtraSavings = new XtraSavingsPlusCustomer();
    const card = new PaymentCards();
    const xsPlus = new XsplusData();
    let customerVisa, subscriptionID, visa, newSubscriptionID;
    beforeAll(async () => {
    });

    test('subscription registration with Visa card', async () => {
        visa = await card.getVisaCard();
        customerVisa = await customerXtraSavings.createCustomer(true);
        expect(customerVisa.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerVisa.uuid, customerVisa.email, customerVisa.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        subscriptionID = response.data.response.xtraSavingsPlus.subscriptions[0].subscriptionId;
        expect(response.status).toBe(200);
        let {data} = response;
        expect(customerVisa.uuid).toBe(data.response.uuid);
        expect(customerVisa.email).toBe(data.response.email);
        expect(customerVisa.firstName).toBe(data.response.firstName);
        expect(customerVisa.lastName).toBe(data.response.lastName);
        expect(customerVisa.mobileNumber).toBe(data.response.mobileNumber);
        expect(customerVisa.idNumber).toBe(data.response.saIdNumber);
        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "active",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "applyTill": expect.any(String),
                "couponId": "R50DISCOUNTCOUPON"
            }],
            "nextBillingAt": expect.any(String)
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "firstName": customerVisa.firstName,
            "lastName": customerVisa.lastName,
            "mobileNumber": customerVisa.mobileNumber,
            "email": customerVisa.email
        });

        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customerVisa.firstName, customerVisa.lastName, customerVisa.email, customerVisa.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customerVisa.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customerVisa.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customerVisa.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customerVisa.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(cbCustomerResponse.list[0].customer.id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0].item_price_id).toBe('R149-plan-ZAR-Monthly');
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('active');
        expect(cbSubscriptionResponse.list[0].subscription.coupon).toBe('R50DISCOUNTCOUPON');
    });

    test('cancel subscription', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customerVisa.uuid}&subscriptionId=${subscriptionID}`, null, headers);
        await addMsg(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customerVisa.uuid}&subscriptionId=${subscriptionID}`);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('reactivate subscription', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions(`${customerVisa.uuid}`, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(customerVisa.uuid);
        newSubscriptionID = cbSubscriptionResponse.list[0].subscription.id;
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0].item_price_id).toBe('R149-plan-ZAR-Monthly');
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('active');
        expect(cbSubscriptionResponse.list[0].subscription.coupon).toBe('R50DISCOUNTCOUPON');
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0]).toMatchObject({
            "item_price_id": "R149-plan-ZAR-Monthly",
            "item_type": "plan",
            "quantity": 1,
            "unit_price": 14900,
            "amount": 14900,
            "free_quantity": 0,
            "object": "subscription_item"
        });
    });

    test('cancel subscription again', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customerVisa.uuid}&subscriptionId=${newSubscriptionID}`, null, headers);
        await addMsg(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/cancel?uid=${customerVisa.uuid}&subscriptionId=${newSubscriptionID}`);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });

    test('reactivate subscription again', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions(`${customerVisa.uuid}`, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        expect(data).toMatchSnapshot();
    });
});
