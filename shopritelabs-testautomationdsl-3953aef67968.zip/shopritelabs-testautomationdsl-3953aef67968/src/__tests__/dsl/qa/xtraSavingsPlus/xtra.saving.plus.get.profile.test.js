import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import responseSchema from "../../../__utils__/xtraSavingPlus/schemas/customer.schema.json";
import DataHelpers from "../../../__utils__/data_helpers";

jest.retryTimes(1);
describe.skip('DSL - XSPlus GET Customer Subscriptions(/xsplus/register)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();

    beforeAll(async () => {

    });

    test('get customer profile', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=24210976-ccda-4516-907a-a344c6c0b838`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect('24210976-ccda-4516-907a-a344c6c0b838').toBe(data.response.uuid);
        expect('Chloe-Maggio@shoprite-testautomation.com').toBe(data.response.email);
        expect('Chloe').toBe(data.response.firstName);
        expect('Maggio').toBe(data.response.lastName);
        expect('+27843233106').toBe(data.response.mobileNumber);
        expect('7610144741187').toBe(data.response.saIdNumber);
        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "cancelled",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "couponId": "R50DISCOUNTCOUPON"
            }]
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            // "consentTemplateVersion": "1.0",
            "updated": expect.any(String),
            "granted": true
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "firstName": "Chloe",
            "lastName": "Maggio",
            "mobileNumber": "+27843233106",
            "email": "Chloe-Maggio@shoprite-testautomation.com"
        });
        expect(data.response.xtraSavingsPlus.savings).toMatchObject({
            "billingPeriod": "",
            "monthlySavingsAmount": "0",
            "monthlyFreeDeliverySavings": "0",
            "monthlyFreeDeliveryCount": "0",
            "monthlyDiscountSavings": "0",
            "monthlyExtraSavings": "0",
            "discountRedeemed": false
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('get customer profile - with CAR savings', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=984d79a3-392e-4df6-90a6-50949a150ade`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect('984d79a3-392e-4df6-90a6-50949a150ade').toBe(data.response.uuid);
        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-Plan-Daily-ZAR-Daily"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "cancelled",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "couponId": "R50DISCOUNTCOUPON"
            }]
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            // "consentTemplateVersion": "1.0",
            "updated": expect.any(String),
            "granted": true
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "email": "Pattie-Feest@shoprite-testautomation.com",
            "firstName": "Pattie",
            "lastName": "Feest",
            "mobileNumber": "+27815499635"
        });
        expect(data.response.xtraSavingsPlus.savings).toMatchObject({
            "billingPeriod": "",
            "monthlySavingsAmount": "0",
            "monthlyFreeDeliverySavings": "0",
            "monthlyFreeDeliveryCount": "0",
            "monthlyDiscountSavings": "0",
            "monthlyExtraSavings": "0",
            "discountRedeemed": false
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('get customer profile - with CAR savings over 2 periods', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=e874f7ea-271e-4318-a8ee-18aae6267e52`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect('e874f7ea-271e-4318-a8ee-18aae6267e52').toBe(data.response.uuid);
        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "active",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "couponId": "R50DISCOUNTCOUPON"
            }]
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            // "consentTemplateVersion": "1.0",
            "updated": expect.any(String),
            "granted": true
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "email": "Casper-Ward@shoprite-testautomation.com",
            "firstName": "Casper",
            "lastName": "Ward",
            "mobileNumber": "+27822563744"
        });
        expect(data.response.xtraSavingsPlus.savings).toMatchObject({
            "billingPeriod": "",
            "monthlySavingsAmount": "0",
            "monthlyFreeDeliverySavings": "0",
            "monthlyFreeDeliveryCount": "0",
            "monthlyDiscountSavings": "0",
            "monthlyExtraSavings": "0",
            "discountRedeemed": false
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('get customer profile for customer in CIAM but not in Chargebee', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let uuid = 'bf288b98-6d9f-4209-9016-df9d94824b25';
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response).toMatchObject({
            "birthDate": "15/12/2000",
            "cards": [
                {
                    "cardNumber": "9710084459046328",
                    "theme": "Checkers",
                    "active": true
                }
            ],
            "emailVerified": "false",
            "firstName": "Josue",
            "lastName": "Weissnat",
            "mobileNumber": "+27843023187",
            "mobileNumberVerified": "true",
            "saIdNumber": "0012152428186",
            "uid": "bf288b98-6d9f-4209-9016-df9d94824b25",
            "uuid": "bf288b98-6d9f-4209-9016-df9d94824b25",
            "xtraSavingsPlus": {
                "consents": [
                    {}
                ],
                "billingInformation": {},
                "subscriptions": [
                    {}
                ]
            }
        });
    });

    test('with invalid uuid', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=1299999`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/xsplus/profile?uid=24210976-ccda-4516-907a-a344c6c0b838`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with Shoprite brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/xsplus/profile?uid=24210976-ccda-4516-907a-a344c6c0b838`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('with invalid countryCode', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/xsplus/profile?uid=24210976-ccda-4516-907a-a344c6c0b838`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
