import ApiMethodUtil from '../../../__utils__/api_method_util';
import ChargebeeCustomer from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.customer.sdk";
import {addMsg} from "jest-html-reporters/helper";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import {faker} from "@faker-js/faker";
import DataHelpers from "../../../__utils__/data_helpers";

jest.retryTimes(1);
describe.skip('DSL - XSPlus CIAM to Chargebee webhook', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const chargebeeCustomer = new ChargebeeCustomer();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    let accessToken;
    let originalData;
    let firstName;
    let lastName;
    let mobileNumber;
    let email;

    beforeAll(async () => {
        originalData = {
            "firstName": "Harvey",
            "lastName": "Torphy",
            "mobileNumber": "+27863527795",
            "email": "Harvey-Torphy@shoprite-testautomation.com"
        };
        accessToken = await ciamAuth.ciam_trusted_auth(process.env.CIAM, originalData.mobileNumber, 'dsl');
    });

    test('update firstName and lastName', async () => {
        firstName = faker.name.firstName();
        lastName = faker.name.lastName();
        const json = {
            "firstName": firstName,
            "lastName": lastName
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${accessToken.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(json.firstName, json.lastName, originalData.email, originalData.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(originalData.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(originalData.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(json.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(json.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
    });

    test('update firstName only', async () => {
        firstName = faker.name.firstName();
        const json = {
            "firstName": firstName
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${accessToken.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(json.firstName, lastName, originalData.email, originalData.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(originalData.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(originalData.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(json.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
    });

    test('update lastName only', async () => {
        lastName = faker.name.lastName();
        const json = {
            "lastName": lastName
        };

        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${accessToken.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(firstName, json.lastName, originalData.email, originalData.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(originalData.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(originalData.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(json.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
    });

    test('update mobileNumber', async () => {
        mobileNumber = dataHelpers.generatePhoneNumber(true);
        const json = {
            "mobileNumber": mobileNumber
        };

        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${accessToken.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(firstName, lastName, originalData.email, mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(originalData.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
    });

    test('update email Address', async () => {
        email = `${faker.internet.userName()}@shoprite-testautomation.com`;
        const json = {
            "email": email
        };

        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${accessToken.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(firstName, lastName, email, mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
    });

    test('update firstName and lastName on cancelled customer(XSPlus consent false)', async () => {
        let firstNameOriginal = "Bridie";
        let firstName = faker.name.firstName();
        let lastNameOriginal = "Becker";
        let lastName = faker.name.lastName();
        let email = "Bridie-Becker@shoprite-testautomation.com";
        let mobileNumber = "+27889713871";
        const json = {
            "firstName": firstName,
            "lastName": lastName
        };
        let accessToken = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${accessToken.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(firstNameOriginal, lastNameOriginal, email, mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(firstNameOriginal).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(lastNameOriginal).toBe(cbCustomerResponse.list[0].customer.last_name);
    });

    test('reset firstName and lastName', async () => {
        const json = {
            "firstName": originalData.firstName,
            "lastName": originalData.lastName,
            "mobileNumber": originalData.mobileNumber,
            "email": originalData.email
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${accessToken.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(json.firstName, json.lastName, json.email, json.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(json.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(json.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(json.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(json.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
    });
});
