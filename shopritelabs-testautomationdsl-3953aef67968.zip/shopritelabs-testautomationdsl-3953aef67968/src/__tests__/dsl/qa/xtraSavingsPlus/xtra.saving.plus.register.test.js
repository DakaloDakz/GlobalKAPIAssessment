import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import DataHelpers from "../../../__utils__/data_helpers";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import XsplusData from "../../../__utils__/xtraSavingPlus/data/xsplus.data";
import XtraSavingsPlusCustomer from "../../../__utils__/xtraSavingPlus/lib/customer";
import ChargebeeCustomer from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.customer.sdk";
import ChargebeeSubscriptions from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.subscriptions.sdk";
import PaymentCards from "../../../__utils__/xtraSavingPlus/lib/paymentCardsQA";
import responseSchema from "../../../__utils__/xtraSavingPlus/schemas/register.schema.json";

jest.retryTimes(1);
describe.skip('DSL - XSPlus Register Customer Subscriptions(/xsplus/register)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const chargebeeCustomer = new ChargebeeCustomer();
    const chargebeeSubscription = new ChargebeeSubscriptions();
    const customerXtraSavingsPlus = new XtraSavingsPlusCustomer();
    const xsPlus = new XsplusData();
    const card = new PaymentCards();
    let customerNegativeTests;
    let customerVisa;
    let visa;
    let mastercard;
    let errorCard;
    let mastercardSeries2;
    let americanExpress;
    beforeAll(async () => {
        visa = await card.getVisaCard();
        // visa = "cus_NPNgnx8zKkA3nk/card_1MeYvJBgdHE1ezvrb5052U6m"
        mastercard = await card.getMasterCard();
        mastercardSeries2 = await card.getMasterSeries2Card();
        americanExpress = await card.getAmericanExpressCard();
        errorCard = await card.getErrorCard();
        customerNegativeTests = await customerXtraSavingsPlus.createCustomer(true);
    });

    test('valid subscription registration with Visa card', async () => {
        customerVisa = await customerXtraSavingsPlus.createCustomer(true);
        expect(customerVisa.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerVisa.uuid, customerVisa.email, customerVisa.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(customerVisa.uuid).toBe(data.response.uuid);
        expect(customerVisa.email).toBe(data.response.email);
        expect(customerVisa.firstName).toBe(data.response.firstName);
        expect(customerVisa.lastName).toBe(data.response.lastName);
        expect(customerVisa.mobileNumber).toBe(data.response.mobileNumber);
        expect(customerVisa.idNumber).toBe(data.response.saIdNumber);
        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "active",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "applyTill": expect.any(String),
                "couponId": "R50DISCOUNTCOUPON"
            }],
            "nextBillingAt": expect.any(String)
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            "consentTemplateVersion": "1",
            "updated": expect.any(String),
            "granted": true
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "firstName": customerVisa.firstName,
            "lastName": customerVisa.lastName,
            "mobileNumber": customerVisa.mobileNumber,
            "email": customerVisa.email
        });

        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customerVisa.firstName, customerVisa.lastName, customerVisa.email, customerVisa.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customerVisa.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customerVisa.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customerVisa.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customerVisa.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(cbCustomerResponse.list[0].customer.id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0].item_price_id).toBe('R149-plan-ZAR-Monthly');
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('active');
        expect(cbSubscriptionResponse.list[0].subscription.coupon).toBe('R50DISCOUNTCOUPON');
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0]).toMatchObject({
            "item_price_id": "R149-plan-ZAR-Monthly",
            "item_type": "plan",
            "quantity": 1,
            "unit_price": 14900,
            "amount": 14900,
            "free_quantity": 0,
            "object": "subscription_item"
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('valid subscription registration with customer already registered', async () => {
        expect(customerVisa.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerVisa.uuid, customerVisa.email, customerVisa.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        expect(data.exception).toBe(`id : The value ${customerVisa.uuid} is already present.`);
    });

    test('valid subscription registration with MasterCard card', async () => {
        let customer = await customerXtraSavingsPlus.createCustomer(true);
        await addMsg({message: JSON.stringify(customer, null, 2)});
        expect(customer.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, mastercard, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(customer.uuid).toBe(data.response.uuid);
        expect(customer.email).toBe(data.response.email);
        expect(customer.firstName).toBe(data.response.firstName);
        expect(customer.lastName).toBe(data.response.lastName);
        expect(customer.mobileNumber).toBe(data.response.mobileNumber);
        expect(customer.idNumber).toBe(data.response.saIdNumber);

        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "active",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "applyTill": expect.any(String),
                "couponId": "R50DISCOUNTCOUPON"
            }],
            "nextBillingAt": expect.any(String)
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            "consentTemplateVersion": "1",
            "updated": expect.any(String),
            "granted": true
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "firstName": customer.firstName,
            "lastName": customer.lastName,
            "mobileNumber": customer.mobileNumber,
            "email": customer.email
        });

        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(cbCustomerResponse.list[0].customer.id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0].item_price_id).toBe('R149-plan-ZAR-Monthly');
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('active');
        expect(cbSubscriptionResponse.list[0].subscription.coupon).toBe('R50DISCOUNTCOUPON');
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0]).toMatchObject({
            "item_price_id": "R149-plan-ZAR-Monthly",
            "item_type": "plan",
            "quantity": 1,
            "unit_price": 14900,
            "amount": 14900,
            "free_quantity": 0,
            "object": "subscription_item"
        });

        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('valid subscription registration with MasterCard Series 2 card', async () => {
        let customer = await customerXtraSavingsPlus.createCustomer(true);
        await addMsg({message: JSON.stringify(customer, null, 2)});
        expect(customer.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, mastercardSeries2, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(customer.uuid).toBe(data.response.uuid);
        expect(customer.email).toBe(data.response.email);
        expect(customer.firstName).toBe(data.response.firstName);
        expect(customer.lastName).toBe(data.response.lastName);
        expect(customer.mobileNumber).toBe(data.response.mobileNumber);
        expect(customer.idNumber).toBe(data.response.saIdNumber);

        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "active",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "applyTill": expect.any(String),
                "couponId": "R50DISCOUNTCOUPON"
            }],
            "nextBillingAt": expect.any(String)
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            "consentTemplateVersion": "1",
            "updated": expect.any(String),
            "granted": true
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "firstName": customer.firstName,
            "lastName": customer.lastName,
            "mobileNumber": customer.mobileNumber,
            "email": customer.email
        });

        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(cbCustomerResponse.list[0].customer.id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0].item_price_id).toBe('R149-plan-ZAR-Monthly');
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('active');
        expect(cbSubscriptionResponse.list[0].subscription.coupon).toBe('R50DISCOUNTCOUPON');
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0]).toMatchObject({
            "item_price_id": "R149-plan-ZAR-Monthly",
            "item_type": "plan",
            "quantity": 1,
            "unit_price": 14900,
            "amount": 14900,
            "free_quantity": 0,
            "object": "subscription_item"
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('valid subscription registration with American Express card', async () => {
        let customer = await customerXtraSavingsPlus.createCustomer(true);
        await addMsg({message: JSON.stringify(customer, null, 2)});
        expect(customer.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, americanExpress, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(customer.uuid).toBe(data.response.uuid);
        expect(customer.email).toBe(data.response.email);
        expect(customer.firstName).toBe(data.response.firstName);
        expect(customer.lastName).toBe(data.response.lastName);
        expect(customer.mobileNumber).toBe(data.response.mobileNumber);
        expect(customer.idNumber).toBe(data.response.saIdNumber);

        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "active",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "couponId": "R50DISCOUNTCOUPON"
            }],
            "nextBillingAt": expect.any(String)
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            "consentTemplateVersion": "1",
            "updated": expect.any(String),
            "granted": true
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "firstName": customer.firstName,
            "lastName": customer.lastName,
            "mobileNumber": customer.mobileNumber,
            "email": customer.email
        });

        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(cbCustomerResponse.list[0].customer.id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0].item_price_id).toBe('R149-plan-ZAR-Monthly');
        expect(cbSubscriptionResponse.list[0].subscription.status).toBe('active');
        expect(cbSubscriptionResponse.list[0].subscription.coupon).toBe('R50DISCOUNTCOUPON');
        expect(cbSubscriptionResponse.list[0].subscription.subscription_items[0]).toMatchObject({
            "item_price_id": "R149-plan-ZAR-Monthly",
            "item_type": "plan",
            "quantity": 1,
            "unit_price": 14900,
            "amount": 14900,
            "free_quantity": 0,
            "object": "subscription_item"
        });
        let isResponseValid = dataHelpers.validateSchema(responseSchema, response.data);
        if (!isResponseValid.success) {
            await addMsg({message: JSON.stringify(isResponseValid.errors, null, 2)});
            throw new Error(`Schema Validation Failed:\n${JSON.stringify(isResponseValid.errors, null, 2)}`);
        }
        expect(isResponseValid.success).toBe(true);
    });

    test('subscription registration with declined transaction and retry with different valid card', async () => {
        let customer = await customerXtraSavingsPlus.createCustomer(true);
        await addMsg({message: JSON.stringify(customer, null, 2)});
        expect(customer.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, errorCard, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let inputData1 = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const responseRetry = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData1, headers);
        await addMsg({message: JSON.stringify(responseRetry.data, null, 2)});
        expect(responseRetry.status).toBe(200);
        let {data} = responseRetry;
        expect(customer.uuid).toBe(data.response.uuid);
        expect(customer.email).toBe(data.response.email);
        expect(customer.firstName).toBe(data.response.firstName);
        expect(customer.lastName).toBe(data.response.lastName);
        expect(customer.mobileNumber).toBe(data.response.mobileNumber);
        expect(customer.idNumber).toBe(data.response.saIdNumber);

        expect(data.response.xtraSavingsPlus.subscriptions[0]).toMatchObject({
            "createdAt": expect.any(String),
            "subscriptionItems": [{
                "unitPrice": "149.00",
                "amount": "149.00",
                "itemPriceId": "R149-plan-ZAR-Monthly"
            }],
            "currentTermStart": expect.any(String),
            "currentTermEnd": expect.any(String),
            "subscriptionStatus": "active",
            "subscriptionId": expect.any(String),
            "couponItems": [{
                "applyTill": expect.any(String),
                "couponId": "R50DISCOUNTCOUPON"
            }],
            "nextBillingAt": expect.any(String)
        });
        expect(data.response.xtraSavingsPlus.consents[0]).toMatchObject({
            "consentTemplateId": "checkers-za-xtrasavingsplus-consent",
            "consentTemplateVersion": "1",
            "updated": expect.any(String),
            "granted": true
        });
        expect(data.response.xtraSavingsPlus.billingInformation).toMatchObject({
            "firstName": customer.firstName,
            "lastName": customer.lastName,
            "mobileNumber": customer.mobileNumber,
            "email": customer.email
        });
    });

    test('subscription registration with declined transaction and retry with same error card', async () => {
        let customer = await customerXtraSavingsPlus.createCustomer(true);
        let errorCard = await card.getErrorCard();
        await addMsg({message: JSON.stringify(customer, null, 2)});
        expect(customer.email).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, errorCard, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let errorCard1 = await card.getErrorCard();
        let inputData1 = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, errorCard1, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const responseRetry = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData1, headers);
        await addMsg({message: JSON.stringify(responseRetry.data, null, 2)});
        expect(responseRetry.status).toBe(400);
        let {data} = responseRetry;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('customer with no Loyalty Card', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription('04ffb40d-e531-422f-a304-a578284e747f', "test@test.com", "+27833937876", visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid UID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription('123456', customerNegativeTests.email, customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid EMAIL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, 'something.com', customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid MobileNumber', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, 'test', visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid Payment Card Token', async () => {
        await addMsg({message: JSON.stringify(customerNegativeTests, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, 'invalidToken', 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid Subscription Item ID', async () => {
        let customer = await customerXtraSavingsPlus.createCustomer(true);
        await addMsg({message: JSON.stringify(customer, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, visa, 'R149-plan-invalid', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('invalid Coupon ID', async () => {
        await addMsg({message: JSON.stringify(customerNegativeTests, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPONINVALID');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing UID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        inputData = dataHelpers.removeObjectInJson(inputData, 'uid');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing EMAIL', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, 'test@something.com', customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        inputData = dataHelpers.removeObjectInJson(inputData, 'email');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing MobileNumber', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, '+27836751520', visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        inputData = dataHelpers.removeObjectInJson(inputData, 'mobileNumber');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing Payment Card Token', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, 'invalidToken', 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        inputData = dataHelpers.removeObjectInJson(inputData, 'paymentCardToken');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing Subscription Item ID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, visa, 'R149-plan-invalid', 'R50DISCOUNTCOUPON');
        inputData = dataHelpers.removeObjectInJson(inputData, 'subscriptionItemId');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing Coupon ID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPONINVALID');
        inputData = dataHelpers.removeObjectInJson(inputData, 'couponId');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('subscription registration with Shoprite brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('subscription registration with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petShop/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('subscription registration with invalid country', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNegativeTests.uuid, customerNegativeTests.email, customerNegativeTests.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/bw/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('subscription registration with empty object', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {};
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('subscription registration with GET method', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(403);
    });
});
