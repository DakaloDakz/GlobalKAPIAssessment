import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import DataHelpers from "../../../__utils__/data_helpers";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import XsplusData from "../../../__utils__/xtraSavingPlus/data/xsplus.data";
import XtraSavingsPlusCustomer from "../../../__utils__/xtraSavingPlus/lib/customer";
import ChargebeeCustomer from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.customer.sdk";
import ChargebeeSubscriptions from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.subscriptions.sdk";
import PaymentCards from "../../../__utils__/xtraSavingPlus/lib/paymentCardsQA";

jest.retryTimes(1);
describe.skip('DSL - Reactivate Customer Subscriptions)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const chargebeeCustomer = new ChargebeeCustomer();
    const chargebeeSubscription = new ChargebeeSubscriptions();
    const customerXtraSavings = new XtraSavingsPlusCustomer();
    const xsPlus = new XsplusData();
    const card = new PaymentCards();
    let visa;
    let customer;
    let subscriptionID;
    beforeAll(async () => {
        visa = await card.getVisaCard();
        customer = await customerXtraSavings.createCustomer(true);
    });

    test('Create customer for adding valid subscription', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customer.uuid, customer.email, customer.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        subscriptionID = response.data.response.xtraSavingsPlus.subscriptions[0].subscriptionId;
    });

    test('Add valid subscription', async () => {
        let deleteSubscription = await chargebeeSubscription.cancelSubscription(subscriptionID);
        await addMsg({message: JSON.stringify(deleteSubscription, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions(`${customer.uuid}`, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add valid subscription to expired card', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions(`6faa99c2-3b58-4f89-8f71-52b4b6c34989`, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add invalid subscription with missing uid', async () => {
        let deleteSubscription = await chargebeeSubscription.cancelSubscription(subscriptionID);
        await addMsg({message: JSON.stringify(deleteSubscription, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions('R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add invalid subscription with missing subscriptionItemId', async () => {
        let deleteSubscription = await chargebeeSubscription.cancelSubscription(subscriptionID);
        await addMsg({message: JSON.stringify(deleteSubscription, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions(`${customer.uuid}`, 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add invalid subscription with missing couponId', async () => {
        let deleteSubscription = await chargebeeSubscription.cancelSubscription(subscriptionID);
        await addMsg({message: JSON.stringify(deleteSubscription, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions(`${customer.uuid}`, 'R149-plan-ZAR-Monthly');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add invalid subscription with empty payload', async () => {
        let deleteSubscription = await chargebeeSubscription.cancelSubscription(subscriptionID);
        await addMsg({message: JSON.stringify(deleteSubscription, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions('', '', '');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add valid subscription with customer having active subscription', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions('2f5074ff-838d-4f87-9400-9cb97823db35', 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add valid subscription with customer that does not exist', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions(`ef46f7cc-a8e4-4b2a-8c00-1a57fdc8f894`, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add valid subscription with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions('ba55d8f1-9a85-48fc-a1bc-c05143215ec0', 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/okfood/countries/za/xsplus/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Add valid subscription with invalid url', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.addSubscriptions('2f5074ff-838d-4f87-9400-9cb97823db7', 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xtra/add`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(403);
    });
});
