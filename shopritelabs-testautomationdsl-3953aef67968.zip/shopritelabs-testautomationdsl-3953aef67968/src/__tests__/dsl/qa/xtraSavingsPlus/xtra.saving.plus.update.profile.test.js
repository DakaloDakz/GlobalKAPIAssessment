import ApiMethodUtil from '../../../__utils__/api_method_util';
import XtraSavingsPlusCustomer from '../../../__utils__/xtraSavingPlus/lib/customer';
import ChargebeeCustomer from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.customer.sdk";
import ChargebeeSubscriptions from "../../../__utils__/xtraSavingPlus/lib/chargebee/chargebee.subscriptions.sdk";
import {addMsg} from "jest-html-reporters/helper";
import XsplusData from "../../../__utils__/xtraSavingPlus/data/xsplus.data";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../__utils__/data_helpers";
import PaymentCards from "../../../__utils__/xtraSavingPlus/lib/paymentCardsQA";

const dataHelpers = new DataHelpers();

jest.retryTimes(1);
describe.skip('DSL - XSPlus Update Customer Billing Information(/xsplus/billingInformation)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const card = new PaymentCards();
    const customerXtraSavings = new XtraSavingsPlusCustomer();
    const chargebeeCustomer = new ChargebeeCustomer();
    const chargebeeSubscription = new ChargebeeSubscriptions();
    const xsPlus = new XsplusData();
    let customerNew;
    let customer;
    let visa;
    let mastercard;
    let errorCard;

    beforeAll(async () => {
        visa = await card.getVisaCard();
        mastercard = await card.getMasterCard();
        errorCard = await card.getErrorCard();
        customerNew = await customerXtraSavings.createCustomer(true);
        expect(customerNew.uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = xsPlus.registerCustomerSubscription(customerNew.uuid, customerNew.email, customerNew.mobileNumber, visa, 'R149-plan-ZAR-Monthly', 'R50DISCOUNTCOUPON');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/register`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let subscription = {
            "subscriptionItemId": "R149-plan-ZAR-Monthly",
            "couponId": "R50DISCOUNTCOUPON"
        };
        customer = {...customerNew, ...subscription};
    });

    test('full update payload', async () => {
        await addMsg({message: JSON.stringify(customerNew, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let date = new Date();
        let termEndDate = new Date(date.getFullYear(), date.getMonth() + 1, 0).toISOString().slice(0, 10);
        let inputData = xsPlus.patchBillingInformation(customer.email, customer.mobileNumber, null, null);
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        let id = cbCustomerResponse.list[0].customer.id;
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        let termEndSubscription = new Date(cbSubscriptionResponse.list[0].subscription.next_billing_at * 1000).toISOString().slice(0, 10);
        let expectedDate = new Date();
        expectedDate = expectedDate.setMonth(expectedDate.getMonth() + 1);
        expect(termEndSubscription).toBe(new Date(expectedDate).toISOString().slice(0, 10));
        const responseGet = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=${customer.uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseGet.data, null, 2)});
        expect(responseGet.status).toBe(200);
        expect(termEndSubscription).toBe(responseGet.data.response.xtraSavingsPlus.subscriptions[0].nextBillingAt.slice(0, 10));
    });

    test('update email only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        customer.email = 'updatedEmail@testautomation.com';
        let inputData = {
            email: customer.email
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        let id = cbCustomerResponse.list[0].customer.id;
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
    });

    test('update with invalid email', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            email: 'updatedEmailtestautomation.com'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with empty email', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };

        let inputData = {
            email: ''
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update mobileNumber only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date().toISOString().slice(0, 10);
        customer.mobileNumber = dataHelpers.generatePhoneNumber(true);
        let inputData = {
            mobileNumber: customer.mobileNumber
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        let id = cbCustomerResponse.list[0].customer.id;
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
    });

    test('update with invalid mobileNumber', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date().toISOString().slice(0, 10);

        let inputData = {
            mobileNumber: '06477837658'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with empty mobileNumber', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date().toISOString().slice(0, 10);
        let inputData = {
            mobileNumber: ''
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update Payment Card only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            paymentCardToken: mastercard
        };
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await addMsg({message: JSON.stringify(customer, null, 2)});
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        let id = cbCustomerResponse.list[0].customer.id;
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        expect(mastercard).toBe(cbCustomerResponse.list[0].customer.payment_method.reference_id);
    });

    test('update Payment Card with insufficient funds', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            paymentCardToken: errorCard
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(customer.firstName, customer.lastName, customer.email, customer.mobileNumber);
        let id = cbCustomerResponse.list[0].customer.id;
        await addMsg({message: JSON.stringify(cbCustomerResponse, null, 2)});
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect(customer.mobileNumber).toBe(cbCustomerResponse.list[0].customer.phone);
        expect(customer.email).toBe(cbCustomerResponse.list[0].customer.email);
        expect(customer.firstName).toBe(cbCustomerResponse.list[0].customer.first_name);
        expect(customer.lastName).toBe(cbCustomerResponse.list[0].customer.last_name);
        expect(errorCard).toContain(cbCustomerResponse.list[0].customer.payment_method.reference_id);
    });

    test('update with invalid Payment Card', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date().toISOString().slice(0, 10);
        let inputData = {
            paymentCardToken: 'abdchkkhksfkhfkfkk'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with empty Payment Card', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date().toISOString().slice(0, 10);
        let inputData = {
            paymentCardToken: ''
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update Term End Date with customers current Renewal Date', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date();
        let inputData = {
            termEndDate: new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(411);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update Term End Date only', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date();
        currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 28);
        let inputData = {
            termEndDate: currentDate.toISOString().slice(0, 10)
        };
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(411);
    });

    test('update with invalid Term End Date', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            termEndDate: 'abcd'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with invalid Term End Date - YYYYMMDD', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date().toISOString().slice(0, 10).replace('-', '');
        let inputData = {
            termEndDate: currentDate
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with invalid Term End Date - DD/MM/YYYY', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            termEndDate: new Date().toLocaleDateString()
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with empty Term End Date', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            termEndDate: null
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with Term End Date 10 years in the future', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            termEndDate: '2033-11-10'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with empty object', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {};
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with Shoprite brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            email: 'updatedEmail@testautomation.com'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            email: 'updatedEmail@testautomation.com'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/petShop/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with invalid countryCode', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            email: 'updatedEmail@testautomation.com'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with no UID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            email: 'updatedEmail@testautomation.com'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/xsplus/billingInformation`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with invalid UID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            email: 'updatedEmail@testautomation.com'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=122947578`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update with UID not in chargebee', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let inputData = {
            email: 'updatedEmail@testautomation.com'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=bf288b98-6d9f-4209-9016-df9d94824b25`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(404);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    /*********************************************************************************************************************************************************/
    /*BILLING DATE UPDATE TESTS*/
    test('update Term End Date within first billing period', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date();
        currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 28);
        let inputData = {
            termEndDate: currentDate.toISOString().slice(0, 10)
        };
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${customer.uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(411);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('update Term End Date after first billing period', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let currentDate = new Date();
        currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 28);
        let inputData = {
            termEndDate: currentDate.toISOString().slice(0, 10)
        };
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=7df0be62-896c-4837-a8c6-7852acbb57a3`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(412);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('EndTerm updates minus', async () => {
        let date = new Date();
        let metaDate = new Date(date.getFullYear(), date.getMonth() - 3, 0).toISOString().slice(0, 10);
        let updateMetaData = await chargebeeSubscription.updateSubscriptionMetaData('169ltWTYjtePJ5lZ', "{\"BillingDateChanged\":\"" + metaDate + "\"}");
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const rndInt = dataHelpers.generateRandomNumber(1, 6);
        let termEndDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate() - rndInt).toISOString().slice(0, 10);
        let inputData = xsPlus.patchBillingInformation('Odie-Marquardt@shoprite-testautomation.com', '+27894740319', null, termEndDate);
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=c524c347-ddf4-45bf-81a3-48ac55a4cd9b`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer('Odie', 'Marquardt', 'Odie-Marquardt@shoprite-testautomation.com', '+27894740319');
        let id = cbCustomerResponse.list[0].customer.id;
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect('+27894740319').toBe(cbCustomerResponse.list[0].customer.phone);
        expect('Odie-Marquardt@shoprite-testautomation.com').toBe(cbCustomerResponse.list[0].customer.email);
        expect('Odie').toBe(cbCustomerResponse.list[0].customer.first_name);
        expect('Marquardt').toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        let termEndSubscription = new Date(cbSubscriptionResponse.list[0].subscription.next_billing_at * 1000).toISOString().slice(0, 10);
        let expectedDate = new Date(termEndDate).setMonth(date.getMonth() + 2);
        expect(termEndSubscription).toBe(new Date(expectedDate).toISOString().slice(0, 10));
        const responseGet = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=c524c347-ddf4-45bf-81a3-48ac55a4cd9b`, headers, null);
        await addMsg({message: JSON.stringify(responseGet.data, null, 2)});
        expect(responseGet.status).toBe(200);
        expect(termEndSubscription).toBe(responseGet.data.response.xtraSavingsPlus.subscriptions[0].nextBillingAt.slice(0, 10));
    });

    test('EndTerm updates plus', async () => {
        let date = new Date();
        let metaDate = new Date(date.getFullYear(), date.getMonth() - 3, 0).toISOString().slice(0, 10);
        let updateMetaData = await chargebeeSubscription.updateSubscriptionMetaData('169ltWTYjtcWM5kC', "{\"BillingDateChanged\":\"" + metaDate + "\"}");
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const rndInt = dataHelpers.generateRandomNumber(1, 6);
        let termEndDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate() + rndInt).toISOString().slice(0, 10);
        let inputData = xsPlus.patchBillingInformation('Keely-Koelpin@shoprite-testautomation.com', '+27812891690', null, termEndDate);
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=7df0be62-896c-4837-a8c6-7852acbb57a3`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer('Keely', 'Koelpin', 'Keely-Koelpin@shoprite-testautomation.com', '+27812891690');
        let id = cbCustomerResponse.list[0].customer.id;
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        expect('+27812891690').toBe(cbCustomerResponse.list[0].customer.phone);
        expect('Keely-Koelpin@shoprite-testautomation.com').toBe(cbCustomerResponse.list[0].customer.email);
        expect('Keely').toBe(cbCustomerResponse.list[0].customer.first_name);
        expect('Koelpin').toBe(cbCustomerResponse.list[0].customer.last_name);
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        let termEndSubscription = new Date(cbSubscriptionResponse.list[0].subscription.next_billing_at * 1000).toISOString().slice(0, 10);
        let expectedDate = new Date(termEndDate).setMonth(date.getMonth() + 2);
        expect(termEndSubscription).toBe(new Date(expectedDate).toISOString().slice(0, 10));
        const responseGet = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=7df0be62-896c-4837-a8c6-7852acbb57a3`, headers, null);
        await addMsg({message: JSON.stringify(responseGet.data, null, 2)});
        expect(responseGet.status).toBe(200);
        expect(termEndSubscription).toBe(responseGet.data.response.xtraSavingsPlus.subscriptions[0].nextBillingAt.slice(0, 10));
    });

    test('EndTerm updates current month before next billing cycle', async () => {
        let subscriptionId = 'AzZiz7TYjtXQA4ekO';
        let email = 'Trenton-Marks@shoprite-testautomation.com';
        let mobileNumber = '+27896217313';
        let firstName = 'Trenton';
        let lastName = 'Marks';
        let uuid = 'c110053e-9fc8-4a02-a83a-0a5baa82b287';
        let date = new Date();
        let metaDate = new Date(date.getFullYear(), date.getMonth() - 3, date.getDate()).toISOString().slice(0, 10);
        let originalEpoch = Math.floor(new Date(date.getFullYear(), date.getMonth() + 1, date.getDate() + 1).getTime() / 1000.0);
        let updateMetaData = await chargebeeSubscription.updateSubscriptionMetaData(subscriptionId, "{\"BillingDateChanged\":\"" + metaDate + "\"}");
        let updateTermEnd = await chargebeeSubscription.updateSubscriptionTermEnd(subscriptionId, originalEpoch);
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const rndInt = dataHelpers.generateRandomNumber(1, 6);
        let termEndDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate() - 3).toISOString().slice(0, 10);
        let inputData = xsPlus.patchBillingInformation(email, mobileNumber, null, termEndDate);
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(firstName, lastName, email, mobileNumber);
        let id = cbCustomerResponse.list[0].customer.id;
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        let termEndSubscription = new Date(cbSubscriptionResponse.list[0].subscription.next_billing_at * 1000).toISOString().slice(0, 10);
        let expectedDate = new Date(termEndDate).setMonth(date.getMonth() + 2);
        expect(termEndSubscription).toBe(new Date(expectedDate).toISOString().slice(0, 10));
        const responseGet = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=${uuid}`, headers, null);
        await addMsg({
            message: JSON.stringify({
                "original": new Date(originalEpoch * 1000).toISOString().slice(0, 10),
                "setValue": termEndDate,
                "billingDate": termEndSubscription
            }, null, 2)
        });
        expect(responseGet.status).toBe(200);
        expect(termEndSubscription).toBe(responseGet.data.response.xtraSavingsPlus.subscriptions[0].nextBillingAt.slice(0, 10));
    });

    test('EndTerm updates current month after next billing cycle', async () => {
        let subscriptionId = 'AzZiz7TYjtXQA4ekO';
        let email = 'Trenton-Marks@shoprite-testautomation.com';
        let mobileNumber = '+27896217313';
        let firstName = 'Trenton';
        let lastName = 'Marks';
        let uuid = 'c110053e-9fc8-4a02-a83a-0a5baa82b287';
        let date = new Date();
        let metaDate = new Date(date.getFullYear(), date.getMonth() - 3, date.getDate()).toISOString().slice(0, 10);
        let originalEpoch = Math.floor(new Date(date.getFullYear(), date.getMonth() + 1, date.getDate() + 1).getTime() / 1000.0);
        let updateMetaData = await chargebeeSubscription.updateSubscriptionMetaData(subscriptionId, "{\"BillingDateChanged\":\"" + metaDate + "\"}");
        let updateTermEnd = await chargebeeSubscription.updateSubscriptionTermEnd(subscriptionId, originalEpoch);
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const rndInt = dataHelpers.generateRandomNumber(1, 6);
        let termEndDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate() + 3).toISOString().slice(0, 10);
        let inputData = xsPlus.patchBillingInformation(email, mobileNumber, null, termEndDate);
        await addMsg({message: JSON.stringify(inputData, null, 2)});
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/billingInformation?uid=${uuid}`, inputData, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let cbCustomerResponse = await chargebeeCustomer.getCustomer(firstName, lastName, email, mobileNumber);
        let id = cbCustomerResponse.list[0].customer.id;
        expect(cbCustomerResponse.list[0].customer.id).toBeDefined();
        let cbSubscriptionResponse = await chargebeeSubscription.getCustomerSubscriptions(id);
        await addMsg({message: JSON.stringify(cbSubscriptionResponse, null, 2)});
        let termEndSubscription = new Date(cbSubscriptionResponse.list[0].subscription.next_billing_at * 1000).toISOString().slice(0, 10);
        let expectedDate = new Date(termEndDate).setMonth(date.getMonth() + 1);
        expect(termEndSubscription).toBe(new Date(expectedDate).toISOString().slice(0, 10));
        const responseGet = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/xsplus/profile?uid=${uuid}`, headers, null);
        await addMsg({
            message: JSON.stringify({
                "original": new Date(originalEpoch * 1000).toISOString().slice(0, 10),
                "setValue": termEndDate,
                "billingDate": termEndSubscription
            }, null, 2)
        });
        expect(responseGet.status).toBe(200);
        expect(termEndSubscription).toBe(responseGet.data.response.xtraSavingsPlus.subscriptions[0].nextBillingAt.slice(0, 10));
    });
});

