import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';

describe('DSL - Get Stores (/stores)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    let access;

    beforeAll(async () => {

    });

    test('all stores', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.stores.length).toBeGreaterThan(0);
    });

    test('using geopoint', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`});

        let params = {
            geopoint: '33.8854048,18.6796247',
            radius: 1000,
            currentPage: 0,
            pageSize: 0
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('using query', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`});

        let params = {query: '7130'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data.response.stores.length).toBeGreaterThan(0);
    });

    test('using invalid query', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`});

        let params = {query: '12345'};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('using invalid geopoint', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`});

        let params = {
            geopoint: 'abc',
            radius: 1000,
            currentPage: 0,
            pageSize: 0
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('using empty geopoint', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`});

        let params = {
            geopoint: '',
            radius: 1000,
            currentPage: 0,
            pageSize: 0
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('using identifier - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores/31398`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores/31398`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('using identifier - shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores/1006`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/stores/1006`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('using invalid identifier', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores/31300`});

        let params = {
            geopoint: '',
            radius: 1000,
            currentPage: 0,
            pageSize: 0
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/stores/31300`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('using invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/stores`});

        let params = {
            geopoint: '33.8854048,18.6796247',
            radius: 1000,
            currentPage: 0,
            pageSize: 0
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/stores`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('using invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/stores`});

        let params = {
            geopoint: '33.8854048,18.6796247',
            radius: 1000,
            currentPage: 0,
            pageSize: 0
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/uk/stores`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
