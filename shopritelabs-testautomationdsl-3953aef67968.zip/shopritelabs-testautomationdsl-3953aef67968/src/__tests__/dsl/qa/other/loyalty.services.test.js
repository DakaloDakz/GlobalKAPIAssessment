import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import Authentication from "../../../__utils__/auth/dsl/auth.methods";
import ValueAddedServices from "../../data/value.added.services.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - Loyalty Services(/loyaltyservices)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const vas = new ValueAddedServices();
    const ciamAuth = new CIAMAuth();
    let access;

    beforeAll(async () => {

    });

    test('LoyaltyServices update Lname and Fname', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "ShakaUpdated",
                "lastName": "KhozaUpdated",
                "mobileNumber": "+27717850087"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices/SwipeForCover?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices for customer after PUT', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.details[0].updatedDate']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices update with brand checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "ShakaUpdated",
                "lastName": "KhozaUpdated",
                "mobileNumber": "+27717850087"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loyaltyservices/SwipeForCover?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices revert back Lname and Fname', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Shaka",
                "lastName": "Khoza",
                "mobileNumber": "+27717850087"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices/SwipeForCover?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices for customer after PUT revert', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.details[0].updatedDate']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices invalid customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Dakalo",
                "lastName": "Nduo",
                "mobileNumber": "+27647572677"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices/SwipeForCover?uid=dakalo.ndou`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(404);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices with no UID', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Dakalo",
                "lastName": "Nduo",
                "mobileNumber": "+27647572677"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/loyaltyservices/SwipeForCover`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices for customer with checkers brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/loyaltyservices?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.details[0].updatedDate']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices put with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Dakalo",
                "lastName": "Nduo",
                "mobileNumber": "+27647572677"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/loyaltyservices/SwipeForCover?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('LoyaltyServices put with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/loyaltyservices`});
        let json = {
            "details": {
                "firstName": "Dakalo",
                "lastName": "Nduo",
                "mobileNumber": "+27647572677"
            }
        };
        const response = await apiCall.PUT(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/loyaltyservices/SwipeForCover?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices with invalid brand', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/usave/countries/za/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/usave/countries/za/loyaltyservices?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get LoyaltyServices with invalid country code', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/loyaltyservices`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/uk/loyaltyservices?uid=07a96d9d-bb74-4d18-8aae-0460ca167471`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
