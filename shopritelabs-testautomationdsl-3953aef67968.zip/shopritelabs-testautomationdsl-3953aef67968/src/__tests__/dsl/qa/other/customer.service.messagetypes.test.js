import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DSLServiceTicket from "../../data/service.ticket.data";

describe('DSL - Create Authenticated Customer Service Ticket (/dsl/customerservices/servicetickets@email/servicetickets)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const ticket = new DSLServiceTicket();
    let access;

    beforeAll(async () => {

    });

    test('valid Sixty60 ticket', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMC4CNewApikey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/messagetypes`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/customerservices/messagetypes`, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.referenceNumber']);
        //expect(data).toMatchSnapshot();
    });

    test('with invalid token', async () => {
        await addMsg({message: `${process.env.DSLGroup}/dsl/customerservices/messagetypes`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/customerservices/messagetypes`);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        //expect(data).toMatchSnapshot();
    });
});
