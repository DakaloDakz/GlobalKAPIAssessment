import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - GET on /savings/auth', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    let access;

    beforeAll(async () => {

    });

    test('get valid auth', async () => {
        const headers = {
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/savings/auth`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/savings/auth`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
    });
});