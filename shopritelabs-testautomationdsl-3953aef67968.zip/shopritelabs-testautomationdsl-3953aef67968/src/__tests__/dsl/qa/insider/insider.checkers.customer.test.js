import InsiderApi from '../../../__utils__/insider.api.integration';
import DataHelpers from "../../../__utils__/data_helpers";
import DSLCustomer from "../../data/customer.data";
import ApiMethodUtil from "../../../__utils__/api_method_util";
import chalk from "chalk";
import _ from "lodash";
import DSLConsent from "../../data/consents.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import CiamCustomerConsents from "../../../ciam/qa/data/consents.data";
import CardService from "../../../__utils__/cards/cardService";
import fakeSaIdGenerator from "south-african-fake-id-generator";
import CiamCustomerPreferences from "../../../ciam/qa/data/preferences.data";

const {faker} = require("@faker-js/faker");
const {addMsg} = require("jest-html-reporters/helper");

describe.skip('Insider API Tests - Checkers', () => {
    let email;
    let mobileNumber;
    let firstName;
    let lastName;
    let dob;
    let cardNumber;
    let idNumber;
    let uuid;
    let newEmail;
    let newFirstName;
    let newLastName;
    let newMobileNumber;

    let dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const apiCall = new ApiMethodUtil();
    const insiderCheckersApi = new InsiderApi('checkers');
    const insiderShopriteApi = new InsiderApi('shoprite');
    const dSLConsent = new DSLConsent();
    const ciamAuth = new CIAMAuth();
    const consent = new CiamCustomerConsents();
    const cardService = new CardService();
    const auth = new Authentication();
    const preferences = new CiamCustomerPreferences();
    let headers;
    let gender;

    beforeAll(() => {
        headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
    });

    test('create customer via DSL /partialuser endpoint', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        cardNumber = json.foxCard.cardNumber;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        uuid = response.data.response.uuid;

        await new Promise(resolve => {
            console.log(chalk.redBright(`Waiting for 10s to allow Insider to process the request!`));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.events.rewards_card_registered === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });

            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.status).toBe(200);
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(firstName);
        expect(insiderResponse.data.attributes.surname).toBe(lastName);
        expect(insiderResponse.data.attributes.birthday).toBe(`${dob}T00:00:00Z`);
        expect(insiderResponse.data.attributes.gender).toBe(gender);
        expect(insiderResponse.data.attributes.language).toBe('EN_ZA');
        expect(insiderResponse.data.attributes.country).toBe('ZA');
        expect(insiderResponse.data.attributes.email_optin).toBe(false);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.gdpr).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
        expect(insiderResponse.data.attributes.unique_user_id).toBe(uuid);
        expect(insiderResponse.data.attributes.c_idenfication_number).toBe(idNumber);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(cardNumber);
        expect(insiderResponse.data.events.user_created).toBeDefined();
        expect(insiderResponse.data.events.rewards_card_registered).toBeDefined();
    });

    test('create customer via DSL /partialuser endpoint with no email address', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        let firstName = json.userDetails.firstName;
        let lastName = json.userDetails.lastName;
        let dob = json.userDetails.birthDate.split('/').reverse().join('-');
        let mobileNumber = json.contactDetails[0].value;
        let cardNumber = json.foxCard.cardNumber;
        let idNumber = json.identity[0].value;
        let gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let uuid = response.data.response.uuid;

        await new Promise(resolve => {
            console.log(chalk.redBright(`Waiting for 10s to allow Insider to process the request!`));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_rewards_card_number === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.status).toBe(200);
        expect(insiderResponse.data.attributes.email).toBeUndefined();
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(firstName);
        expect(insiderResponse.data.attributes.surname).toBe(lastName);
        expect(insiderResponse.data.attributes.birthday).toBe(`${dob}T00:00:00Z`);
        expect(insiderResponse.data.attributes.gender).toBe(gender);
        expect(insiderResponse.data.attributes.language).toBe('EN_ZA');
        expect(insiderResponse.data.attributes.country).toBe('ZA');
        expect(insiderResponse.data.attributes.email_optin).toBe(false);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.gdpr).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
        expect(insiderResponse.data.attributes.unique_user_id).toBe(uuid);
        expect(insiderResponse.data.attributes.c_idenfication_number).toBe(idNumber);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(cardNumber);
        expect(insiderResponse.data.events.user_created).toBeDefined();
        expect(insiderResponse.data.events.rewards_card_registered).toBeDefined();
    });

    test('add a Shoprite xtraSavings Card', async () => {
        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_rewards_card_number === undefined || insiderResponse.data.events.rewards_card_registered === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(firstName);
        expect(insiderResponse.data.attributes.surname).toBe(lastName);
        expect(insiderResponse.data.attributes.birthday).toBe(`${dob}T00:00:00Z`);
        expect(insiderResponse.data.attributes.gender).toBe(gender);
        expect(insiderResponse.data.attributes.language).toBe('EN_ZA');
        expect(insiderResponse.data.attributes.country).toBe('ZA');
        expect(insiderResponse.data.attributes.email_optin).toBe(false);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.gdpr).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
        expect(insiderResponse.data.attributes.unique_user_id).toBe(uuid);
        expect(insiderResponse.data.attributes.c_idenfication_number).toBe(idNumber);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(newCardSH);
        expect(insiderResponse.data.events.user_created).toBeDefined();
        expect(insiderResponse.data.events.rewards_card_registered).toBeDefined();
    });

    test('add checkers rewards and marketing consent', async () => {
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.MARKETING_CONSENT,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        // expect(insiderResponse.data.attributes.c_marketing_consent[0]).toBe('Xtra Savings');
        // expect(insiderResponse.data.attributes.c_terms_and_conditions_accepted[0]).toBe('Xtra Savings');
        // expect(insiderResponse.data.events.marketing_consent_updated).toBeDefined();
    });

    test('add contact preferences', async () => {
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": true
            },
            {
                "code": "sms",
                "active": false
            },
            {
                "code": "mobileApp",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
    });

    test('add Money Market contact preferences', async () => {
        const headersMoneyMarket = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.byteOrbitCiamApiKey,
            'Content-Type': 'application/json'
        };

        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": true
            },
            {
                "code": "sms",
                "active": false
            },
            {
                "code": "mobileApp",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headersMoneyMarket);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.email_optin !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
    });

    test('add Sixty60 preferences', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {
            "contactPreferences": [
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "EMAIL",
                    "addressValue": "test@test.com",
                    "granted": true
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "SMS",
                    "addressValue": "+27833965802",
                    "granted": false
                },
                {
                    "retailService": "Sixty60",
                    "contactPreferenceRole": "WHATSAPP",
                    "addressValue": "+27833965802",
                    "granted": false
                }
            ]
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.sms.addressValue).toBe('+27833965802');
    });

    test(`add sfgFoodAndTreesForAfrica and sfgLunchboxFund to customer`, async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "name": "sfgFoodAndTreesForAfrica",
                "active": true
            },
            {
                "name": "sfgLunchboxFund",
                "active": true
            },
            {
                "name": "sfgSPCA",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_swipe_for_good_lunchbox_fund !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_swipe_for_good_lunchbox_fund).toBe(true);
        expect(insiderResponse.data.attributes.c_swipe_for_good_food_trees).toBe(true);
    });

    test('update customer details mobileNumber, firstName and lastName', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        newFirstName = faker.name.firstName();
        newLastName = faker.name.lastName();
        newMobileNumber = dataHelpers.generatePhoneNumber();
        const json = {
            "firstName": newFirstName,
            "lastName": newLastName,
            "mobileNumber": newMobileNumber,
            "email": email
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright(`Waiting for 10s to allow Insider to process the request!`));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "benefit_name",
                        "event_params",
                        "timestamp"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.phone_number !== newMobileNumber || insiderResponse.data.attributes.name !== newFirstName) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(newFirstName);
        expect(insiderResponse.data.attributes.surname).toBe(newLastName);
    });

    test('update customer email', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        newEmail = `${newFirstName}-${newLastName}@dsl-insider.automation.com`;
        const json = {
            "email": newEmail
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email !== newEmail.toLowerCase()) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.name).toBe(newFirstName);
        expect(insiderResponse.data.attributes.surname).toBe(newLastName);
    });

    test('add Money Market consents - Checkers', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'MoneyMarketAccount marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        await addMsg({message: JSON.stringify(response.data, null, 2)});

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.MARKETING_CONSENT,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_terms_and_conditions_accepted === undefined || !insiderResponse.data.attributes.c_terms_and_conditions_accepted.includes('Money Market')) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_money_market_wallet).toBe(true);
    });

    test('add Money Market consents - Shoprite', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'MoneyMarketAccount marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/shoprite/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        await addMsg({message: JSON.stringify(response.data, null, 2)});

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderShopriteApi.ciamEvents.MARKETING_CONSENT,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_terms_and_conditions_accepted === undefined || !insiderResponse.data.attributes.c_terms_and_conditions_accepted.includes('Money Market')) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(false);
        expect(insiderResponse.data.attributes.c_money_market_wallet).toBe(true);
    });

    test('add consent - LiquorShop Checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('liquorshop-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('liquorshop-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('add consent - LiquorShop Shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('liquorshop-za-termsandconditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('liquorshop-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('set all checkers xtraSavings contact preferences to false', async () => {
        let json = [
            {
                "code": "email",
                "active": false
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": false
            },
            {
                "code": "mobileApp",
                "active": false
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email_optin !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
    });

    test('add contact preferences - LiquorShop Checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": true
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email_optin !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(true);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
    });

    test('add contact preferences - LiquorShop Shoprite', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.ecommerceLiquorshopApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": true
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email_optin !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(true);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(true);
    });

    test('stop card - checkers', async () => {
        let tokenCH = await ciamAuth.ciam_trusted_auth(process.env.CIAM, newMobileNumber, 'dsl');

        const headers = {
            'access_token': `${tokenCH.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": cardNumber
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/stop`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/stop`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_CANCELLED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_rewards_card_number.length !== 0) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.status).toBe(200);
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.email_optin).toBe(true);
        expect(insiderResponse.data.attributes.sms_optin).toBe(false);
        expect(insiderResponse.data.attributes.whatsapp_optin).toBe(false);
    });

    test(`remove sfgFoodAndTreesForAfrica and sfgLunchboxFund to customer`, async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "name": "sfgFoodAndTreesForAfrica",
                "active": false
            },
            {
                "name": "sfgLunchboxFund",
                "active": false
            },
            {
                "name": "sfgSPCA",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_swipe_for_good_lunchbox_fund !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_swipe_for_good_lunchbox_fund).toBe(false);
        expect(insiderResponse.data.attributes.c_swipe_for_good_food_trees).toBe(false);
    });

    test('add digitalCard to customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "digitalCard": true
        };
        await addMsg({message: `${JSON.stringify(json, null, 2)}`});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card/digital?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_rewards_card_number[0] === cardNumber) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).not.toBe(cardNumber);
    });

    test(`add srSwipeForCover,sfgFoodAndTreesForAfrica and sfgLunchboxFund to customer - Shoprite`, async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "name": "srSwipeForCover",
                "active": true
            },
            {
                "name": "sfgFoodAndTreesForAfrica",
                "active": true
            },
            {
                "name": "sfgLunchboxFund",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.BENEFITS_UPDATED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_swipe_for_cover === false || insiderResponse.data.attributes.c_swipe_for_cover === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(false);
        expect(insiderResponse.data.attributes.c_swipe_for_cover).toBe(true);
        expect(insiderResponse.data.attributes.c_swipe_for_good_lunchbox_fund).toBe(false);
        expect(insiderResponse.data.attributes.c_swipe_for_good_food_trees).toBe(false);
    });

    test('with updated ID Number', async () => {
        let token = await auth.ciamASMCognitoAuth(process.env.DSLGroup);
        token = await token.data.access_token;
        let newIdNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        const json = {
            "saIdNumber": newIdNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        await new Promise(resolve => {
            console.log(chalk.redBright(`Waiting for 10s to allow Insider to process the request!`));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.status !== 200 || insiderResponse.data.attributes.c_idenfication_number !== newIdNumber) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });

            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.status).toBe(200);
        expect(insiderResponse.data.attributes.unique_user_id).toBe(uuid);
        expect(insiderResponse.data.attributes.c_idenfication_number).toBe(newIdNumber);
    });

    test('with updated Passport Number and Date of Birth', async () => {
        let token = await auth.ciamASMCognitoAuth(process.env.DSLGroup);
        token = await token.data.access_token;
        let passport = faker.internet.password(15, false, /[0-9A-Z]/);
        const json = {
            "passportNumber": passport,
            "birthDate": '31/12/1975'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.ASMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();

        await new Promise(resolve => {
            console.log(chalk.redBright(`Waiting for 10s to allow Insider to process the request!`));
            setTimeout(resolve, 10000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderCheckersApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.status !== 200 || insiderResponse.data.attributes.c_passport_number !== passport) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });

            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.status).toBe(200);
        expect(insiderResponse.data.attributes.unique_user_id).toBe(uuid);
        expect(insiderResponse.data.attributes.c_passport_number).toBe(passport);
    });

    test('remove Money Market consents - Checkers', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'MoneyMarketAccount marketing consent', false);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        await addMsg({message: JSON.stringify(response.data, null, 2)});

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderCheckersApi.ciamEvents.MARKETING_CONSENT,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_money_market_wallet !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_money_market_wallet).toBe(false);
    });

    test('remove Money Market consents - Shoprite', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'MoneyMarketAccount marketing consent', false);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/shoprite/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        await addMsg({message: JSON.stringify(response.data, null, 2)});

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 10s to allow Insider to process the request!'));
            setTimeout(resolve, 10000);
        });

        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderShopriteApi.ciamEvents.MARKETING_CONSENT,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.c_money_market_wallet !== false) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelper.generateRandomNumber(2, 1, 10);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 1000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 4);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(newEmail.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(newMobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(false);
        expect(insiderResponse.data.attributes.c_money_market_wallet).toBe(false);
    });
});
