import InsiderApi from '../../../__utils__/insider.api.integration';
import ApiMethodUtil from "../../../__utils__/api_method_util";
import chalk from "chalk";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../__utils__/data_helpers";

const {faker} = require("@faker-js/faker");
const {addMsg} = require("jest-html-reporters/helper");

describe.skip('Insider Webhook to CIAM Tests - PetShopScience', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelper = new DataHelpers();
    const insiderPetShopApi = new InsiderApi('petshop');
    const ciamAuth = new CIAMAuth();
    let uuid = '5b833088-223b-49d7-bc4b-6d3d63baf15e';
    let email = 'missouri-batz@dsl-insider.automation.com';
    let accessTokenPetShop;

    beforeAll(async () => {
        accessTokenPetShop = await ciamAuth.petShopScienceCognitoAuth(process.env.CIAM);
        accessTokenPetShop = accessTokenPetShop.data.access_token;
    });

    test('set sms_optin, email_optin and whatsapp_optin to true', async () => {
        let data = JSON.stringify({
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "sms_optin": true,
                        "email_optin": true,
                        "whatsapp_optin": true
                    }
                }
            ]
        });
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderPetShopApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }
    });

    test('set sms_optin, email_optin and whatsapp_optin to false', async () => {
        let data = JSON.stringify({
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "sms_optin": false,
                        "email_optin": false,
                        "whatsapp_optin": false
                    }
                }
            ]
        });
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderPetShopApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }
    });

    test('set email_optin = true', async () => {
        let data = JSON.stringify({
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "email_optin": true
                    }
                }
            ]
        });
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderPetShopApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }
    });

    test('set sms_optin = true', async () => {
        let data = JSON.stringify({
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "sms_optin": true
                    }
                }
            ]
        });
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderPetShopApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }
    });

    test('set whatsapp_optin = true', async () => {
        let data = JSON.stringify({
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "whatsapp_optin": true
                    }
                }
            ]
        });
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderPetShopApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }
    });

    test('set email_optin = false', async () => {
        let data = JSON.stringify({
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "email_optin": false
                    }
                }
            ]
        });
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderPetShopApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
        }
    });

    test('set sms_optin = false', async () => {
        let data = JSON.stringify({
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "sms_optin": false
                    }
                }
            ]
        });
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderPetShopApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(true);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }
    });

    test('set whatsapp_optin = false', async () => {
        let data = JSON.stringify({
            "users": [
                {
                    "identifiers": {
                        "uuid": uuid,
                        "email": email
                    },
                    "attributes": {
                        "whatsapp_optin": false
                    }
                }
            ]
        });
        await addMsg({message: JSON.stringify(data, null, 2)});
        const response = await insiderPetShopApi.upsertCustomer(uuid, data);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            let waitPeriod = dataHelper.generateRandomNumber(2, 30, 60);
            console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
            setTimeout(resolve, waitPeriod * 1000);
        });

        const headers = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        const responseContactPreferences = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(responseContactPreferences.data, null, 2)});
        expect(responseContactPreferences.status).toBe(200);
        for (let i = 0; i < responseContactPreferences.data.response.contactPreferences.length; i++) {
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'WHATSAPP') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'EMAIL') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
            if (responseContactPreferences.data.response.contactPreferences[i].code === 'SMS') {
                expect(responseContactPreferences.data.response.contactPreferences[i].active).toBe(false);
            }
        }
    });
});
