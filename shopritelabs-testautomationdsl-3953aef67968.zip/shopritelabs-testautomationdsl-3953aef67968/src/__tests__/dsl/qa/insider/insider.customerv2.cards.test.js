import InsiderApi from '../../../__utils__/insider.api.integration';
import DataHelpers from "../../../__utils__/data_helpers";
import DSLCustomer from "../../data/customer.data";
import ApiMethodUtil from "../../../__utils__/api_method_util";
import chalk from "chalk";
import _ from "lodash";
import DSLConsent from "../../data/consents.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import CiamCustomerConsents from "../../../ciam/qa/data/consents.data";
import CardService from "../../../__utils__/cards/cardService";

const {faker} = require("@faker-js/faker");
const {addMsg} = require("jest-html-reporters/helper");

// jest.retryTimes(1);
describe.skip('Insider API Tests - PetShopScience', () => {
    let email;
    let mobileNumber;
    let firstName;
    let lastName;
    let dob;
    let cardNumber;
    let idNumber;
    let uuid;

    let dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const apiCall = new ApiMethodUtil();
    const insiderPetShopApi = new InsiderApi('petshop');
    const insiderCheckersApi = new InsiderApi('checkers');
    const insiderShopriteApi = new InsiderApi('shoprite');
    const dSLConsent = new DSLConsent();
    const consent = new CiamCustomerConsents();
    const ciamAuth = new CIAMAuth();
    const cardService = new CardService();
    let headers;
    let accessTokenPetShop, headersPetShop;
    let gender;

    beforeAll(async () => {
        accessTokenPetShop = await ciamAuth.petShopScienceCognitoAuth(process.env.CIAM);
        accessTokenPetShop = accessTokenPetShop.data.access_token;
        headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        headersPetShop = {
            Authorization: `Bearer ${accessTokenPetShop}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
    });

    test('petshop customer with no XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/partialuser`, json, headersPetShop);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;

        let rewards = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let jsonPetShopConsent = _.union(rewards, marketing);

        await addMsg({message: JSON.stringify(jsonPetShopConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`});
        const responsePetShopConsent = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`, jsonPetShopConsent, headersPetShop);
        await addMsg({message: JSON.stringify(responsePetShopConsent.data, null, 2)});
        expect(responsePetShopConsent.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
    });

    test('checkers customer with no XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsCheckers = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.c_rewards_card_number !== undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_rewards_card_number).toBeUndefined();
    });

    test('shoprite customer with no XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('shoprite', false);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsShoprite = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');
        let marketingShoprite = dSLConsent.create_valid_user_consents('shoprite-za-marketing-consent');
        let jsonConsent = _.union(rewardsShoprite, marketingShoprite);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.c_rewards_card_number !== undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_rewards_card_number).toBeUndefined();
    });

    test('petshop customer with a checkers XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        cardNumber = json.foxCard.cardNumber;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsCheckers = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let rewards = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let jsonPetShopConsent = _.union(rewards, marketing);

        await addMsg({message: JSON.stringify(jsonPetShopConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`});
        const responsePetShopConsent = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`, jsonPetShopConsent, headersPetShop);
        await addMsg({message: JSON.stringify(responsePetShopConsent.data, null, 2)});
        expect(responsePetShopConsent.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(cardNumber);

    });

    test('petshop customer with a shoprite XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('shoprite', true);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        cardNumber = json.foxCard.cardNumber;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsCheckers = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('shoprite-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let rewards = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let jsonPetShopConsent = _.union(rewards, marketing);

        await addMsg({message: JSON.stringify(jsonPetShopConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`});
        const responsePetShopConsent = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`, jsonPetShopConsent, headersPetShop);
        await addMsg({message: JSON.stringify(responsePetShopConsent.data, null, 2)});
        expect(responsePetShopConsent.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(cardNumber);

    });

    test('petshop customer with a checkers and shoprite XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        cardNumber = json.foxCard.cardNumber;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;

        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        let jsonAddCard = {
            "cardNumber": newCardSH
        };
        await addMsg({message: JSON.stringify(jsonAddCard, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const responseAddCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, jsonAddCard, headers);
        await addMsg({message: JSON.stringify(responseAddCard.data, null, 2)});
        expect(responseAddCard.status).toBe(200);

        let rewardsCheckers = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let rewards = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let jsonPetShopConsent = _.union(rewards, marketing);

        await addMsg({message: JSON.stringify(jsonPetShopConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`});
        const responsePetShopConsent = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/consent?uid=${uuid}`, jsonPetShopConsent, headersPetShop);
        await addMsg({message: JSON.stringify(responsePetShopConsent.data, null, 2)});
        expect(responsePetShopConsent.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderPetShopApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(cardNumber);

    });

    test('checkers customer with a shoprite XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', false);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsCheckers = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        let jsonAddCard = {
            "cardNumber": newCardSH
        };
        await addMsg({message: JSON.stringify(jsonAddCard, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const responseAddCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, jsonAddCard, headers);
        await addMsg({message: JSON.stringify(responseAddCard.data, null, 2)});
        expect(responseAddCard.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.c_rewards_card_number === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(newCardSH);
    });

    test('checkers customer with a checkers and shoprite XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        cardNumber = json.foxCard.cardNumber;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsCheckers = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        let jsonAddCard = {
            "cardNumber": newCardSH
        };
        await addMsg({message: JSON.stringify(jsonAddCard, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const responseAddCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, jsonAddCard, headers);
        await addMsg({message: JSON.stringify(responseAddCard.data, null, 2)});
        expect(responseAddCard.status).toBe(200);

        let rewardsShoprite = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');
        let marketingShoprite = dSLConsent.create_valid_user_consents('shoprite-za-marketing-consent');
        let jsonShopriteConsent = _.union(rewardsShoprite, marketingShoprite);

        await addMsg({message: JSON.stringify(jsonShopriteConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const responseShopriteConsent = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, jsonShopriteConsent, headers);
        await addMsg({message: JSON.stringify(responseShopriteConsent.data, null, 2)});
        expect(responseShopriteConsent.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderCheckersResponse;
        let insiderShopriteResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderCheckersResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);
            insiderShopriteResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderCheckersResponse.data.attributes.email === email || insiderCheckersResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderCheckersResponse.status).toBe(200);
            } else {
                break;
            }
            if (insiderShopriteResponse.data.attributes.email === email || insiderShopriteResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderShopriteResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);

        await addMsg({message: `CheckersPanel:\n` + JSON.stringify(insiderCheckersResponse.data, null, 2)});
        await addMsg({message: `ShopritePanel:\n` + JSON.stringify(insiderShopriteResponse.data, null, 2)});
        expect(insiderCheckersResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderCheckersResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderCheckersResponse.data.attributes.gdpr).toBe(true);
        expect(insiderCheckersResponse.data.attributes.c_rewards_card_number[0]).toBe(cardNumber);
        expect(insiderCheckersResponse.data.attributes.c_rewards_card_number[1]).toBeUndefined();

        expect(insiderShopriteResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderShopriteResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderShopriteResponse.data.attributes.gdpr).toBe(true);
        expect(insiderShopriteResponse.data.attributes.c_rewards_card_number[0]).toBe(newCardSH);
        expect(insiderShopriteResponse.data.attributes.c_rewards_card_number[1]).toBeUndefined();
    });

    test('shoprite customer with a checkers XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('shoprite', false);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsCheckers = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('shoprite-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        let newCardCH = await cardService.getCardOffline(false, 'checkers');
        let jsonAddCard = {
            "cardNumber": newCardCH
        };
        await addMsg({message: JSON.stringify(jsonAddCard, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuid}`});

        const responseAddCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuid}`, jsonAddCard, headers);
        await addMsg({message: JSON.stringify(responseAddCard.data, null, 2)});
        expect(responseAddCard.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.c_rewards_card_number === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(newCardCH);
    });

    test('shoprite customer with a shoprite and checkers XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('shoprite', true);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        cardNumber = json.foxCard.cardNumber;
        idNumber = json.identity[0].value;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsShoprite = dSLConsent.create_valid_user_consents('shoprite-za-rewards-consent');
        let marketingShoprite = dSLConsent.create_valid_user_consents('shoprite-za-marketing-consent');
        let jsonShopriteConsent = _.union(rewardsShoprite, marketingShoprite);

        await addMsg({message: JSON.stringify(jsonShopriteConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/consent?uid=${uuid}`, jsonShopriteConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        let newCardCH = await cardService.getCardOffline(false, 'checkers');
        let jsonAddCard = {
            "cardNumber": newCardCH
        };
        await addMsg({message: JSON.stringify(jsonAddCard, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuid}`});

        const responseAddCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/card?uid=${uuid}`, jsonAddCard, headers);
        await addMsg({message: JSON.stringify(responseAddCard.data, null, 2)});
        expect(responseAddCard.status).toBe(200);

        let rewardsCheckers = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const responseShopriteConsent = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(responseShopriteConsent.data, null, 2)});
        expect(responseShopriteConsent.status).toBe(200);
        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderCheckersResponse;
        let insiderShopriteResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderCheckersResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);
            insiderShopriteResponse = await insiderShopriteApi.getCustomerInsider(identifierObj, events);

            if (insiderCheckersResponse.data.attributes.email === email || insiderCheckersResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderCheckersResponse.status).toBe(200);
            } else {
                break;
            }
            if (insiderShopriteResponse.data.attributes.email === email || insiderShopriteResponse.data.attributes.gdpr !== true) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderShopriteResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);

        await addMsg({message: `CheckersPanel:\n` + JSON.stringify(insiderCheckersResponse.data, null, 2)});
        await addMsg({message: `ShopritePanel:\n` + JSON.stringify(insiderShopriteResponse.data, null, 2)});
        expect(insiderCheckersResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderCheckersResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderCheckersResponse.data.attributes.gdpr).toBe(true);
        expect(insiderCheckersResponse.data.attributes.c_rewards_card_number[0]).toBe(newCardCH);
        expect(insiderCheckersResponse.data.attributes.c_rewards_card_number[1]).toBeUndefined();

        expect(insiderShopriteResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderShopriteResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderShopriteResponse.data.attributes.gdpr).toBe(true);
        expect(insiderShopriteResponse.data.attributes.c_rewards_card_number[0]).toBe(cardNumber);
        expect(insiderShopriteResponse.data.attributes.c_rewards_card_number[1]).toBeUndefined();
    });

    test('checkers customer with an inactive checkers and add a shoprite XS card', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        let emailAddress = {
            "description": "Contact Type by Automation",
            "id": "05",
            "type": "Email",
            "value": `${json.userDetails.firstName}-${json.userDetails.lastName}@dsl-insider.automation.com`
        };
        json.contactDetails.push(emailAddress);
        await addMsg({message: JSON.stringify(json, null, 2)});
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        email = json.contactDetails[1].value;
        idNumber = json.identity[0].value;
        cardNumber = json.foxCard.cardNumber;
        gender = dataHelpers.getGenderFromIDNumber(idNumber);

        const responsePartial = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(responsePartial.data, null, 2)});
        expect(responsePartial.status).toBe(200);
        expect(responsePartial.data.response.uuid).not.toBeNull();
        uuid = responsePartial.data.response.uuid;
        let rewardsCheckers = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketingCheckers = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let jsonConsent = _.union(rewardsCheckers, marketingCheckers);

        await addMsg({message: JSON.stringify(jsonConsent, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, jsonConsent, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        let tokenCH = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');

        const headerStopCard = {
            'access_token': `${tokenCH.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let jsonStopCard = {
            "cardNumber": cardNumber
        };
        await addMsg({message: JSON.stringify(jsonStopCard, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/stop`});

        const responseStopCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/stop`, jsonStopCard, headerStopCard);
        await addMsg({message: JSON.stringify(responseStopCard.data, null, 2)});
        let {data} = responseStopCard;
        expect(responseStopCard.status).toBe(200);

        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        let jsonAddCard = {
            "cardNumber": newCardSH
        };
        await addMsg({message: JSON.stringify(jsonAddCard, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const responseAddCard = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, jsonAddCard, headers);
        await addMsg({message: JSON.stringify(responseAddCard.data, null, 2)});
        expect(responseAddCard.status).toBe(200);

        await new Promise(resolve => {
            console.log(chalk.redBright('Waiting for 30s to allow Insider to process the request!'));
            setTimeout(resolve, 30000);
        });
        let insiderResponse;
        let retry = 0;
        do {
            console.log(`*****${retry}*******`);
            /*Getting Customer Data from Insider API*/
            let identifierObj = {
                "uuid": uuid
            };
            let events = [
                {
                    "event_name": insiderPetShopApi.ciamEvents.CREATE_USER,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                },
                {
                    "event_name": insiderPetShopApi.ciamEvents.CARD_REGISTERED,
                    "params": [
                        "timestamp",
                        "event_params",
                        "custom"
                    ]
                }
            ];

            insiderResponse = await insiderCheckersApi.getCustomerInsider(identifierObj, events);

            if (insiderResponse.data.attributes.email === email || insiderResponse.data.attributes.c_rewards_card_number === undefined) {
                await new Promise(resolve => {
                    let waitPeriod = dataHelpers.generateRandomNumber(20, 40);
                    console.log(chalk.redBright(`Waiting for ${waitPeriod}s to allow Insider to process the request!`));
                    setTimeout(resolve, waitPeriod * 2000);
                });
                expect(insiderResponse.status).toBe(200);
            } else {
                break;
            }
            retry++;
        } while (retry <= 7);
        await addMsg({message: JSON.stringify(insiderResponse.data, null, 2)});
        expect(insiderResponse.data.attributes.email).toBe(email.toLowerCase());
        expect(insiderResponse.data.attributes.phone_number).toBe(mobileNumber);
        expect(insiderResponse.data.attributes.gdpr).toBe(true);
        expect(insiderResponse.data.attributes.c_rewards_card_number[0]).toBe(newCardSH);
    });
});
