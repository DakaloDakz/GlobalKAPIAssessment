import ApiMethodUtil from "../../__utils__/api_method_util";
import DataHelpers from '../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../__utils__/auth/ciam/auth.methods";
import DSLCustomer from "../data/customer.data";
import DSLPreferences from "../data/preferences.data";

jest.retryTimes(1);
describe('International Numbers', () => {
    const apiCall = new ApiMethodUtil();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const ciamAuth = new CIAMAuth();
    const dSLPreferences = new DSLPreferences();
    let uuid;
    let mobileNumber;
    let firstName;
    let lastName;
    let zaMobileNumber;
    let newIntMobileNumber;
    beforeAll(async () => {

    });

    test('created partial customer', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false, false);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        json = dataHelpers.removeObjectInJson(json, 'foxCard');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        mobileNumber = json.contactDetails[0].value;
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        uuid = response.data.response.uuid;
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toBe(mobileNumber);
        expect(response1.data.response.givenName).toBe(firstName);
        expect(response1.data.response.familyName).toBe(lastName);
    });

    test('created partial customer with ++ in the mobile number should return an error', async () => {
        let json = await dSLCustomer.create_customer_valid_partial('checkers', false, false);
        json = dataHelpers.setValueInJson(json, 'contactDetails[0].value', `+${dataHelpers.generatePhoneNumber()}`);
        json = dataHelpers.setValueInJson(json, 'userDetails.type', 'whatsapp');
        json = dataHelpers.removeObjectInJson(json, 'foxCard');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get customer should return customer details including international number', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.user.mobileNumber).toBe(mobileNumber);
    });

    test('update customer mobileNumber from international number to south african number', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        zaMobileNumber = dataHelpers.generatePhoneNumber(true);
        const json = {
            "mobileNumber": zaMobileNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 5000));
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, zaMobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(zaMobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
    });

    test('update customer mobileNumber from south african number to international number', async () => {
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, zaMobileNumber, 'dsl');
        newIntMobileNumber = dataHelpers.generatePhoneNumber(false);
        const json = {
            "mobileNumber": newIntMobileNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 5000));
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, newIntMobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(newIntMobileNumber);
        expect(response1.data.response.givenName).toEqual(firstName);
        expect(response1.data.response.familyName).toEqual(lastName);
    });

    test('search customer by mobile should return the correct customer', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/searchbymobilenumber`});
        let params = {
            mobileNumber: newIntMobileNumber
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/searchbymobilenumber`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.firstName).toBe(firstName);
    });

    test('set customer contact preferences for customer with international number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, newIntMobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted')).toBe(true);
    });

    test('get customer contact preferences for customer with international number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        for (let i = 0; i < data.response.contactPreferences.length; i++) {
            data.response.contactPreferences[i].updated = '[SANITIZED]';
        }
        expect(data).toMatchSnapshot();
    });

    test('loginByMobile for customer with international number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: newIntMobileNumber};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/loginbymobile`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        const paramsVerify = {
            "target": {
                "type": "SMS",
                "identifier": newIntMobileNumber,
                "reference": reference
            },
            "otp": 0
        };
        const responseVerify = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, paramsVerify, headers);
        await addMsg({message: JSON.stringify(responseVerify.data, null, 2)});
        expect(responseVerify.status).toBe(200);
        expect(responseVerify.data.response.accessToken).toBeDefined();
        expect(responseVerify.data.response.refreshToken).toBeDefined();
    });

    test('login for customer with international number', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const params = {query: newIntMobileNumber};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/login`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let reference = response.data.response.reference;
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.expiry.value', 'response.reference']);
        expect(data).toMatchSnapshot();
        let json = {
            "target": {
                "type": "SMS",
                "identifier": newIntMobileNumber,
                "reference": reference
            },
            "otp": 0
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response1 = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/loginbymobile/verify`, json, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.accessToken).toBeDefined();
        expect(response1.data.response.refreshToken).toBeDefined();
    });
});
