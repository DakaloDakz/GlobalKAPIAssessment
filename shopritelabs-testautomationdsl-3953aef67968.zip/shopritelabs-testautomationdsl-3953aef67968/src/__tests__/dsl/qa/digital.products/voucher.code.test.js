import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('Send voucher code to the mobile number provided and returns the voucher code to the requester', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;

    beforeAll(async () => {
        access = await ciamAuth.ciamFNBCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('Send valid voucher code to the mobile number', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1118&mobileNumber=+27647572677&sendCode=true&generateBarcodeImage=false&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the mobile number with generateBarcodeImage = true', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendCode=true&generateBarcodeImage=true&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send Invalid voucher code to the mobile number', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendCode=true&generateBarcodeImage=false&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the mobile number but Sendcode is false', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendCode=false&generateBarcodeImage=false&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the mobile number that is not provided but Sendcode is false', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendCode=false&generateBarcodeImage=false&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the without mobile number and sendCode is true', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&sendCode=true&generateBarcodeImage=false&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the without voucherId', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&mobileNumber=+27647572677&sendCode=true&generateBarcodeImage=false&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the without sendcode', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&generateBarcodeImage=false&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the without generated barImage', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendCode=true&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the without request id', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendCode=true&generateBarcodeImage=false`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the without any parameters', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the with invalid mobile number', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/code?voucherId=1119&mobileNumber=dakalo&sendCode=true&generateBarcodeImage=false&requestId=1252553&clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher code to the with invalid url', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/code`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/Digital/voucher/code?voucherId=1119&mobileNumber=+27647572677&sendCode=true&generateBarcodeImage=false&requestId=1252553&clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
    });

});
