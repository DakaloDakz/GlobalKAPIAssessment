import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import DSLReceiver from '../../../dsl/data/reciever.data';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('Connect Mobile delivery report callback', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const dSLReceiver = new DSLReceiver();
    let access;

    beforeAll(async () => {
        access = await ciamAuth.ciamConnectMobileCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('Connect Mobile delivery report send valid', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(45, '+27142523625', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send valid min dir', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(0, '+27142523625', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send valid max dir', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(64, '+27142523625', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send Invalid DIR >', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(80, '+27142523625', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send Invalid DIR <', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(0.5, '+27142523625', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send Invalid mobile number', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(45, '0142523625', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send with missing dir', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report('', '+27142523625', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send missing da', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(45, '', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send with missing userID', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(45, '+27142523625', '');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Connect Mobile delivery report send invalid url', async () => {
        const headers = {
            'Authorization': `Bearer ${access}`,
            'x-api-key': process.env.ConnectMobileClientApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}/dsl/products/digital/Voucher/deliveryReport`});
        let json = dSLReceiver.create_delivery_report(45, '+27142523625', 'dec80b8a-36a4-4fb0-a233-0eb013c9659b');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/Voucher/deliveryReport`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

});
