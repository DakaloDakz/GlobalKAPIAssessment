import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import DataHelpers from '../../../__utils__/data_helpers';
import CIAMCustomer from '../../../ciam/common/create_customer';
import {addMsg} from "jest-html-reporters/helper";

describe.skip('Send voucher resendCode to the mobile number provided and returns the voucher resendCode to the requester', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    let access;

    beforeAll(async () => {
        access = await ciamAuth.ciamFNBCognitoAuth(process.env.CIAM);
        access = access.data.access_token;
    });

    test('Send valid voucher resendCode to the mobile number', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=true&voucherCode=9301109600006922`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the different mobile number', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572600&sendresendCode=true&requestId=1252553,voucherCode=9301109600006922`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the mobile number with sendresendCode=false', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=false&requestId=1252553,voucherCode=9301109600006922`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the mobile number field is not provided with resendCode=false', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=&sendresendCode=false&requestId=1252553,voucherCode=9301109600006922`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send Invalid voucher resendCode to the mobile number', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=000&mobileNumber=+27647572677&sendresendCode=true&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the mobile number but SendresendCode is false', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=false&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the without mobile number and sendresendCode is true', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&sendresendCode=true&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the without voucherId', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&mobileNumber=+27647572677&sendresendCode=true&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the without sendresendCode', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the without generated barImage', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=true&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the without request id', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=true`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the without any parameters', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the with invalid mobile number', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=dakalo&sendresendCode=true&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the with invalid requestId', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=true&requestId=dakalo`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the with invalid voucherCode', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=true&voucherCode=dakalo`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the with invalid voucherCodeHash', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=true&voucherCodeHash=dakalo`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Send valid voucher resendCode to the with invalid url', async () => {
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.CIAMFNBApiKey,
            'Content-Type': 'application/json'
        };

        await addMsg({message: `${process.env.DSLGroup}https:/dsl/products/digital/voucher/resendCode`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/products/Digital/voucher/resendCode?clientKey=7235b37d1e5c88ee4ca5cdac0afd79158788456f&voucherId=1119&mobileNumber=+27647572677&sendresendCode=true&requestId=1252553`, null, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(403);
    });
});
