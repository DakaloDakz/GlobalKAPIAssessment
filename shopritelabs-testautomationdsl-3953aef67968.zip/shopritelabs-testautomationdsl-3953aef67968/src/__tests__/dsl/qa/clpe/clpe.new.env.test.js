import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

// jest.retryTimes(1)
describe('DSLGroup - CLPE POST, CANCEL and VOID (/baskets/transactions)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    let access;

    beforeAll(async () => {

    });

    test('Post basket to LPRO - Inclusive with transaction type 0', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '0');
        json = dataHelpers.setValueInJson(json, 'missedPromotions', true);
        json = dataHelpers.setValueInJson(json, 'tender[0].tenderId', '35');
        json = dataHelpers.setValueInJson(json, 'tender[0].tenderAmount', '400');
        await addMsg({message: JSON.stringify(json, null, 2)});
        let response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test('Post basket to LPRO - Inclusive with transaction type 1', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '1');
        json = dataHelpers.setValueInJson(json, 'tender[0].tenderId', '35');
        json = dataHelpers.setValueInJson(json, 'tender[0].tenderAmount', '400');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test('Post basket to LPRO - Inclusive with transaction type 5', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '5');
        json = dataHelpers.setValueInJson(json, 'tender[0].tenderId', '35');
        json = dataHelpers.setValueInJson(json, 'tender[0].tenderAmount', '400');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test('Post basket to LPRO - Inclusive with invalid transaction type', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '99');
        json = dataHelpers.setValueInJson(json, 'tender[0].tenderId', '35');
        json = dataHelpers.setValueInJson(json, 'tender[0].tenderAmount', '400');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test('Post basket to LPRO - Exclusive', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_exclusive.json');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test('Post basket to LPRO - Missed Offers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_missed_offer.json');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test('Post basket to LPRO - Discount', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_discount.json');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test('Post basket to LPRO - New Price', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_new_price.json');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    let postFields = ["transactionId", "storeId", "posId", "cashierId", "transactionType", "retailerId", "transactionItemList[0].departmentCode", "transactionItemList[0].itemCode", "transactionItemList[0].qty", "transactionItemList[0].retailPrice", "transactionItemList[0].amount", "transactionItemList[0].sequenceId", "transactionItemList[0].saleType", "transactionTotal.totalNumberOfItems", "checkoutType", "cardNo", "orderStatus", "externalOrderId", "missedPromotions", "dateTime", "promotionAggregatedBy"];

    test.each(postFields)('Post basket  - with invalid %s', async (field) => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.setValueInJson(json, field, '0');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test.each(postFields)('Post basket  - with missing %s', async (field) => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.removeObjectInJson(json, field);
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });

    test('Cancel basket to LPRO', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions/cancel`});
        let json = require('./data/baskets_transactions_cancel.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '2');
        const response = await apiCall.DELETE(`${process.env.DSLGroup}/dsl/baskets/transactions/cancel`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    let cancelFields = ["transactionVoid[0]", "transactionVoid[0].originalTransactionId", "transactionVoid[0].originalPosId", "transactionVoid[0].originalStoreId", "transactionVoid[0].retailerId", "storeId", "posId", "transactionId", "cashierId", "checkoutType", "retailerId"];

    test.each(cancelFields)('Cancel basket to LPRO  - with invalid %s', async (field) => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions/cancel`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '2');
        json = dataHelpers.setValueInJson(json, field, '0');
        const response = await apiCall.DELETE(`${process.env.DSLGroup}/dsl/baskets/transactions/cancel`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test.each(cancelFields)('Cancel basket to LPRO  - with missing %s', async (field) => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions/cancel`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '2');
        json = dataHelpers.removeObjectInJson(json, field);
        const response = await apiCall.DELETE(`${process.env.DSLGroup}/dsl/baskets/transactions/cancel`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Void basket to LPRO', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions/void`});
        let json = require('./data/baskets_transactions_void.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '4');
        const response = await apiCall.DELETE(`${process.env.DSLGroup}/dsl/baskets/transactions/void`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    let voidFields = ["transactionVoid[0].originalTransactionId", "transactionVoid[0].originalPosId", "transactionVoid[0].originalStoreId", "transactionVoid[0].retailerId", "storeId", "posId", "transactionId", "cashierId", "checkoutType", "retailerId"];

    test.each(voidFields)('Void basket to LPRO  - with invalid %s', async (field) => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions/void`});
        let json = require('./data/baskets_transactions_inclusive.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '4');
        json = dataHelpers.setValueInJson(json, field, '0');
        const response = await apiCall.DELETE(`${process.env.DSLGroup}/dsl/baskets/transactions/void`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(400);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('Post basket to LPRO - E2E BonusBuys', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/baskets/transactions`});
        let json = require('./data/baskets_transactions_bonusbuys.json');
        json = dataHelpers.setValueInJson(json, 'transactionType', '0');
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/baskets/transactions`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.loyalty.cardLocked']);
        expect(data).toMatchSnapshot();
    });
});
