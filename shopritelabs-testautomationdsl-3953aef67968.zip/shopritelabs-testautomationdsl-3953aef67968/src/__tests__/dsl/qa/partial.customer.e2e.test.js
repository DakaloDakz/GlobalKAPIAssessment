import ApiMethodUtil from "../../__utils__/api_method_util";
import DataHelpers from '../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../__utils__/auth/commerce/auth.methods";
import DSLCustomer from "../data/customer.data";
import interests from "../prep/customer/preferences/data/personal.interests.json";
import DSLPreferences from "../data/preferences.data";
import CIAMCustomer from "../../ciam/common/create_customer";
import _ from "lodash";
import DSLConsent from "../data/consents.data";
import CiamCustomerConsents from "../../ciam/qa/data/consents.data";
import CardService from "../../__utils__/cards/cardService";
import CiamCustomerPreferences from "../../ciam/qa/data/preferences.data";
import LproPayloads from "../../__utils__/auth/ciam/payloads/lpro.payloads";
import {encode} from "../../__utils__/encryption.util";

jest.retryTimes(1);
describe('E2E - Partial Customer', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const ciamAuth = new CIAMAuth();
    const cIAMCustomer = new CIAMCustomer();
    const dSLCustomer = new DSLCustomer();
    const dSLPreferences = new DSLPreferences();
    const preferences = new CiamCustomerPreferences();
    const dSLConsent = new DSLConsent();
    const consent = new CiamCustomerConsents();
    const cardService = new CardService();
    const lproPayloads = new LproPayloads();
    let uuid;
    let mobileNumber;
    let firstName;
    let lastName;
    let credentials;
    let sessionKey;
    beforeAll(async () => {
        let occAuthUserName = process.env.LPROClientID;
        let occAuthPassword = process.env.LPROClientSecret;
        credentials = encode(`${occAuthUserName}:${occAuthPassword}`);
        let payload = await lproPayloads.loginPayload();
        sessionKey = await ciamAuth.lpro_session_key_auth(payload, 'qa');
    });

    test('created partial customer', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        mobileNumber = json.contactDetails[0].value;
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        uuid = response.data.response.uuid;
    });

    test(`add personal interest`, async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('cfsb2b', true);
        for (let i = 1; i < interests.checkers.length; i++) {
            json.push({
                "active": true,
                "name": interests.checkers[i].name
            });
        }
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add contact preferences', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add contact preferences - PetShopScience', async () => {
        expect(uuid).toBeDefined();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "code": "email",
                "active": true
            },
            {
                "code": "mobileApp",
                "active": true
            },
            {
                "code": "whatsApp",
                "active": false
            },
            {
                "code": "sms",
                "active": true
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/contactPreferences`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/contactPreferences`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add consent', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add consent - PetshopScience', async () => {
        expect(uuid).toBeDefined();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.PetShopScienceApiKkey,
            'Content-Type': 'application/json'
        };
        let marketing = dSLConsent.create_valid_user_consents('petshopScience-za-marketing-consent');
        let signup = dSLConsent.create_valid_user_consents('petshopScience-za-terms-and-conditions-consent');
        let json = _.union(signup, marketing);

        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/consent`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/petshop/countries/za/users/consent`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.marketing.consentName')).toBe('petshopScience-za-marketing-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.petshopScience.za.shopriteGroup.consents.termsOfService.consentName')).toBe('petshopScience-za-terms-and-conditions-consent');

    });

    test('add Sixty60 consents', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('Sixty60', 'sixty60-za-marketing-consent', '1', 'Sixty60 marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');

    });

    test('add Money Market consents', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'Sixty60 marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add shoprite card', async () => {
        expect(uuid).toBeDefined();
        let newCardSH = await cardService.getCardOffline(false, 'shoprite');
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": newCardSH
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('add email to customer', async () => {
        expect(uuid).toBeDefined();
        let tk = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const json = {
            "email": `${firstName}-${lastName}@shoprite-testautomation.com`
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${tk.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test('add multiple Sixty60 preferences', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await preferences.createMultiplePreferencesPayload('Sixty60', 'SMS', '+27833965802', true,
            'Sixty60', 'EMAIL', 'testautomation@auto.com', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.sms.addressValue).toBe('+27833965802');
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.email.addressValue).toBe('testautomation@auto.com');
    });

    test('add multiple preferences ByteOrbit', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            'x-api-key': process.env.byteOrbitApiKey
        };
        let body = await preferences.createMultiplePreferencesPayload('Sixty60', 'SMS', '+27833965802', true,
            'Sixty60', 'EMAIL', 'testautomation@auto.com', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.sms.addressValue).toBe('+27833965802');
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.email.addressValue).toBe('testautomation@auto.com');
    });

    test('add SwipeForCover and AutoAirtimeInjection', async () => {
        expect(uuid).toBeDefined();
        const headers = {
            'Authorization': `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        let json = [
            {
                "active": true,
                "name": "srswipeforcover"
            }, {
                "active": true,
                "name": "srautoairtime"
            }
        ];
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/users/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();

        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(uuid);
        let headers1 = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response1 = await apiCall.POST(url, body, headers1);
        let responseJson = dataHelpers.xml2json(response1.data);
        console.log(JSON.stringify(responseJson), null, 2);
        let respJson = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let aa = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'][0]['$']['Id'];
        let sfc = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'][1]['$']['Id'];
        let segments = respJson['HouseHold']['HouseHoldSegments'][0]['Segment'];
        expect(segments).toHaveLength(2);
        expect(aa).toBe('1201');
        expect(sfc).toBe('1301');
    });

    test('Get Customer', async () => {
        expect(uuid).toBeDefined();
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
    });
});
