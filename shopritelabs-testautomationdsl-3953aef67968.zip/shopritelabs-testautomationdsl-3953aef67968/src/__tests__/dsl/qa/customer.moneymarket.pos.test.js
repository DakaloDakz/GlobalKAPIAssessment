import ApiMethodUtil from '../../__utils__/api_method_util';
import DataHelpers from '../../__utils__/data_helpers';
import DSLCustomer from '../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../__utils__/auth/ciam/auth.methods";
import LproPayloads from "../../__utils__/auth/ciam/payloads/lpro.payloads";
import {get_otp_reference} from "../../__utils__/auth/dsl/otp";
import _ from "lodash";
import DSLConsent from "../data/consents.data";
import DSLPreferences from "../data/preferences.data";
import interests from "./customer/preferences/data/personal.interests.json";
import CardService from "../../__utils__/cards/cardService";

jest.retryTimes(1);
describe('MoneyMarketPOS - Customer endpoints E2E', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const lproPayloads = new LproPayloads();
    const cardService = new CardService();
    const dSLConsent = new DSLConsent();
    const dSLPreferences = new DSLPreferences();

    let token, email, emailNew, uuid, mobileNumber, firstName, lastName;
    beforeAll(async () => {
        token = await ciamAuth.ciamMoneyMarketPOSCognitoAuth(process.env.CIAM);
        token = await token.data.access_token;

    });

    test('create customer', async () => {
        let json = await dSLCustomer.create_customer_valid_partial_web('checkers');
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };

        mobileNumber = json.contactDetails[0].value;
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        let response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
        expect(response.data.response.uuid).toBeDefined();
        uuid = response.data.response.uuid;
    });

    test('patch customer', async () => {
        const json = {
            "firstName": firstName + 'Updated',
            "lastName": lastName,
            "mobileNumber": mobileNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'Authorization': `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.mobileNumber).toEqual(mobileNumber);
        expect(response1.data.response.mobileNumberVerified).toBeUndefined();
        expect(response1.data.response.givenName).toEqual(firstName + 'updated');
        expect(response1.data.response.familyName).toEqual(lastName);
    });

    test('add mobile verified', async () => {
        let reference = await get_otp_reference(process.env.DSLGroup, mobileNumber, token);
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };

        let otp = {
            "target": {
                "type": "SMS",
                "identifier": mobileNumber,
                "targetIsVerified": true
            },
            "action": "verify"
        };
        const responseOTP = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/otp/generate`, otp, headers);
        await addMsg({message: JSON.stringify(responseOTP.data, null, 2)});
        expect(responseOTP.status).toBe(200);

        let json = {
            "target": {
                "type": "SMS",
                "identifier": mobileNumber,
                "reference": reference
            },
            "otp": 4745
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verifymobile`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });

    test('add consent', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        let rewards = dSLConsent.create_valid_user_consents('checkers-za-rewards-consent');
        let marketing = dSLConsent.create_valid_user_consents('checkers-za-marketing-consent');
        let json = _.union(rewards, marketing);
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.consentName')).toBe('checkers-za-marketing-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.marketing.consentVersion')).toBe("1");
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.termsOfService.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName')).toBe('checkers-za-rewards-consent');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.consents.termsOfService.consentVersion')).toBe("1");
    });

    test('get consent', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/consent?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('add contact preferences', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_contact_preference();
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.whatsApp.granted')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.sms.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.mobileApp.granted')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.contactPreferences.email.granted')).toBe(true);
    });

    test('get contact preferences', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/contactPreferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('add personal interests', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        let json = dSLPreferences.create_user_personal_preference('chbabyandparenting', true);
        json.push({
            "active": false,
            "name": 'inhealthandbeauty'
        });
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chBabyAndParenting.optIn')).toBe(true);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.chBabyAndParenting.identifier')).toBe('7');
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inHealthAndBeauty.optIn')).toBe(false);
        expect(dataHelpers.getValueFromJson(response1.data, 'response.retailServices.xtraSavings.za.checkers.personalInterests.inHealthAndBeauty.identifier')).toBe('48');
    });

    test('get personal interests', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`});
        await addMsg({message: `Shoprite - ${interests.shoprite.length}`});
        await addMsg({message: `Checkers - ${interests.checkers.length}`});
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/preferences?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('add card', async () => {
        let card = await cardService.getCardOffline(false, 'checkers');
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        let json = {
            "cardNumber": card
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`});

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/card?uid=${uuid}`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('send card', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/send?mobileNumber=${mobileNumber}`});
        let params = {
            mobileNumber: mobileNumber
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/card/send`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    test('verify customer with valid mobile number', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        const params = {mobileNumber: mobileNumber};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/verify`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data.response.message).toBe('Mobilenumber exists - update customer');
    });

    test('get customer', async () => {
        const headers = {
            Authorization: `Bearer ${token}`,
            'x-api-key': process.env.moneyMarketPOSApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za?uid=${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });
});
