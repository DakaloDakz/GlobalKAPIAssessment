import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";
import ProductPricePayloads from "./data/product_price";

jest.retryTimes(1);
describe('DSL - Add product price (/dsl/productPrice)', () => {
    const apiCall = new ApiMethodUtil();
    const productPrice = new ProductPricePayloads();

    beforeAll(async () => {

    });

    test('post product price', async () => {
        const headers = {
            'x-api-key': 'sRTDQr1GvnxSwozgpg5e2AMfgPR9bAR4nnmDHxqb',
            'Content-Type': 'application/xml'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/productPrice`});
        let body = await productPrice.payload();

        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/productPrice`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response).toBeDefined();
    });
});
