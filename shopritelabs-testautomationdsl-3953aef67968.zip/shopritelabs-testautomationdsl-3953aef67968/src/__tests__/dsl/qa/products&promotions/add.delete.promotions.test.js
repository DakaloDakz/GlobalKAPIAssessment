import ApiMethodUtil from '../../../__utils__/api_method_util';
import CIAMAuth from '../../../__utils__/auth/ciam/auth.methods';
import {addMsg} from "jest-html-reporters/helper";

jest.retryTimes(1);
describe('DSL - Add Delete promotions (/products/specials)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    let access;

    beforeAll(async () => {

    });

    test('get promotions', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`});
        let params = {};
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials?query=Q%3Dmerlot¤tPage=1&pageSize=5&sort=name-asc&preferredStoreId=1103&saveType=ALL_SPECIALS`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response).toBeDefined();
    });
});
