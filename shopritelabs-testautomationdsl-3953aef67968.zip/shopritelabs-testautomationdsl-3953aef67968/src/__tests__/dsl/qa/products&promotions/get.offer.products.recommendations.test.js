import ApiMethodUtil from '../../../__utils__/api_method_util';
import {addMsg} from "jest-html-reporters/helper";

jest.retryTimes(1);
describe('DSL - Retrieve a list of Non-Personalised Offer Product Recommendations based on offer type (/offers/products/recommendations)', () => {
    const apiCall = new ApiMethodUtil();

    beforeAll(async () => {

    });

    test('Get Offer Products Recommendation with type DH_RANKEDSPECIALS_COM - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/offers/products/recommendations`});
        let params = {
            uid: 'larilityane@mail.com',
            type: 'DH_RANKEDSPECIALS_COM'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/offers/products/recommendations`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBeDefined();
    });

    test('Get Offer Products Recommendation with type DH_MEMBERSDEALS_COM - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/offers/products/recommendations`});
        let params = {
            uid: 'larilityane@mail.com',
            type: 'DH_MEMBERSDEALS_COM'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/offers/products/recommendations`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBeDefined();
    });

    test('Get Offer Products Recommendation with type DH_OFFERSFORYOU_COM - checkers', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/offers/products/recommendations`});
        let params = {
            uid: 'larilityane@mail.com',
            type: 'DH_OFFERSFORYOU_COM'
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/offers/products/recommendations`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBeDefined();
    });
});
