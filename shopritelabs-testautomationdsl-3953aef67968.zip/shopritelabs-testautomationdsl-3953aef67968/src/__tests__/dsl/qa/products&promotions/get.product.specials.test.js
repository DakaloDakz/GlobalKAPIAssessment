import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - Get Product Specials (/products/specials/specials)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    let access;

    beforeAll(async () => {

    });

    test('get all products specials - ALL_SPECIALS', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`});
        let params = {
            query: "",
            currentPage: "1",
            pageSize: "20",
            sort: "relevance",
            preferredStoreId: "5204",
            saveType: "ALL_SPECIALS"
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.facets.length).toBeGreaterThan(0);
    });

    test('get all products specials Shoprite - ALL_SPECIALS', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/specials`});
        let params = {
            query: "",
            currentPage: "1",
            pageSize: "20",
            sort: "relevance",
            preferredStoreId: "6420",
            saveType: "ALL_SPECIALS"
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/products/specials`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.facets.length).toBeGreaterThan(0);
    });

    test('get all products specials - XTRA_SAVE', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`});
        let params = {
            query: "",
            currentPage: "1",
            pageSize: "20",
            sort: "relevance",
            preferredStoreId: "1569",
            saveType: "XTRA_SAVE"
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.facets.length).toBeGreaterThan(0);
    });

    test('get all products specials - REGULAR_SAVE', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`});
        let params = {
            query: "",
            currentPage: "1",
            pageSize: "20",
            sort: "relevance",
            preferredStoreId: "5204",
            saveType: "REGULAR_SAVE"
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.facets.length).toBeGreaterThan(0);
    });

    test('get specific products specials - Q=ceres', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`});
        let params = {
            query: "Q=ceres",
            currentPage: "1",
            pageSize: "20",
            sort: "relevance",
            preferredStoreId: "5204"
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.facets.length).toBeGreaterThan(0);
    });

    test('get all products specials - :relevance:category:food', async () => {
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`});
        let params = {
            query: ":relevance:category:food",
            currentPage: "1",
            pageSize: "20",
            sort: "relevance",
            preferredStoreId: "5204"
        };
        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/specials`, headers, params);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
        expect(data.response.facets.length).toBeGreaterThan(0);
    });
});
