export default class ProductPricePayloads {

    payload = async () => {
        return `<?xml version="1.0" encoding="UTF-8"?>
<soap-env:Envelope xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/">
    <soap-env:Header>
    </soap-env:Header>
    <soap-env:Body>
        <n0:MerchandiseERPByElementsResponseMessage_sync xmlns:n0="http://sap.com/xi/SAPGlobal20/Global">
            <Merchandise>
                <ProductInternalID>10139619</ProductInternalID>
                <MaterialTypeCode>ZHAW</MaterialTypeCode>
                <MaterialTypeName>SR:Trading Goods</MaterialTypeName>
                <MaterialMerchandiseTypeCode>3</MaterialMerchandiseTypeCode>
                <MaterialMerchandiseTypeName>Variant</MaterialMerchandiseTypeName>
                <Description>
                    <Description>JUICE CERES 200ML, WHISP OF SUMM</Description>
                </Description>
                <GlobalTradeItemNumber>
                    <ProductStandardID>6001240200148</ProductStandardID>
                    <MeasureUnitCode>EA</MeasureUnitCode>
                    <MeasureUnitName>each</MeasureUnitName>
                    <ProductStandardMainIndicator>true</ProductStandardMainIndicator>
                </GlobalTradeItemNumber>
                <QuantityUnit>
                    <MeasureUnitCode>EA</MeasureUnitCode>
                    <MeasureUnitName>each</MeasureUnitName>
                    <BaseQuantityUnitIndicator>true</BaseQuantityUnitIndicator>
                    <SupplementaryQuantityUnitUsageCode>5</SupplementaryQuantityUnitUsageCode>
                    <SupplementaryQuantityUnitUsageName>Alternative</SupplementaryQuantityUnitUsageName>
                </QuantityUnit>
                <QuantityConversion>
                    <Quantity>1</Quantity>
                    <CorrespondingQuantity>1</CorrespondingQuantity>
                </QuantityConversion>
                <ProductCategory>
                    <ProductCategoryInternalID>10320702</ProductCategoryInternalID>
                    <ProductCategoryDescription>Cordials and Juices</ProductCategoryDescription>
                    <ProductCategoryHierarchyTypeCode>3</ProductCategoryHierarchyTypeCode>
                    <ProductCategoryHierarchyTypeName>Merchand. Cat. Hier.</ProductCategoryHierarchyTypeName>
                </ProductCategory>
                <TaxClassification>
                    <CountryCode>ZA</CountryCode>
                    <CountryName>South Africa</CountryName>
                    <TaxTypeCode>0</TaxTypeCode>
                    <TaxRateTypeCode>0</TaxRateTypeCode>
                    <Percent>15</Percent>
                    <ProductTaxationCharacteristicsCode>A3</ProductTaxationCharacteristicsCode>
                    <ProductTaxationCharacteristicsName>Output VAT Standard 15%</ProductTaxationCharacteristicsName>
                </TaxClassification>
                <ProcurementPriceInformation>
                    <ProductStandardID>6001240238486</ProductStandardID>
                    <OrderMeasureUnitCode>PK2</OrderMeasureUnitCode>
                    <OrderMeasureUnitName>Pack 2</OrderMeasureUnitName>
                    <OrderTransactionCurrencyCode>ZAR</OrderTransactionCurrencyCode>
                    <OrderTransactionCurrencyName>South African Rand</OrderTransactionCurrencyName>
                    <StrategicPurchasingOrganisationID>1001</StrategicPurchasingOrganisationID>
                    <SupplierInternalID>404793</SupplierInternalID>
                    <ValidityPeriod>
                        <StartDate>2023-02-14</StartDate>
                        <EndDate>9999-12-31</EndDate>
                    </ValidityPeriod>
                    <PriceSpecification>
                        <PriceSpecificationElementTypeCode>PB00</PriceSpecificationElementTypeCode>
                        <PriceSpecificationElementTypeName>Calc. Export Cost</PriceSpecificationElementTypeName>
                        <PriceSpecificationElementCategoryCode>1</PriceSpecificationElementCategoryCode>
                        <PriceSpecificationElementCategoryName>Price</PriceSpecificationElementCategoryName>
                        <ValidityPeriod>
                            <IntervalBoundaryTypeCode>3</IntervalBoundaryTypeCode>
                            <StartTimePoint>
                                <TypeCode>1</TypeCode>
                                <Date>2023-02-14</Date>
                            </StartTimePoint>
                            <EndTimePoint>
                                <TypeCode>1</TypeCode>
                                <Date>9999-12-31</Date>
                            </EndTimePoint>
                        </ValidityPeriod>
                        <Amount>137.36</Amount>
                        <BaseQuantity>1</BaseQuantity>
                        <OrderPriceAmount>137.36</OrderPriceAmount>
                        <OrderBaseQuantity>1</OrderBaseQuantity>
                    </PriceSpecification>
                </ProcurementPriceInformation>
                <SalesPriceInformation>
                    <ProductStandardID>2245949914</ProductStandardID>
                    <MeasureUnitCode>EA</MeasureUnitCode>
                    <MeasureUnitName>each</MeasureUnitName>
                    <SalesOrganisationID>1001</SalesOrganisationID>
                    <SalesOrganisationFormattedName>Western Cape</SalesOrganisationFormattedName>
                    <DistributionChannelCode>10</DistributionChannelCode>
                    <DistributionChannelName>Supermarket</DistributionChannelName>
                    <PlantName>COD HERMANUS</PlantName>
                    <ValidityPeriod>
                        <StartDate>2022-12-21</StartDate>
                        <EndDate>9999-12-31</EndDate>
                    </ValidityPeriod>
                    <SalesPriceSpecificationLevelCode>1</SalesPriceSpecificationLevelCode>
                    <SalesPriceSpecificationLevelName>Distribution Chain</SalesPriceSpecificationLevelName>
                    <PriceSpecification>
                        <PriceSpecificationElementTypeCode>PB00</PriceSpecificationElementTypeCode>
                        <PriceSpecificationElementTypeName>Calc. Export Cost</PriceSpecificationElementTypeName>
                        <PriceSpecificationElementCategoryCode>1</PriceSpecificationElementCategoryCode>
                        <PriceSpecificationElementCategoryName>Price</PriceSpecificationElementCategoryName>
                        <Amount>8.99</Amount>
                        <BaseQuantity>1</BaseQuantity>
                    </PriceSpecification>
                </SalesPriceInformation>
            </Merchandise>
            <ProcessingConditions>
                <ReturnedQueryHitsNumberValue>1</ReturnedQueryHitsNumberValue>
                <MoreHitsAvailableIndicator>false</MoreHitsAvailableIndicator>
            </ProcessingConditions>
            <Log>
                <BusinessDocumentProcessingResultCode>3</BusinessDocumentProcessingResultCode>
                <MaximumLogItemSeverityCode>1</MaximumLogItemSeverityCode>
                <Item>
                    <TypeID>026(WART_MSG)</TypeID>
                    <SeverityCode>1</SeverityCode>
                    <Note>Names of MaterialMerchandiseTypeCode, ProductTaxationCharacteristics and  can be cut because of longer text in the backend.
                    </Note>
                </Item>
            </Log>
            <AdditionalInfo>
                <TargetSystem>COM</TargetSystem>
                <MeasureUnitCode>EA</MeasureUnitCode>
                <ConditionRecord>2245949914</ConditionRecord>
            </AdditionalInfo>
        </n0:MerchandiseERPByElementsResponseMessage_sync>
    </soap-env:Body>
</soap-env:Envelope>`;
    };
}
