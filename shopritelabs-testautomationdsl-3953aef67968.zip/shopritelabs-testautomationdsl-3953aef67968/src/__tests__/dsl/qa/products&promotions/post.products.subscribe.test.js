import ApiMethodUtil from '../../../__utils__/api_method_util';
import DataHelpers from '../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import DSLProductsSubscribe from "../../data/products.subscribe.data";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";

jest.retryTimes(1);
describe('DSL - Subscribe to a product enhancement process', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const productsubscribe = new DSLProductsSubscribe();

    beforeAll(async () => {

    });

    test('Subscribe to a valid product', async () => {
        const headers = {
            'x-api-key': process.env.EverlyticApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`});
        let json = productsubscribe.get_productsubscribe_payload('10407762EA');
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/products/subscribe`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);
    });

    // test('valid invalid Id number', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json'
    //     };
    //     await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/claims`});
    //     let json = claims.get_claims_payload('9207280055089', '+27662118750');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/claims`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(400);
    //     let {data} = response;
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     //expect(data).toMatchSnapshot();
    // });

    // test('valid invalid mobile number', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json'
    //     };
    //     await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/claims`});
    //     let json = claims.get_claims_payload('8307280055089', '62118750');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/claims`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(400);
    //     let {data} = response;
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     //expect(data).toMatchSnapshot();
    // });

    // test('valid claim with missing id number', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json'
    //     };
    //     await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/claims`});
    //     let json = claims.get_claims_payload('', '+27662118750');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/claims`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(400);
    //     let {data} = response;
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     //expect(data).toMatchSnapshot();
    // });

    // test('valid claim with missing mobile number', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json'
    //     };
    //     await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/claims`});
    //     let json = claims.get_claims_payload('8307280055089', '');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/claims`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(400);
    //     let {data} = response;
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     //expect(data).toMatchSnapshot();
    // });

    // test('valid claim with invalid brand', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json'
    //     };
    //     await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/za/claims`});
    //     let json = claims.get_claims_payload('8307280055089', '+27662118750');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/Okfood/countries/za/claims`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(400);
    //     let {data} = response;
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     //expect(data).toMatchSnapshot();
    // });

    // test('valid claim with invalid country code', async () => {
    //     const headers = {
    //         Authorization: `Bearer ${cognitoDSLToken}`,
    //         'x-api-key': process.env.DSLCIAMApiKey,
    //         'Content-Type': 'application/json'
    //     };
    //     await addMsg({message: `${process.env.DSLGroup}/dsl/brands/shoprite/countries/zim/claims`});
    //     let json = claims.get_claims_payload('8307280055089', '+27662118750');
    //     await addMsg({message: JSON.stringify(json, null, 2)});
    //     const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/zim/claims`, json, headers);
    //     await addMsg({message: JSON.stringify(response.data, null, 2)});
    //     expect(response.status).toBe(400);
    //     let {data} = response;
    //     data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    //     //expect(data).toMatchSnapshot();
    // });
});
