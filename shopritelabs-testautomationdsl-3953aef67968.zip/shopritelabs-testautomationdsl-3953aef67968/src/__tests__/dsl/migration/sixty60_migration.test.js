import DataHelpers from '../../__utils__/data_helpers';
import DSLCustomer from '../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import {appendFileSync} from "fs";
import ApiMethodUtil from "../../__utils__/api_method_util";
import {faker} from "@faker-js/faker";
import moment from "moment";
import CIAMAuth from "../../__utils__/auth/ciam/auth.methods";

describe('MoneyMarketPOS - Customer endpoints E2E', () => {
    const apiCall = new ApiMethodUtil();
    const dSLCustomer = new DSLCustomer();
    const dataHelpers = new DataHelpers();
    const ciamAuth = new CIAMAuth();
    let dateString;

    beforeAll(async () => {
        dateString = moment().format('YYYYMMDDhhmm');
    });
    // https://prep.shopritegroup.co.za/dsl/brands/checkers/countries/ZA/promotions/ranked?uid=754cb7b0-4319-407f-b17f-c42b266c645f&scenarioType=CHECKERS_RD&channel=WHATSAPP

    test.skip('Create CSV with existing CIAM customers', async () => {
        let fileName = `./src/__tests__/dsl/migration/data/${globalThis.environment}_customers_${dateString}.csv`;
        let header = '6060_externalMemberId,6060_firstName,6060_lastName,6060_mobile,6060_email\n';
        appendFileSync(fileName, header);
        for (let i = 1; i <= 3; i++) {
            const padString = (str, len) => {
                if (str.length < len) {
                    const random = dataHelpers.generateRandomNumber(1, 10);
                    return padString(str + random, len);
                }
                return str;
            };
            let json = await dSLCustomer.create_customer_valid_partial('checkers', false);
            json = dataHelpers.setValueInJson(json, 'userDetails.type', 'WEB');
            const firstName = json.userDetails.firstName;
            const lastName = json.userDetails.lastName;
            const dob = json.userDetails.birthDate.split('/').reverse().join('-');
            const mobileNumber = json.contactDetails[0].value;
            json.identity.shift();
            let emailAddr = `${firstName}-${lastName}@sixty60-migration.com`;
            let emailAddrUpdated = `${firstName}-${lastName}@sixty60-migration-updated.com`;
            let passportNumber = padString('MIG', 10);
            let email = {
                "description": "Contact Type by Automation",
                "id": "05",
                "type": "Email",
                "value": emailAddr
            };
            let passport = {
                "type": "PASSPORT",
                "value": passportNumber
            };
            json.contactDetails.push(email);
            json.identity.push(passport);
            await addMsg({message: JSON.stringify(json, null, 2)});
            const headers = {
                Authorization: `Bearer ${cognitoDSLToken}`,
                'x-api-key': process.env.DSLCIAMApiKey,
                'Content-Type': 'application/json'
            };
            const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headers);
            await addMsg({message: JSON.stringify(response.data, null, 2)});
            expect(response.status).toBe(200);
            expect(response.data.response.uuid).not.toBeNull();
            // const csv = `${response.data.response.uuid},${firstName},${lastName},${mobileNumber},${emailAddr},${passportNumber}\n`;
            const csv = `${response.data.response.uuid},${firstName},${lastName},${mobileNumber},${emailAddrUpdated}\n`;
            try {
                appendFileSync(fileName, csv);
            } catch (err) {
                console.error(err);
            }
        }
    });

    test.skip('Create CSV with customers not in CIAM', async () => {
        let fileName = `./src/__tests__/dsl/migration/data/${globalThis.environment}_customers_not_in_ciam_${dateString}.csv`;
        let header = '6060_externalMemberId,6060_firstName,6060_lastName,6060_mobile,6060_email\n';
        appendFileSync(fileName, header);
        for (let i = 1; i <= 3; i++) {
            let firstName = faker.name.firstName();
            let lastName = faker.name.lastName();
            expect(firstName).toBeDefined();
            const csv = `,${firstName},${lastName},${faker.phone.number('+2783#######')},${faker.internet.userName(firstName, lastName)}@sixty60-migration.test.com\n`;
            try {
                appendFileSync(fileName, csv);
            } catch (err) {
                console.error(err);
            }
        }
    });

    test('get customer', async () => {
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, 'Jaquelin_Littel@sixty60-migration.test.com', 'dsl');

        const headers = {
            'access_token': `${token.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`});

        const response = await apiCall.GET(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let {data} = response;
        expect(response.status).toBe(200);

        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
    });
});
