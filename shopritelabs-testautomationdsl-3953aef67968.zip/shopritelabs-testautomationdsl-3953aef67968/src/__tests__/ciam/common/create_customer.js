import _ from "lodash";
import {faker} from '@faker-js/faker';
import fakeSaIdGenerator from "south-african-fake-id-generator";
import ApiMethodUtil from "../../__utils__/api_method_util";
import DataHelpers from "../../__utils__/data_helpers";

const apiCall = new ApiMethodUtil();
const dataHelpers = new DataHelpers();

export default class CreateCIAMCustomer {
    createValidCIAMCustomerMinimal = async (brand = 'checkers') => {
        let response, surname, mobileNumber, email, name;
        let retryCount = 0;

        do {
            name = _.startCase(_.toLower(faker.name.firstName()));
            surname = _.startCase(_.toLower(faker.name.lastName()));
            email = `${name}-${surname}@shoprite-testautomation.com`;
            mobileNumber = dataHelpers.generatePhoneNumber(true);
            const saIdNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
                min: 18,
                max: 99
            }));
            const dob = this.formatDOB(saIdNumber.substring(0, 6));

            const json = this.buildJson(name, surname, dob, mobileNumber, email, saIdNumber);
            const headers = this.buildHeaders();

            response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/${brand}/countries/za/users/partialuser`, json, headers);
            await new Promise((r) => setTimeout(r, 10000));
            retryCount++;
        } while (response.status !== 200 && retryCount < 3);

        if (response.status !== 200) {
            throw new Error(`Failed to create customer after ${retryCount} retries`);
        }

        return this.buildReturnObject(response, name, surname, mobileNumber, email);
    };

    formatDOB = (date) => {
        return date.startsWith('0') ? `${date.charAt(4)}${date.charAt(5)}/${date.charAt(2)}${date.charAt(3)}/20${date.charAt(0)}${date.charAt(1)}` : `${date.charAt(4)}${date.charAt(5)}/${date.charAt(2)}${date.charAt(3)}/19${date.charAt(0)}${date.charAt(1)}`;
    };

    buildJson = (name, surname, dob, mobileNumber, email, saIdNumber) => {
        return {
            "identity": [{
                "type": "SAID",
                "value": saIdNumber
            }],
            "userDetails": {
                "firstName": name,
                "lastName": surname,
                "type": "whatsapp",
                "birthDate": dob
            },
            "contactDetails": [
                {
                    "description": "Contact Type by Automation",
                    "id": "05",
                    "type": "Mobile",
                    "value": mobileNumber
                },
                {
                    "description": "Contact Type by Automation",
                    "id": "05",
                    "type": "Email",
                    "value": email
                }
            ]
        };
    };

    buildHeaders = () => {
        return {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
    };

    buildReturnObject = (response, name, surname, mobileNumber, email) => {
        return {
            uuid: response.data.response.uuid,
            firstName: name,
            lastName: surname,
            mobileNumber: mobileNumber,
            email: email
        };
    };
}
