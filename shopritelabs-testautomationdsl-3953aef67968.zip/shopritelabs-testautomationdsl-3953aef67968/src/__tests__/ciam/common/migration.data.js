import {faker} from '@faker-js/faker';
import moment from "moment";
import {v4} from "uuid";
import fakeSaIdGenerator from "south-african-fake-id-generator";
import DataHelpers from "../../__utils__/data_helpers";

const dataHelpers = new DataHelpers();
export default class MigrationCustomer {

    create = async () => {
        let firstName = faker.name.firstName();
        let lastName = faker.name.lastName();
        let mobileNumber = dataHelpers.generatePhoneNumber(true);
        let email = `${name}-${surname}@shoprite-testautomation.com`;
        let birthDate = faker.date.between('1910-01-01', '2001-01-01');
        let dob = moment(new Date(birthDate)).format('YYYY-MM-DD');
        let customerId = v4();
        let idNumber = `ZA-${fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }))}`;
        let cardNum = `97100850${faker.datatype.number({
            min: 10000000,
            max: 99999999
        }).toString()}`;
        let date = moment(new Date()).format('YYYY-MM-DD h:mm:ss ') + '+0000';
        return {
            "givenName": firstName,
            "email": email,
            "mobileNumber": mobileNumber,
            "birthday": dob,
            "personalIdentifications": {
                "passport": {
                    "clientId": null,
                    "context": null,
                    "updated": null,
                    "number": null
                },
                "nationalIdentification": {
                    "clientId": null,
                    "context": null,
                    "updated": date,
                    "number": idNumber
                }
            },
            "familyName": lastName,
            "cards": {
                "za": {
                    "rewards": {
                        "checkers": {
                            "clientId": null,
                            "status": null,
                            "context": null,
                            "createdDate": null,
                            "updated": null,
                            "number": null
                        },
                        "shoprite": {
                            "clientId": null,
                            "status": "inactive",
                            "context": null,
                            "createdDate": date,
                            "updated": date,
                            "number": cardNum
                        }
                    }
                }
            },
            "emailVerified": date,
            "mobileNumberVerified": date,
            "retailServices": {
                "xtraSavings": {
                    "za": {
                        "checkers": {
                            "memberInfo": {
                                "clientId": customerId,
                                "context": "",
                                "householdId": customerId,
                                "registrationChannel": "WEB",
                                "memberId": customerId,
                                "registrationAgent": "ussd",
                                "customerCreateDate": date,
                                "preferredStore": "3301",
                                "inferredStore": "3301"
                            },
                            "consents": {
                                "termsOfService": {
                                    "consentVersion": "1",
                                    "clientId": null,
                                    "granted": true,
                                    "context": "MIG",
                                    "consentName": "checkers-za-rewards-consent",
                                    "parentalConsent": true,
                                    "parentalConsentUpdated": "2021-01-26",
                                    "updated": "2021-01-26"
                                },
                                "marketing": {
                                    "consentVersion": null,
                                    "clientId": null,
                                    "granted": false,
                                    "context": null,
                                    "consentName": 'checkers-za-marketing-consent',
                                    "parentalConsent": null,
                                    "parentalConsentUpdated": null,
                                    "updated": null
                                }
                            },
                            "personalInterests": {
                                "cfsNewsletter": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inBaby": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "sfgLunchboxFund": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "yrCBW": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "sfgAACL": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chWorldOfCheckersNewsletter": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "sfgFoodAndTreesForAfrica": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chLiquorshop": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inHealthAndBeauty": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inSpecialsAndPromotions": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chClothAndFoot": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chVineSociety": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chBabyAndParenting": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "cfsB2B": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inVegetarian": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chBackToSchool": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chWhiskySociety": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inWine": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inKids": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chWorldofWhiskey": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "cfsB2C": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inCoffee": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "sfgSPCA": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inDog": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inLiquor": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inBraai": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inHealthyLiving": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inCat": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chSurvey": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                }
                            },
                            "contactPreferences": {
                                "email": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": email,
                                    "updated": date,
                                    "type": "EMAIL"
                                },
                                "whatsApp": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": mobileNumber,
                                    "updated": date,
                                    "type": "WHATSAPP"
                                },
                                "sms": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": mobileNumber,
                                    "updated": date,
                                    "type": "SMS"
                                },
                                "mobileApp": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": false,
                                    "addressValue": email,
                                    "updated": null,
                                    "type": "mobileApp"
                                }
                            }
                        },
                        "shoprite": {
                            "consents": {
                                "termsOfService": {
                                    "consentVersion": "1",
                                    "clientId": null,
                                    "granted": true,
                                    "context": "MIG",
                                    "consentName": "shoprite-za-rewards-consent",
                                    "parentalConsent": true,
                                    "parentalConsentUpdated": "2021-01-26",
                                    "updated": "2021-01-26"
                                },
                                "marketing": {
                                    "consentVersion": null,
                                    "clientId": null,
                                    "granted": false,
                                    "context": null,
                                    "consentName": 'shoprite-za-marketing-consent',
                                    "parentalConsent": null,
                                    "parentalConsentUpdated": null,
                                    "updated": null
                                }
                            },
                            "personalInterests": {
                                "srInGroceryEssentials": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInCleanhome": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srSwipeForCover": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInWineLovers": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "yrCBW": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInHomebar": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInGreatOutdoors": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srLiquorshop": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srBaby": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srAutoAirtime": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srWine": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srWorldOfShoprite": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInLookingGood": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srBackToSchool": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInHealthyLiving": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInPartiesAndTreats": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInBraaiAndGrill": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInBabyAndKids": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInCat": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srB2B": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInFamilyMeals": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srSfgSanitary": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srSurvey": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srHustle": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                }
                            },
                            "contactPreferences": {
                                "email": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": email,
                                    "updated": date,
                                    "type": "EMAIL"
                                },
                                "whatsApp": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": mobileNumber,
                                    "updated": date,
                                    "type": "WHATSAPP"
                                },
                                "sms": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": mobileNumber,
                                    "updated": date,
                                    "type": "SMS"
                                },
                                "mobileApp": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": false,
                                    "addressValue": email,
                                    "updated": null,
                                    "type": "mobileApp"
                                }
                            },
                            "memberInfo": {
                                "clientId": null,
                                "context": null,
                                "registrationChannel": "WEB",
                                "preferredStore": "6543",
                                "memberId": customerId,
                                "registrationAgent": null,
                                "householdId": customerId,
                                "customerCreateDate": date,
                                "inferredStore": null,
                                "updated": date,
                                "rewardServices": {
                                    "swipeForCover": {
                                        "recipientMobile": "+27832766784",
                                        "recipientFirstName": "Timmy",
                                        "recipientLastName": "O'Higgins",
                                        "updated": date
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };
    };
    createFull = async () => {
        let firstName = faker.name.firstName();
        let lastName = faker.name.lastName();
        let mobileNumber = dataHelpers.generatePhoneNumber(true);
        let email = `${name}-${surname}@shoprite-testautomation.com`;
        let birthDate = faker.date.between('1910-01-01', '2001-01-01');
        let dob = moment(new Date(birthDate)).format('YYYY-MM-DD');
        let customerId = v4();
        let idNumber = `ZA-${fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }))}`;
        let cardNum = `97100850${faker.datatype.number({
            min: 10000000,
            max: 99999999
        }).toString()}`;
        let date = moment(new Date()).format('YYYY-MM-DD h:mm:ss ') + '+0000';
        return {
            "givenName": firstName,
            "email": email,
            "mobileNumber": mobileNumber,
            "birthday": dob,
            "personalIdentifications": {
                "passport": {
                    "clientId": null,
                    "context": null,
                    "updated": null,
                    "number": null
                },
                "nationalIdentification": {
                    "clientId": null,
                    "context": null,
                    "updated": date,
                    "number": idNumber
                }
            },
            "familyName": lastName,
            "cards": {
                "za": {
                    "rewards": {
                        "checkers": {
                            "clientId": null,
                            "status": null,
                            "context": null,
                            "createdDate": null,
                            "updated": null,
                            "number": null
                        },
                        "shoprite": {
                            "clientId": null,
                            "status": "inactive",
                            "context": null,
                            "createdDate": date,
                            "updated": date,
                            "number": cardNum
                        }
                    }
                }
            },
            "emailVerified": date,
            "mobileNumberVerified": date,
            "retailServices": {
                "xtraSavings": {
                    "za": {
                        "checkers": {
                            "memberInfo": {
                                "clientId": customerId,
                                "context": "",
                                "householdId": customerId,
                                "registrationChannel": "WEB",
                                "memberId": customerId,
                                "registrationAgent": "ussd",
                                "customerCreateDate": date,
                                "preferredStore": "3301",
                                "inferredStore": "3301"
                            },
                            "consents": {
                                "termsOfService": {
                                    "consentVersion": "1",
                                    "clientId": null,
                                    "granted": true,
                                    "context": "MIG",
                                    "consentName": "checkers-za-rewards-consent",
                                    "parentalConsent": true,
                                    "parentalConsentUpdated": "2021-01-26",
                                    "updated": "2021-01-26"
                                },
                                "marketing": {
                                    "consentVersion": null,
                                    "clientId": null,
                                    "granted": false,
                                    "context": null,
                                    "consentName": 'checkers-za-marketing-consent',
                                    "parentalConsent": null,
                                    "parentalConsentUpdated": null,
                                    "updated": null
                                }
                            },
                            "contactPreferences": {
                                "email": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": email,
                                    "updated": date,
                                    "type": "EMAIL"
                                },
                                "whatsApp": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": mobileNumber,
                                    "updated": date,
                                    "type": "WHATSAPP"
                                },
                                "sms": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": mobileNumber,
                                    "updated": date,
                                    "type": "SMS"
                                },
                                "mobileApp": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": false,
                                    "addressValue": email,
                                    "updated": null,
                                    "type": "mobileApp"
                                }
                            },
                            "personalInterests": {
                                "cfsNewsletter": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inBaby": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "sfgLunchboxFund": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "yrCBW": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "sfgAACL": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chWorldOfCheckersNewsletter": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "sfgFoodAndTreesForAfrica": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chLiquorshop": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inHealthAndBeauty": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inSpecialsAndPromotions": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chClothAndFoot": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chVineSociety": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chBabyAndParenting": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "cfsB2B": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inVegetarian": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chBackToSchool": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chWhiskySociety": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inWine": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inKids": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chWorldofWhiskey": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "cfsB2C": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inCoffee": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "sfgSPCA": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inDog": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inLiquor": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inBraai": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inHealthyLiving": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "inCat": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "chSurvey": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                }
                            }
                        },
                        "shoprite": {
                            "consents": {
                                "termsOfService": {
                                    "consentVersion": "1",
                                    "clientId": null,
                                    "granted": true,
                                    "context": "MIG",
                                    "consentName": "shoprite-za-rewards-consent",
                                    "parentalConsent": true,
                                    "parentalConsentUpdated": "2021-01-26",
                                    "updated": "2021-01-26"
                                },
                                "marketing": {
                                    "consentVersion": null,
                                    "clientId": null,
                                    "granted": false,
                                    "context": null,
                                    "consentName": 'shoprite-za-marketing-consent',
                                    "parentalConsent": null,
                                    "parentalConsentUpdated": null,
                                    "updated": null
                                }
                            },
                            "personalInterests": {
                                "srInGroceryEssentials": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInCleanhome": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srSwipeForCover": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInWineLovers": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "yrCBW": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInHomebar": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInGreatOutdoors": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srLiquorshop": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srBaby": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srAutoAirtime": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srWine": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srWorldOfShoprite": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInLookingGood": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srBackToSchool": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInHealthyLiving": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInPartiesAndTreats": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInBraaiAndGrill": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInBabyAndKids": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInCat": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srB2B": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srInFamilyMeals": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srSfgSanitary": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srSurvey": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                },
                                "srHustle": {
                                    "clientId": "",
                                    "optIn": true,
                                    "identifier": "123",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                }
                            },
                            "contactPreferences": {
                                "email": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": email,
                                    "updated": date,
                                    "type": "EMAIL"
                                },
                                "whatsApp": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": mobileNumber,
                                    "updated": date,
                                    "type": "WHATSAPP"
                                },
                                "sms": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": true,
                                    "addressValue": mobileNumber,
                                    "updated": date,
                                    "type": "SMS"
                                },
                                "mobileApp": {
                                    "clientId": null,
                                    "granted": true,
                                    "context": null,
                                    "addressVerified": false,
                                    "addressValue": email,
                                    "updated": null,
                                    "type": "mobileApp"
                                }
                            },
                            "memberInfo": {
                                "clientId": null,
                                "context": null,
                                "registrationChannel": "WEB",
                                "preferredStore": "6543",
                                "memberId": customerId,
                                "registrationAgent": null,
                                "householdId": customerId,
                                "customerCreateDate": date,
                                "inferredStore": null,
                                "updated": date,
                                "rewardServices": {
                                    "swipeForCover": {
                                        "recipientMobile": "+27832766784",
                                        "recipientFirstName": "Timmy",
                                        "recipientLastName": "O'Higgins",
                                        "updated": date
                                    }
                                }
                            }
                        }
                    }
                },
                "sixty60": {
                    "za": {
                        "checkers": {
                            "consents": {
                                "termsOfService": {
                                    "clientId": customerId,
                                    "granted": true,
                                    "context": "MIG",
                                    "parentalConsent": true,
                                    "parentalConsentUpdated": null,
                                    "consentName": "sixty60-za-rewards-consent",
                                    "consentVersion": "1",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                }
                            },
                            "contactPreferences": {
                                "email": {
                                    "clientId": customerId,
                                    "granted": true,
                                    "context": "MIG",
                                    "addressVerified": true,
                                    "type": "EMAIL",
                                    "addressValue": email
                                },
                                "sms": {
                                    "clientId": customerId,
                                    "granted": true,
                                    "context": "MIG",
                                    "addressVerified": true,
                                    "type": "MOBILE",
                                    "addressValue": mobileNumber
                                },
                                "whatsApp": {
                                    "clientId": "",
                                    "granted": true,
                                    "context": "MIG",
                                    "addressVerified": true,
                                    "type": "WHATSAPP",
                                    "addressValue": mobileNumber
                                },
                                "mobileApp": {
                                    "clientId": "",
                                    "granted": true,
                                    "context": "MIG",
                                    "addressVerified": true,
                                    "type": "MOBILE_APP",
                                    "addressValue": "ciTUErVg4sk:APA91bHQ4IA1XFfe3JBEYvNwNxCxIhjI6-BwhMUIpZgf3ro_Sa1EEmbF6zbkvHUHXRBxoGABjBKesoFzcjmkObmd281bG7-hlaO6B3mYt0Hm_CR0Fcv_vGi9eGxQ6brISMijkPeuR8Oi"
                                }
                            },
                            "deliveryAddress1": {
                                "clientId": customerId,
                                "context": "",
                                "type": "House",
                                "Name": "Home Address",
                                "complexName": "La Vista",
                                "unitNumber": "1",
                                "deliveryNotes": "",
                                "streetNumber": faker.address.streetNumber,
                                "street": faker.address.streetName,
                                "suburb": faker.address.county,
                                "city": faker.address.cityName,
                                "postalCode": faker.address.zipCode
                            },
                            "deliveryAddress2": {
                                "clientId": customerId,
                                "context": "",
                                "type": "House",
                                "Name": "Home Address",
                                "complexName": "La Vista",
                                "unitNumber": "1",
                                "deliveryNotes": "",
                                "streetNumber": faker.address.streetNumber,
                                "street": faker.address.streetName,
                                "suburb": faker.address.county,
                                "city": faker.address.cityName,
                                "postalCode": faker.address.zipCode
                            }
                        }
                    }
                },
                "moneyMarket": {
                    "za": {
                        "checkers": {
                            "consents": {
                                "termsOfService": {
                                    "clientId": customerId,
                                    "granted": true,
                                    "context": "MIG",
                                    "parentalConsent": true,
                                    "parentalConsentUpdated": null,
                                    "consentName": "MMAtermsandconditions",
                                    "consentVersion": "1",
                                    "updated": "2021-08-12 13:16:19.310273 +0000"
                                }
                            },
                            "contactPreferences": {
                                "email": {
                                    "clientId": customerId,
                                    "granted": true,
                                    "context": "MIG",
                                    "addressVerified": true,
                                    "type": "EMAIL",
                                    "addressValue": email
                                },
                                "sms": {
                                    "clientId": customerId,
                                    "granted": true,
                                    "context": "MIG",
                                    "addressVerified": true,
                                    "type": "MOBILE",
                                    "addressValue": mobileNumber
                                },
                                "whatsApp": {
                                    "clientId": "",
                                    "granted": true,
                                    "context": "MIG",
                                    "addressVerified": true,
                                    "type": "WHATSAPP",
                                    "addressValue": mobileNumber
                                },
                                "mobileApp": {
                                    "clientId": "",
                                    "granted": true,
                                    "context": "MIG",
                                    "addressVerified": true,
                                    "type": "MOBILE_APP",
                                    "addressValue": "ciTUErVg4sk:APA91bHQ4IA1XFfe3JBEYvNwNxCxIhjI6-BwhMUIpZgf3ro_Sa1EEmbF6zbkvHUHXRBxoGABjBKesoFzcjmkObmd281bG7-hlaO6B3mYt0Hm_CR0Fcv_vGi9eGxQ6brISMijkPeuR8Oi"
                                }
                            },
                            "deliveryAddress1": {
                                "clientId": customerId,
                                "context": "",
                                "type": "House",
                                "Name": "Home Address",
                                "complexName": "La Vista",
                                "unitNumber": "1",
                                "deliveryNotes": "",
                                "streetNumber": faker.address.streetNumber,
                                "street": faker.address.streetName,
                                "suburb": faker.address.county,
                                "city": faker.address.cityName,
                                "postalCode": faker.address.zipCode
                            },
                            "deliveryAddress2": {
                                "clientId": customerId,
                                "context": "",
                                "type": "House",
                                "Name": "Home Address",
                                "complexName": "La Vista",
                                "unitNumber": "1",
                                "deliveryNotes": "",
                                "streetNumber": faker.address.streetNumber,
                                "street": faker.address.streetName,
                                "suburb": faker.address.county,
                                "city": faker.address.cityName,
                                "postalCode": faker.address.zipCode
                            }
                        }
                    }
                }
            }
        };
    };
}
