'use strict';
import {faker} from '@faker-js/faker';
import moment from "moment";
import fakeSaIdGenerator from 'south-african-fake-id-generator';
import CardService from "../../__utils__/cards/cardService";
import DataHelpers from "../../__utils__/data_helpers";

const cardService = new CardService();
const dataHelpers = new DataHelpers();
export default class DSLCustomer {
    /**
     * Create DSL Customer
     * @param name
     * @param surname
     * @param email
     * @param mobileNumber
     * @param saIdNumber
     * @param birthDate
     * @param titleCode
     * @param cardNumber
     * @param password
     * @returns {Object} {preferredStoreId: string, firstName, lastName, uid, password: string, mobileNumber, saIdNumber, birthDate, titleCode}
     */
    create_customer_full = (name, surname, email, mobileNumber, saIdNumber, birthDate, titleCode, cardNumber, password) => {
        return {
            "preferredStoreId": "1103",
            "firstName": name,
            "lastName": surname,
            "uid": email,
            "mobileNumber": mobileNumber,
            "saIdNumber": saIdNumber,
            "birthDate": birthDate,
            "titleCode": titleCode,
            "cardNumber": cardNumber,
            "password": password
        };
    };

    /**
     * Create DSL Customer
     * @param name
     * @param surname
     * @param email
     * @param mobileNumber
     * @param saIdNumber
     * @param birthDate
     * @param cardNumber
     * @param type
     * @returns {Object} {preferredStoreId: string, firstName, lastName, uid, password: string, mobileNumber, saIdNumber, birthDate, titleCode}
     */
    create_customer_partial = (name, surname, email, mobileNumber, saIdNumber, birthDate, cardNumber, type) => {
        return {
            "identity": [
                {
                    "type": "SAID",
                    "value": saIdNumber
                }
            ],
            "userDetails": {
                "firstName": name,
                "lastName": surname,
                "type": type,
                "birthDate": birthDate
            },
            "contactDetails": [
                {
                    "description": "Contact Type by Automation",
                    "id": "05",
                    "type": "Mobile",
                    "value": mobileNumber
                }
            ],
            "foxCard": {
                "active": true,
                "cardNo": cardNumber
            }
        };
    };

    /**
     * Creat full customer with random data
     * @returns {{preferredStoreId: string, firstName: (*), lastName: (*), uid, mobileNumber, saIdNumber: string, birthDate: string, titleCode: string, cardNumber: string}}
     */
    create_customer_valid_full = async (positive) => {
        let cardNumber;
        if (positive) {
            cardNumber = await cardService.getCardOffline();
        }
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let email = `${faker.internet.userName(name, surname)}@shoprite-testautomation.com`;
        let mobileNumber = faker.phone.number('+2783#######');
        let birthDate = faker.date.between('1910-01-01', '2001-01-01');
        let dob = moment(new Date(birthDate)).format('DD/MM/YYYY');
        let saIdNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        let title = "mr";
        // let passport = ${fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({min:18, max:99}))}
        //let password = encode(faker.internet.password())
        return {
            "preferredStoreId": "1103",
            "firstName": name,
            "lastName": surname,
            "email": email,
            "mobileNumber": mobileNumber,
            "saIdNumber": saIdNumber,
            "birthDate": dob,
            "titleCode": title,
            "cardNumber": cardNumber
            // "passport" : passport,
            //  "consentId": "checkers-za-signup",
            // "consentVersion": "1"
        };
    };

    create_customer_valid_partial = async (withCard) => {
        let cardNumber;
        if (withCard) {
            cardNumber = await cardService.getCardOffline();
        }
        let name = faker.name.firstName();
        let surname = faker.name.lastName();
        let mobileNumber = dataHelpers.generatePhoneNumber(true);
        let saIdNumber = fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }));
        let date = saIdNumber.substring(0, 6);
        let dob;
        if (date.startsWith('0')) {
            dob = `${date.charAt(4)}${date.charAt(5)}/${date.charAt(2)}${date.charAt(3)}/20${date.charAt(0)}${date.charAt(1)}`;
        } else {
            dob = `${date.charAt(4)}${date.charAt(5)}/${date.charAt(2)}${date.charAt(3)}/19${date.charAt(0)}${date.charAt(1)}`;
        }
        let json = {
            "identity": [
                {
                    "type": "SAID",
                    "value": saIdNumber
                }
            ],
            "userDetails": {
                "firstName": name,
                "lastName": surname,
                "type": "ussd",
                "birthDate": dob
            },
            "contactDetails": [
                {
                    "description": "Contact Type by Automation",
                    "id": "05",
                    "type": "Mobile",
                    "value": mobileNumber
                }
            ],
            "foxCard": {
                "active": true,
                "cardNumber": cardNumber
            }
        };
        if (!withCard) {
            json = dataHelpers.removeObjectInJson(json, 'foxCard');
        }
        return json;
    };

    /**
     * Generate invalid South African ID Number
     * @returns {string}
     */
    invalidIdNumber = () => {
        return fakeSaIdGenerator.generateInvalidFakeId();
    };
}
