import ApiMethodUtil from "../../../../__utils__/api_method_util";
import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../../__utils__/data_helpers";
import CiamCustomerConsents from "../../data/consents.data";
import _ from "lodash";
import CreateCIAMCustomer from "../../../common/create_customer";

const {addMsg} = require("jest-html-reporters/helper");
const testData = require("../../data/json/sixty60Consent.json");

jest.retryTimes(1);

describe('CIAM - Consents (/ciam/brands/checkers/countries/za/users/$customerId/consents)', () => {
    const apiCall = new ApiMethodUtil();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const consent = new CiamCustomerConsents();
    const customer = new CreateCIAMCustomer();
    let uuid;
    let mobileNumber;

    beforeAll(async () => {
        let newCustomer = await customer.createValidCIAMCustomerMinimal();
        await new Promise((r) => setTimeout(r, 10000));
        uuid = newCustomer.uuid;
        mobileNumber = newCustomer.mobileNumber;
    });

    test('add Sixty60 consents - Marketing', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('Sixty60', 'sixty60-za-marketing-consent', '1', 'Sixty60 marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.marketing.granted).toBe(true);

    });

    test('add Sixty60 consents - TermsAndConditions with spaces', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('Sixty60', 'Sixty60 terms and conditions', '1', 'sixty60-za-termsandconditions', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.termsOfService.consentName).toBe('Sixty60 terms and conditions');
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.termsOfService.granted).toBe(true);

    });

    test('add Money Market consents', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createConsentPayload('MoneyMarketAccount', 'MMAtermsandconditions', '1', 'MoneyMarketAccount marketing consent', true);
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.moneyMarket.za.checkers.consents.termsOfService.consentName).toBe('MMAtermsandconditions');
        expect(response1.data.response.retailServices.moneyMarket.za.checkers.consents.termsOfService.granted).toBe(true);
    });

    test('add multiple Sixty60 consents  - TermsAndConditions without spaces', async () => {
        let newCustomer1 = await customer.createValidCIAMCustomerMinimal();
        let uuidNew = newCustomer1.uuid;
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createMultipleConsentPayload('Sixty60', 'sixty60-za-marketing-consent', '1', 'Sixty60 marketing consent', true,
            'Sixty60', 'sixty60-za-termsandconditions', '1', 'Sixty60 rewards consent', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuidNew}/consents`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, newCustomer1.mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.marketing.granted).toBe(true);
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.termsOfService.consentName).toBe('sixty60-za-termsandconditions');
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.termsOfService.granted).toBe(true);
    });

    test('add multiple Sixty60 consents  - TermsAndConditions with spaces', async () => {
        let newCustomer1 = await customer.createValidCIAMCustomerMinimal();
        let uuidNew = newCustomer1.uuid;
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await consent.createMultipleConsentPayload('Sixty60', 'sixty60-za-marketing-consent', '1', 'Sixty60 marketing consent', true,
            'Sixty60', 'Sixty60 terms and conditions', '1.1.0 Xtra Savings Deals Go Live', 'Sixty60 rewards consent', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuidNew}/consents`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, newCustomer1.mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.termsOfService.consentName).toBe('Sixty60 terms and conditions');
    });

    test('add multiple consents ByteOrbit', async () => {
        let newCustomer1 = await customer.createValidCIAMCustomerMinimal();
        let uuidNew = newCustomer1.uuid;
        const headers = {
            'x-api-key': process.env.byteOrbitCiamApiKey
        };
        let body = await consent.createMultipleConsentPayload('Sixty60', 'sixty60-za-marketing-consent', '1', 'Sixty60 marketing consent', true,
            'Sixty60', 'sixty60-za-termsandconditions', '1', 'Sixty60 rewards consent', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuidNew}/consents`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, newCustomer1.mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.marketing.consentName).toBe('sixty60-za-marketing-consent');
        expect(response1.data.response.retailServices.sixty60.za.checkers.consents.termsOfService.consentName).toBe('sixty60-za-termsandconditions');
    });

    test.each(testData)(`$scenario`, async (testCase) => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'ContentType': 'application/json'
        };
        let body = await consent.createConsentPayload(testCase.retailService, testCase.documentPurposeName, testCase.documentVersion, testCase.consentReason, testCase.granted);

        if (!_.isEmpty(testCase.missingFields)) {
            body = dataHelpers.removeObjectInJson(body, testCase.missingFields);
        }

        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}${testCase.resource}${testCase.parameter}`, body, headers);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toEqual(testCase.expected);
        expect(data).toMatchSnapshot();
    });

    test('add empty object', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {};
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        expect(data.errorMessage).toContain('Cannot construct instance of `java.util.ArrayList`');
    });

    test('add empty consents object', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        const uuid = '7efb7ff6-b8aa-43a7-b9e8-ac501470d0a3';
        let body = {
            "consents": []
        };
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/consents`, body, headers);
        expect(response.status).toBe(400);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
