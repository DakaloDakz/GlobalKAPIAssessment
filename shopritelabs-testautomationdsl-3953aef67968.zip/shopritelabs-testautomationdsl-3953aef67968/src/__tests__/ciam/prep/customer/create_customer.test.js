import ApiMethodUtil from "../../../__utils__/api_method_util";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../__utils__/data_helpers";
import CreateCIAMCustomer from "../../common/create_customer";

const {addMsg} = require("jest-html-reporters/helper");
const testData = require("../data/json/sixty60GetCustomer.json");

jest.retryTimes(1);

describe('CIAM - Get Customer (/ciam/brands/checkers/countries/za/users/$customerId)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const customer = new CreateCIAMCustomer();
    let log = console.log;

    beforeAll(async () => {

    });

    test('getDemographic CIAM Customer', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/73186482-646b-4040-bf53-b5c90f0dcf96`});
        const response = await apiCall.GET(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/73186482-646b-4040-bf53-b5c90f0dcf96`, headers, null);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: dataHelpers.prettify(data)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('get Sixty60 Customer', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/73186482-646b-4040-bf53-b5c90f0dcf96`});
        const response = await apiCall.GET(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/73186482-646b-4040-bf53-b5c90f0dcf96`, headers, null);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: dataHelpers.prettify(data)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
