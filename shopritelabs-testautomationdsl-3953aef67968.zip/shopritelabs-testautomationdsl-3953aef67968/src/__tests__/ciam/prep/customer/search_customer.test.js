import ApiMethodUtil from "../../../__utils__/api_method_util";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../__utils__/data_helpers";
import CiamCustomerConsents from "../data/consents.data";

const {addMsg} = require("jest-html-reporters/helper");
const testData = require("../data/json/CIAMSearchCustomer.json");

jest.retryTimes(1);

describe('CIAM - Search Customer (/ciam/brands/checkers/countries/za/users/search/?filter=${filter})', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const consent = new CiamCustomerConsents();

    beforeAll(async () => {

    });

    test('search Sixty60 Customer', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/search?filter=uuid='6a0310ae-ed9a-47af-9d1d-1c59bffa53a4'`});
        const response = await apiCall.GET(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/search?filter=uuid='6a0310ae-ed9a-47af-9d1d-1c59bffa53a4'`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'results[0].lastUpdated']);
        expect(data).toMatchSnapshot();
    });

    test('search Customer ByteOrbit', async () => {
        const headers = {
            'x-api-key': process.env.byteOrbitCiamApiKey
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/search?filter=uuid='6a0310ae-ed9a-47af-9d1d-1c59bffa53a4`});
        const response = await apiCall.GET(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/search?filter=uuid='6a0310ae-ed9a-47af-9d1d-1c59bffa53a4'`, headers, null);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'results[0].lastUpdated']);
        expect(data).toMatchSnapshot();
    });

    test('search Customer - DSL key', async () => {
        const headers = {
            'x-api-key': process.env.CIAMDSLApiKey
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/search?filter=uuid='6a0310ae-ed9a-47af-9d1d-1c59bffa53a4`});
        const response = await apiCall.GET(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/search?filter=uuid='6a0310ae-ed9a-47af-9d1d-1c59bffa53a4'`, headers, null);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'results[0].lastUpdated']);
        expect(data).toMatchSnapshot();
    });

    test.each(testData)(`$scenario`, async (testCase) => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'ContentType': 'application/json'
        };
        await addMsg({message: `${process.env.CIAM}${testCase.resource}${testCase.parameter ?? ""}`});
        const response = await apiCall.GET(`${process.env.CIAM}${testCase.resource}${testCase.parameter ?? ""}`, headers, null);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.requestId', 'results[0].lastUpdated']);
        expect(response.status).toEqual(testCase.expected);
        expect(data).toMatchSnapshot();
    });
});
