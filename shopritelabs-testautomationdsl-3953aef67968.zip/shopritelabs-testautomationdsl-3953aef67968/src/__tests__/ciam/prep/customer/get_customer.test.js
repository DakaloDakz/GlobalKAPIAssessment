import ApiMethodUtil from "../../../__utils__/api_method_util";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../__utils__/data_helpers";
import CreateCIAMCustomer from "../../common/create_customer";
import _ from "lodash";

const {addMsg} = require("jest-html-reporters/helper");
const testData = require("../data/json/sixty60GetCustomer.json");

jest.retryTimes(1);

describe('CIAM - Get Customer (/ciam/brands/checkers/countries/za/users/$customerId)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const customer = new CreateCIAMCustomer();

    beforeAll(async () => {

    });

    test('get Sixty60 Customer', async () => {
        let newCustomer = await customer.createValidCIAMCustomerMinimal();
        let uuid = newCustomer.uuid;
        await addMsg({message: dataHelpers.prettify(newCustomer)});
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}`});
        const response = await apiCall.GET(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}`, headers, null);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        expect(data.response.uuid).toBe(uuid);
    });

    test('get Customer ByteOrbit', async () => {
        let newCustomer = await customer.createValidCIAMCustomerMinimal();
        let uuid = newCustomer.uuid;
        await addMsg({message: dataHelpers.prettify(newCustomer)});
        const headers = {
            'x-api-key': process.env.byteOrbitCiamApiKey
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}`});
        const response = await apiCall.GET(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response.uuid).toBe(uuid);
    });

    test('get Customer DSL API Key', async () => {
        let newCustomer = await customer.createValidCIAMCustomerMinimal();
        let uuid = newCustomer.uuid;
        await addMsg({message: dataHelpers.prettify(newCustomer)});
        const headers = {
            'x-api-key': process.env.CIAMDSLApiKey
        };
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}`});
        const response = await apiCall.GET(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}`, headers, null);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        expect(data.response.uuid).toBe(uuid);
    });

    test.each(testData)(`$scenario`, async (testCase) => {
        let headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'ContentType': 'application/json'
        };
        if (testCase.scenario === 'Sixty60 get Customer using Hybris ID with different API key' || testCase.scenario === 'Sixty60 get Customer using CIAM UUID with different API key') {
            headers = {
                'x-api-key': process.env.CIAMC4CApiKey,
                'ContentType': 'application/json'
            };
        }
        if (testCase.scenario === 'Sixty60 get Customer using invalid API key') {
            headers = {
                'x-api-key': testCase.password,
                'ContentType': 'application/json'
            };
        }
        await addMsg({message: `${process.env.CIAM}${testCase.resource}`});
        const response = await apiCall.GET(`${process.env.CIAM}${testCase.resource}`, headers, null);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.requestId', 'response.lastUpdated']);
        if (response.status === 200) {
            if (testCase.scenario !== 'Sixty60 get Customer using invalid CIAM UUID') {
                expect(_.isEmpty(data.response)).toBe(false);
            }
        }
        expect(response.status).toEqual(testCase.expected);
        expect(data).toMatchSnapshot();
    });
});
