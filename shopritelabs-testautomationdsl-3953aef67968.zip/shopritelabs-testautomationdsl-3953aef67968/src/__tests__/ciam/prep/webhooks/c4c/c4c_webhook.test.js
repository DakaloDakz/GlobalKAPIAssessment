import ApiMethodUtil from "../../../../__utils__/api_method_util";
import Authentication from "../../../../__utils__/auth/ciam/auth.methods";
import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../../__utils__/data_helpers";
import {faker} from '@faker-js/faker';

const {addMsg} = require("jest-html-reporters/helper");

// jest.retryTimes(3)
describe('CIAM - C4C Webhook', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const ciamAuth = new CIAMAuth();
    let email;
    let mobileNumber;
    let customerID;
    let firstName;
    let lastName;
    let cardNumber;
    let uuid;
    let access;
    let new_Email;

    beforeAll(async () => {
        access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27843621759', 'dsl');
    });

    test('get CIAM Customer Information', async () => {
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        email = response1.data.response.email;
        mobileNumber = response1.data.response.mobileNumber;
        customerID = '9e6fe8c2-af6c-42f8-827c-b99642fe7c8f';
        firstName = response1.data.response.givenName;
        lastName = response1.data.response.familyName;
        cardNumber = response1.data.response.cards.za.rewards.checkers.number;
        uuid = '9e6fe8c2-af6c-42f8-827c-b99642fe7c8f';
    });

    test.skip('check CIAM Customer Information in C4C', async () => {
        await addMsg({message: `https://soaqaint1.shoprite.co.za/dev/sap/c4c/individual/customer/service/sap/c4c/odata/v1/c4codataapi/IndividualCustomerCollection?%24filter=NormalisedMobile+eq+%27%2B${mobileNumber}%27&%24filter=Email+eq+%27${email}%27`});
        const response = await apiCall.GET(`https://soaqaint1.shoprite.co.za/dev/sap/c4c/individual/customer/service/sap/c4c/odata/v1/c4codataapi/IndividualCustomerCollection?%24filter=NormalisedMobile+eq+%27%2B${mobileNumber}%27&%24filter=Email+eq+%27${email}%27`, await auth.c4c_auth(), null);
        expect(response.status).toBe(200);
        let {data} = response;
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].Email')).toEqual(email);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].FirstName')).toEqual(firstName);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].LastName')).toEqual(lastName);
    });

    let new_FirstName;

    test('update Customer FirstName in CIAM', async () => {
        new_FirstName = firstName + "updated";
        const json = {
            "firstName": new_FirstName,
            "lastName": lastName,
            "mobileNumber": mobileNumber,
            "email": email
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${access.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test.skip('check CIAM Customer in C4C after FirstName update', async () => {
        await new Promise((r) => setTimeout(r, 30000));
        await addMsg({message: `https://soaqaint1.shoprite.co.za/dev/sap/c4c/individual/customer/service/sap/c4c/odata/v1/c4codataapi/IndividualCustomerCollection?%24filter=NormalisedMobile+eq+%27%2B${mobileNumber}%27&%24filter=Email+eq+%27${email}%27`});
        const response = await apiCall.GET(`https://soaqaint1.shoprite.co.za/dev/sap/c4c/individual/customer/service/sap/c4c/odata/v1/c4codataapi/IndividualCustomerCollection?%24filter=NormalisedMobile+eq+%27%2B${mobileNumber}%27&%24filter=Email+eq+%27${email}%27`, await auth.c4c_auth(), null);
        expect(response.status).toBe(200);
        let {data} = response;
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].Email')).toEqual(email);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].NormalisedMobile')).toEqual(mobileNumber);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].FirstName')).toEqual(new_FirstName);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].LastName')).toEqual(lastName);
    });

    let new_LastName;

    test('update Customer LastName in CIAM', async () => {
        new_LastName = lastName + "updated";
        const json = {
            "firstName": new_FirstName,
            "lastName": new_LastName,
            "mobileNumber": mobileNumber,
            "email": email
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${access.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test.skip('check CIAM Customer in C4C after LastName update', async () => {
        await new Promise((r) => setTimeout(r, 30000));
        await addMsg({message: `https://soaqaint1.shoprite.co.za/dev/sap/c4c/individual/customer/service/sap/c4c/odata/v1/c4codataapi/IndividualCustomerCollection?%24filter=NormalisedMobile+eq+%27%2B${mobileNumber}%27&%24filter=Email+eq+%27${email}%27`});
        const response = await apiCall.GET(`https://soaqaint1.shoprite.co.za/dev/sap/c4c/individual/customer/service/sap/c4c/odata/v1/c4codataapi/IndividualCustomerCollection?%24filter=NormalisedMobile+eq+%27%2B${mobileNumber}%27&%24filter=Email+eq+%27${email}%27`, await auth.c4c_auth(), null);
        expect(response.status).toBe(200);
        let {data} = response;
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].Email')).toEqual(email);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].NormalisedMobile')).toEqual(mobileNumber);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].FirstName')).toEqual(new_FirstName);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].LastName')).toEqual(new_LastName);
    });

    test('update Customer Email in CIAM', async () => {
        new_Email = `${faker.internet.userName(new_FirstName, new_LastName)}@shoprite-testautomation.com`;
        const json = {
            "firstName": new_FirstName,
            "lastName": new_LastName,
            "email": new_Email
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${access.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });

    test.skip('check CIAM Customer in C4C after Email update', async () => {
        await new Promise((r) => setTimeout(r, 50000));
        await addMsg({message: `https://soaqaint1.shoprite.co.za/dev/sap/c4c/individual/customer/service/sap/c4c/odata/v1/c4codataapi/IndividualCustomerCollection?%24filter=NormalisedMobile+eq+%27%2B${mobileNumber}%27&%24filter=Email+eq+%27${new_Email}%27`});
        const response = await apiCall.GET(`https://soaqaint1.shoprite.co.za/dev/sap/c4c/individual/customer/service/sap/c4c/odata/v1/c4codataapi/IndividualCustomerCollection?%24filter=NormalisedMobile+eq+%27%2B${mobileNumber}%27&%24filter=Email+eq+%27${new_Email}%27`, await auth.c4c_auth(), null);
        expect(response.status).toBe(200);
        let {data} = response;
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].Email')).toEqual(new_Email);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].FirstName')).toEqual(new_FirstName);
        expect(dataHelpers.getValueFromJson(data, 'd.results[0].LastName')).toEqual(new_LastName);
    });

    test('reset data', async () => {
        const json = {
            "firstName": 'Marilyne',
            "lastName": 'Wiza',
            "mobileNumber": '+27843621759',
            "email": 'Marilyne.Wiza@shoprite-testautomation.com'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headers = {
            'access_token': `${access.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const response = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response.uuid).not.toBeNull();
    });
});
