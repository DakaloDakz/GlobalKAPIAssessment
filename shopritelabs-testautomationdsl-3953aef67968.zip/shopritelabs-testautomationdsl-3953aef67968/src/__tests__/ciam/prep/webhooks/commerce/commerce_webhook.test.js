import ApiMethodUtil from "../../../../__utils__/api_method_util";
import DataHelpers from '../../../../__utils__/data_helpers';
import DSLCustomer from '../../../data/customer.data';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../../../__utils__/auth/commerce/auth.methods";

jest.retryTimes(1);
describe('CIAM - Commerce Webhook)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const dSLCustomer = new DSLCustomer();
    const ciamAuth = new CIAMAuth();

    beforeAll(async () => {

    });

    test('with valid input data', async () => {
        const json = dSLCustomer.create_customer_valid_full(true);
        const firstName = json.firstName;
        const lastName = json.lastName;
        const cardNumber = json.cardNumber;
        const idNumber = json.saIdNumber;
        const mobileNumber = json.mobileNumber;
        const email = json.email;
        const headers = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const response = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/full`, json, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        let access = await auth.commerceAuth(process.env.CommerceUrl, email, 'dsl');
        console.log(access);
        let userId = email;
        const Commerceheaders = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.CommerceUrl}/shopritewebservices/v2/checkersZA/users/${userId}`});
        const response1 = await apiCall.GET(`${process.env.CommerceUrl}/shopritewebservices/v2/checkersZA/users/${userId}`, Commerceheaders, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
// let {data} = response;
// data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    });
});
