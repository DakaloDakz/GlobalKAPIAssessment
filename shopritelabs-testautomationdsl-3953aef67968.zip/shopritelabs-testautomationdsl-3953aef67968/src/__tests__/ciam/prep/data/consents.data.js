export default class CiamCustomerConsents {
    /**
     *
     * @param retailService
     * @param documentPurposeName
     * @param documentVersion
     * @param consentReason
     * @param granted
     * @returns {Promise<{consents: [{retailService, communicationEventDocument: [{documentPurposeName, documentVersion}], consentReason, granted}]}>}
     */
    createConsentPayload = async (retailService, documentPurposeName, documentVersion, consentReason, granted) => {
        return {
            "consents": [
                {
                    "retailService": retailService,
                    "communicationEventDocument": [
                        {
                            "documentPurposeName": documentPurposeName,
                            "documentVersion": documentVersion
                        }
                    ],
                    "consentReason": consentReason,
                    "granted": granted
                }
            ]
        };
    };

    /**
     *
     * @param retailService
     * @param documentPurposeName
     * @param documentVersion
     * @param consentReason
     * @param granted
     * @param retailService1
     * @param documentPurposeName1
     * @param documentVersion1
     * @param consentReason1
     * @param granted1
     * @returns {Promise<{consents: [{retailService, communicationEventDocument: [{documentPurposeName, documentVersion}], consentReason, granted}, {retailService, communicationEventDocument: [{documentPurposeName, documentVersion}], consentReason, granted}]}>}
     */
    createMultipleConsentPayload = async (retailService, documentPurposeName, documentVersion, consentReason, granted, retailService1, documentPurposeName1, documentVersion1, consentReason1, granted1) => {
        return {
            "consents": [
                {
                    "retailService": retailService,
                    "communicationEventDocument": [
                        {
                            "documentPurposeName": documentPurposeName,
                            "documentVersion": documentVersion
                        }
                    ],
                    "consentReason": consentReason,
                    "granted": granted
                },
                {
                    "retailService": retailService1,
                    "communicationEventDocument": [
                        {
                            "documentPurposeName": documentPurposeName1,
                            "documentVersion": documentVersion1
                        }
                    ],
                    "consentReason": consentReason1,
                    "granted": granted1
                }
            ]
        };
    };
}