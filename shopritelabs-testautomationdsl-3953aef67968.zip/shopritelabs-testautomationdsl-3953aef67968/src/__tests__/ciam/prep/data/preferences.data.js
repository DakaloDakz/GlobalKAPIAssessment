export default class CiamCustomerPreferences {
    /**
     *
     * @param retailService
     * @param contactPreferenceRole
     * @param addressValue
     * @param granted
     * @returns {Promise<{contactPreferences: [{contactPreferenceRole, retailService, addressValue, granted}]}>}
     */
    createPreferencesPayload = async (retailService, contactPreferenceRole, addressValue, granted) => {
        return {
            "contactPreferences": [
                {
                    "retailService": retailService,
                    "contactPreferenceRole": contactPreferenceRole,
                    "addressValue": addressValue,
                    "granted": granted
                }
            ]
        };
    };

    /**
     *
     * @param retailService
     * @param contactPreferenceRole
     * @param addressValue
     * @param granted
     * @param retailService1
     * @param contactPreferenceRole1
     * @param addressValue1
     * @param granted1
     * @returns {Promise<{contactPreferences: [{contactPreferenceRole, retailService, addressValue, granted}]}>}
     */
    createMultiplePreferencesPayload = async (retailService, contactPreferenceRole, addressValue, granted, retailService1, contactPreferenceRole1, addressValue1, granted1) => {
        return {
            "contactPreferences": [
                {
                    "retailService": retailService,
                    "contactPreferenceRole": contactPreferenceRole,
                    "addressValue": addressValue,
                    "granted": granted
                },
                {
                    "retailService": retailService1,
                    "contactPreferenceRole": contactPreferenceRole1,
                    "addressValue": addressValue1,
                    "granted": granted1
                }
            ]
        };
    };
}