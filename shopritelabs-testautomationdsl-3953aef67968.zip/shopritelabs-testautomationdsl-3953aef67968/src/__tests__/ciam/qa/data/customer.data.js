import {faker} from '@faker-js/faker';
import moment from "moment";
import {v4} from "uuid";
import fakeSaIdGenerator from "south-african-fake-id-generator";
import DataHelpers from "../../../__utils__/data_helpers";

const dataHelpers = new DataHelpers();
export default class CiamCustomer {
    /**
     *
     * @param firstName
     * @param lastName
     * @param mobileNumber
     * @param email
     * @param birthDate
     * @param customerId
     * @param cardNum
     * @param idNumber
     * @returns {Promise<{birthday, personalIdentification: [{number, type: string}], lastName, gender: string, loyalty: [{preferredStore: string, countryOfIssue: string, retailBrand: string, loyaltyBrand: string, otherServices: [{retailService: string, sourceSystem: string, serviceRecipient: [{name: *, contactDetails}]}], customerId, optIn: boolean, cardCreateDate: string, cardNo, registrationAgent: string, registrationChannel: string}], title: string, personalInterests: [{retailBrand: string, optIn: string, typeIdentifier: string, type: string}], firstName, phoneNumber, consents: [{countryOfIssue: string, retailService: string, retailBrand: string, communicationEventDocument: [{documentPurposeName: string, documentVersion: string}], consentReason: string, updated: string, granted: boolean}], middleName: string, contactPreferences: [{contactPreferenceRole: string, retailBrand: string, retailService: string, countryOfIssue: string, addressValue, granted: boolean}], email}>}
     */
    createCIAMCustomerPayload = async (firstName, lastName, mobileNumber, email, birthDate, customerId, cardNum, idNumber) => {
        return {
            "title": "Mr",
            "gender": "male",
            "firstName": firstName,
            "middleName": "",
            "lastName": lastName,
            "phoneNumber": mobileNumber,
            "email": email,
            "birthday": birthDate,
            "contactPreferences": [
                {
                    "contactPreferenceRole": "SMS",
                    "addressValue": mobileNumber,
                    "retailBrand": "Checkers",
                    "retailService": "Sixty60",
                    "countryOfIssue": "ZA",
                    "granted": true
                }
            ],
            "loyalty": [
                {
                    "customerId": customerId,
                    "cardNo": cardNum,
                    "registrationChannel": "WEB",
                    "countryOfIssue": "ZA",
                    "optIn": true,
                    "cardCreateDate": "2020-10-11",
                    "registrationAgent": "ussd",
                    "preferredStore": "1103",
                    "retailBrand": "Checkers",
                    "loyaltyBrand": "Xtra-Savings",
                    "otherServices": [
                        {
                            "retailService": "Vouchers",
                            "sourceSystem": "SAP",
                            "serviceRecipient": [
                                {
                                    "name": firstName + lastName,
                                    "contactDetails": mobileNumber
                                }
                            ]
                        }
                    ]
                }
            ],
            "consents": [
                {
                    "granted": true,
                    "countryOfIssue": "ZA",
                    "retailService": "Sixty60",
                    "retailBrand": "Checkers",
                    "consentReason": "I want to receive marketing information for this product",
                    "updated": "2020-02-01",
                    "communicationEventDocument": [
                        {
                            "documentPurposeName": "rDocumentPurposeName",
                            "documentVersion": "1"
                        }
                    ]
                }
            ],
            "personalIdentification": [
                {
                    "type": "National Identification Number",
                    "number": idNumber
                }
            ],
            "personalInterests": [
                {
                    "retailBrand": "Checkers",
                    "optIn": "Y",
                    "type": "Grocery essentials",
                    "typeIdentifier": "92"
                }
            ]
        };
    };
    createValidCIAMCustomerNewModel = async () => {
        let url = `${process.env.CIAM}/ciam/user`;
        let firstName = faker.name.firstName();
        let lastName = faker.name.lastName();
        let mobileNumber = dataHelpers.generatePhoneNumber(true);
        let email = `${name}-${surname}@shoprite-testautomation.com`;
        let birthDate = faker.date.between('1910-01-01', '2001-01-01');
        let dob = moment(new Date(birthDate)).format('YYYY-MM-DD');
        let customerId = v4();
        let idNumber = `ZA-${fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }))}`;
        let cardNum = `97100850${faker.datatype.number({
            min: 10000000,
            max: 99999999
        }).toString()}`;
        return {
            "firstName": firstName,
            "lastName": lastName,
            "birthday": dob,
            "phoneNumber": mobileNumber,
            "email": email,
            "personalIdentifications": {
                "nationalIdentification": {
                    "number": idNumber
                }
            },
            "cards": {
                "za": {
                    "rewards": {
                        "checkers": {
                            "clientId": "1234",
                            "context": "card",
                            "number": cardNum,
                            "status": "Active"
                        }
                    }
                }
            },
            "retailServices": {
                "xtraSavings": {
                    "za": {
                        "checkers": {
                            "memberInfo": {
                                "clientId": customerId,
                                "context": "",
                                "householdId": customerId,
                                "registrationChannel": "WEB",
                                "memberId": customerId,
                                "registrationAgent": "ussd",
                                "preferredStore": "3301",
                                "inferredStore": "3301"
                            }
                        },
                        "shoprite": {
                            "memberInfo": {
                                "clientId": customerId,
                                "context": "",
                                "householdId": customerId,
                                "registrationChannel": "WEB",
                                "memberId": customerId,
                                "registrationAgent": "ussd",
                                "preferredStore": "3301",
                                "inferredStore": "3301"
                            }
                        }
                    }
                }
            }
        };
    };

}
