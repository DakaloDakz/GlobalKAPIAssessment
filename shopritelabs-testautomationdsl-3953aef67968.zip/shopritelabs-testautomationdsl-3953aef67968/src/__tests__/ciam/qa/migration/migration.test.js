import ApiMethodUtil from "../../../__utils__/api_method_util";
import Authentication from "../../../__utils__/auth/ciam/auth.methods";
import CIAMAuth from "../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../__utils__/data_helpers";
import CIAMCustomer from "../../common/migration.data";
import {faker} from '@faker-js/faker';
import fakeSaIdGenerator from "south-african-fake-id-generator";

const {addMsg} = require("jest-html-reporters/helper");

describe('CIAM - Data Migration (/data/new/migration)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const cIAMCustomer = new CIAMCustomer();
    const ciamAuth = new CIAMAuth();
    let token = globalThis.cognitoCIAMToken;

    beforeAll(async () => {

    });

    test('check field mappings to AKAMAI', async () => {
        const newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);

        let {data} = response;
        expect(data.response[0].uuid).toBeDefined();
        expect(data.response[0].uuid).not.toBeNull();
        expect(data.response[0].commerceId).toBeDefined();
        expect(data.response[0].commerceId).not.toBeNull();
        expect(data.response[0].statusCode).toBe('200');
        expect(data.response[0].messageDescription).toBe('Created customer successfully');

        await new Promise((r) => setTimeout(r, 10000));
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response1.status).toBe(200);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.data.response.email).toBe(newCustomer.email);
        expect(response1.data.response.givenName).toBe(newCustomer.givenName);
        expect(response1.data.response.familyName).toBe(newCustomer.familyName);
        expect(response1.data.response.mobileNumber).toBe(newCustomer.mobileNumber);
        expect(response1.data.response.birthday).toBe(newCustomer.birthday);
        expect(response1.data.response.personalIdentifications.nationalIdentification.number).toBe(newCustomer.personalIdentifications.nationalIdentification.number);
        expect(response1.data.response.cards.za.rewards.shoprite.number).toBe(newCustomer.cards.za.rewards.shoprite.number);
        expect(response1.data.response.cards.za.rewards.shoprite.status).toBe(newCustomer.cards.za.rewards.shoprite.status);

        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.consents.termsOfService.consentName).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.consents.termsOfService.consentName);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted);

        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.consents.marketing.consentName).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.consents.marketing.consentName);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.consents.marketing.granted).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.consents.marketing.granted);

        expect(response1.data.response.retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName).toBe(newCustomer.retailServices.xtraSavings.za.checkers.consents.termsOfService.consentName);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.consents.termsOfService.granted).toBe(newCustomer.retailServices.xtraSavings.za.checkers.consents.termsOfService.granted);

        expect(response1.data.response.retailServices.xtraSavings.za.checkers.consents.marketing.consentName).toBe(newCustomer.retailServices.xtraSavings.za.checkers.consents.marketing.consentName);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.consents.marketing.granted).toBe(newCustomer.retailServices.xtraSavings.za.checkers.consents.marketing.granted);

        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.householdId).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.memberInfo.householdId);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.preferredStore).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.memberInfo.preferredStore);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.memberInfo.rewardServices.swipeForCover.recipientMobile).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.memberInfo.rewardServices.swipeForCover.recipientMobile);

        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.householdId).toBe(newCustomer.retailServices.xtraSavings.za.checkers.memberInfo.householdId);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.preferredStore).toBe(newCustomer.retailServices.xtraSavings.za.checkers.memberInfo.preferredStore);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.memberId).toBe(newCustomer.retailServices.xtraSavings.za.checkers.memberInfo.memberId);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.memberInfo.clientId).toBe(newCustomer.retailServices.xtraSavings.za.checkers.memberInfo.clientId);

        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.cfsNewsletter.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.cfsNewsletter.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inBaby.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inBaby.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.sfgLunchboxFund.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.sfgLunchboxFund.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.yrCBW.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.yrCBW.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.sfgAACL.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.sfgAACL.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chWorldOfCheckersNewsletter.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chWorldOfCheckersNewsletter.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.sfgFoodAndTreesForAfrica.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.sfgFoodAndTreesForAfrica.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chLiquorshop.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chLiquorshop.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inHealthAndBeauty.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inHealthAndBeauty.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inSpecialsAndPromotions.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inSpecialsAndPromotions.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chClothAndFoot.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chClothAndFoot.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chVineSociety.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chVineSociety.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chBabyAndParenting.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chBabyAndParenting.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.cfsB2B.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.cfsB2B.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inVegetarian.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inVegetarian.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chBackToSchool.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chBackToSchool.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chWhiskySociety.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chWhiskySociety.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inWine.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inWine.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inKids.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inKids.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chWorldofWhiskey.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chWorldofWhiskey.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.cfsB2C.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.cfsB2C.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inCoffee.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inCoffee.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.sfgSPCA.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.sfgSPCA.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inDog.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inDog.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inLiquor.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inLiquor.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inBraai.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inBraai.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inHealthyLiving.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inHealthyLiving.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.inCat.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.inCat.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.checkers.personalInterests.chSurvey.optIn).toBe(newCustomer.retailServices.xtraSavings.za.checkers.personalInterests.chSurvey.optIn);

        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInGroceryEssentials.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInGroceryEssentials.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInCleanhome.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInCleanhome.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srSwipeForCover.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srSwipeForCover.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInWineLovers.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInWineLovers.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.yrCBW.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.yrCBW.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInHomebar.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInHomebar.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInGreatOutdoors.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInGreatOutdoors.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srLiquorshop.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srLiquorshop.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srBaby.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srBaby.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srAutoAirtime.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srAutoAirtime.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srWine.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srWine.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srWorldOfShoprite.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srWorldOfShoprite.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInLookingGood.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInLookingGood.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srBackToSchool.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srBackToSchool.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInHealthyLiving.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInHealthyLiving.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInPartiesAndTreats.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInPartiesAndTreats.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInBraaiAndGrill.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInBraaiAndGrill.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInBabyAndKids.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInBabyAndKids.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInCat.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInCat.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srB2B.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srB2B.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srInFamilyMeals.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srInFamilyMeals.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srSfgSanitary.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srSfgSanitary.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srSurvey.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srSurvey.optIn);
        expect(response1.data.response.retailServices.xtraSavings.za.shoprite.personalInterests.srHustle.optIn).toBe(newCustomer.retailServices.xtraSavings.za.shoprite.personalInterests.srHustle.optIn);

    });

    test('empty array', async () => {
        const newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response).toHaveLength(0);
    });

    test('empty object', async () => {
        const newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [{}];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('array with 1 valid object and one empty', async () => {
        const newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer, {}];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing givenName in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'givenName');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing familyName in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'familyName');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing email in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'email');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.uuid', 'commerceId']);
        expect(data).toMatchSnapshot();
    });

    test('missing mobileNumber in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'mobileNumber');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing personalIdentifications in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'personalIdentifications');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing idNumber in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'personalIdentifications.nationalIdentification.number');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('missing retailServices in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'retailServices');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.uuid', 'commerceId']);
        expect(data).toMatchSnapshot();
    });

    test('missing cards in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'cards');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId', 'response.uuid', 'commerceId']);
        expect(data).toMatchSnapshot();
    });

    test('missing consents in Customer', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'retailServices.xtraSavings.za.shoprite.consents');
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'retailServices.xtraSavings.za.checkers.consents');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('errors in 2 different customer objects', async () => {
        let newCustomer = await cIAMCustomer.create();
        let newCustomer1 = await cIAMCustomer.create();
        let email = newCustomer.email;
        newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'givenName');
        newCustomer1 = dataHelpers.removeObjectInJson(newCustomer1, 'familyName');
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer, newCustomer1];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
        let {data} = response.data;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test('array with 30 customers', async () => {
        let body = [];
        for (let i = 0; i < 30; i++) {
            const newCustomer = await cIAMCustomer.create();
            body.push(newCustomer);
        }
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        expect(response.data.response).toHaveLength(30);
    });

    test('array with 30 customers all errors', async () => {
        let body = [];
        for (let i = 0; i < 30; i++) {
            let newCustomer = await cIAMCustomer.create();
            newCustomer = dataHelpers.removeObjectInJson(newCustomer, 'givenName');
            body.push(newCustomer);
        }
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(400);
    });

    test('update existing customer - givenName', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response[0].uuid).toBeDefined();
        expect(data.response[0].uuid).not.toBeNull();
        expect(data.response[0].commerceId).toBeDefined();
        expect(data.response[0].commerceId).not.toBeNull();
        expect(data.response[0].statusCode).toBe('200');
        expect(data.response[0].messageDescription).toBe('Created customer successfully');
        await new Promise((r) => setTimeout(r, 10000));
        newCustomer = dataHelpers.setValueInJson(newCustomer, 'givenName', 'UpdatedGivenName');
        let body1 = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body1, null, 2)});
        const response1 = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body1, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);

        expect(response1.data.response[0].uuid).toBeDefined();
        expect(response1.data.response[0].uuid).not.toBeNull();
        expect(response1.data.response[0].commerceId).toBeDefined();
        expect(response1.data.response[0].commerceId).not.toBeNull();
        expect(response1.data.response[0].statusCode).toBe('200');
        expect(response1.data.response[0].messageDescription).toBe('Customer all ready exists updated successfully');
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response2 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response2.status).toBe(200);
        await addMsg({message: JSON.stringify(response2.data, null, 2)});
        expect(response2.data.response.email).toBe(newCustomer.email);
        expect(response2.data.response.givenName).toBe('UpdatedGivenName');
    });

    test('update existing customer - familyName', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response[0].uuid).toBeDefined();
        expect(data.response[0].uuid).not.toBeNull();
        expect(data.response[0].commerceId).toBeDefined();
        expect(data.response[0].commerceId).not.toBeNull();
        expect(data.response[0].statusCode).toBe('200');
        expect(data.response[0].messageDescription).toBe('Created customer successfully');
        await new Promise((r) => setTimeout(r, 10000));
        newCustomer = dataHelpers.setValueInJson(newCustomer, 'familyName', 'UpdatedFamilyName');
        let body1 = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body1, null, 2)});
        const response1 = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body1, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);

        expect(response1.data.response[0].uuid).toBeDefined();
        expect(response1.data.response[0].uuid).not.toBeNull();
        expect(response1.data.response[0].commerceId).toBeDefined();
        expect(response1.data.response[0].commerceId).not.toBeNull();
        expect(response1.data.response[0].statusCode).toBe('200');
        expect(response1.data.response[0].messageDescription).toBe('Customer all ready exists updated successfully');
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response2 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response2.status).toBe(200);
        await addMsg({message: JSON.stringify(response2.data, null, 2)});
        expect(response2.data.response.email).toBe(newCustomer.email);
        expect(response2.data.response.familyName).toBe('UpdatedFamilyName');
    });

    test('update existing customer - cardNumber', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response[0].uuid).toBeDefined();
        expect(data.response[0].uuid).not.toBeNull();
        expect(data.response[0].commerceId).toBeDefined();
        expect(data.response[0].commerceId).not.toBeNull();
        expect(data.response[0].statusCode).toBe('200');
        expect(data.response[0].messageDescription).toBe('Created customer successfully');

        newCustomer = dataHelpers.setValueInJson(newCustomer, 'cards.za.rewards.checkers.number', '9710085084658788');
        newCustomer = dataHelpers.setValueInJson(newCustomer, 'cards.za.rewards.checkers.status', 'active');
        let body1 = [newCustomer];
        await new Promise((r) => setTimeout(r, 10000));
        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body1, null, 2)});
        const response1 = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body1, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);

        expect(response1.data.response[0].uuid).toBeDefined();
        expect(response1.data.response[0].uuid).not.toBeNull();
        expect(response1.data.response[0].commerceId).toBeDefined();
        expect(response1.data.response[0].commerceId).not.toBeNull();
        expect(response1.data.response[0].statusCode).toBe('200');
        expect(response1.data.response[0].messageDescription).toBe('Customer all ready exists updated successfully');
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response2 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response2.status).toBe(200);
        await addMsg({message: JSON.stringify(response2.data, null, 2)});
        expect(response2.data.response.email).toBe(newCustomer.email);
        expect(response2.data.response.cards.za.rewards.checkers.number).toBe('9710085084658788');
        expect(response2.data.response.cards.za.rewards.checkers.status).toBe('active');
    });

    test('update existing customer - MobileNumber', async () => {
        let newCustomer = await cIAMCustomer.create();
        let email = newCustomer.email;
        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response[0].uuid).toBeDefined();
        expect(data.response[0].uuid).not.toBeNull();
        expect(data.response[0].commerceId).toBeDefined();
        expect(data.response[0].commerceId).not.toBeNull();
        expect(data.response[0].statusCode).toBe('200');
        expect(data.response[0].messageDescription).toBe('Created customer successfully');
        let mobileNumber = dataHelpers.generatePhoneNumber(true);
        newCustomer = dataHelpers.setValueInJson(newCustomer, 'mobileNumber', mobileNumber);
        let body1 = [newCustomer];
        await new Promise((r) => setTimeout(r, 10000));
        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body1, null, 2)});
        const response1 = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body1, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);

        expect(response1.data.response[0].uuid).toBeDefined();
        expect(response1.data.response[0].uuid).not.toBeNull();
        expect(response1.data.response[0].commerceId).toBeDefined();
        expect(response1.data.response[0].commerceId).not.toBeNull();
        expect(response1.data.response[0].statusCode).toBe('200');
        expect(response1.data.response[0].messageDescription).toBe('Customer all ready exists updated successfully');
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response2 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response2.status).toBe(200);
        await addMsg({message: JSON.stringify(response2.data, null, 2)});
        expect(response2.data.response.email).toBe(newCustomer.email);
        expect(response2.data.response.mobileNumber).toBe(mobileNumber);
    });

    test('update existing customer - Email', async () => {
        let newCustomer = await cIAMCustomer.create();

        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response[0].uuid).toBeDefined();
        expect(data.response[0].uuid).not.toBeNull();
        expect(data.response[0].commerceId).toBeDefined();
        expect(data.response[0].commerceId).not.toBeNull();
        expect(data.response[0].statusCode).toBe('200');
        expect(data.response[0].messageDescription).toBe('Created customer successfully');
        let newEmail = `${faker.internet.userName()}@shoprite-testautomation.com`;
        newCustomer = dataHelpers.setValueInJson(newCustomer, 'email', newEmail);
        let body1 = [newCustomer];
        let email = newCustomer.email;
        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body1, null, 2)});

        await new Promise((r) => setTimeout(r, 10000));
        const response1 = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body1, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);

        expect(response1.data.response[0].uuid).toBeDefined();
        expect(response1.data.response[0].uuid).not.toBeNull();
        expect(response1.data.response[0].commerceId).toBeDefined();
        expect(response1.data.response[0].commerceId).not.toBeNull();
        expect(response1.data.response[0].statusCode).toBe('200');
        expect(response1.data.response[0].messageDescription).toBe('Customer all ready exists updated successfully');
        await new Promise((r) => setTimeout(r, 10000));
        let token = await ciamAuth.ciam_trusted_auth(process.env.CIAM, email, 'dsl');
        const headersCiam = {
            'accessToken': `${token.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response2 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        expect(response2.status).toBe(200);
        await addMsg({message: JSON.stringify(response2.data, null, 2)});
        expect(response2.data.response.email).toBe(newEmail);
    });

    test('update existing customer - IdNumber', async () => {
        let newCustomer = await cIAMCustomer.create();

        const headers = {
            'x-api-key': process.env.CIAMMigrationApiKey
        };
        let body = [newCustomer];

        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        expect(data.response[0].commerceId).toBeDefined();
        expect(data.response[0].commerceId).not.toBeNull();
        expect(data.response[0].statusCode).toBe('200');
        expect(data.response[0].messageDescription).toBe('Created customer successfully');
        let idNumber = `ZA-${fakeSaIdGenerator.generateFakeIdByAge(faker.datatype.number({
            min: 18,
            max: 99
        }))}`;
        newCustomer = dataHelpers.setValueInJson(newCustomer, 'personalIdentifications.nationalIdentification.number', idNumber);
        await new Promise((r) => setTimeout(r, 10000));
        let body1 = [newCustomer];
        await addMsg({message: `${process.env.CIAM}/data/new/migration`});
        await addMsg({message: JSON.stringify(body1, null, 2)});
        const response1 = await apiCall.POST(`${process.env.CIAM}/data/new/migration`, body1, headers);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response[0].statusCode).toBe('361');
    });
});
