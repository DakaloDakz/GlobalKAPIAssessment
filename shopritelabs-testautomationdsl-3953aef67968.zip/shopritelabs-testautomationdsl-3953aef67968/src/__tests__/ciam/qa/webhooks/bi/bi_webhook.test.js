import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import _ from "lodash";
import DataHelpers from "../../../../__utils__/data_helpers";
import {decode} from '../../../../__utils__/encryption.util';
import moment from "moment";

const ftp = require('basic-ftp');
const {addMsg} = require("jest-html-reporters/helper");
// jest.retryTimes(3)
describe('CIAM - BI Webhook', () => {
    const ciamAuth = new CIAMAuth();
    const ftpClient = new ftp.Client();
    const dataHelpers = new DataHelpers();
    let access;
    let credentials = decode(process.env.S3FTP);
    let username = credentials.split(':')[0];
    let password = credentials.split(':')[1];

    beforeAll(async () => {
        access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, '+27726773388', 'dsl');
    });

    test('get CIAM Customer Information', async () => {
        let filesOrdered;
        let configFTP = {
            host: 'qa-ire-integration-all.shoprite.co.za',
            port: '21',
            user: username,
            password: password,
            secure: true,
            secureOptions: {
                rejectUnauthorized: false
            }
        };
        try {
            let conn = await ftpClient.access(configFTP);
            let files = await ftpClient.list('/inbound/sap-commerce/pricingandpromotion');
            console.log(files);
            filesOrdered = _.orderBy(files, [(item) => {
                return moment(item.modifiedAt).format('YYYYMMDDhhmmss');
            }], ['desc']);
            expect(filesOrdered[0].name).toContain(`.json`);
        } catch (e) {
            console.error(e.message);
        } finally {
            await ftpClient.close();
        }
    });
});
