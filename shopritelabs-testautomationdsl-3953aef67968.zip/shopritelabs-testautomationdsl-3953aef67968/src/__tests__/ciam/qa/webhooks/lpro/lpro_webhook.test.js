import ApiMethodUtil from "../../../../__utils__/api_method_util";
import Authentication from "../../../../__utils__/auth/ciam/auth.methods";
import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../../__utils__/data_helpers";

import LproPayloads from "../../../../__utils__/auth/ciam/payloads/lpro.payloads";
import {encode} from "../../../../__utils__/encryption.util";
import 'jest-matcher-one-of';

import DSLCustomer from "../../../../dsl/data/customer.data";

const {addMsg} = require("jest-html-reporters/helper");

jest.retryTimes(1);
describe('CIAM - LPRO Webhook', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const lproPayloads = new LproPayloads();
    const dSLCustomer = new DSLCustomer();
    const ciamAuth = new CIAMAuth();
    let sessionKey;
    let credentials;
    let firstName;
    let lastName;
    let dob;
    let mobileNumber;
    let cardNumber;
    let customer;

    beforeAll(async () => {
        let occAuthUserName = process.env.LPROClientID;
        let occAuthPassword = process.env.LPROClientSecret;
        credentials = encode(`${occAuthUserName}:${occAuthPassword}`);
        let payload = await lproPayloads.loginPayload();
        sessionKey = await auth.lpro_session_key_auth(payload, 'qa');
    });

    test('get LPRO Customer Information - New', async () => {
        const json = await dSLCustomer.create_customer_valid_partial('checkers', true);
        await addMsg({message: `${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`});
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headerDSL = {
            Authorization: `Bearer ${cognitoDSLToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        firstName = json.userDetails.firstName;
        lastName = json.userDetails.lastName;
        dob = json.userDetails.birthDate.split('/').reverse().join('-');
        mobileNumber = json.contactDetails[0].value;
        cardNumber = json.foxCard.cardNumber;
        const respDSL = await apiCall.POST(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users/partialuser`, json, headerDSL);
        await addMsg({message: JSON.stringify(respDSL.data, null, 2)});
        expect(respDSL.status).toBe(200);
        expect(respDSL.data.response.uuid).not.toBeNull();
        customer = respDSL.data.response.uuid;
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(customer);
        let headers = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response = await apiCall.POST(url, body, headers);
        await addMsg({message: dataHelpers.prettifyXML(response.data)});
        let responseJson = dataHelpers.xml2json(response.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let xml = responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0];
        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];
        let lpro_dob = resp['HouseHold']['Members'][0]['Member'][0]['$']['BirthDate'];
        let lpro_card = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][0]['$']['Id'];
        let lpro_card_status = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][0]['$']['CardStatus'];
        let lpro_uuid = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][1]['$']['Id'];
        let lpro_mobileNumber = resp['HouseHold']['Members'][0]['Member'][0]['$']['MobilePhoneNumber'];
        await addMsg({message: dataHelpers.prettifyXML(xml)});
        expect(lpro_firstName).toEqual(firstName);
        expect(lpro_lastName).toEqual(lastName);
        expect(lpro_dob).toEqual(dob);
        expect(lpro_card).toBeOneOf([cardNumber, customer]);
        expect(lpro_card_status).toBe("1");
        expect(lpro_uuid).toBeOneOf([cardNumber, customer]);
        expect(lpro_mobileNumber).toBe('');
    });

    test('update firstName and check LPRO Customer Information', async () => {
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        let new_FirstName = firstName + "updated";
        const json = {
            "firstName": new_FirstName,
            "lastName": lastName,
            "mobileNumber": mobileNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersDSL = {
            'access_token': `${access.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseDSL = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headersDSL);
        await addMsg({message: JSON.stringify(responseDSL.data, null, 2)});
        expect(responseDSL.status).toBe(200);
        expect(responseDSL.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(customer);
        let headers = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response = await apiCall.POST(url, body, headers);
        let responseJson = dataHelpers.xml2json(response.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let xml = responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0];
        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];
        let lpro_dob = resp['HouseHold']['Members'][0]['Member'][0]['$']['BirthDate'];
        let lpro_card = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][0]['$']['Id'];
        let lpro_card_status = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][0]['$']['CardStatus'];
        let lpro_uuid = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][1]['$']['Id'];
        let lpro_mobileNumber = resp['HouseHold']['Members'][0]['Member'][0]['$']['MobilePhoneNumber'];
        await addMsg({message: dataHelpers.prettifyXML(xml)});
        expect(lpro_firstName).toEqual(new_FirstName);
        expect(lpro_lastName).toEqual(lastName);
        expect(lpro_dob).toEqual(dob);
        expect(lpro_card).toBeOneOf([cardNumber, customer]);
        expect(lpro_card_status).toBe("1");
        expect(lpro_uuid).toBeOneOf([cardNumber, customer]);
        expect(lpro_mobileNumber).toBe('');
    });

    test('update lastName and check LPRO Customer Information', async () => {
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        let new_FirstName = firstName + "updated";
        let new_LastName = lastName + "updated";
        const json = {
            "firstName": new_FirstName,
            "lastName": new_LastName,
            "mobileNumber": mobileNumber
        };
        await addMsg({message: JSON.stringify(json, null, 2)});
        const headersDSL = {
            'access_token': `${access.data.response.accessToken}`,
            'x-api-key': process.env.DSLCIAMApiKey,
            'Content-Type': 'application/json'
        };
        const responseDSL = await apiCall.PATCH(`${process.env.DSLGroup}/dsl/brands/checkers/countries/za/users`, json, headersDSL);
        await addMsg({message: JSON.stringify(responseDSL.data, null, 2)});
        expect(responseDSL.status).toBe(200);
        expect(responseDSL.data.response.uuid).not.toBeNull();
        await new Promise((r) => setTimeout(r, 30000));
        let url = `${process.env.LPRO}/member/service?sk=${sessionKey}`;
        let body = await lproPayloads.getDemographic(customer);
        let headers = {
            "Content-Type": "text/xml",
            "Authorization": "Basic " + credentials,
            "ContractID": process.env.LPROContractID,
            "UIUser": "ncrlpro_login"
        };

        let response = await apiCall.POST(url, body, headers);
        let responseJson = dataHelpers.xml2json(response.data);
        let resp = dataHelpers.xml2json(responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0]);
        let xml = responseJson['soap:Envelope']['soap:Body'][0]['GetDemographicResponse'][0]['out_HouseHold'][0];
        let lpro_firstName = resp['HouseHold']['Members'][0]['Member'][0]['$']['FirstName'];
        let lpro_lastName = resp['HouseHold']['Members'][0]['Member'][0]['$']['LastName'];
        let lpro_dob = resp['HouseHold']['Members'][0]['Member'][0]['$']['BirthDate'];
        let lpro_card = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][0]['$']['Id'];
        let lpro_card_status = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][0]['$']['CardStatus'];
        let lpro_uuid = resp['HouseHold']['Members'][0]['Member'][0]['Cards'][0]['Card'][1]['$']['Id'];
        let lpro_mobileNumber = resp['HouseHold']['Members'][0]['Member'][0]['$']['MobilePhoneNumber'];
        await addMsg({message: dataHelpers.prettifyXML(xml)});
        expect(lpro_firstName).toEqual(new_FirstName);
        expect(lpro_lastName).toEqual(new_LastName);
        expect(lpro_dob).toEqual(dob);
        expect(lpro_card).toBeOneOf([cardNumber, customer]);
        expect(lpro_card_status).toBe("1");
        expect(lpro_uuid).toBeOneOf([cardNumber, customer]);
        expect(lpro_mobileNumber).toBe('');
    });
});
