import ApiMethodUtil from "../../../../__utils__/api_method_util";
import DataHelpers from '../../../../__utils__/data_helpers';
import {addMsg} from "jest-html-reporters/helper";
import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import Authentication from "../../../../__utils__/auth/commerce/auth.methods";

jest.retryTimes(1);
describe('CIAM - Commerce Webhook)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const dataHelpers = new DataHelpers();
    const ciamAuth = new CIAMAuth();
    let token;

    beforeAll(async () => {
        token = await auth.commerceAuth(process.env.CommerceUrl);
        console.log(token);
    });

    test('Get commerce users', async () => {
        let userId = "larilityane@mail.com";
        const headers = {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
        };
        await addMsg({message: `${process.env.CommerceUrl}/shopritewebservices/v2/checkersZA/users/${userId}`});
        const response = await apiCall.GET(`${process.env.CommerceUrl}/shopritewebservices/v2/checkersZA/users/${userId}`, headers, null);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
// let {data} = response;
// data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
    });
});
