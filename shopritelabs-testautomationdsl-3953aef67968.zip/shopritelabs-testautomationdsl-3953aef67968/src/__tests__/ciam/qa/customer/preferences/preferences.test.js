import ApiMethodUtil from "../../../../__utils__/api_method_util";
import Authentication from "../../../../__utils__/auth/ciam/auth.methods";
import CIAMAuth from "../../../../__utils__/auth/ciam/auth.methods";
import DataHelpers from "../../../../__utils__/data_helpers";
import CiamCustomerPreferences from "../../data/preferences.data";
import _ from "lodash";
import CreateCIAMCustomer from "../../../common/create_customer";

const {addMsg} = require("jest-html-reporters/helper");
const testData = require("../../data/json/sixty60Preferences.json");

jest.retryTimes(1);

describe('CIAM - Preferences (/ciam/brands/checkers/countries/za/users/$customerId/preferences)', () => {
    const apiCall = new ApiMethodUtil();
    const auth = new Authentication();
    const ciamAuth = new CIAMAuth();
    const dataHelpers = new DataHelpers();
    const preferences = new CiamCustomerPreferences();
    const customer = new CreateCIAMCustomer();
    let uuid;
    let mobileNumber;

    beforeAll(async () => {
        let newCustomer = await customer.createValidCIAMCustomerMinimal();
        await new Promise((r) => setTimeout(r, 10000));
        uuid = newCustomer.uuid;
        mobileNumber = newCustomer.mobileNumber;
    });

    test('add Sixty60 preferences', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await preferences.createPreferencesPayload('Sixty60', 'SMS', '+27833965802', true);
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.sms.addressValue).toBe('+27833965802');
    });

    test('add Sixty60 preferences - PUSH', async () => {
        let newCustomer = await customer.createValidCIAMCustomerMinimal();
        uuid = newCustomer.uuid;
        mobileNumber = newCustomer.mobileNumber;
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await preferences.createPreferencesPayload('Sixty60', 'PUSH', '+27833965802', true);
        await addMsg({message: `${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.mobileApp.addressValue).toBe('+27833965802');
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.mobileApp.granted).toBe(true);
    });

    test('add multiple Sixty60 preferences', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await preferences.createMultiplePreferencesPayload('Sixty60', 'SMS', '+27833965802', true,
            'Sixty60', 'EMAIL', 'testautomation@auto.com', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.sms.addressValue).toBe('+27833965802');
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.email.addressValue).toBe('testautomation@auto.com');
    });

    test('add multiple preferences ByteOrbit', async () => {
        const headers = {
            'x-api-key': process.env.byteOrbitCiamApiKey
        };
        let body = await preferences.createMultiplePreferencesPayload('Sixty60', 'SMS', '+27833965802', true,
            'Sixty60', 'EMAIL', 'testautomation@auto.com', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
        let access = await ciamAuth.ciam_trusted_auth(process.env.CIAM, mobileNumber, 'dsl');
        const headersCiam = {
            'accessToken': `${access.data.response.accessToken}`,
            'x-api-key': process.env.CIAMDSLApiKey,
            'Content-Type': 'application/json'
        };
        const response1 = await apiCall.GET(`${process.env.CIAM}/ciam/user`, headersCiam, null);
        await addMsg({message: JSON.stringify(response1.data, null, 2)});
        expect(response1.status).toBe(200);
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.sms.addressValue).toBe('+27833965802');
        expect(response1.data.response.retailServices.sixty60.za.checkers.contactPreferences.email.addressValue).toBe('testautomation@auto.com');
    });

    test('add multiple MoneyMarketAccount preferences', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = await preferences.createMultiplePreferencesPayload('MoneyMarketAccount', 'SMS', '+27833965802', true,
            'MoneyMarketAccount', 'EMAIL', 'testautomation@auto.com', true
        );
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        await addMsg({message: JSON.stringify(response.data, null, 2)});
        expect(response.status).toBe(200);
        let {data} = response;
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });

    test.each(testData)(`$scenario`, async (testCase) => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey,
            'ContentType': 'application/json'
        };
        let body = await preferences.createPreferencesPayload(testCase.retailService, testCase.contactPreferenceRole, testCase.addressValue, testCase.granted);

        if (!_.isEmpty(testCase.missingFields)) {
            body = dataHelpers.removeObjectInJson(body, testCase.missingFields);
        }
        await addMsg({message: `${process.env.CIAM}${testCase.resource}${testCase.parameter}`});
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}${testCase.resource}${testCase.parameter}`, body, headers);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(response.status).toEqual(testCase.expected);
        expect(data).toMatchSnapshot();
    });

    test('add empty object', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {};
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        expect(response.status).toBe(200);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        expect(data.errorMessage).toContain('Cannot construct instance of `java.util.ArrayList`');
    });

    test('add empty contactPreferences object', async () => {
        const headers = {
            'x-api-key': process.env.CIAMSixty60ApiKey
        };
        let body = {
            "contactPreferences": []
        };
        await addMsg({message: JSON.stringify(body, null, 2)});
        const response = await apiCall.POST(`${process.env.CIAM}/ciam/brands/checkers/countries/za/users/${uuid}/preferences`, body, headers);
        expect(response.status).toBe(400);
        let {data} = response;
        await addMsg({message: JSON.stringify(data, null, 2)});
        data = dataHelpers.sanitize(data, ['serverTime', 'requestId']);
        expect(data).toMatchSnapshot();
    });
});
