import AkamaiGetEntity from "../__utils__/cards/akamai.get.entity";
import DataHelpers from "../__utils__/data_helpers";

const akamaiGetEntity = new AkamaiGetEntity();
const dataHelpers = new DataHelpers();
describe('DSL - Get customers from Akamai', () => {

    test('testing', async () => {
        // let filterIdNumber = encodeURIComponent(`retailServices.xtraSavings.za.shoprite.consents.termsOfService.granted='true' and cards.za.rewards.shoprite.number is not null and cards.za.rewards.shoprite.status='Active' and retailServices.xtraSavings.za.shoprite.contactPreferences.sms.granted is not null and retailServices.xtraSavings.za.shoprite.memberInfo.memberId is not null and created < '2024-01-10'`);
        let filterIdNumber = encodeURIComponent(` retailServices.xtraSavings.za.checkers.consents.termsOfService.granted='true' and cards.za.rewards.checkers.status='Active' and retailServices.xtraSavings.za.checkers.memberInfo.memberId is not null and personalIdentifications.nationalIdentification.number is not null and created < '2023-01-10'`);
        let akamaiCustomersWithIdNumber = await akamaiGetEntity.akamaiFindCustomerUsingFilter(filterIdNumber);
        console.log(akamaiCustomersWithIdNumber.results.length);

        for (let i = 20; i <= 30; i++) {
            const akamaiCustomerWithIdNumberElement = akamaiCustomersWithIdNumber.results[i];
            console.log(akamaiCustomerWithIdNumberElement.uuid + ", " + akamaiCustomerWithIdNumberElement.retailServices.xtraSavings.za.checkers.memberInfo.memberId + ", " + akamaiCustomerWithIdNumberElement.email + ", " + akamaiCustomerWithIdNumberElement.personalIdentifications.nationalIdentification.number);
        }
        expect(akamaiCustomersWithIdNumber.results.length).toBeGreaterThan(0);
    });

    test('testing2', async () => {
        console.log(parseInt(dataHelpers.generateRandomNumber(0, 0, 100)));
        console.log(parseInt(dataHelpers.generateRandomNumber(1, 0, 100)));
        console.log(parseInt(dataHelpers.generateRandomNumber(2, 0, 100)));
        console.log(parseInt(dataHelpers.generateRandomNumber(3, 0, 100)));
        console.log(parseInt(dataHelpers.generateRandomNumber(3, 0, 1000)));
        console.log(parseInt(dataHelpers.generateRandomNumber(3, 30, 90)));
    });
});
