#!/bin/bash

SYSTEM=$1
ENVIRONMENT=$2
METABASE=$3
BUILD_ID=$4
DD_ENV=$5
DD_SERVICE=$6
DD_CIVISIBILITY_AGENTLESS_ENABLED=$7
DD_API_KEY=$8
DD_SITE=$9

if [ "${SYSTEM^^}" == "DSL" ] && [ "${ENVIRONMENT^^}" == "QA" ]; then
  npm run test:dsl:qa -- --publish=true --metabase="${METABASE,,}" --buildId="${BUILD_ID}"
fi
if [ "${SYSTEM^^}" == "DSL" ] && [ "${ENVIRONMENT^^}" == "PREP" ]; then
  npm run test:dsl:prep -- --publish=true --metabase="${METABASE,,}" --buildId="${BUILD_ID}"
fi
if [ "${SYSTEM^^}" == "DSL" ] && [ "${ENVIRONMENT^^}" == "PROD" ]; then
  npm run test:dsl:prod -- --publish=true --buildId="${BUILD_ID}"
fi
